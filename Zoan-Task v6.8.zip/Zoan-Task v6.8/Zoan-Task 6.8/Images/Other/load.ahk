#Requires AutoHotkey v2.0
; Script:    ImagePut.ahk
; License:   MIT License
; Author:    Edison Hua (iseahound)
; Github:    https://github.com/iseahound/ImagePut
; Date:      2023-03-02
; Version:   1.10


; Puts the image into a file format and returns a base64 encoded string.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutBase64(image, extension := "", quality := "") {
   return ImagePut("Base64", image, extension, quality)
}

; Puts the image into a GDI+ Bitmap and returns a pointer.
ImagePutBitmap(image) {
   return ImagePut("Bitmap", image)
}

; Puts the image into a GDI+ Bitmap and returns a buffer object with GDI+ scope.
ImagePutBuffer(image) {
   return ImagePut("Buffer", image)
}

; Puts the image onto the clipboard and returns ClipboardAll().
ImagePutClipboard(image) {
   return ImagePut("Clipboard", image)
}

; Puts the image as the cursor and returns the variable A_Cursor.
;   xHotspot   -  X Click Point           |  pixel    ->   0 - width
;   yHotspot   -  Y Click Point           |  pixel    ->   0 - height
ImagePutCursor(image, xHotspot := "", yHotspot := "") {
   return ImagePut("Cursor", image, xHotspot, yHotspot)
}

; Puts the image onto a device context and returns the handle.
;   alpha      -  Alpha Replacement Color |  RGB      ->   0xFFFFFF
ImagePutDC(image, alpha := "") {
   return ImagePut("DC", image, alpha)
}

; Puts the image behind the desktop icons and returns the string "desktop".
;   See ImageShow for parameter descriptions.
ImagePutDesktop(image, title := "", pos := "", style := 0x50000000, styleEx := 0x80000, parent := "", playback := True, cache := False) {
   return ImagePut("Desktop", image, title, pos, style, styleEx, parent, playback, cache)
}

; Puts the image as an encoded format into a binary data object.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutEncodedBuffer(image, extension := "", quality := "") {
   return ImagePut("EncodedBuffer", image, extension, quality)
}

; Puts the image into the currently active explorer window.
;   default_dir -  Default Directory       |  string   ->   C:\Users\Me\Pictures
;   background  -  Find Inactive Windows?  |  bool     ->   False
ImagePutExplorer(image, default_dir := "", background_window := False) {
   return ImagePut("Explorer", image, default_dir, background_window)
}

; Puts the image into a file and returns its filepath.
;   filepath   -  Filepath + Extension    |  string   ->   *.bmp, *.gif, *.jpg, *.png, *.tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutFile(image, filepath := "", quality := "") {
   return ImagePut("File", image, filepath, quality)
}

; Puts the image into a multipart/form-data in binary and returns a SafeArray COM Object.
;   boundary   -  Content-Type            |  string   ->   multipart/form-data; boundary=something
ImagePutFormData(image, boundary := "--ImagePut abc 321 xyz--") {
   return ImagePut("FormData", image, boundary)
}

; Puts the image into a device independent bitmap and returns the handle.
;   alpha      -  Alpha Replacement Color |  RGB      ->   0xFFFFFF
ImagePutHBitmap(image, alpha := "") {
   return ImagePut("HBitmap", image, alpha)
}

; Puts the image into a file format and returns a hexadecimal encoded string.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutHex(image, extension := "", quality := "") {
   return ImagePut("Hex", image, extension, quality)
}

; Puts the image into an icon and returns the handle.
ImagePutHIcon(image) {
   return ImagePut("HIcon", image)
}

; Puts the image into a file format and returns a pointer to a RandomAccessStream.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutRandomAccessStream(image, extension := "", quality := "") {
   return ImagePut("RandomAccessStream", image, extension, quality)
}

; Puts the image into a file format and returns a SafeArray COM Object.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutSafeArray(image, extension := "", quality := "") {
   return ImagePut("SafeArray", image, extension, quality)
}

; Puts the image on the shared screen device context and returns an array of coordinates.
;   screenshot -  Screen Coordinates      |  array    ->   [x,y,w,h] or [0,0]
;   alpha      -  Alpha Replacement Color |  RGB      ->   0xFFFFFF
ImagePutScreenshot(image, screenshot := "", alpha := "") {
   return ImagePut("Screenshot", image, screenshot, alpha)
}

; Puts the image into a file mapping and returns a buffer object sharable across processes.
;   name       -  Global Name             |  string   ->   "SharedBuffer"
ImagePutSharedBuffer(image, name := "") {
   return ImagePut("SharedBuffer", image, name)
}

; Puts the image into a file format and returns a pointer to a stream.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutStream(image, extension := "", quality := "") {
   return ImagePut("Stream", image, extension, quality)
}

; Puts the image into a base64 string and returns a Uniform Resource Identifier.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutURI(image, extension := "", quality := "") {
   return ImagePut("URI", image, extension, quality)
}

; Uploads the image onto Imgur and returns the URL hyperlink.
;   extension  -  File Encoding           |  string   ->   bmp, gif, jpg, png, tiff
;   quality    -  JPEG Quality Level      |  integer  ->   0 - 100
ImagePutURL(image, extension := "", quality := "") {
   return ImagePut("URL", image, extension, quality)
}

; Puts the image as the desktop wallpaper and returns the string "wallpaper".
ImagePutWallpaper(image) {
   return ImagePut("Wallpaper", image)
}

; Puts the image into a WICBitmap and returns the pointer to the interface.
ImagePutWICBitmap(image) {
   return ImagePut("WICBitmap", image)
}

; Puts the image in a window (with a border) and returns a handle to a window.
;   See ImageShow for parameter descriptions.
ImagePutWindow(image, title := "", pos := "", style := 0x82C80000, styleEx := 0x9, parent := "", playback := True, cache := False) {
   return ImagePut("Window", image, title, pos, style, styleEx, parent, playback, cache)
}

; Shows the image in a window (without a border) and returns a handle to a window.
;   title      -  Window Title            |  string   ->   MyTitle
;   pos        -  Window Coordinates      |  array    ->   [x,y,w,h] or [0,0]
;   style      -  Window Style            |  uint     ->   WS_VISIBLE
;   styleEx    -  Window Extended Style   |  uint     ->   WS_EX_LAYERED
;   parent     -  Window Parent           |  ptr      ->   hwnd
;   playback   -  Animate Window?         |  bool     ->   True
;   cache      -  Cache Animation Frames? |  bool     ->   False
ImageShow(image, title := "", pos := "", style := 0x90000000, styleEx := 0x80088, parent := "", playback := True, cache := False) {
   return ImagePut("Show", image, title, pos, style, styleEx, parent, playback, cache)
}

ImageDestroy(image) {
   return ImagePut.Destroy(image)
}

ImageWidth(image) {
   return ImagePut.Dimensions(image)[1]
}

ImageHeight(image) {
   return ImagePut.Dimensions(image)[2]
}
/*
ImagePut(cotype, image, p*) {
   return ImagePut.call(cotype, image, p*)
}

ImageEqual(images*) {
   return ImageEqual.call(images*)
}
*/

class ImagePut {

   static decode := False    ; Decompresses image to a pixel buffer. Any encoding such as JPG will be lost.
   static render := True     ; Determines whether vectorized formats such as SVG and PDF are rendered to pixels.
   static validate := False  ; Always copies pixels to new memory immediately instead of copy-on-read/write.

   static call(cotype, image, p*) {
      this.gdiplusStartup()                      ; Start!
      coimage := this.convert(cotype, image, p*) ; Convert!
      this.gdiplusShutdown(cotype)               ; Check if GDI+ is still needed.
      return coimage
   }

   static convert(cotype, image, p*) {
      ; Take a guess as to what the image might be. (>95% accuracy!)
      try type := this.DontVerifyImageType(&image, &keywords)
      catch
         type := this.ImageType(image)

      ; Extract options to be directly applied the intermediate representation here.
      crop      := keywords.HasProp("crop")      ? keywords.crop      : ""
      scale     := keywords.HasProp("scale")     ? keywords.scale     : ""
      upscale   := keywords.HasProp("upscale")   ? keywords.upscale   : ""
      downscale := keywords.HasProp("downscale") ? keywords.downscale : ""
      minsize   := keywords.HasProp("minsize")   ? keywords.minsize   : ""
      maxsize   := keywords.HasProp("maxsize")   ? keywords.maxsize   : ""
      sprite    := keywords.HasProp("sprite")    ? keywords.sprite    : ""
      decode    := keywords.HasProp("decode")    ? keywords.decode    : this.decode
      render    := keywords.HasProp("render")    ? keywords.render    : this.render
      validate  := keywords.HasProp("validate")  ? keywords.validate  : this.validate
      width     := keywords.HasProp("width") && keywords.width ~= "^(?!0+$)\d+$" ? keywords.width : ""
      height    := keywords.HasProp("height") && keywords.height ~= "^(?!0+$)\d+$" ? keywords.height : ""

      ; Keywords are for (image -> intermediate).
      try index := keywords.index

      weight := crop || scale || upscale || downscale || minsize || maxsize || sprite || decode
      cleanup := ""
      if (weight)
         goto make_bitmap

      ; #0 - Special cases.
      if (type = "SharedBuffer" && cotype = "SharedBuffer")
         return this.SharedBufferToSharedBuffer(image)

      if (type = "Monitor" && cotype = "Buffer")
         return this.MonitorToBuffer(image)

      if (type = "Screenshot" && cotype = "Buffer")
         return this.ScreenshotToBuffer(image)

      ; #1 - Stream as the intermediate representation.
      try stream := this.ImageToStream(type, image, keywords)
      catch Error as e
         if (e.Message ~= "^Conversion from")
            goto make_bitmap
         else throw
      if not stream
         throw Error("Stream cannot be zero.")

      ; Check the file signature for magic numbers.
      stream:
      (ComCall(Seek := 5, stream, "uint64", 0, "uint", 1, "uint64*", &current:=0), current != 0 && MsgBox(current))
      extension := this.GetExtensionFromStream(stream)

      ; Convert vectorized formats to rasterized formats.
      if (render && extension ~= "^(?i:pdf|svg)$") {
         (extension = "pdf") && this.RenderPDF(&stream, index?)
         (extension = "svg") && pBitmap := this.RenderSVG(&stream, width, height)
         goto( IsSet(pBitmap) ? "bitmap" : "stream" )
      }

      ; To determine whether the stream should be decoded into pixels:
      ; (1) Check for scaling or cropping, etc.
      ; (2) Check if the source encoding is different from the destination.
      weight |=

         ; The 1st parameter holds the destination encoding.
         !( cotype ~= "^(?i:safearray|encodedbuffer|hex|base64|uri|stream|randomaccessstream|)$"
            && (!p.Has(1) || p[1] == "" || p[1] = extension                    && !(extension = "jpg" && p.Has(2) && p[2] != ""))

         ; The 2nd parameter holds the destination encoding.
         || cotype = "formdata"
            && (!p.Has(2) || p[2] == "" || p[2] = extension                    && !(extension = "jpg" && p.Has(3) && p[3] != ""))

         ; Filepaths have the destination encoding as part of the filepath.
         || cotype = "file"
            && (!p.Has(1) || p[1] == "" || p[1] ~= "(^|:|\\|\.)" extension "$" && !(extension = "jpg" && p.Has(2) && p[2] != "")

               ; If the desired extension is not supported, it is ignored.
               || !(RegExReplace(p[1], "^.*(?:^|:|\\|\.)(.*)$", "$1")
               ~= "^(?i:avif|avifs|bmp|dib|rle|gif|heic|heif|hif|jpg|jpeg|jpe|jfif|png|tif|tiff)$"))

         ; Pass through all functions that don't specify an extension.
         || cotype ~= "^(?i:clipboard|url|explorer)")

         ; MsgBox weight ? "convert to pixels" : "stay as stream"

      if weight
         goto clean_stream

      ; Attempt conversion using StreamToCoimage.
      try coimage := this.StreamToCoimage(cotype, stream, p*)
      catch Error as e
         if (e.Message ~= "^Conversion from")
            goto clean_stream
         else throw

      ; Clean up the copy. Export raw pointers if requested.
      if (cotype != "stream")
         ObjRelease(stream)

      return coimage

      ; Otherwise export the image as a stream.
      clean_stream:
      type := "stream"
      image := stream
      cleanup := "stream"

      ; #2 - Fallback to GDI+ bitmap as the intermediate.
      make_bitmap:
      if !(pBitmap := this.ImageToBitmap(type, image, keywords))
         throw Error("pBitmap cannot be zero.")

      ; GdipImageForceValidation must be called immediately or it fails silently.
      bitmap:
      (validate) && DllCall("gdiplus\GdipImageForceValidation", "ptr", pBitmap)
      (crop) && this.BitmapCrop(&pBitmap, crop)
      (scale) && this.BitmapScale(&pBitmap, scale)
      (upscale) && this.BitmapScale(&pBitmap, upscale, 1)
      (downscale) && this.BitmapScale(&pBitmap, downscale, -1)
      (minsize) && this.BitmapScale(&pBitmap, minsize, 1, "join", True)
      (maxsize) && this.BitmapScale(&pBitmap, maxsize, -1, "meet", True)
      (sprite) && this.BitmapSprite(&pBitmap)

      ; Save frame delays and loop count for webp.
      if (type = "stream" && extension = "webp" && cotype ~= "^(?i:show|window|desktop)$") {
         this.ParseWEBP(stream, &pDelays, &pCount)
         IsSet(pDelays) && DllCall("gdiplus\GdipSetPropertyItem", "ptr", pBitmap, "ptr", pDelays)
         IsSet(pCount) && DllCall("gdiplus\GdipSetPropertyItem", "ptr", pBitmap, "ptr", pCount)
      }

      ; Attempt conversion using BitmapToCoimage.
      coimage := this.BitmapToCoimage(cotype, pBitmap, p*)

      ; Clean up the copy. Export raw pointers if requested.
      if (cotype != "bitmap")
         DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)

      if (cleanup = "stream")
         ObjRelease(stream)

      return coimage
   }

   static Inputs :=

   [
      "ClipboardPNG",
      "Clipboard",
      "SafeArray",
      "Screenshot",
      "Window",
      "Object",
      "EncodedBuffer",
      "Buffer",
      "Monitor",
      "Desktop",
      "Wallpaper",
      "Cursor",
      "URL",
      "File",
      "SharedBuffer",
      "Hex",
      "Base64",
      "DC",
      "HBitmap",
      "HIcon",
      "Bitmap",
      "Stream",
      "RandomAccessStream",
      "WICBitmap",
      "D2DBitmap"
   ]

   static DontVerifyImageType(&image, &keywords := "") {

      ; Sentinel value.
      keywords := {}

      ; Try ImageType.
      if !IsObject(image)
         throw Error("Must be an object.")

      ; Goto ImageType.
      if image.HasProp("image") && !image.HasMethod("image") {
         keywords := image
         image := image.image
         throw Error("Must catch this error with ImageType.")
      }

      ; Skip ImageType.
      for type in this.inputs
         if image.HasProp(type) && !image.HasMethod(type) {
            keywords := image
            image := image.%type%
            return type
         }

      ; Continue ImageType.
      throw Error("Invalid type.")
   }

   static ImageType(image) {

      if not IsObject(image)
         goto string

      if image.HasProp("prototype") && image.prototype.HasProp("__class") && image.prototype.__class == "ClipboardAll"
      or Type(image) == "ClipboardAll" && this.IsClipboard(image.ptr, image.size)
         ; A "clipboardpng" is a pointer to a PNG stream saved as the "png" clipboard format.
         if DllCall("IsClipboardFormatAvailable", "uint", DllCall("RegisterClipboardFormat", "str", "png", "uint"))
            return "ClipboardPNG"

         ; A "clipboard" is a handle to a GDI bitmap saved as CF_BITMAP.
         else if DllCall("IsClipboardFormatAvailable", "uint", 2)
            return "Clipboard"

         else throw Error("Clipboard format not supported.")




      array:
      ; A "safearray" is a pointer to a SafeArray COM Object.
      if ComObjType(image) and ComObjType(image) & 0x2000
         return "SafeArray"

      ; A "screenshot" is an array of 4 numbers with an optional window.
      if image.HasProp("__Item") && image.HasProp("length") && image.length ~= "4|5"
      && image[1] ~= "^-?\d+$" && image[2] ~= "^-?\d+$" && image[3] ~= "^(?!0+$)\d+$" && image[4] ~= "^(?!0+$)\d+$"
      && image[1] > -65536 && image[1] < 65536 && image[2] > -65536 && image[2] < 65536 && image[3] < 65536 && image[4] < 65536
      && (image.Has(5) ? WinExist(image[5]) : True)
         return "Screenshot"

      object:
      ; A "window" is an object with an hwnd property.
      if image.HasProp("hwnd")
         return "Window"

      ; A "object" has a pBitmap property that points to an internal GDI+ bitmap.
      if image.HasProp("pBitmap")
         try if !DllCall("gdiplus\GdipGetImageType", "ptr", image.pBitmap, "ptr*", &_type:=0) && (_type == 1)
            return "Object"

      if not image.HasProp("ptr")
         goto end

      ; Check if image is a pointer. If not, crash and do not recover.
      ("POINTER IS BAD AND PROGRAM IS CRASH") && NumGet(image.ptr, "char")

      ; An "encodedbuffer" contains a pointer to the bytes of an encoded image format.
      if image.HasProp("ptr") && image.HasProp("size") && this.IsImage(image.ptr, image.size)
         return "EncodedBuffer"

      ; A "buffer" is an object with a pointer to bytes and properties to determine its 2-D shape.
      if image.HasProp("ptr")
         and ( image.HasProp("width") && image.HasProp("height")
            or image.HasProp("stride") && image.HasProp("height")
            or image.HasProp("size") && (image.HasProp("stride") || image.HasProp("width") || image.HasProp("height")))
         return "Buffer"

      image := image.ptr
      goto pointer

      string:
      if (image == "")
         throw Error("Image data is an empty string.")

      ; A non-zero "monitor" number identifies each display uniquely; and 0 refers to the entire virtual screen.
      if (image ~= "^\d+$" && image >= 0 && image <= MonitorGetCount())
         return "Monitor"

      ; A "desktop" is a hidden window behind the desktop icons created by ImagePutDesktop.
      if (image = "desktop")
         return "Desktop"

      ; A "wallpaper" is the desktop wallpaper.
      if (image = "wallpaper")
         return "Wallpaper"

      ; A "cursor" is the name of a known cursor name.
      if (image ~= "(?i)^A_Cursor|Unknown|(IDC_)?(AppStarting|Arrow|Cross|Hand(writing)?|"
      . "Help|IBeam|No|Pin|Person|SizeAll|SizeNESW|SizeNS|SizeNWSE|SizeWE|UpArrow|Wait)$")
         return "Cursor"

      ; A "url" satisfies the url format.
      if this.IsURL(image)
         return "URL"

      ; A "file" is stored on the disk or network.
      if FileExist(image)
         return "File"

      ; A "window" is anything considered a Window Title including ahk_class and "A".
      if WinExist(image)
         return "Window"

      ; A "sharedbuffer" is a file mapping kernel object.
      if DllCall("CloseHandle", "ptr", DllCall("OpenFileMapping", "uint", 2, "int", 0, "str", "ImagePut_" image, "ptr"))
         return "SharedBuffer"

      ; A "hex" string is binary image data encoded into text using hexadecimal.
      if (StrLen(image) >= 48) && (image ~= "^\s*(?:[A-Fa-f0-9]{2})*+\s*$")
         return "Hex"

      ; A "base64" string is binary image data encoded into text using standard 64 characters.
      if (StrLen(image) >= 32) && (image ~= "^\s*(?:data:image\/[a-z]+;base64,)?"
      . "(?:[A-Za-z0-9+\/]{4})*+(?:[A-Za-z0-9+\/]{3}=|[A-Za-z0-9+\/]{2}==)?\s*$")
         return "Base64"

      ; For more helpful error messages: Catch file names without extensions!
      if not (image ~= "^-?\d+$") {
         for extension in ["bmp","dib","rle","jpg","jpeg","jpe","jfif","gif","tif","tiff","png","ico","exe","dll"]
            if FileExist(image "." extension)
               throw Error("A ." extension " file extension is required!", -3)

         goto end
      }

      handle:
      ; A "dc" is a handle to a GDI device context.
      if (DllCall("GetObjectType", "ptr", image, "uint") == 3 || DllCall("GetObjectType", "ptr", image, "uint") == 10)
         return "DC"

      ; An "hBitmap" is a handle to a GDI Bitmap.
      if (DllCall("GetObjectType", "ptr", image, "uint") == 7)
         return "HBitmap"

      ; An "hIcon" is a handle to a GDI icon.
      if DllCall("DestroyIcon", "ptr", DllCall("CopyIcon", "ptr", image, "ptr"))
         return "HIcon"

      ; Check if image is a pointer. If not, crash and do not recover.
      ("POINTER IS BAD AND PROGRAM IS CRASH") && NumGet(image, "char")

      ; A "bitmap" is a pointer to a GDI+ Bitmap. GdiplusStartup exception is caught above.
      try if !DllCall("gdiplus\GdipGetImageType", "ptr", image, "ptr*", &_type:=0) && (_type == 1)
         return "Bitmap"

      ; Note 1: All GDI+ functions add 1 to the reference count of COM objects on 64-bit systems.
      ; Note 2: GDI+ pBitmaps that are queried cease to stay pBitmaps.
      ; Note 3: Critical error for ranges 0-4095 on v1 and 0-65535 on v2.
      (A_PtrSize == 8) && ObjRelease(image) ; Therefore do not move this, it has been tested.

      pointer:
      ; A "stream" is a pointer to the IStream interface.
      try if ComObjQuery(image, "{0000000C-0000-0000-C000-000000000046}")
         return "Stream"

      ; A "randomaccessstream" is a pointer to the IRandomAccessStream interface.
      try if ComObjQuery(image, "{905A0FE1-BC53-11DF-8C49-001E4FC686DA}")
         return "RandomAccessStream"

      ; A "wicbitmap" is a pointer to a IWICBitmapSource.
      try if ComObjQuery(image, "{00000120-A8F2-4877-BA0A-FD2B6645FB94}")
         return "WICBitmap"

      ; A "d2dbitmap" is a pointer to a ID2D1Bitmap.
      try if ComObjQuery(image, "{A2296057-EA42-4099-983B-539FB6505426}")
         return "D2DBitmap"

      end:
      throw Error("Image type could not be identified.")
   }

   static ImageToBitmap(type, image, keywords := "") {

      try index := keywords.index

      if (type = "Object")
         return this.BitmapToBitmap(image.pBitmap)

      if (type = "Clipboard")
         return this.ClipboardToBitmap()

      if (type = "ClipboardPNG")
         return this.ClipboardPNGToBitmap()

      if (type = "SafeArray")
         return this.SafeArrayToBitmap(image)

      if (type = "EncodedBuffer")
         return this.EncodedBufferToBitmap(image)

      if (type = "SharedBuffer")
         return this.SharedBufferToBitmap(image)

      if (type = "Buffer")
         return this.BufferToBitmap(image)

      if (type = "Monitor")
         return this.MonitorToBitmap(image)

      if (type = "Screenshot")
         return this.ScreenshotToBitmap(image)

      if (type = "Window")
         return this.WindowToBitmap(image)

      if (type = "Desktop")
         return this.DesktopToBitmap()

      if (type = "Wallpaper")
         return this.WallpaperToBitmap()

      if (type = "Cursor")
         return this.CursorToBitmap()

      if (type = "URL")
         return this.URLToBitmap(image)

      if (type = "File")
         return this.FileToBitmap(image)

      if (type = "Hex")
         return this.HexToBitmap(image)

      if (type = "Base64")
         return this.Base64ToBitmap(image)

      if (type = "DC")
         return this.DCToBitmap(image)

      if (type = "HBitmap")
         return this.HBitmapToBitmap(image)

      if (type = "HIcon")
         return this.HIconToBitmap(image)

      if (type = "Bitmap")
         return this.BitmapToBitmap(image)

      if (type = "Stream")
         return this.StreamToBitmap(image)

      if (type = "RandomAccessStream")
         return this.RandomAccessStreamToBitmap(image)

      if (type = "WICBitmap")
         return this.WICBitmapToBitmap(image)

      if (type = "D2DBitmap")
         return this.D2DBitmapToBitmap(image)

      throw Error("Conversion from " type " to bitmap is not supported.")
   }

   static BitmapToCoimage(cotype, pBitmap, p1:="", p2:="", p3:="", p4:="", p5:="", p6:="", p7:="", p*) {

      if (cotype = "Clipboard") ; (pBitmap)
         return this.BitmapToClipboard(pBitmap)

      if (cotype = "SafeArray") ; (pBitmap, extension, quality)
         return this.BitmapToSafeArray(pBitmap, p1, p2)

      if (cotype = "EncodedBuffer") ; (pBitmap, extension, quality)
         return this.BitmapToEncodedBuffer(pBitmap, p1, p2)

      if (cotype = "SharedBuffer") ; (pBitmap, name)
         return this.BitmapToSharedBuffer(pBitmap, p1)

      if (cotype = "Buffer") ; (pBitmap)
         return this.BitmapToBuffer(pBitmap)

      if (cotype = "Screenshot") ; (pBitmap, pos, alpha)
         return this.BitmapToScreenshot(pBitmap, p1, p2)

      if (cotype = "Window") ; (pBitmap, title, pos, style, styleEx, parent, playback, cache)
         return this.BitmapToWindow(pBitmap, p1, p2, p3, p4, p5, p6, p7)

      if (cotype = "Show") ; (pBitmap, title, pos, style, styleEx, parent, playback, cache)
         return this.Show(pBitmap, p1, p2, p3, p4, p5, p6, p7)

      if (cotype = "Desktop") ; (pBitmap, title, pos, style, styleEx, parent, playback, cache)
         return this.BitmapToDesktop(pBitmap, p1, p2, p3, p4, p5, p6, p7)

      if (cotype = "Wallpaper") ; (pBitmap)
         return this.BitmapToWallpaper(pBitmap)

      if (cotype = "Cursor") ; (pBitmap, xHotspot, yHotspot)
         return this.BitmapToCursor(pBitmap, p1, p2)

      if (cotype = "URL") ; (pBitmap)
         return this.BitmapToURL(pBitmap)

      if (cotype = "Explorer") ; (pBitmap, default_dir, background_window)
         return this.BitmapToExplorer(pBitmap, p1, p2)

      if (cotype = "File") ; (pBitmap, filepath, quality)
         return this.BitmapToFile(pBitmap, p1, p2)

      if (cotype = "Hex") ; (pBitmap, extension, quality)
         return this.BitmapToHex(pBitmap, p1, p2)

      if (cotype = "Base64") ; (pBitmap, extension, quality)
         return this.BitmapToBase64(pBitmap, p1, p2)

      if (cotype = "URI") ; (pBitmap, extension, quality)
         return this.BitmapToURI(pBitmap, p1, p2)

      if (cotype = "DC") ; (pBitmap, alpha)
         return this.BitmapToDC(pBitmap, p1)

      if (cotype = "HBitmap") ; (pBitmap, alpha)
         return this.BitmapToHBitmap(pBitmap, p1)

      if (cotype = "HIcon") ; (pBitmap)
         return this.BitmapToHIcon(pBitmap)

      if (cotype = "Bitmap")
         return pBitmap

      if (cotype = "Stream") ; (pBitmap, extension, quality)
         return this.BitmapToStream(pBitmap, p1, p2)

      if (cotype = "RandomAccessStream") ; (pBitmap, extension, quality)
         return this.BitmapToRandomAccessStream(pBitmap, p1, p2)

      if (cotype = "WICBitmap") ; (pBitmap)
         return this.BitmapToWICBitmap(pBitmap)

      if (cotype = "D2DBitmap") ; (pBitmap)
         return this.BitmapToD2DBitmap(pBitmap)

      if (cotype = "FormData") ; (pBitmap, boundary, extension, quality)
         return this.BitmapToFormData(pBitmap, p1, p2, p3)

      throw Error("Conversion from bitmap to " cotype " is not supported.")
   }

   static ImageToStream(type, image, keywords := "") {

      try index := keywords.index

      if (type = "ClipboardPNG")
         return this.ClipboardPNGToStream()

      if (type = "SafeArray")
         return this.SafeArrayToStream(image)

      if (type = "EncodedBuffer")
         return this.EncodedBufferToStream(image)

      if (type = "URL")
         return this.URLToStream(image)

      if (type = "File")
         return this.FileToStream(image)

      if (type = "Hex")
         return this.HexToStream(image)

      if (type = "Base64")
         return this.Base64ToStream(image)

      if (type = "Stream")
         return this.StreamToStream(image)

      if (type = "RandomAccessStream")
         return this.RandomAccessStreamToStream(image)

      throw Error("Conversion from " type " to stream is not supported.")
   }

   static StreamToCoimage(cotype, stream, p1 := "", p2 := "", p*) {

      if (cotype = "Clipboard") ; (stream)
         return this.StreamToClipboard(stream)

      if (cotype = "SafeArray") ; (stream)
         return this.StreamToSafeArray(stream)

      if (cotype = "EncodedBuffer") ; (stream)
         return this.StreamToEncodedBuffer(stream)

      if (cotype = "URL") ; (stream)
         return this.StreamToURL(stream)

      if (cotype = "Explorer") ; (stream, default_dir, background_window)
         return this.StreamToExplorer(stream, p1, p2)

      if (cotype = "File") ; (stream, filepath)
         return this.StreamToFile(stream, p1)

      if (cotype = "Hex") ; (stream)
         return this.StreamToHex(stream)

      if (cotype = "Base64") ; (stream)
         return this.StreamToBase64(stream)

      if (cotype = "URI") ; (stream)
         return this.StreamToURI(stream)

      if (cotype = "Stream")
         return stream

      if (cotype = "RandomAccessStream") ; (stream)
         return this.StreamToRandomAccessStream(stream)

      if (cotype = "FormData") ; (stream, boundary)
         return this.StreamToFormData(stream, p1)

      throw Error("Conversion from stream to " cotype " is not supported.")
   }

   static BitmapCrop(&pBitmap, crop) {
      if not (IsObject(crop)
      && crop[1] ~= "^-?\d+(\.\d*)?%?$" && crop[2] ~= "^-?\d+(\.\d*)?%?$"
      && crop[3] ~= "^-?\d+(\.\d*)?%?$" && crop[4] ~= "^-?\d+(\.\d*)?%?$")
         throw Error("Invalid crop.")

      ; Get Bitmap width, height, and format.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)
      DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", pBitmap, "int*", &format:=0)

      ; Abstraction Shift.
      ; Previously, real values depended on abstract values.
      ; Now, real values have been resolved, and abstract values depend on reals.

      ; Are the numbers percentages?
      (crop[1] ~= "%$") && crop[1] := SubStr(crop[1], 1, -1) * 0.01 *  width
      (crop[2] ~= "%$") && crop[2] := SubStr(crop[2], 1, -1) * 0.01 * height
      (crop[3] ~= "%$") && crop[3] := SubStr(crop[3], 1, -1) * 0.01 *  width
      (crop[4] ~= "%$") && crop[4] := SubStr(crop[4], 1, -1) * 0.01 * height

      ; If numbers are negative, subtract the values from the edge.
      crop[1] := Abs(crop[1])
      crop[2] := Abs(crop[2])
      crop[3] := (crop[3] < 0) ?  width - Abs(crop[3]) - Abs(crop[1]) : crop[3]
      crop[4] := (crop[4] < 0) ? height - Abs(crop[4]) - Abs(crop[2]) : crop[4]

      ; Round to the nearest integer. Reminder: width and height are distances, not coordinates.
      crop[1] := Round(crop[1])
      crop[2] := Round(crop[2])
      crop[3] := Round(crop[1] + crop[3]) - Round(crop[1])
      crop[4] := Round(crop[2] + crop[4]) - Round(crop[2])

      ; Avoid cropping if no changes are detected.
      if (crop[1] = 0 && crop[2] = 0 && crop[3] == width && crop[4] == height)
         return pBitmap

      ; Minimum size is 1 x 1. Ensure that coordinates can never exceed the expected Bitmap area.
      safe_x := (crop[1] >= width)
      safe_y := (crop[2] >= height)
      safe_w := (crop[3] <= 0 || crop[1] + crop[3] > width)
      safe_h := (crop[4] <= 0 || crop[2] + crop[4] > height)

      ; Abort cropping if any of the changes would exceed a safe bound.
      if (safe_x || safe_y || safe_w || safe_h)
         return pBitmap

      ; Clone and retain a reference to the backing stream.
      DllCall("gdiplus\GdipCloneBitmapAreaI"
               ,    "int", crop[1]
               ,    "int", crop[2]
               ,    "int", crop[3]
               ,    "int", crop[4]
               ,    "int", format
               ,    "ptr", pBitmap
               ,   "ptr*", &pBitmapCrop:=0)

      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)

      return pBitmap := pBitmapCrop
   }

   static BitmapScale(&pBitmap, scale, direction := 0, bound := "", preserveAspectRatio := False) {
      ; min() specifies the greatest lower bound or the maximum size, fitting the image to the bounding box.
      ; max() specifies the least upper bound or the minimum size, filling the image to the bounding box.
      bound := !HasMethod(bound) && (bound ~= "^(?i:fit|meet|and|infimum)$") ? min
            :  !HasMethod(bound) && (bound ~= "^(?i:fill|join|or|supremum)$") ? max
            :  !HasMethod(bound) && (bound == "") ? ((direction < 0) ? max : min)
            :  bound ; Please specify your own bound function

      ; Get Bitmap width, height, and format.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)
      DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", pBitmap, "int*", &format:=0)

      ; Scale using a real number greater than 0.
      if !IsObject(scale) && scale ~= "^(?!0+$)\d+(\.\d+)?$" {
         safe_w := Round(width * scale)
         safe_h := Round(height * scale)
      }

      ; Specify min or max as the bounding function to fit or fill to the specified edge length.
      if Type(scale) == "Array" && scale.length = 1 && scale.Has(1) && scale[1] ~= "^(?!0+$)\d+$" {
         safe_w := Round(width * bound(scale[1] / width, scale[1] / height))
         safe_h := Round(height * bound(scale[1] / width, scale[1] / height))
      }

      ; (1) If either the width or the height is set to "auto", the other dimension is calculated from the aspect ratio.
      ; (2) Preserve the aspect ratio using either the width or the height as the reference.
      ; (3) Scale to the given width x height.
      if Type(scale) == "Array" && scale.length = 2 && (scale.Has(1) && scale[1] ~= "^(?!0+$)\d+$" || scale.Has(2) && scale[2] ~= "^(?!0+$)\d+$") {
         safe_w := !(scale[1] ~= "^(?!0+$)\d+$") ? Round(width / height * scale[2])
               : (preserveAspectRatio) ? Round(width * bound(scale[1] / width, scale[2] / height))
               : scale[1]
         safe_h := !(scale[2] ~= "^(?!0+$)\d+$") ? Round(height / width * scale[1])
               : (preserveAspectRatio) ? Round(height * bound(scale[1] / width, scale[2] / height))
               : scale[2]
      }

      if Type(scale) == "Array" && scale.length = 1 && scale.Has(1) && scale[1] ~= "^(?!0+$)\d+$" && direction = 0
         throw Error("Single scale value requires a direction such as upscale or downscale.")
      if !IsSet(safe_w) || !IsSet(safe_h)
         throw Error("Invalid scale.")

      ; Minimum size is 1 x 1.
      safe_w := max(1, safe_w)
      safe_h := max(1, safe_h)

      ; Avoid drawing if no changes detected.
      if (safe_w = width && safe_h = height)
         return pBitmap

      ; Force upscaling.
      if (direction > 0 and (safe_w < width && safe_h < height))
         return pBitmap

      ; Force downscaling.
      if (direction < 0 and (safe_w > width && safe_h > height))
         return pBitmap

      ; Create a destination GDI+ Bitmap that owns its memory.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", safe_w, "int", safe_h, "int", 0, "int", format, "ptr", 0, "ptr*", &pBitmapScale:=0)

      ; Create a graphics context as the rendering destination.
      DllCall("gdiplus\GdipGetImageGraphicsContext", "ptr", pBitmapScale, "ptr*", &pGraphics:=0)
      DllCall("gdiplus\GdipSetPixelOffsetMode",    "ptr", pGraphics, "int", 2) ; Half pixel offset.
      DllCall("gdiplus\GdipSetCompositingMode",    "ptr", pGraphics, "int", 1) ; Overwrite/SourceCopy.
      DllCall("gdiplus\GdipSetInterpolationMode",  "ptr", pGraphics, "int", 7) ; HighQualityBicubic

      ; Draw Image.
      DllCall("gdiplus\GdipCreateImageAttributes", "ptr*", &ImageAttr:=0)
      DllCall("gdiplus\GdipSetImageAttributesWrapMode", "ptr", ImageAttr, "int", 3, "uint", 0, "int", 0) ; WrapModeTileFlipXY
      DllCall("gdiplus\GdipDrawImageRectRectI"
               ,    "ptr", pGraphics
               ,    "ptr", pBitmap
               ,    "int", 0, "int", 0, "int", safe_w, "int", safe_h ; destination rectangle
               ,    "int", 0, "int", 0, "int",  width, "int", height ; source rectangle
               ,    "int", 2
               ,    "ptr", ImageAttr
               ,    "ptr", 0
               ,    "ptr", 0)
      DllCall("gdiplus\GdipDisposeImageAttributes", "ptr", ImageAttr)

      ; Cleanup!
      DllCall("gdiplus\GdipDeleteGraphics", "ptr", pGraphics)
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)

      return pBitmap := pBitmapScale
   }

   static BitmapSprite(&pBitmap) {
      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 3) Expose the pixel buffer for modification.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 3            ; ImageLockMode.ReadWrite
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)
      Scan0 := NumGet(BitmapData, 16, "ptr")

      ; C source code - https://godbolt.org/z/nrv5Yr3Y3
      static code := 0
      if !code {
         b64 := (A_PtrSize == 4)
            ? "VYnli0UIi1UMi00QOdBzDzkIdQbHAAAAAACDwATr7V3D"
            : "SDnRcw9EOQF1BDHAiQFIg8EE6+zD"
         n64 := StrLen(RTrim(b64, "=")) * 3 // 4
         code := DllCall("GlobalAlloc", "uint", 0, "uptr", n64, "ptr")
         DllCall("crypt32\CryptStringToBinary", "str", b64, "uint", 0, "uint", 0x1, "ptr", code, "uint*", n64, "ptr", 0, "ptr", 0)
         DllCall("VirtualProtect", "ptr", code, "uptr", n64, "uint", 0x40, "uint*", 0)
      }

      ; Sample the top-left pixel and set all matching pixels to be transparent.
      DllCall(code, "ptr", Scan0, "ptr", Scan0 + 4*width*height, "uint", NumGet(Scan0, "uint"), "cdecl")

      ; Write pixels to bitmap.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      return pBitmap
   }

   static GetExtensionFromStream(stream) {
      ; 2048 characters should be good enough to identify the file correctly.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      size := min(size, 2048)
      bin := Buffer(size)

      ; Get the first few bytes of the image.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Allocate enough space for a hexadecimal string with spaces interleaved and a null terminator.
      length := 2*size + (size-1) + 1
      VarSetStrCapacity(&str, length)

      ; Lift the binary representation to hex.
      flags := 0x40000004 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_HEX
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Determine the extension using herustics. See: http://fileformats.archiveteam.org
      extension := 0                                                              ? ""
      : str ~= "(?i)66 74 79 70 61 76 69 66"                                      ? "avif" ; ftypavif
      : str ~= "(?i)^42 4d (.. ){36}00 00 .. 00 00 00"                            ? "bmp"  ; BM
      : str ~= "(?i)^01 00 00 00 (.. ){36}20 45 4D 46"                            ? "emf"  ; emf
      : str ~= "(?i)^47 49 46 38 (37|39) 61"                                      ? "gif"  ; GIF87a or GIF89a
      : str ~= "(?i)66 74 79 70 68 65 69 63"                                      ? "heic" ; ftypheic
      : str ~= "(?i)^00 00 01 00"                                                 ? "ico"
      : str ~= "(?i)^ff d8 ff"                                                    ? "jpg"
      : str ~= "(?i)^25 50 44 46 2d"                                              ? "pdf"  ; %PDF-
      : str ~= "(?i)^89 50 4e 47 0d 0a 1a 0a"                                     ? "png"  ; PNG
      : str ~= "(?i)^(((?!3c|3e).. )|3c (3f|21) ((?!3c|3e).. )*3e )*+3c 73 76 67" ? "svg"  ; <svg
      : str ~= "(?i)^(49 49 2a 00|4d 4d 00 2a)"                                   ? "tif"  ; II* or MM*
      : str ~= "(?i)^52 49 46 46 .. .. .. .. 57 45 42 50"                         ? "webp" ; RIFF....WEBP
      : str ~= "(?i)^d7 cd c6 9a"                                                 ? "wmf"
      : "" ; Extension must be blank for file pass-through as-is.

      return extension
   }

   static IsClipboard(ptr, size) {
      ; When the clipboard is empty, both the pointer and size are zero.
      if (ptr == 0 && size == 0)
         return True

      ; Look for a RIFF-like structure.
      pos := 0
      while (pos < size)
         if (offset := NumGet(ptr + pos + 4, "uint"))
            pos += offset + 8
         else break
      return pos + 4 == size && !NumGet(ptr + pos, "uint") ; 4 byte null terminator
   }

   static IsImage(bin, size) {
      ; Shortest possible image is 24 bytes.
      if (size < 24)
         return False

      size := min(size, 2048)
      length := VarSetStrCapacity(&str, 2*size + (size-1) + 1)
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", 0x40000004, "str", str, "uint*", &length)
      if str ~= "(?i)66 74 79 70 61 76 69 66"                                      ; "avif"
      || str ~= "(?i)^42 4d (.. ){36}00 00 .. 00 00 00"                            ; "bmp"
      || str ~= "(?i)^01 00 00 00 (.. ){36}20 45 4D 46"                            ; "emf"
      || str ~= "(?i)^47 49 46 38 (37|39) 61"                                      ; "gif"
      || str ~= "(?i)66 74 79 70 68 65 69 63"                                      ; "heic"
      || str ~= "(?i)^00 00 01 00"                                                 ; "ico"
      || str ~= "(?i)^ff d8 ff"                                                    ; "jpg"
      || str ~= "(?i)^25 50 44 46 2d"                                              ; "pdf"
      || str ~= "(?i)^89 50 4e 47 0d 0a 1a 0a"                                     ; "png"
      || str ~= "(?i)^(((?!3c|3e).. )|3c (3f|21) ((?!3c|3e).. )*3e )*+3c 73 76 67" ; "svg"
      || str ~= "(?i)^(49 49 2a 00|4d 4d 00 2a)"                                   ; "tif"
      || str ~= "(?i)^52 49 46 46 .. .. .. .. 57 45 42 50"                         ; "webp"
      || str ~= "(?i)^d7 cd c6 9a"                                                 ; "wmf"
         return True

      return False
   }

   static IsURL(url) {
      ; Thanks dperini - https://gist.github.com/dperini/729294
      ; Also see for comparisons: https://mathiasbynens.be/demo/url-regex
      ; Modified to be compatible with AutoHotkey. \u0000 -> \x{0000}.
      ; Force the declaration of the protocol because WinHttp requires it.
      return url ~= "^(?i)"
         . "(?:(?:https?|ftp):\/\/)" ; protocol identifier (FORCE)
         . "(?:\S+(?::\S*)?@)?" ; user:pass BasicAuth (optional)
         . "(?:"
            ; IP address exclusion
            ; private & local networks
            . "(?!(?:10|127)(?:\.\d{1,3}){3})"
            . "(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})"
            . "(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})"
            ; IP address dotted notation octets
            ; excludes loopback network 0.0.0.0
            ; excludes reserved space >= 224.0.0.0
            ; excludes network & broadcast addresses
            ; (first & last IP address of each class)
            . "(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])"
            . "(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}"
            . "(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))"
         . "|"
            ; host & domain names, may end with dot
            ; can be replaced by a shortest alternative
            ; (?![-_])(?:[-\\w\\u00a1-\\uffff]{0,63}[^-_]\\.)+
            . "(?:(?:[a-z0-9\x{00a1}-\x{ffff}][a-z0-9\x{00a1}-\x{ffff}_-]{0,62})?[a-z0-9\x{00a1}-\x{ffff}]\.)+"
            ; TLD identifier name, may end with dot
            . "(?:[a-z\x{00a1}-\x{ffff}]{2,}\.?)"
         . ")"
         . "(?::\d{2,5})?" ; port number (optional)
         . "(?:[/?#]\S*)?$" ; resource path (optional)
   }

   static ClipboardToBitmap() {
      ; Check for CF_DIB to retrieve transparent pixels when possible.
      if !DllCall("IsClipboardFormatAvailable", "uint", 8)
         throw Error("Clipboard does not have CF_DIB image data.")

      ; Open the clipboard with exponential backoff.
      loop
         if DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            break
         else
            if A_Index < 6
               Sleep (2**(A_Index-1) * 30)
            else throw Error("Clipboard could not be opened.")

      ; CF_DIB (8) can be synthesized from CF_DIBV5 (17) or CF_BITMAP (2).
      if !(handle := DllCall("GetClipboardData", "uint", 8, "ptr")) {
         DllCall("CloseClipboard")
         throw Error("Shared clipboard data has been deleted.")
      }

      ; CF_DIB (8) - A memory object containing a BITMAPINFO structure followed by the bitmap bits.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      ptr := DllCall("GlobalLock", "ptr", handle, "ptr")
         , width := NumGet(ptr + 4, "int")
         , height := NumGet(ptr + 8, "int")
         , bpp := NumGet(ptr + 14, "ushort")

      ; Note: Bottom-up is assumed by EVERY APPLICATION. A top-down bitmap will be upaide down.
      stride := -(width * bpp + 31) // 32 * 4
      pBits := ptr + 40 ; Todo: This is likely not true.
      Scan0 := pBits - (height-1)*stride

      ; Create a destination GDI+ Bitmap that owns its memory. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 6) Copy external pixels into the GDI+ Bitmap.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",     stride, BitmapData,  8) ; Stride
         NumPut(   "ptr",      Scan0, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (Scan0) to the CF_DIB.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      DllCall("CloseClipboard")
      return pBitmap
   }

   static ClipboardPNGToBitmap() {
      stream := this.ClipboardPNGToStream()
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static ClipboardPNGToStream() {
      ; Open the clipboard with exponential backoff.
      loop
         if DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            break
         else
            if A_Index < 6
               Sleep (2**(A_Index-1) * 30)
            else throw Error("Clipboard could not be opened.")

      png := DllCall("RegisterClipboardFormat", "str", "png", "uint")
      if !DllCall("IsClipboardFormatAvailable", "uint", png)
         throw Error("Clipboard does not have PNG stream data.")

      if !(handle := DllCall("GetClipboardData", "uint", png, "ptr"))
         throw Error("Shared clipboard PNG has been deleted.")

      ; Create a new stream from the clipboard data.
      size := DllCall("GlobalSize", "ptr", handle, "uptr")
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", False, "ptr*", &PngStream:=0, "hresult")
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", True, "ptr*", &stream:=0, "hresult")
      DllCall("shlwapi\IStream_Copy", "ptr", PngStream, "ptr", stream, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      DllCall("CloseClipboard")
      return stream
   }

   static SafeArrayToBitmap(image) {
      stream := this.SafeArrayToStream(image)
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static SafeArrayToStream(image) {
      ; Expects a 1-D safe array of bytes. (VT_UI1)
      size := image.MaxIndex()
      pvData := NumGet(ComObjValue(image), 8 + A_PtrSize, "ptr")

      ; Copy data to a new stream.
      handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", size, "ptr")
      ptr := DllCall("GlobalLock", "ptr", handle, "ptr")
      DllCall("RtlMoveMemory", "ptr", ptr, "ptr", pvData, "uptr", size)
      DllCall("GlobalUnlock", "ptr", handle)
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", True, "ptr*", &stream:=0, "hresult")
      return stream
   }

   static EncodedBufferToBitmap(image) {
      stream := this.EncodedBufferToStream(image)
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static EncodedBufferToStream(image) { ; Likely faster than ISteam_Read
      handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", image.size, "ptr")
      ptr := DllCall("GlobalLock", "ptr", handle, "ptr")
      DllCall("RtlMoveMemory", "ptr", ptr, "ptr", image.ptr, "uptr", image.size)
      DllCall("GlobalUnlock", "ptr", handle)
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", True, "ptr*", &stream:=0, "hresult")
      return stream
   }

   static SharedBufferToBitmap(image) {
      hMap := DllCall("OpenFileMapping", "uint", 0x2, "int", 0, "str", "ImagePut_" image, "ptr")
      pMap := DllCall("MapViewOfFile", "ptr", hMap, "uint", 0x2, "uint", 0, "uint", 0, "uptr", 0, "ptr")

      width := NumGet(pMap + 0, "uint")
      height := NumGet(pMap + 4, "uint")
      stride := NumGet(pMap + 8, "uint") ? NumGet(pMap + 8, "uint") : 4 * width
      size := stride * height
      ptr := pMap + 12

      ; Create a destination GDI+ Bitmap that owns its memory. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 6) Copy external pixels into the GDI+ Bitmap.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",     stride, BitmapData,  8) ; Stride
         NumPut(   "ptr",        ptr, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (ptr) to the FileMapping.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      DllCall("UnmapViewOfFile", "ptr", pMap)
      DllCall("CloseHandle", "ptr", hMap)

      return pBitmap
   }

   static BufferToBitmap(image) {

      if image.HasProp("pitch")
         stride := image.pitch

      else if image.HasProp("stride")
         stride := image.stride
      else if image.HasProp("width")
         stride := image.width * 4
      else if image.HasProp("height") && image.HasProp("size")
         stride := image.size // image.height
      else throw Error("Image buffer is missing a stride or pitch property.")

      if image.HasProp("height")
         height := image.height
      else if stride && image.HasProp("size")
         height := image.size // stride
      else if image.HasProp("width") && image.HasProp("size")
         height := image.size // (4 * image.width)
      else throw Error("Image buffer is missing a height property.")

      if image.HasProp("width")
         width := image.width
      else if stride
         width := stride // 4
      else if height && image.HasProp("size")
         width := image.size // (4 * height)
      else throw Error("Image buffer is missing a width property.")

      ; Could assert a few assumptions, such as stride * height = size.
      ; However, I'd like for the pointer and its size to be as flexable as possible.
      ; User is responsible for underflow.

      ; Check for buffer overflow errors.
      if image.HasProp("size") && (abs(stride * height) > image.size)
         throw Error("Image dimensions exceed the size of the buffer.")

      ; Create a source GDI+ Bitmap that owns its memory. The pixel format is 32-bit ARGB.
      ; Case 1: (+) height (+) stride -> Use ptr or Scan0 (top-down bitmap)
      ; Case 2: (+) height (-) stride -> Use Scan0 only (bottom-up bitmap)
      ; Case 3: (-) height (+) stride -> Use ptr only (bottom-up bitmap)
      ; Case 4: (-) height (-) stride -> Use Scan0 only (top-down bitmap)
      if (height > 0)
         DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height
         , "int", stride, "int", 0x26200A, "ptr", image.ptr, "ptr*", &pBitmap:=0)
      else {
         height := abs(height)
         DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height
         , "int", -stride, "int", 0x26200A, "ptr", image.ptr + (height-1)*stride, "ptr*", &pBitmap:=0)
      }
      return pBitmap
   }

   static MonitorToBuffer(image) {
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      if (image > 0) {
         MonitorGet(image, &Left, &Top, &Right, &Bottom)
         x := Left
         y := Top
         w := Right - Left
         h := Bottom - Top
      } else {
         x := DllCall("GetSystemMetrics", "int", 76, "int")
         y := DllCall("GetSystemMetrics", "int", 77, "int")
         w := DllCall("GetSystemMetrics", "int", 78, "int")
         h := DllCall("GetSystemMetrics", "int", 79, "int")
      }
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
      return this.ScreenshotToBuffer([x,y,w,h])
   }

   static MonitorToBitmap(image) {
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      if (image > 0) {
         MonitorGet(image, &Left, &Top, &Right, &Bottom)
         x := Left
         y := Top
         w := Right - Left
         h := Bottom - Top
      } else {
         x := DllCall("GetSystemMetrics", "int", 76, "int")
         y := DllCall("GetSystemMetrics", "int", 77, "int")
         w := DllCall("GetSystemMetrics", "int", 78, "int")
         h := DllCall("GetSystemMetrics", "int", 79, "int")
      }
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
      return this.ScreenshotToBitmap([x,y,w,h])
   }

   static ScreenshotToBuffer(image) {
      ; Allow the image to be a window handle.
      if !IsObject(image) and WinExist(image) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &x, &y, &w, &h, image
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         image := [x, y, w, h]
      }




      ; Adjust coordinates relative to specified window.
      if image.Has(5) and WinExist(image[5]) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &xr, &yr,,, image[5]
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         image[1] += xr
         image[2] += yr
      }




      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",  image[3], bi,  4) ; Width
         NumPut(   "int", -image[4], bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Retrieve the device context for the screen.
      sdc := DllCall("GetDC", "ptr", 0, "ptr")

      ; Wrap the pointer to the pixels in a buffer object.
      buf := ImagePut.BitmapBuffer(pBits, 4 * image[3] * image[4], image[3], image[4])

      ; Copies a portion of the screen to a new device context.
      buf.draw := () => DllCall("gdi32\BitBlt"
               , "ptr", hdc, "int", 0, "int", 0, "int", image[3], "int", image[4]
               , "ptr", sdc, "int", image[1], "int", image[2], "uint", 0x00CC0020 | 0x40000000) ; SRCCOPY | CAPTUREBLT

      ; Draw the first frame.
      buf.Update()

      ; Cleanup!
      buf.free := () => (
         ; Release the device context to the screen.
         DllCall("ReleaseDC", "ptr", 0, "ptr", sdc),

         ; Cleanup the hBitmap and device contexts.
         DllCall("SelectObject", "ptr", hdc, "ptr", obm),
         DllCall("DeleteObject", "ptr", hbm),
         DllCall("DeleteDC",     "ptr", hdc)
      )

      return buf
   }

   static ScreenshotToBitmap(image) {
      ; Allow the image to be a window handle.
      if !IsObject(image) and WinExist(image) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &x, &y, &w, &h, image
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         image := [x, y, w, h]
      }




      ; Adjust coordinates relative to specified window.
      if image.Has(5) and WinExist(image[5]) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &xr, &yr,,, image[5]
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         image[1] += xr
         image[2] += yr
      }




      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",  image[3], bi,  4) ; Width
         NumPut(   "int", -image[4], bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Retrieve the device context for the screen.
      sdc := DllCall("GetDC", "ptr", 0, "ptr")

      ; Copies a portion of the screen to a new device context.
      DllCall("gdi32\BitBlt"
               , "ptr", hdc, "int", 0, "int", 0, "int", image[3], "int", image[4]
               , "ptr", sdc, "int", image[1], "int", image[2], "uint", 0x00CC0020 | 0x40000000) ; SRCCOPY | CAPTUREBLT

      ; Release the device context to the screen.
      DllCall("ReleaseDC", "ptr", 0, "ptr", sdc)

      ; Convert the hBitmap to a Bitmap using a built in function as there is no transparency.
      DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return pBitmap
   }

   static DesktopDuplicationToBuffer(image) {
      ; A correct monitor name must look like: \\.\DISPLAY1
      if image ~= "^(?!0+$)\d+$"
         image := MonitorGetName(image)

      ; Load DirectX Graphics Infrastructure 1.2+ and Direct3D 11.
      DllCall("GetModuleHandle", "str", "DXGI") || DllCall("LoadLibrary", "str", "DXGI")
      DllCall("GetModuleHandle", "str", "D3D11") || DllCall("LoadLibrary", "str", "D3D11")

      ; Create a DXGI factory.
      DllCall("ole32\IIDFromString", "wstr", "{770aae78-f26f-4dba-a829-253c83d1b387}", "ptr", IID_IDXGIFactory1 := Buffer(16), "hresult")
      DllCall("dxgi\CreateDXGIFactory1", "ptr", IID_IDXGIFactory1, "ptr*", &IDXGIFactory1:=0, "hresult")

      ; Find the correct adapter attached to the specified monitor. DXGI_ERROR_NOT_FOUND = 0x887A0002
      while (0x887A0002 != ComCall(EnumAdapters := 7, IDXGIFactory1, "uint", A_Index-1, "ptr*", &IDXGIAdapter:=0, "uint")) {
         while (0x887A0002 != ComCall(EnumOutputs := 7, IDXGIAdapter, "uint", A_Index-1, "ptr*", &IDXGIOutput:=0, "uint")) {

            ; Get the description of the adapter output.
            ComCall(GetDesc := 7, IDXGIOutput, "ptr", DXGI_OUTPUT_DESC := Buffer(88+A_PtrSize))
               DeviceName        := StrGet(DXGI_OUTPUT_DESC, 32, "UTF-16")
               AttachedToDesktop := NumGet(DXGI_OUTPUT_DESC, 80, "int")

            ; Match the specified monitor with its gpu adapter.
            if (AttachedToDesktop = 1 && DeviceName = image)
               goto AdapterFound

            ObjRelease(IDXGIOutput)
         }
         ObjRelease(IDXGIAdapter)
      }
      throw Error("Could not find a matching adapter for the Desktop Duplication API."
         . "`n" . "Note that only one Desktop Duplication can be active per process."
         . "`n" . "Laptops with hybrid graphics must have this process be running on the same GPU as the display.")

      AdapterFound:
      ; Creates a device that represents the display adapter.
      DllCall("D3D11\D3D11CreateDevice"
               ,    "ptr", IDXGIAdapter                 ; pAdapter
               ,    "int", D3D_DRIVER_TYPE_UNKNOWN := 0 ; DriverType
               ,    "ptr", 0                            ; Software
               ,   "uint", 0                            ; Flags
               ,    "ptr", 0                            ; pFeatureLevels
               ,   "uint", 0                            ; FeatureLevels
               ,   "uint", D3D11_SDK_VERSION := 7       ; SDKVersion
               ,   "ptr*", &ID3D11Device:=0             ; ppDevice
               ,   "ptr*", 0                            ; pFeatureLevel
               ,   "ptr*", &ID3D11DeviceContext:=0      ; ppImmediateContext
               ,"hresult")

      ; Cast to IDXGIOutput1 to access the Desktop Duplication API.
      IDXGIOutput1 := ComObjQuery(IDXGIOutput, "{00cddea8-939b-4b83-a340-a685226666cc}")
      ComCall(DuplicateOutput := 22, IDXGIOutput1, "ptr", ID3D11Device, "ptr*", &IDXGIOutputDuplication:=0)

      ; Get the description of the output. Currently doesn't account for rotation of the monitor...
      ComCall(GetDesc := 7, IDXGIOutputDuplication, "ptr", DXGI_OUTDUPL_DESC := Buffer(36))
         width := NumGet(DXGI_OUTDUPL_DESC,  0, "uint")
         height := NumGet(DXGI_OUTDUPL_DESC,  4, "uint")
         DesktopImageInSystemMemory := NumGet(DXGI_OUTDUPL_DESC, 32, "uint")
      ; Sleep 50 ; (AutoHotkey v1 only) As I understand - need some sleep for successful connecting to IDXGIOutputDuplication interface

      ; Creates a CPU accessable texture called as a staging texture.
      D3D11_TEXTURE2D_DESC := Buffer(44, 0)
         NumPut("uint",                            width, D3D11_TEXTURE2D_DESC,  0)   ; Width
         NumPut("uint",                           height, D3D11_TEXTURE2D_DESC,  4)   ; Height
         NumPut("uint",                                1, D3D11_TEXTURE2D_DESC,  8)   ; MipLevels
         NumPut("uint",                                1, D3D11_TEXTURE2D_DESC, 12)   ; ArraySize
         NumPut("uint", DXGI_FORMAT_B8G8R8A8_UNORM := 87, D3D11_TEXTURE2D_DESC, 16)   ; Format
         NumPut("uint",                                1, D3D11_TEXTURE2D_DESC, 20)   ; SampleDescCount
         NumPut("uint",                                0, D3D11_TEXTURE2D_DESC, 24)   ; SampleDescQuality
         NumPut("uint",         D3D11_USAGE_STAGING := 3, D3D11_TEXTURE2D_DESC, 28)   ; Usage
         NumPut("uint",                                0, D3D11_TEXTURE2D_DESC, 32)   ; BindFlags
         NumPut("uint", D3D11_CPU_ACCESS_READ := 0x20000, D3D11_TEXTURE2D_DESC, 36)   ; CPUAccessFlags
         NumPut("uint",                                0, D3D11_TEXTURE2D_DESC, 40)   ; MiscFlags
      ComCall(CreateTexture2D := 5, ID3D11Device, "ptr", D3D11_TEXTURE2D_DESC, "ptr", 0, "ptr*", &staging_texture:=0)

      buf := ImagePut.DesktopDuplicationBuffer()
      buf.width := width
      buf.height := height
      buf.DesktopImageInSystemMemory := DesktopImageInSystemMemory

      buf.staging_texture := staging_texture
      buf.IDXGIOutputDuplication := IDXGIOutputDuplication
      buf.ID3D11DeviceContext := ID3D11DeviceContext
      buf.ID3D11Device := ID3D11Device
      buf.IDXGIOutput1 := IDXGIOutput1
      buf.IDXGIOutput := IDXGIOutput
      buf.IDXGIAdapter := IDXGIAdapter
      buf.IDXGIFactory1 := IDXGIFactory1

      buf.Update()

      return buf
   }

   class DesktopDuplicationBuffer extends ImagePut.BitmapBuffer { ; Extending is optional!
      Update(timeout := unset) {

         ; Reset the timeout error state.
         this.timeout := False

         ; Release the current frame to acquire a new frame.
         this.Unbind()

         ; The following loop structure repeatedly checks for a new frame.
         loop {
            ; Ask if there is a new frame available immediately.
            try ComCall(AcquireNextFrame := 8, this.IDXGIOutputDuplication, "uint", timeout ?? 0, "ptr", DXGI_OUTDUPL_FRAME_INFO := Buffer(48), "ptr*", &desktop_resource:=0)
            catch OSError as e
               if e.number = 0x887A0027 ; DXGI_ERROR_WAIT_TIMEOUT
                  if IsSet(timeout) {
                     this.timeout := True
                     return this ; Note: The bitmap is in an invalid state. However, it has already been cached by BitmapBuffer.
                  } else
                     continue
               else throw

            ; Exclude mouse movement events by ensuring LastPresentTime is greater than zero.
            if NumGet(DXGI_OUTDUPL_FRAME_INFO, 0, "int64") > 0
               goto FrameAcquired

            ; If the frame is not new, return the existing frame when a timeout is set.
            else if IsSet(timeout)
               goto FrameAcquired

            ; Otherwise, continue the loop to search for a new frame.
            ObjRelease(desktop_resource)
            ComCall(ReleaseFrame := 14, this.IDXGIOutputDuplication)
         }

         FrameAcquired:
         this.desktop_resource := desktop_resource

         ; Maybe the laptop uses a unified RAM for the CPU and the GPU?
         if (this.DesktopImageInSystemMemory = 1) {
            ComCall(MapDesktopSurface := 12, this.IDXGIOutputDuplication, "ptr", DXGI_MAPPED_RECT := Buffer(A_PtrSize*2, 0))
            pitch := NumGet(DXGI_MAPPED_RECT, 0, "int")
            pBits := NumGet(DXGI_MAPPED_RECT, A_PtrSize, "ptr")
         }
         else {
            tex := ComObjQuery(this.desktop_resource, "{6f15aaf2-d208-4e89-9ab4-489535d34f9c}") ; ID3D11Texture2D
            ComCall(CopyResource := 47, this.ID3D11DeviceContext, "ptr", this.staging_texture, "ptr", tex)
            ComCall(_Map := 14, this.ID3D11DeviceContext, "ptr", this.staging_texture, "uint", 0, "uint", D3D11_MAP_READ := 1, "uint", 0, "ptr", D3D11_MAPPED_SUBRESOURCE := Buffer(8+A_PtrSize, 0))
            pBits := NumGet(D3D11_MAPPED_SUBRESOURCE, 0, "ptr")
            pitch := NumGet(D3D11_MAPPED_SUBRESOURCE, A_PtrSize, "uint")
            ; (v1 only) ObjRelease(tex)
         }
         this.ptr := pBits
         this.size := pitch * this.height

         return this
      }

      Unbind() {
         if this.HasProp("desktop_resource") {
            ObjRelease(this.desktop_resource)
            ComCall(ReleaseFrame := 14, this.IDXGIOutputDuplication)
            this.DeleteProp("desktop_resource")
         }

         if this.HasProp("ptr") && this.HasProp("size") {
            if (this.DesktopImageInSystemMemory = 1)
               ComCall(UnMapDesktopSurface := 13, this.IDXGIOutputDuplication)
            else
               ComCall(Unmap := 15, this.ID3D11DeviceContext, "ptr", this.staging_texture, "uint", 0)
            this.DeleteProp("ptr")
            this.DeleteProp("size")
         }
      }

      Cleanup() {
         this.Unbind()
         ObjRelease(this.staging_texture)
         ObjRelease(this.IDXGIOutputDuplication)
         ObjRelease(this.ID3D11DeviceContext)
         ObjRelease(this.ID3D11Device)
         this.IDXGIOutput1 := ""
         ObjRelease(this.IDXGIOutput)
         ObjRelease(this.IDXGIAdapter)
         ObjRelease(this.IDXGIFactory1)
      }
   }

   static WindowToBitmap(image) {
      ; Thanks tic - https://www.autohotkey.com/boards/viewtopic.php?t=6517

      ; Get the handle to the window.
      image := WinExist(image)

      ; Test whether keystrokes can be sent to this window using a reserved virtual key code.
      try PostMessage WM_KEYDOWN := 0x100, 0x88,,, image
      catch OSError
         throw Error("Administrator privileges are required to capture the window.")
      PostMessage WM_KEYUP := 0x101, 0x88, 0xC0000000,, image

      ; Restore the window if minimized! Must be visible for capture.
      if DllCall("IsIconic", "ptr", image)
         DllCall("ShowWindow", "ptr", image, "int", 4)

      ; Get the width and height of the client window.
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      DllCall("GetClientRect", "ptr", image, "ptr", rect := Buffer(16)) ; sizeof(rect) = 16
         , width  := NumGet(rect, 8, "int")
         , height := NumGet(rect, 12, "int")
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Print the window onto the hBitmap using an undocumented flag. https://stackoverflow.com/a/40042587
      DllCall("user32\PrintWindow", "ptr", image, "ptr", hdc, "uint", 0x3) ; PW_RENDERFULLCONTENT | PW_CLIENTONLY
      ; Additional info on how this is implemented: https://www.reddit.com/r/windows/comments/8ffr56/altprintscreen/

      ; Convert the hBitmap to a Bitmap using a built in function as there is no transparency.
      DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return pBitmap
   }

   static DesktopToBitmap() {
      windows := WinGetList("ahk_class WorkerW")
      if (windows.length == 0)
         throw Error("The hidden desktop window has not been initalized. Call ImagePutDesktop() first.")

      ; Find a child window of class SHELLDLL_DefView.

      for window in WinGetList("ahk_class WorkerW")
         if DllCall("FindWindowEx", "ptr", window, "ptr", 0, "str", "SHELLDLL_DefView", "ptr", 0) {
            hwnd := window
            break
         }

      ; Find a child window of the desktop after the previous window of class WorkerW.
      if !(WorkerW := DllCall("FindWindowEx", "ptr", 0, "ptr", hwnd, "str", "WorkerW", "ptr", 0, "ptr"))
         throw Error("Could not locate hidden window behind desktop icons.")

      ; Returns the first child window of the WorkerW window.
      if !(child := DllCall("FindWindowEx", "ptr", WorkerW, "ptr", 0, "ptr", 0, "ptr", 0))
         throw Error("No child windows are attached to the hidden desktop window.")

      ; Use PrintWindow as the window is overlapped by other windows. Could use BitBlt on dc?
      return this.WindowToBitmap(child)
   }

   static WallpaperToBitmap() {
      ; Get the width and height of all monitors.
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      width  := DllCall("GetSystemMetrics", "int", 78, "int")
      height := DllCall("GetSystemMetrics", "int", 79, "int")
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Paints the wallpaper.
      DllCall("user32\PaintDesktop", "ptr", hdc)

      ; Convert the hBitmap to a Bitmap using a built in function as there is no transparency.
      DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hbm, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return pBitmap
   }

   static CursorToBitmap() {
      ; Thanks 23W - https://stackoverflow.com/a/13295280

      ; struct CURSORINFO - https://docs.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-cursorinfo
      ci := Buffer(16+A_PtrSize, 0) ; sizeof(CURSORINFO) = 20, 24
         NumPut("int", ci.size, ci)
      DllCall("GetCursorInfo", "ptr", ci)
         ; cShow   := NumGet(ci,  4, "int") ; 0x1 = CURSOR_SHOWING, 0x2 = CURSOR_SUPPRESSED
         , hCursor := NumGet(ci,  8, "ptr")
         ; xCursor := NumGet(ci,  8+A_PtrSize, "int")
         ; yCursor := NumGet(ci, 12+A_PtrSize, "int")

      ; Cursors are the same as icons!
      pBitmap := this.HIconToBitmap(hCursor)

      ; Cleanup the handle to the cursor. Same as DestroyIcon.
      DllCall("DestroyCursor", "ptr", hCursor)

      return pBitmap
   }

   static URLToBitmap(image) {
      stream := this.URLToStream(image)
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static URLToStream(image) {
      req := ComObject("WinHttp.WinHttpRequest.5.1")
      req.Open("GET", image, True)
      req.Send()
      req.WaitForResponse()
      IStream := ComObjQuery(req.ResponseStream, "{0000000C-0000-0000-C000-000000000046}"), ObjAddRef(IStream.ptr)
      return IStream.ptr
   }

   static FileToBitmap(image) {
      stream := this.FileToStream(image) ; Faster than GdipCreateBitmapFromFile and does not lock the file.
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static FileToStream(image) {
      file := FileOpen(image, "r")
      file.pos := 0
      handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", file.length, "ptr")
      ptr := DllCall("GlobalLock", "ptr", handle, "ptr")
      file.RawRead(ptr, file.length)
      DllCall("GlobalUnlock", "ptr", handle)
      file.Close()
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", True, "ptr*", &stream:=0, "hresult")
      return stream
   }

   static HexToBitmap(image) {
      stream := this.HexToStream(image)
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static HexToStream(image) {
      ; Trim whitespace and remove hexadecimal indicator.
      image := Trim(image)
      image := RegExReplace(image, "^(0[xX])")

      ; Retrieve the size of bytes from the length of the hex string.
      size := StrLen(image) / 2
      handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", size, "ptr")
      bin := DllCall("GlobalLock", "ptr", handle, "ptr")

      ; Place the decoded hex string into a binary buffer.
      flags := 0xC ; CRYPT_STRING_HEXRAW
      DllCall("crypt32\CryptStringToBinary", "str", image, "uint", 0, "uint", flags, "ptr", bin, "uint*", size, "ptr", 0, "ptr", 0)

      ; Returns a stream that release the handle on ObjRelease().
      DllCall("GlobalUnlock", "ptr", handle)
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", True, "ptr*", &stream:=0, "hresult")
      return stream
   }

   static Base64ToBitmap(image) {
      stream := this.Base64ToStream(image)
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static Base64ToStream(image) {
      ; Trim whitespace and remove mime type.
      image := Trim(image)
      image := RegExReplace(image, "(?i)^data:image\/[a-z]+;base64,")

      ; Retrieve the size of bytes from the length of the base64 string.
      size := StrLen(RTrim(image, "=")) * 3 // 4
      handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", size, "ptr")
      bin := DllCall("GlobalLock", "ptr", handle, "ptr")

      ; Place the decoded base64 string into a binary buffer.
      flags := 0x1 ; CRYPT_STRING_BASE64
      DllCall("crypt32\CryptStringToBinary", "str", image, "uint", 0, "uint", flags, "ptr", bin, "uint*", size, "ptr", 0, "ptr", 0)

      ; Returns a stream that release the handle on ObjRelease().
      DllCall("GlobalUnlock", "ptr", handle)
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", True, "ptr*", &stream:=0, "hresult")
      return stream
   }

   static DCToBitmap(image) {
      ; An application cannot select a single bitmap into more than one DC at a time.
      if !(sbm := DllCall("GetCurrentObject", "ptr", image, "uint", 7))
         throw Error("The device context has no bitmap selected.")

      ; struct DIBSECTION - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-dibsection
      ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
      dib := Buffer(64+5*A_PtrSize) ; sizeof(DIBSECTION) = 84, 104
      DllCall("GetObject", "ptr", sbm, "int", dib.size, "ptr", dib)
         , width  := NumGet(dib, 4, "uint")
         , height := NumGet(dib, 8, "uint")
         , bpp    := NumGet(dib, 18, "ushort")
         , pBits  := NumGet(dib, A_PtrSize = 4 ? 20:24, "ptr")

      ; Fallback to built-in method if pixels are not 32-bit ARGB or hBitmap is a device dependent bitmap.
      if (pBits = 0 || bpp != 32) { ; This built-in version is 120% faster but ignores transparency.
         DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", sbm, "ptr", 0, "ptr*", &pBitmap:=0)
         return pBitmap
      }

      ; Create a device independent bitmap with negative height. All DIBs use the screen pixel format (pARGB).
      ; Use hbm to buffer the image such that top-down and bottom-up images are mapped to this top-down buffer.
      ; pBits is the pointer to (top-down) pixel values. The Scan0 will point to the pBits.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Create a destination GDI+ Bitmap that owns its memory to receive the final converted pixels. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 6c) Prepare to copy pixels from pBits (pARGB) into the GDI+ Bitmap (ARGB).
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
               ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.

      ; Copies the image (hBitmap) to a top-down bitmap. Removes bottom-up-ness if present.
      DllCall("gdi32\BitBlt"
               , "ptr", hdc, "int", 0, "int", 0, "int", width, "int", height
               , "ptr", image, "int", 0, "int", 0, "uint", 0x00CC0020) ; SRCCOPY

      ; Convert the pARGB pixels copied into the device independent bitmap (hbm) to ARGB.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return pBitmap
   }

   static HBitmapToBitmap(image) {
      ; Thanks Florence - https://discord.com/channels/115993023636176902/1258513077679292517

      ; struct DIBSECTION - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-dibsection
      ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
      dib := Buffer(64+5*A_PtrSize) ; sizeof(DIBSECTION) = 84, 104
      DllCall("GetObject", "ptr", image, "int", dib.size, "ptr", dib)
         , width  := NumGet(dib, 4, "uint")
         , height := NumGet(dib, 8, "uint")
         , bpp    := NumGet(dib, 18, "ushort")
         , pBits  := NumGet(dib, A_PtrSize = 4 ? 20:24, "ptr")

      ; Fallback to built-in method if pixels are not 32-bit ARGB or hBitmap is a device dependent bitmap.
      if (pBits = 0 || bpp != 32) { ; This built-in version is 120% faster but ignores transparency.
         DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", image, "ptr", 0, "ptr*", &pBitmap:=0)
         return pBitmap
      }

      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",         1, bi,  4) ; Width
         NumPut(   "int",        -1, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel

      ; Test a single pixel to determine if the image is top-down or bottom-up.
      bottomup := True
      ARGB_0 := NumGet(pBits, "uint")         ; Backup the original pixel
      NumPut("uint", 0xB0BA1234, pBits)       ; Test first pixel
      DllCall("GetDIBits", "ptr", hdc, "ptr", image, "uint", 0, "uint", 1, "uint*", &ARGB_1:=0, "ptr", bi, "uint", 0)
      if (ARGB_1 == 0xB0BA1234) {             ; Could be by pure coincidence
         NumPut("uint", 0xDECADEB4, pBits)    ; Test second pixel
         DllCall("GetDIBits", "ptr", hdc, "ptr", image, "uint", 0, "uint", 1, "uint*", &ARGB_2:=0, "ptr", bi, "uint", 0)
         if (ARGB_2 == 0xDECADEB4)
            bottomup := False
      }
      NumPut("uint", ARGB_0, pBits)           ; Restore the original pixel
      DllCall("DeleteDC", "ptr", hdc)         ; Device Context was for palette matching

      ; pBits is the pointer to the start of the pixel data. The Scan0 points to the top-left pixel.
      stride := (-1)**(bottomup) * Ceil(width * bpp / 32) * 4 ; Round up to the next 4 byte boundary
      Scan0 := (bottomup) ? pBits - (height-1)*stride : pBits ; Points to the first scanline (horizontal row)

      ; Create a destination GDI+ Bitmap that owns its memory to receive the final converted pixels. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 6c) Prepare to copy pixels from pBits (pARGB) into the GDI+ Bitmap (ARGB).
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",     stride, BitmapData,  8) ; Stride
         NumPut(   "ptr",      Scan0, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
               ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.

      ; Convert pBits (pARGB) pixel data from the hBitmap into the pBitmap (ARGB).
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      return pBitmap
   }

   static HIconToBitmap(image) {
      ; struct ICONINFO - https://docs.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-iconinfo
      ii := Buffer(8+3*A_PtrSize)                       ; sizeof(ICONINFO) = 20, 32
      DllCall("GetIconInfo", "ptr", image, "ptr", ii)
         ; xHotspot := NumGet(ii, 4, "uint")
         ; yHotspot := NumGet(ii, 8, "uint")
         , hbmMask  := NumGet(ii, 8+A_PtrSize, "ptr")   ; 12, 16
         , hbmColor := NumGet(ii, 8+2*A_PtrSize, "ptr") ; 16, 24

      ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
      bm := Buffer(16+2*A_PtrSize)                      ; sizeof(BITMAP) = 24, 32
      DllCall("GetObject", "ptr", hbmMask, "int", bm.size, "ptr", bm)
         , width  := NumGet(bm, 4, "uint")
         , height := NumGet(bm, 8, "uint") / (hbmColor ? 1 : 2) ; Black and White cursors have doubled height.

      ; Clean up these hBitmaps.
      DllCall("DeleteObject", "ptr", hbmMask)
      DllCall("DeleteObject", "ptr", hbmColor)

      ; Create a device independent bitmap with negative height. All DIBs use the screen pixel format (pARGB).
      ; Use hbm to buffer the image such that top-down and bottom-up images are mapped to this top-down buffer.
      ; pBits is the pointer to (top-down) pixel values. The Scan0 will point to the pBits.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Create a destination GDI+ Bitmap that owns its memory to receive the final converted pixels. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 6c) Prepare to copy pixels from pBits (pARGB) into the GDI+ Bitmap (ARGB).
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
               ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.

      ; Don't use DI_DEFAULTSIZE to draw the icon like DrawIcon does as it will resize to 32 x 32.
      DllCall("user32\DrawIconEx"
               , "ptr", hdc,   "int", 0, "int", 0
               , "ptr", image, "int", 0, "int", 0
               , "uint", 0, "ptr", 0, "uint", 0x1 | 0x2 | 0x4) ; DI_MASK | DI_IMAGE | DI_COMPAT

      ; Convert the pARGB pixels copied into the device independent bitmap (hbm) to ARGB.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return pBitmap
   }

   static BitmapToBitmap(image) {
      ; Clone and retain a reference to the backing stream.
      DllCall("gdiplus\GdipCloneImage", "ptr", image, "ptr*", &pBitmap:=0)
      return pBitmap
   }

   static StreamToBitmap(image) {
      stream := this.StreamToStream(image) ; Below adds +3 references and seeks to 4096.
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static StreamToStream(image) {
      ; Creates a new, separate stream. Necessary to separate reference counting through a clone.
      ComCall(Clone := 13, image, "ptr*", &stream:=0)
      ; Ensures that a duplicated stream does not inherit the original seek position.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      return stream
   }

   static RandomAccessStreamToBitmap(image) {
      stream := this.RandomAccessStreamToStream(image) ; Below adds +3 to the reference count.
      DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
      ObjRelease(stream)
      return pBitmap
   }

   static RandomAccessStreamToStream(image) {
      ; CreateStreamOverRandomAccessStream returns the original wrapped IStream.
      ; Deceptively, the seek position is reset to zero by CreateStreamOverRandomAccessStream.
      ; The returned IStream shares a seek position and reference count with the original IStream.
      DllCall("ole32\IIDFromString", "wstr", "{0000000C-0000-0000-C000-000000000046}", "ptr", IID_IStream := Buffer(16), "hresult")
      DllCall("shcore\CreateStreamOverRandomAccessStream", "ptr", image, "ptr", IID_IStream, "ptr*", &IStream:=0, "hresult")
      ComCall(Clone := 13, IStream, "ptr*", &stream:=0)
      ObjRelease(IStream)
      return stream
   }

   static WICBitmapToBitmap(image) {
      IWICBitmap := image

      ; Get Bitmap width and height.
      ComCall(GetSize := 3, IWICBitmap, "uint*", &width:=0, "uint*", &height:=0)

      ; Create a destination GDI+ Bitmap that owns its memory. The pixel format is 32-bit ARGB.
      DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", width, "int", height, "int", 0, "int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; Check if the pixel format needs to be converted.
      ComCall(GetPixelFormat := 4, image, "ptr", format := Buffer(16))
      DllCall("ole32\CLSIDFromString", "wstr", "{6fddc324-4e03-4bfe-b185-3d77768dc90f}", "ptr", GUID_WICPixelFormat32bppBGRA := Buffer(16), "hresult")
      convert :=  16 != DllCall("RtlCompareMemory", "ptr", format, "ptr", GUID_WICPixelFormat32bppBGRA, "uptr", 16)

      ; Case 1: Convert the pixel format to 32-bit ARGB. Preforms 2 memory copies.
      if (convert) {
         ; Create a 32-bit ARGB IWICBitmapSource.
         DllCall("windowscodecs\WICConvertBitmapSource", "ptr", GUID_WICPixelFormat32bppBGRA, "ptr", IWICBitmap, "ptr*", &IWICBitmapSource:=0, "hresult")

         ; (Type 2) Allocate a temporary pixel buffer to be copied into the GDI+ Bitmap.
         BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         DllCall("gdiplus\GdipBitmapLockBits"
                  ,    "ptr", pBitmap
                  ,    "ptr", rect
                  ,   "uint", 2            ; ImageLockMode.WriteOnly
                  ,    "int", 0x26200A     ; Buffer: Format32bppArgb
                  ,    "ptr", BitmapData)
         ptr := NumGet(BitmapData, 16, "ptr")
         stride := NumGet(BitmapData, 8, "int")

         ; Write from the IWICBitmapSource to the temporary pixel buffer.
         ComCall(CopyPixels := 7, IWICBitmapSource, "ptr", rect, "uint", stride, "uint", stride * height, "ptr", ptr)

         ; Copy pixels into the GDI+ Bitmap and free the pixel buffer.
         DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

         ; Cleanup!
         ObjRelease(IWICBitmapSource)
      }

      ; Case 2: Access the underlying pixels directly. Preforms 1 memory copy.
      else {
         ; Lock the WIC bitmap to access to its pixel data.
         ComCall(Lock := 8, IWICBitmap, "ptr", rect, "uint", 0x1, "ptr*", &IWICBitmapLock:=0)
         ComCall(GetDataPointer := 5, IWICBitmapLock, "uint*", &size:=0, "ptr*", &ptr:=0)
         ComCall(GetStride := 4, IWICBitmapLock, "uint*", &stride:=0)

         ; (Type 6) Copy external pixels into the GDI+ Bitmap.
         BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
            NumPut(   "int",     stride, BitmapData,  8) ; Stride
            NumPut(   "ptr",        ptr, BitmapData, 16) ; Scan0
         DllCall("gdiplus\GdipBitmapLockBits"
                  ,    "ptr", pBitmap
                  ,    "ptr", rect
                  ,   "uint", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
                  ,    "int", 0x26200A     ; Buffer: Format32bppArgb
                  ,    "ptr", BitmapData)  ; Contains the pointer (ptr) to the IWICBitmap.
         DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

         ; Cleanup!
         ObjRelease(IWICBitmapLock)
      }

      return pBitmap
   }

   static BitmapToClipboard(pBitmap) {
      ; Standard Clipboard Formats - https://www.codeproject.com/Reference/1091137/Windows-Clipboard-Formats
      ; Synthesized Clipboard Formats - https://docs.microsoft.com/en-us/windows/win32/dataxchg/clipboard-formats

      ; Open the clipboard with exponential backoff.
      loop
         if DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            break
         else
            if A_Index < 6
               Sleep (2**(A_Index-1) * 30)
            else throw Error("Clipboard could not be opened.")

      ; Requires a valid window handle via OpenClipboard or the next call to OpenClipboard will crash.
      DllCall("EmptyClipboard")

      ; #1 - PNG holds the transparency and is the most widely supported image format.
      ; Thanks Jochen Arndt - https://www.codeproject.com/Answers/1207927/Saving-an-image-to-the-clipboard#answer3
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", False, "ptr*", &stream:=0, "hresult")
      DllCall("ole32\CLSIDFromString", "wstr", "{557CF406-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec := Buffer(16), "hresult")
      DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", stream, "ptr", pCodec, "ptr", 0)
      DllCall("ole32\GetHGlobalFromStream", "ptr", stream, "uint*", &handle:=0, "hresult")
      ObjRelease(stream)

      ; Set the clipboard data with the case insensitive identifier png.
      png := DllCall("RegisterClipboardFormat", "str", "png", "uint")
      DllCall("SetClipboardData", "uint", png, "ptr", handle)
      ; GlobalFree will be called when the clipboard is emptied.


      ; #2 - Fallback to the CF_DIB format (bottom-up bitmap) for maximum compatibility.
      ; Note: Bottom-up is assumed by EVERY APPLICATION. A top-down bitmap will be upaide down.
      DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", pBitmap, "ptr*", &hbm:=0, "uint", 0)

      ; struct DIBSECTION - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-dibsection
      ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
      dib := Buffer(64+5*A_PtrSize) ; sizeof(DIBSECTION) = 84, 104
      DllCall("GetObject", "ptr", hbm, "int", dib.size, "ptr", dib)
         , pBits := NumGet(dib, A_PtrSize = 4 ? 20:24, "ptr")  ; bmBits
         , size  := NumGet(dib, A_PtrSize = 4 ? 44:52, "uint") ; biSizeImage

      ; Allocate space for a new device independent bitmap on movable memory.
      hdib := DllCall("GlobalAlloc", "uint", 0x2, "uptr", 40 + size, "ptr") ; sizeof(BITMAPINFOHEADER) = 40
      pdib := DllCall("GlobalLock", "ptr", hdib, "ptr")

      ; Copy the BITMAPINFOHEADER and pixel data respectively.
      DllCall("RtlMoveMemory", "ptr", pdib, "ptr", dib.ptr + (A_PtrSize = 4 ? 24:32), "uptr", 40)
      DllCall("RtlMoveMemory", "ptr", pdib+40, "ptr", pBits, "uptr", size)

      ; Unlock to moveable memory because the clipboard requires it.
      DllCall("GlobalUnlock", "ptr", hdib)

      ; CF_DIB (8) can be synthesized into CF_DIBV5 (17) or CF_BITMAP (2) with delayed rendering.
      DllCall("SetClipboardData", "uint", 8, "ptr", hdib)

      ; GlobalFree will be called when the clipboard is emptied.
      DllCall("DeleteObject", "ptr", hbm)

      ; Close the clipboard.
      DllCall("CloseClipboard")

      ; Honestly why would the user use this return value? Use a sentinel instead.
      return ClipboardAll
   }

   static StreamToClipboard(stream) {
      ; 2048 characters should be good enough to identify the file correctly.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      size := min(size, 2048)
      bin := Buffer(size)

      ; Get the first few bytes of the image.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Allocate enough space for a hexadecimal string with spaces interleaved and a null terminator.
      length := 2*size + (size-1) + 1
      VarSetStrCapacity(&str, length)

      ; Lift the binary representation to hex.
      flags := 0x40000004 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_HEX
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Determine the extension using herustics. See: http://fileformats.archiveteam.org
      extension := 0                                                              ? ""
      : str ~= "(?i)66 74 79 70 61 76 69 66"                                      ? "avif" ; ftypavif
      : str ~= "(?i)^42 4d (.. ){36}00 00 .. 00 00 00"                            ? "bmp"  ; BM
      : str ~= "(?i)^01 00 00 00 (.. ){36}20 45 4D 46"                            ? "emf"  ; emf
      : str ~= "(?i)^47 49 46 38 (37|39) 61"                                      ? "gif"  ; GIF87a or GIF89a
      : str ~= "(?i)66 74 79 70 68 65 69 63"                                      ? "heic" ; ftypheic
      : str ~= "(?i)^00 00 01 00"                                                 ? "ico"
      : str ~= "(?i)^ff d8 ff"                                                    ? "jpg"
      : str ~= "(?i)^25 50 44 46 2d"                                              ? "pdf"  ; %PDF-
      : str ~= "(?i)^89 50 4e 47 0d 0a 1a 0a"                                     ? "png"  ; PNG
      : str ~= "(?i)^(((?!3c|3e).. )|3c (3f|21) ((?!3c|3e).. )*3e )*+3c 73 76 67" ? "svg"  ; <svg
      : str ~= "(?i)^(49 49 2a 00|4d 4d 00 2a)"                                   ? "tif"  ; II* or MM*
      : str ~= "(?i)^52 49 46 46 .. .. .. .. 57 45 42 50"                         ? "webp" ; RIFF....WEBP
      : str ~= "(?i)^d7 cd c6 9a"                                                 ? "wmf"
      : "" ; Extension must be blank for file pass-through as-is.

      ; Open the clipboard with exponential backoff.
      loop
         if DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
            break
         else
            if A_Index < 6
               Sleep (2**(A_Index-1) * 30)
            else throw Error("Clipboard could not be opened.")

      ; Requires a valid window handle via OpenClipboard or the next call to OpenClipboard will crash.
      DllCall("EmptyClipboard")

      ; #1 - Save PNG directly to the clipboard.
      if (extension = "png") {
         ; Clone the stream. Can't use IStream::Clone because the cloned stream must be released.
         DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
         handle := DllCall("GlobalAlloc", "uint", 0x2, "uptr", size, "ptr")
         DllCall("ole32\CreateStreamOnHGlobal", "ptr", handle, "int", False, "ptr*", &ClonedStream:=0, "hresult")
         DllCall("shlwapi\IStream_Copy", "ptr", stream, "ptr", ClonedStream, "uint", size, "hresult")
         DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
         ObjRelease(ClonedStream)

         png := DllCall("RegisterClipboardFormat", "str", "png", "uint") ; case insensitive
         DllCall("SetClipboardData", "uint", png, "ptr", handle)
      }

      ; #2 - Fallback to (8) CF_DIB format (bottom-up bitmap) for maximum compatibility.
      if (extension ~= "^(?i:avif|bmp|emf|gif|heic|ico|jpg|png|tif|webp|wmf)$") {
         ; Convert decodable formats into a DIB.
         DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "ptr", stream, "ptr*", &pBitmap:=0)
         DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", pBitmap, "ptr*", &hbm:=0, "uint", 0)
         DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
         DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

         ; struct DIBSECTION - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-dibsection
         ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
         dib := Buffer(64+5*A_PtrSize) ; sizeof(DIBSECTION) = 84, 104
         DllCall("GetObject", "ptr", hbm, "int", dib.size, "ptr", dib)
            , pBits := NumGet(dib, A_PtrSize = 4 ? 20:24, "ptr")  ; bmBits
            , size  := NumGet(dib, A_PtrSize = 4 ? 44:52, "uint") ; biSizeImage

         ; Allocate space for a new device independent bitmap on movable memory.
         hdib := DllCall("GlobalAlloc", "uint", 0x2, "uptr", 40 + size, "ptr") ; sizeof(BITMAPINFOHEADER) = 40
         pdib := DllCall("GlobalLock", "ptr", hdib, "ptr")

         ; Copy the BITMAPINFOHEADER and pixel data respectively.
         DllCall("RtlMoveMemory", "ptr", pdib, "ptr", dib.ptr + (A_PtrSize = 4 ? 24:32), "uptr", 40)
         DllCall("RtlMoveMemory", "ptr", pdib+40, "ptr", pBits, "uptr", size)

         ; Unlock to moveable memory because the clipboard requires it.
         DllCall("GlobalUnlock", "ptr", hdib)

         ; CF_DIB (8) can be synthesized into CF_DIBV5 (17) or CF_BITMAP (2) with delayed rendering.
         DllCall("SetClipboardData", "uint", 8, "ptr", hdib)

         ; GlobalFree will be called when the clipboard is emptied.
         DllCall("DeleteObject", "ptr", hbm)
      }

      ; #3 - Copy other formats to a file and pass a (15) DROPFILES struct.
      if (extension) {
         filepath := A_Temp "\ImagePut\clipboard." extension
         filepath := RTrim(filepath, ".") ; Remove trailing periods.
         DirCreate(A_Temp "\ImagePut")

         ; For compatibility with SHCreateMemStream do not use GetHGlobalFromStream.
         DllCall("shlwapi\SHCreateStreamOnFileEx"
                  ,   "wstr", filepath
                  ,   "uint", 0x1001          ; STGM_CREATE | STGM_WRITE
                  ,   "uint", 0x80            ; FILE_ATTRIBUTE_NORMAL
                  ,    "int", True            ; fCreate is ignored when STGM_CREATE is set.
                  ,    "ptr", 0               ; pstmTemplate (reserved)
                  ,   "ptr*", &FileStream:=0
                  ,"hresult")
         DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
         DllCall("shlwapi\IStream_Copy", "ptr", stream, "ptr", FileStream, "uint", size, "hresult")
         DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
         ObjRelease(FileStream)

         ; struct DROPFILES - https://learn.microsoft.com/en-us/windows/win32/api/shlobj_core/ns-shlobj_core-dropfiles
         nDropFiles := 20 + StrPut(filepath, "UTF-16") + 2 ; triple/quadruple null terminated
         hDropFiles := DllCall("GlobalAlloc", "uint", 0x42, "uptr", nDropFiles, "ptr")
         pDropFiles := DllCall("GlobalLock", "ptr", hDropFiles, "ptr")
            NumPut("uint", 20, pDropFiles + 0) ; pFiles
            NumPut("uint", 1, pDropFiles + 16) ; fWide
            StrPut(filepath, pDropFiles + 20, "UTF-16")
         DllCall("GlobalUnlock", "ptr", hDropFiles)

         ; Set the file to the clipboard as a shared object.
         DllCall("SetClipboardData", "uint", 15, "ptr", hDropFiles)
      }

      ; Close the clipboard.
      DllCall("CloseClipboard")

      ; Honestly why would the user use this return value? Use a sentinel instead.
      return ClipboardAll
   }

   static BitmapToSafeArray(pBitmap, extension := "", quality := "") {
      ; Thanks tmplinshi - https://www.autohotkey.com/boards/viewtopic.php?p=354007#p354007
      stream := this.BitmapToStream(pBitmap, extension, quality) ; Defaults to PNG for small sizes!

      ; Get a pointer to binary data.
      DllCall("ole32\GetHGlobalFromStream", "ptr", stream, "ptr*", &handle:=0, "hresult")
      bin := DllCall("GlobalLock", "ptr", handle, "ptr")
      size := DllCall("GlobalSize", "ptr", handle, "uptr")

      ; Copy the encoded image to a SAFEARRAY.
      safearray := ComObjArray(0x11, size) ; VT_UI1
      pvData := NumGet(ComObjValue(safearray), 8 + A_PtrSize, "ptr")
      DllCall("RtlMoveMemory", "ptr", pvData, "ptr", bin, "uptr", size)

      ; Release the IStream and call GlobalFree.
      DllCall("GlobalUnlock", "ptr", handle)
      ObjRelease(stream)

      return safearray
   }

   static StreamToSafeArray(stream) {
      ; Allocate a one-dimensional SAFEARRAY based on the size of the stream.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      safearray := ComObjArray(0x11, size) ; VT_UI1
      pvData := NumGet(ComObjValue(safearray), 8 + A_PtrSize, "ptr")

      ; Copy the stream to the SAFEARRAY.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", pvData, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      return safearray
   }

   static BitmapToEncodedBuffer(pBitmap, extension := "", quality := "") {
      stream := this.BitmapToStream(pBitmap, extension, quality) ; Defaults to PNG for small sizes!

      ; Get a pointer to binary data.
      DllCall("ole32\GetHGlobalFromStream", "ptr", stream, "ptr*", &handle:=0, "hresult")
      bin := DllCall("GlobalLock", "ptr", handle, "ptr")
      size := DllCall("GlobalSize", "ptr", handle, "uptr")

      ; Copy data into a buffer.
      buf := Buffer(size)
      DllCall("RtlMoveMemory", "ptr", buf.ptr, "ptr", bin, "uptr", size)

      ; Release binary data and stream.
      DllCall("GlobalUnlock", "ptr", handle)
      ObjRelease(stream)

      return buf
   }

   static StreamToEncodedBuffer(stream) {
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      buf := Buffer(size)
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", buf.ptr, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      return buf
   }

   static BitmapToSharedBuffer(pBitmap, name := "") {

      if (name == "") {
         MsgBox       "You have not specified a resource name. Defaulting to 'SharedBuffer'."
         . "`n"     . "Note that names are case-sensitive and must be unique."
         . "`n"     . "To access the shared buffer in a different script, use:"
         . "`n`n`t" . "#include ImagePut.ahk"
         . "`n`t"   . "shared := ImagePutSharedBuffer(" Chr(34) "SharedBuffer" Chr(34) ")"
         . "`n`t"   . "shared.show()"
         . "`n`n"   . "You can copy this message with Ctrl + c."
         . "`n"     . "Press OK to continue."
      }

      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Allocate shared memory.
      stride := 4 * width
      size := stride * height
      capacity := size + 12
      hMap := DllCall("CreateFileMapping", "ptr", -1, "ptr", 0, "uint", 0x4, "uint", 0, "uint", capacity, "str", "ImagePut_" name, "ptr")
      pMap := DllCall("MapViewOfFile", "ptr", hMap, "uint", 0x2, "uint", 0, "uint", 0, "uptr", 0, "ptr")

      ; Store width x height and stride in the first 12 bytes.
      NumPut("uint",  width, pMap + 0)
      NumPut("uint", height, pMap + 4)
      NumPut("uint", stride, pMap + 8) ; Optional
      ptr := pMap + 12

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 5) Copy pixels to an external pointer.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",     stride, BitmapData,  8) ; Stride
         NumPut(   "ptr",        ptr, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (ptr) to the FileMapping.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Free the pixels later.
      buf := ImagePut.BitmapBuffer(ptr, size, width, height) ; Stride can be calculated via size // height
      buf.free := () => (DllCall("UnmapViewOfFile", "ptr", pMap), DllCall("CloseHandle", "ptr", hMap))
      buf.name := name
      return buf
   }

   static BitmapToBuffer(pBitmap) {
      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Allocate global memory.
      size := 4 * width * height
      ptr := DllCall("GlobalAlloc", "uint", 0, "uptr", size, "ptr")

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 5) Copy pixels to an external pointer.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",        ptr, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (ptr) to the Buffer Object.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Free the pixels later.
      buf := ImagePut.BitmapBuffer(ptr, size, width, height)
      buf.free := () => DllCall("GlobalFree", "ptr", ptr)
      return buf
   }

   class BitmapBuffer {

      __New(ptr:="", size:="", width:="", height:="") { ; Remember to set .free and .draw!
         ImagePut.gdiplusStartup()

         ; Wrap the pointer without copying the data.
         (ptr != "") && this.ptr := ptr
         (size != "") && this.size := size
         (width != "") && this.width := width
         (height != "") && this.height := height
      }

      __Delete() {
         DllCall("gdiplus\GdipDisposeImage", "ptr", this.pBitmap)
         this.Cleanup()
         ImagePut.gdiplusShutdown()
      }

      stride {
         get {
            return this.size // this.height
         }
      }

      pitch {
         get {
            return this.size // this.height
         }
      }

      pBitmap {
         get {
            ; Test if the cached bitmap (this.pBitmap2) already exists.
            renew := False
            renew |= this.HasProp("ptr2") && this.ptr != this.ptr2

            ; Delete the old bitmap.
            (renew) && DllCall("gdiplus\GdipDisposeImage", "ptr", this.pBitmap2)

            ; Test if the cached bitmap needs to be created.
            renew |= !this.HasProp("pBitmap2")
            try renew |= DllCall("gdiplus\GdipGetImageType", "ptr", this.pBitmap2, "ptr*", &_type:=0) or (_type != 1)
            catch
               renew := True

            ; Create a source GDI+ Bitmap that owns its memory. The pixel format is 32-bit ARGB.
            if (renew) {
               DllCall("gdiplus\GdipCreateBitmapFromScan0", "int", this.width, "int", this.height
               , "int", this.size // this.height, "int", 0x26200A, "ptr", this.ptr, "ptr*", &pBitmap:=0)
               this.pBitmap2 := pBitmap
               this.ptr2 := this.ptr
            }

            ; Return the cached bitmap.
            return this.pBitmap2
         }
         set {
            this.pBitmap2 := value
         }
      }

      __Call(name, p) { ; Note: Only Functors have a .call property and methods do not.

         if (name = "Cleanup") && this.HasProp("free") {
            if HasMethod(this.free)
               this.free.call()
            if Type(this.free) = "Array"
               for callback in this.free
                  callback.call()
            return this
         }

         if (name = "Update") && this.HasProp("draw") {
            if HasMethod(this.draw)
               this.draw.call()
            if Type(this.draw) = "Array"
               for callback in this.draw
                  callback.call()
            return this
         }
      }

      __Item[x, y] {
         get => Format("0x{:08X}", NumGet(this.ptr + 4*(y*this.width + x), "uint"))
         set => ((value >> 24) || value |= 0xFF000000,
                  NumPut("uint", value, this.ptr + 4*(y*this.width + x)),
                  value)
      }

      __Enum(n) {
         ; constants
         start := 0
         end := this.size

         switch n {
         case 1: return (&c) => ((start < end) && (                    ; guard
            c := Format("0x{:08X}", NumGet(this.ptr + start, "uint")), ; yield
            start += 4,                                                ; do block
            True))                                                     ; continue?

         case 2: return (&x, &y) => ((start < end) && (
            i := start // 4,
            x := mod(i, this.width),
            y := i // this.width,
            start += 4,
            True))

         case 3: return (&x, &y, &c) => ((start < end) && (
            c := Format("0x{:08X}", NumGet(this.ptr + start, "uint")),
            i := start // 4,
            x := mod(i, this.width),
            y := i // this.width,
            start += 4,
            True))

         case 6: return (&x, &y, &c, &r, &g, &b) => ((start < end) && (
            c := Format("0x{:08X}", NumGet(this.ptr + start, "uint")),
            i := start // 4,
            x := mod(i, this.width),
            y := i // this.width,
            r := c >> 16 & 0xFF,
            g := c >>  8 & 0xFF,
            b := c       & 0xFF,
            start += 4,
            True))

         case 7: return (&x, &y, &c, &r, &g, &b, &a) => ((start < end) && (
            c := Format("0x{:08X}", NumGet(this.ptr + start, "uint")),
            i := start // 4,
            x := mod(i, this.width),
            y := i // this.width,
            a := c >> 24 & 0xFF,
            r := c >> 16 & 0xFF,
            g := c >>  8 & 0xFF,
            b := c       & 0xFF,
            start += 4,
            True))
         }
      }

      Frequency() {
         if this.HasProp(map)
            return
         this.map := Map()
         loop this.width * this.height
            if c := NumGet(this.ptr + 4*(A_Index-1), "uint")
               this.map[c] := this.map.Has(c) ? this.map[c] + 1 : 1
      }

      Count(c*) {
         this.Frequency()
         acc := 0
         for each, color in c {
            ; Lift color to 32-bits if first 8 bits are zero.
            (color >> 24) || color |= 0xFF000000
            acc += this.map.get(color, 0)
         }
         return acc
      }

      Clone() {
         ptr := DllCall("GlobalAlloc", "uint", 0, "uptr", this.size, "ptr")
         DllCall("RtlMoveMemory", "ptr", ptr, "ptr", this.ptr, "uptr", this.size)
         buf := ImagePut.BitmapBuffer(ptr, this.size, this.width, this.height)
         buf.free := () => DllCall("GlobalFree", "ptr", ptr)
         return buf
      }

      Crop(x, y, w, h) {
         DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", this.pBitmap, "int*", &format:=0)
         DllCall("gdiplus\GdipCloneBitmapAreaI", "int", x, "int", y, "int", w, "int", h, "int", format, "ptr", this.pBitmap, "ptr*", &pBitmap:=0)
         try return ImagePut.BitmapToBuffer(pBitmap)
         finally DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
      }

      Show(window_border := False, title:="", pos:="", style:="", styleEx:="", parent:="", playback:="", cache:="") {
         return (window_border)
            ? ImagePut.BitmapToWindow(this.pBitmap, title, pos, style, styleEx, parent, playback, cache)
            : ImagePut.Show(this.pBitmap, title, pos, style, styleEx, parent, playback, cache)
      }

      Save(filepath := "", quality := "")  {
         return ImagePut.BitmapToFile(this.pBitmap, filepath, quality)
      }

      Base64Code(b64) {
         static codes := Map()

         if codes.Has(b64)
            return codes[b64]

         n64 := StrLen(RTrim(b64, "=")) * 3 // 4
         code := DllCall("GlobalAlloc", "uint", 0, "uptr", n64, "ptr")
         DllCall("crypt32\CryptStringToBinary", "str", b64, "uint", 0, "uint", 0x1, "ptr", code, "uint*", n64, "ptr", 0, "ptr", 0)
         DllCall("VirtualProtect", "ptr", code, "uptr", n64, "uint", 0x40, "uint*", 0)

         return codes[b64] := code
      }

      AVX2() {
         ; This is just plain old AVX, not a check for AVX2 (which is neexed for pixelsearch1y)
         ; Also see: https://store.steampowered.com/hwsurvey/steam-hardware-software-survey-welcome-to-steam
         ; C source code - https://godbolt.org/z/n8fxxdsfs
         code := this.Base64Code((A_PtrSize == 4)
            ? "VYnli0UIi1UQi00UO0UMcws5EHUCiQiDwATr8F3D" ; not implemented
            : "U0UxwLgBAAAARInBD6IPuuEbcxkPuuEccxNEicEPAdBI99CoBg+UwA+2wOsCMcBbww==")

         return DllCall(code, "int")
      }

      CPUID() {
         static cpuid := 0

         if not cpuid {
            ; C source code - https://godbolt.org/z/1YPd6jz61
            b64 := (A_PtrSize == 4)
               ? "VYnlV4t9EFaLdQhTiw+LBg+iiQaLRQyJGItFFIkPiRBbXl9dww=="
               : "U4sBSYnKSYnTQYsID6JBiQJBiRtBiQhBiRFbww=="
            n64 := StrLen(RTrim(b64, "=")) * 3 // 4
            code := DllCall("GlobalAlloc", "uint", 0, "uptr", n64, "ptr")
            DllCall("crypt32\CryptStringToBinary", "str", b64, "uint", 0, "uint", 0x1, "ptr", code, "uint*", n64, "ptr", 0, "ptr", 0)
            DllCall("VirtualProtect", "ptr", code, "uptr", n64, "uint", 0x40, "uint*", 0)

            ; Set eax flag to 1 to retrieve supported CPU features.
            ; See this for CPU features: https://wiki.osdev.org/CPUID
            ; Also see: Appendix D.2 - CPUID Feature Flags Related to Instruction Support
            ; On page 1861 - https://www.amd.com/content/dam/amd/en/documents/processor-tech-docs/programmer-references/40332.pdf
            DllCall(code, "uint*", &a := 1, "uint*", &b := 0, "uint*", &c := 0, "uint*", &d := 0, "cdecl")

            ; Free memory.
            DllCall("GlobalFree", "ptr", code)

            ; To check for SSE2 use the following code example:
            ; if cpuid().edx[26] == True
            eax := Map(0, a & 1)
            ebx := Map(0, b & 1)
            ecx := Map(0, c & 1)
            edx := Map(0, d & 1)
            loop 31 {
               eax[A_Index] := !!(1 << A_Index & a)
               ebx[A_Index] := !!(1 << A_Index & b)
               ecx[A_Index] := !!(1 << A_Index & c)
               edx[A_Index] := !!(1 << A_Index & d)
            }
            cpuid := {eax: eax, ebx: ebx, ecx: ecx, edx: edx}
         }

         return cpuid
      }

      ColorKey(key := "sentinel", value := 0x00000000) {
         ; C source code - https://godbolt.org/z/eaG9fax9v
         code := this.Base64Code((A_PtrSize == 4)
            ? "VYnli0UIi1UQi00UO0UMcws5EHUCiQiDwATr8F3D"
            : "SDnRcw5EOQF1A0SJCUiDwQTr7cM=")

         ; Select top-left pixel as default.
         (key == "sentinel") && key := NumGet(this.ptr, "uint")

         ; Replaces one ARGB color with another.
         DllCall(code, "ptr", this.ptr, "uint", this.ptr + this.size, "uint", key, "uint", value, "cdecl")
      }

      SetAlpha(alpha := 0xFF) {
         ; C source code - https://godbolt.org/z/aWf73jTqc
         code := this.Base64Code((A_PtrSize == 4)
            ? "VYnli0UIilUQO0UMcwiIUAODwATr813D"
            : "SDnRcwpEiEEDSIPBBOvxww==")

         ; Sets the transparency of the entire bitmap.
         DllCall(code, "ptr", this.ptr, "ptr", this.ptr + this.size, "uchar", alpha, "cdecl")
      }

      TransColor(color := "sentinel", alpha := 0x00) {
         ; C source code - https://godbolt.org/z/z3a8WcM5M
         code := this.Base64Code((A_PtrSize == 4)
            ? "VYnli0UIilUUO0UMcxWLTRAzCIHh////AHUDiFADg8AE6+Zdww=="
            : "SDnRcxaLAUQxwKn///8AdQREiEkDSIPBBOvlww==")

         ; Select top-left pixel as default.
         (color == "sentinel") && color := NumGet(this.ptr, "uint")

         ; Sets the alpha value of a specified RGB color.
         DllCall(code, "ptr", this.ptr, "ptr", this.ptr + this.size, "uint", color, "uchar", alpha, "cdecl")
      }

      ; Option 1: PixelSearch, single color with no variation.
      ; Option 2: PixelSearch, single color with single variation.
      ; Option 3: PixelSearch, single color with multiple variation.
      ; Option 4: PixelSearch, range of colors.
      ; Option 5: PixelSearch, multiple colors with no variation.
      ; Option 6: PixelSearch, multiple colors with single variation.
      ; Option 7: PixelSearch, multiple colors with multiple variation.

      PixelSearch(color, variation := 0, debug := 0) {

         if not IsObject(color) {

            ; Lift color to 32-bits if first 8 bits are zero.
            (color >> 24) || color |= 0xFF000000

            if not IsObject(variation)
               if (variation == 0)
                  option := 1
               else
                  option := 2
            else if (variation.length == 3)
                  option := 3
            else if (variation.length == 6)
                  option := 4
            else throw Error("Invalid variation parameter.")
         }
         else
            if not IsObject(variation)
               if (variation == 0)
                  option := 5
               else
                  option := 6
            else if (variation.length == 3)
                  option := 7
            else throw Error("Invalid variation parameter.")

         ; ------------------------ Machine code generated with MCode4GCC using gcc 13.2.0 ------------------------

         ; C source code - https://godbolt.org/z/KMcPeav79
         pixelsearch1 := this.Base64Code((A_PtrSize == 4)
            ? "VYnlV4tNEItVDFZTi0UIZg9u0Y1y5GYPcMoAOfBzJw8QAGYPdsFmD9fYDxBAQGYPdsFmD9f4Cft1DIPAIOvcOQh0B4PABDnQcvVb"
            . "Xl9dww=="
            : "ZkEPbtBIichMjUrkZg9wygBMOchzLA8QAGYPdsFmD9fIDxBAQGYPdsFmRA/X0EQJ0XUPSIPAIOvYRDkAdAlIg8AESDnQcvLD")

         ; C source code - https://godbolt.org/z/Gc8nbnPq3
         pixelsearch2 := this.Base64Code((A_PtrSize == 4)
            ? "VWYPduSJ5VdWU4Pk8IPsEIpFFItdEItNGItVHIt1DIt9IIhEJA6KRSSIXCQPD7bbiEwkDcHjEA+2yYhEJAsPtkUgweEIiFQkDA+2"
            . "0gnYweIICcgPtk0kDQAAAP8J0Q+2VRRmD27oi0UIZg9wzQDB4hAJ0Y1W9GYPbvFmD3DWADnQczkPEAAPEBgPEDhmD97BZg/e2mYP"
            . "dMFmD3TfD1TDZg92xGYP18iFyXURg8AQ68+KUAI4VCQPcwmDwAQ58HLw6yM6VCQOcvGKUAE4VCQNcug6VCQMcuKKEIn5ONFy2jpU"
            . "JAty1I1l9FteX13D"
            : "QVZBVUFUVVdWU0SLbCRgi0QkaESLdCRwRItUJHhEie6Jx0UPtu0PtsBBweUIRIn1RQ+29kWJ1EWJw0UPtsBEicvB4AhBweAQRQ+2"
            . "0kUPtslFCfBECdBBweEQRQnoRAnIQYHIAAAA/2YPbuhIichmQQ9uyEiNSvRmD3DBAGYPcM0AZg927Ug5yHM8DxAgDyjQDyjcZg/e"
            . "1GYP3tlmD3TQZg903A9U02YPdtVmRA/XwkWFwHUSSIPAEOvLikgCQTjLcwtIg8AESDnQcu/rHTjZcvGKSAFAOM5y6UA4+XLkighA"
            . "OM1y3UQ44XLYW15fXUFcQV1BXsM=")

         ; C source code - https://godbolt.org/z/cd1xaK5Ec
         pixelsearch3 := this.Base64Code((A_PtrSize == 4)
            ? "VTHSieVXVlOD5PCD7BCLfQyNR/SJRCQEi0UUKdAPhBkBAACD+AF0PoP4AnQhg/gDvgMAAAAPTHQkDIl0JAyLdRBmD25klghmD3Dc"
            . "AOsIx0QkDAIAAACLXRBmD25skwRmD3DVAOsIx0QkDAEAAACLdRBmD240lo0clolcJAhmD3DOAIP4AXR0g/gCi0UIdD6LTCQEOchz"
            . "Lg8QAGYPdsFmD9fYDxAAidlmD3bCZg/X2A8QAAnLZg92w2YP1/AJ83V0g8AQ68qDwgPpS////4139Dnwcx8PEABmD3bBZg/XyA8Q"
            . "AGYPdsJmD9fYCct1RoPAEOvdg8IC6R3///+LRQiNX/Q52HMUDxAAZg92wWYP1/CF9nUgg8AQ6+hC6fn+//+LTCQIiwyROQh0FEI5"
            . "VCQMf+6DwAQ5+HMGMdLr74n4jWX0W15fXcM="
            : "QVVBVFVXVlO9AwAAAEmJykiJ0THSSI1x9ESJyCnQD4QEAQAAg/gBSGPadC6D+AJ0FWZBD25smAiD+ANED03dZg9w3QDrBkG7AgAA"
            . "AGZBD25smARmD3DVAOsGQbsBAAAAZkEPbgyYSY08mGYPcMkAg/gBdHOD+AJMidB0Xkg58HMxDxAADyjhZg924GZED9fsDyjiZg92"
            . "4GYPdsNmD9fcZkQP1+BECetECeN1c0iDwBDryoPCA+lf////DxAADyjhZg924GYPdsJmRA/X5GYP19hECeN1SUiDwBBIOfBy24PC"
            . "Auky////TInQSDnwcxUPEABmD3bBZg/X2IXbdSFIg8AQ6+b/wukO////SP/Ci3SX/DkwdBVBOdN/8EiDwARIOchzBzHS6+5Iichb"
            . "Xl9dQVxBXcM=")

         ; C source code - https://godbolt.org/z/sqc9sfv9s
         pixelsearch4 := this.Base64Code((A_PtrSize == 4)
            ? "VTHAZg925InlV1ZTg+Twg+xAi1UYKcIPhFMCAACD+gF0YIP6AnQzi10Qg/oDuQMAAAAPTflmD25sgwiLXRRmD3D9AA8pfCQwZg9u"
            . "fIMIZg9w3wAPKVwkEOsFvwIAAACLXRBmD25sgwSLXRRmD258gwRmD3DdAGYPcM8ADylMJCDrBb8BAAAAi10QjQyFAAAAAAHLiVwk"
            . "DItdEGYPbiwLi10UZg9uPAuNNAtmD3DNAIl0JAiLdQhmD3DvAIP6AQ+ECwEAAItNDIPpDIP6Ag+EnAAAADnOD4OMAAAADxAGDyjw"
            . "DyjQZg/e9WYP3tFmD3TwZg900Q9U1g8o8GYPdtRmD97zZg9082YP19oPKFQkIGYP3tBmD3TQD1TWDyh0JDBmD3bUZg/e8GYPdHQk"
            . "MGYP19IPKFQkEIlUJARmD97QZg900A9U1mYPdtRmD9fSiRQki1QkBAnaCxQkD4XLAAAAg8YQ6Wz///+DwAPpo/7//2YPdv85znNQ"
            . "DxAWDyjyDyjCZg/e9WYP3sFmD3TyZg90wQ9Uxg8odCQgZg92x2YP3vJmD3TyZg/X2A8owmYP3sNmD3TDD1TGZg92x2YP19AJ2nVo"
            . "g8YQ66yDwALpQ/7//4tVDGYPdvaD6gw51nMtDxAWDxAGDxA+Zg/e1WYP3sFmD3TBZg901w9UwmYPdsZmD9fIhcl1JYPGEOvPQOkC"
            . "/v//OFoCczr/RCQwg8IEg8AEi0wkMDnPf+mDxgQ7dQxzRIpGATHJil4CiUwkMItUJAyIRCQgigaIRCQQi0QkCOvQOlgCcsGKTCQg"
            . "OEoBcrg6SAFys4pMJBA4CnKrOghyp+sDi3UMjWX0ifBbXl9dww=="
            : "QVRVV1ZTSIPsUA8pNCQPKXwkEEQPKUQkIEQPKUwkMEQPKVQkQL8DAAAAZg9220mJ00iJyzHSSY1z9IuMJKAAAAAp0Q+EMgIAAIP5"
            . "AUhjwnRGg/kCdCFmQQ9ufIAIZkEPbnSBCIP5A0QPTddmD3DvAGYPcP4A6wZBugIAAABmQQ9uZIAEZkEPbnSBBGYPcNQAZg9w9gDr"
            . "BkG6AQAAAGZBD24kgGYPcMwAZkEPbiSBSInYZg9w5ACD+QEPhCIBAACD+QIPhKsAAABIOfAPg5oAAAAPEABEDyjIRA8owGZED97M"
            . "ZkQP3sFmRA90yGZED3TBRQ9UwUQPKMhmRA92w2ZED97KZkQPdMpmRQ/X4EQPKMBmRA/exmZED3TARQ9UwUQPKMhmRA92w2ZED97N"
            . "ZkQPdM1mQQ/XyEQPKMBmRA/ex0QJ4WZBD3TAQQ9UwWYPdsNmD9foCel0C8HiAkhj0unfAAAASIPAEOld////g8ID6cf+//9mRQ92"
            . "wEg58HNcRA8QCEUPKNFBDyjBZkQP3tRmD97BZkUPdNFmD3TBQQ9UwkUPKNFmQQ92wGZED97WZg/X6EEPKMFmD97CZkUPdMpmD3TC"
            . "QQ9UwWZBD3bAZg/XyAnpdYRIg8AQ65+DwgLpWf7//2ZFD3bJSDnwczlEDxAARQ8o0EEPKMBmRA/e1GYP3sFmD3TBZkUPdMJBD1TA"
            . "ZkEPdsFmD9fIhckPhTn///9Ig8AQ68L/wukP/v//QTh0CAJzJv/DSIPBBEE52n/uSIPABEw52HM4QIpwAkCKeAFIidEx20CKKOvg"
            . "QTp0CQJy00E4fAgBcsxBOnwJAXLFQTgsCHK/QTosCXK56wNMidgPKDQkDyh8JBBEDyhEJCBEDyhMJDBEDyhUJEBIg8RQW15fXUFc"
            . "ww==")

         ; --------------------------------------------------------------------------------------------------------

         ; Start at the beginning of the image.
         ptr := this.ptr

         ; If the found pixel lies in the forbidden stride area, start from the next scanline!
         redo: ; Unfortunately, unalignment can occur if the stride is not divisible by 4.

         ; When doing pointer arithmetic, *Scan0 + 1 is actually adding 4 bytes.
         if (option == 1)
            address := DllCall(pixelsearch1, "ptr", ptr, "ptr", this.ptr + this.size, "uint", color, "cdecl ptr")

         if (option == 2) {
            r := ((color & 0xFF0000) >> 16)
            g := ((color & 0xFF00) >> 8)
            b := ((color & 0xFF))
            v := abs(variation)

            address := DllCall(pixelsearch2, "ptr", ptr, "ptr", this.ptr + this.size
                     , "uchar", min(r+v, 255)
                     , "uchar", max(r-v, 0)
                     , "uchar", min(g+v, 255)
                     , "uchar", max(g-v, 0)
                     , "uchar", min(b+v, 255)
                     , "uchar", max(b-v, 0)
                     , "cdecl ptr")
         }

         if (option == 3) {
            r := ((color & 0xFF0000) >> 16)
            g := ((color & 0xFF00) >> 8)
            b := ((color & 0xFF))
            vr := abs(variation[1])
            vg := abs(variation[2])
            vb := abs(variation[3])

            address := DllCall(pixelsearch2, "ptr", ptr, "ptr", this.ptr + this.size
                     , "uchar", min(r + vr, 255)
                     , "uchar", max(r - vr, 0)
                     , "uchar", min(g + vg, 255)
                     , "uchar", max(g - vg, 0)
                     , "uchar", min(b + vb, 255)
                     , "uchar", max(b - vb, 0)
                     , "cdecl ptr")
         }

         if (option == 4)
            address := DllCall(pixelsearch2, "ptr", ptr, "ptr", this.ptr + this.size
                     , "uchar", min(max(variation[1], variation[2]), 255)
                     , "uchar", max(min(variation[1], variation[2]), 0)
                     , "uchar", min(max(variation[3], variation[4]), 255)
                     , "uchar", max(min(variation[3], variation[4]), 0)
                     , "uchar", min(max(variation[5], variation[6]), 255)
                     , "uchar", max(min(variation[5], variation[6]), 0)
                     , "cdecl ptr")

         if (option == 5) {
            ; Create a struct of unsigned integers.
            colors := Buffer(4*color.length)

            ; Fill the struct by iterating through the input array.
            for c in color {
               (c >> 24) || c |= 0xFF000000             ; Lift colors to 32-bit ARGB.
               NumPut("uint", c, colors, 4*(A_Index-1)) ; Place the unsigned int at each offset.
            }

            address := DllCall(pixelsearch3, "ptr", ptr, "ptr", this.ptr + this.size, "ptr", colors, "uint", color.length, "cdecl ptr")
         }

         ; Options 6 & 7 - Creates a high and low struct where each pair is the min and max range.

         if (option == 6) {
            high := Buffer(4*color.length)
            low := Buffer(4*color.length)

            for c in color {
               A_Offset := A_Index - 1

               r := ((c & 0xFF0000) >> 16)
               g := ((c & 0xFF00) >> 8)
               b := ((c & 0xFF))
               v := abs(variation)

               NumPut("uchar", 255, high, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", min(r+v, 255), high, 4*A_Offset + 2)
               NumPut("uchar", min(g+v, 255), high, 4*A_Offset + 1)
               NumPut("uchar", min(b+v, 255), high, 4*A_Offset + 0)

               NumPut("uchar", 0, low, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", max(r-v, 0), low, 4*A_Offset + 2)
               NumPut("uchar", max(g-v, 0), low, 4*A_Offset + 1)
               NumPut("uchar", max(b-v, 0), low, 4*A_Offset + 0)
            }

            address := DllCall(pixelsearch4, "ptr", ptr, "ptr", this.ptr + this.size, "ptr", high, "ptr", low, "uint", color.length, "cdecl ptr")
         }

         if (option == 7) {
            high := Buffer(4*color.length)
            low := Buffer(4*color.length)

            for c in color {
               A_Offset := A_Index - 1

               r := ((c & 0xFF0000) >> 16)
               g := ((c & 0xFF00) >> 8)
               b := ((c & 0xFF))
               vr := abs(variation[1])
               vg := abs(variation[2])
               vb := abs(variation[3])

               NumPut("uchar", 255, high, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", min(r + vr, 255), high, 4*A_Offset + 2)
               NumPut("uchar", min(g + vg, 255), high, 4*A_Offset + 1)
               NumPut("uchar", min(b + vb, 255), high, 4*A_Offset + 0)

               NumPut("uchar", 0, low, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", max(r - vr, 0), low, 4*A_Offset + 2)
               NumPut("uchar", max(g - vg, 0), low, 4*A_Offset + 1)
               NumPut("uchar", max(b - vb, 0), low, 4*A_Offset + 0)
            }

            address := DllCall(pixelsearch4, "ptr", ptr, "ptr", this.ptr + this.size, "ptr", high, "ptr", low, "uint", color.length, "cdecl ptr")
         }

         ; Compare the address to the out-of-bounds limit.
         if (address == this.ptr + this.size)
            return False

         ; Calculate the x and y coordinates.
         offset := (address - this.ptr)
         x := mod(offset, this.stride) // 4
         y := offset // this.stride

         ; Advance to the next scanline if the x-coordinate is in the forbidden stride area.
         if x >= this.width {
            ptr := this.ptr + (y + 1) * this.stride
            goto redo
         }

         ; Returns an [x, y] array.
         return [x, y]
      }

      PixelSearchAll(color, variation := 0) {

         if not IsObject(color) {

            ; Lift color to 32-bits if first 8 bits are zero.
            (color >> 24) || color |= 0xFF000000

            if not IsObject(variation)
               if (variation == 0)
                  option := 1
               else
                  option := 2
            else if (variation.length == 3)
                  option := 3
            else if (variation.length == 6)
                  option := 4
            else throw Error("Invalid variation parameter.")
         }
         else
            if not IsObject(variation)
               if (variation == 0)
                  option := 5
               else
                  option := 6
            else if (variation.length == 3)
                  option := 7
            else throw Error("Invalid variation parameter.")

         ; ------------------------ Machine code generated with MCode4GCC using gcc 13.2.0 ------------------------

         ; C source code - https://godbolt.org/z/3rd4drccd
         pixelsearchall1 := this.Base64Code((A_PtrSize == 4)
            ? "VTHSieVXZg9uVRiLRRBWU4tdFGYPcMoAjXP0OfBzDw8QAGYPdsFmD9fIhcl0BY1IEOsVjUgQicjr4TnIdPiLfRg5OHQJg8AEOdhy"
            . "7usOO1UMcwaLfQiJBJdC6+lbidBeX13D"
            : "VlMxwESLVCQ4ZkEPbtJmD3DKAEmNWfRJOdhNjVgQcyNBDxAAZg92wWYP1/CF9nUTTYnY6+JNOdh09kU5EHQLSYPABE05yHLt6w45"
            . "0HMGicZMiQTx/8Dr51teww==")

         ; C source code - https://godbolt.org/z/8859rajsx
         pixelsearchall2 := this.Base64Code((A_PtrSize == 4)
            ? "VWYPduSJ5VdWU4Pk8IPsEItdGItNIItVKIpFHIhcJA8PttuLfRTB4xCIRCQOikUkiEwkDQ+2yY139IhUJAsPttLB4QgJ2ohEJAyK"
            . "RSwJyg+2TSQPttiBygAAAP+IRCQKweEIZg9u6jHSCcsPtk0cZg9wzQDB4RAJy2YPbvNmD3DWADl1EHMri0UQDxAADxAYDxA4Zg/e"
            . "wWYP3tpmD3TBZg903w9Uw2YPdsRmD9fIhcl0CItFEI1IEOsgi0UQjUgQiU0Q6705TRB09otFEIpYAjhcJA9zC4NFEAQ5fRBy5us0"
            . "OlwkDnLvilgBOFwkDXLmOlwkDHLgihg4XCQLctg6XCQKctI7VQxzCYtFCItdEIkckELrwY1l9InQW15fXcM="
            : "QVdBVkFVQVRVV1ZTRItUJGiLhCSIAAAARIucJJAAAABAimwkcESJ10UPttJBicYPtsBBweIQRYnfRQ+220iJy4tMJHiJ1ouUJIAA"
            . "AABECdBNjVH0QYnMD7bJQYnVD7bSweEIweIICchAD7bNRAnaweEQDQAAAP8JymYPbsAxwGYPbupmD3DIAGYPcMUAZg927U050EmN"
            . "UBBzQEEPECAPKNEPKNxmD97UZg/e2GYPdNFmD3TcD1TTZg921WYP18qFyXUXSYnQ68lJOdB09kGKSAJAOM9zC0mDwARNOchy6esu"
            . "QDjpcvBBikgBQTjMcudEOOly4kGKCEE4znLaRDj5ctU58HMGicFMiQTL/8Drx1teX11BXEFdQV5BX8M=")

         ; C source code - https://godbolt.org/z/Ync4eq1rj
         pixelsearchall3 := this.Base64Code((A_PtrSize == 4)
            ? "VTHSMcmJ5VdWU4Pk8IPsEItFFIPoDIlEJASLRRwp0IlEJAwPhDwBAACD+AF0PoP4AnQhg/gDuAMAAAAPTEQkCIlEJAiLRRhmD25k"
            . "kAhmD3DcAOsIx0QkCAIAAACLRRhmD25skARmD3DVAOsIx0QkCAEAAACLRRiNBJCJBCSLRRhmD240kItFEGYPcM4Ag3wkDAF1C4t1"
            . "FI1e9OmJAAAAg3wkDAJ0YIt8JAQ5+HMuDxAAZg92wWYP19gPEACJ32YPdsJmD9fYDxAACftmD3bDZg/X8AnzdQ2DwBDryoPCA+k2"
            . "////jXAQ610PEABmD3bBZg/X8A8QAGYPdsJmD9fYCfN14YPAEIt8JAQ5+HLbg8IC6QT///8PEABmD3bBZg/X8IX2db+DwBA52HLq"
            . "Quno/v//izwkizyfOTh0G0M5XCQIf++DwAQ7RRRzGjnwD4Q6////Mdvr5jtNDHMGi30IiQSPQevXjWX0ichbXl9dww=="
            : "QVdBVkFVQVRVV1ZTQb4DAAAATItcJGhMiUQkWEiJzonXMckx0kmNafREi0QkcEEp0A+EKQEAAEGD+AFIY8J0MEGD+AJ0FmZBD25s"
            . "gwhBg/gDRQ9N1mYPcN0A6wZBugIAAABmQQ9ubIMEZg9w1QDrBkG6AQAAAGZBD24Mg02NJINIi0QkWGYPcMkAQYP4AQ+EigAAAEGD"
            . "+AJ0ZEg56HMxDxAADyjhZg924GZED9f8DyjiZg924GYPdsNmD9fcZkQP1+hECftECet1DkiDwBDryoPCA+lR////TI1oEOthDxAA"
            . "DyjhZg924GYPdsJmRA/X7GYP19hECet13kiDwBBIOehy24PCAuke////DxAAZg92wWYP19iF23W+SIPAEEg56HLo/8Lp//7//0WL"
            . "PJxEOTh0Hkj/w0E52n/vSIPABEw5yHMcTDnoD4Q9////Mdvr5Tn5cwdBic9KiQT+/8Hr04nIW15fXUFcQV1BXkFfww==")

         ; C source code - https://godbolt.org/z/aajP7z1jb
         pixelsearchall4 := this.Base64Code((A_PtrSize == 4)
            ? "VWYPdtKJ5VdWMfZTMduD5PCD7ECJXCQ0i0UgKfCJRCQ8D4R3AgAAg/gBdGOD+AJ0OIP4A7gDAAAAD0xEJDiJRCQ4i0UYZg9uZLAI"
            . "i0UcZg9w7AAPKWwkIGYPbmywCGYPcN0ADykcJOsIx0QkOAIAAACLRRhmD25ksASLRRxmD25MsARmD3DcAGYPcOkA6wjHRCQ4AQAA"
            . "AItdGI0EtQAAAACLVRiLfRABw2YPbiQCiVwkGItdHGYPcMwAjRQDZg9uJAOJVCQUZg9w5ACDfCQ8AYtFFHUIg+gM6SoBAACDfCQ8"
            . "Ao1Q9I1Y9A+E2gAAADnfc3YPEAcPKPgPKPBmD978Zg/e8WYPdPhmD3TxD1T3Dyj4Zg928mYP3vtmD3T7Zg/Xzg8o8GYP3vVmD3Tw"
            . "D1T3Dyh8JCBmD3byZg/e+GYPdHwkIGYP18YPKDQkCchmD97wZg908A9U92YPdvJmD9fWCdB1DYPHEOuGg8YD6aj+//+NRxCJRCQQ"
            . "6dAAAAAPEDcPKP4PKMZmD978Zg/ewWYPdP5mD3TBD1THDyj+Zg92wmYP3v1mD3T+Zg/XyA8oxmYP3sNmD3TDD1THZg92wmYP18AJ"
            . "yHWrg8cQOddysIPGAulE/v//DxA3DxAHDxA/Zg/e9GYP3sFmD3TBZg909w9UxmYPdgUAAAAAZg/X0IXSD4Vs////g8cQOcdyyUbp"
            . "B/7//4tEJBA5xw+Erv7//4pHAjHJi1QkFIlMJDCIRCQfikcBiEQkHooHiEQkHYtEJBiLXCQwOVwkOH8Kg8cEO30UcsDrS4pMJB84"
            . "SAJyNjpKAnIxilwkHjhYAXIoOloBciOKTCQdOAhyGzoKcheLTCQ0O00McwqLTQiLXCQ0iTyZ/0QkNP9EJDCDwASDwgTroYtEJDSN"
            . "ZfRbXl9dww=="
            : "QVdBVkFVQVRVV1ZTSIPseA8pdCQgDyl8JDBEDylEJEBEDylMJFBEDylUJGBFMdJmD3bSSImMJMAAAABNic5Mi4wk6AAAAEyJhCTQ"
            . "AAAATIuEJOAAAABJjXb0iZQkyAAAADHSRIucJPAAAABBKdMPhHgCAABBg/sBSGPCdEtBg/sCdCZmQQ9ufIAIZkEPbnSBCEGD+wO/"
            . "AwAAAA9N32YPcO8AZg9w/gDrBbsCAAAAZkEPbmSABGZBD250gQRmD3DcAGYPcPYA6wW7AQAAAGZBD24kgGYPcMwAZkEPbiSBjQSV"
            . "AAAAAEiYSIlEJBBIi4Qk0AAAAGYPcOQAZkUPdslBg/sBD4RTAQAAQYP7Ag+EBQEAAEg58A+DjgAAAA8QAEQPKMhEDyjAZkQP3sxm"
            . "RA/ewWZED3TIZkQPdMFFD1TBRA8oyGZED3bCZkQP3stmRA90y2ZBD9foRA8owGZED97GZkQPdMBFD1TBRA8oyGZED3bCZkQP3s1m"
            . "RA90zWZBD9fIRA8owGZED97HCelmQQ90wEEPVMFmD3bCZg/X+An5dRFIg8AQ6Wn///+DwgPpsv7//0iNeBBIiXwkGOnYAAAARA8Q"
            . "AEUPKMhBDyjAZkQP3sxmD97BZkUPdMhmD3TBQQ9UwUUPKMhmD3bCZkQP3s5mD9f4QQ8owGYP3sNmRQ90wWYPdMNBD1TAZg92wmYP"
            . "18gJ+XWeSIPAEEg58HKjg8IC6T/+//9EDxAARQ8o0EEPKMBmRA/e1GYP3sFmD3TBZkUPdMJBD1TAZkEPdsFmD9fIhckPhVr///9I"
            . "g8AQSDnwcsT/wun8/f//SIt8JBhIOfgPhIT+//8x/0CKaAJEimABRIooSItMJBCJfCQMi3wkDDn7fwtIg8AETDnwcsvrTkE4bAgC"
            . "cj1BOmwJAnI2RThkCAFyL0U6ZAkBcihFOCwIciJFOiwJchxEO5QkyAAAAHMPSIu8JMAAAABFiddKiQT/Qf/C/0QkDEiDwQTrnw8o"
            . "dCQgDyh8JDBEidBEDyhEJEBEDyhMJFBEDyhUJGBIg8R4W15fXUFcQV1BXkFfww==")

         ; --------------------------------------------------------------------------------------------------------

         ; Global number of addresses (matching searches) to allocate.
         limit := 256

         ; If the limit is exceeded, the following routine will be run again.
         redo:
         result := Buffer(A_PtrSize * limit) ; Allocate buffer for addresses.

         ; When doing pointer arithmetic, *Scan0 + 1 is actually adding 4 bytes.
         if (option == 1)
            count := DllCall(pixelsearchall1, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size, "uint", color, "cdecl uint")

         if (option == 2) {
            r := ((color & 0xFF0000) >> 16)
            g := ((color & 0xFF00) >> 8)
            b := ((color & 0xFF))
            v := abs(variation)

            count := DllCall(pixelsearchall2, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size
                     , "uchar", min(r+v, 255)
                     , "uchar", max(r-v, 0)
                     , "uchar", min(g+v, 255)
                     , "uchar", max(g-v, 0)
                     , "uchar", min(b+v, 255)
                     , "uchar", max(b-v, 0)
                     , "cdecl ptr")
         }

         if (option == 3) {
            r := ((color & 0xFF0000) >> 16)
            g := ((color & 0xFF00) >> 8)
            b := ((color & 0xFF))
            vr := abs(variation[1])
            vg := abs(variation[2])
            vb := abs(variation[3])

            count := DllCall(pixelsearchall2, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size
                     , "uchar", min(r + vr, 255)
                     , "uchar", max(r - vr, 0)
                     , "uchar", min(g + vg, 255)
                     , "uchar", max(g - vg, 0)
                     , "uchar", min(b + vb, 255)
                     , "uchar", max(b - vb, 0)
                     , "cdecl ptr")
         }

         if (option == 4)
            count := DllCall(pixelsearchall2, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size
                     , "uchar", min(max(variation[1], variation[2]), 255)
                     , "uchar", max(min(variation[1], variation[2]), 0)
                     , "uchar", min(max(variation[3], variation[4]), 255)
                     , "uchar", max(min(variation[3], variation[4]), 0)
                     , "uchar", min(max(variation[5], variation[6]), 255)
                     , "uchar", max(min(variation[5], variation[6]), 0)
                     , "cdecl ptr")

         if (option == 5) {
            ; Create a struct of unsigned integers.
            colors := Buffer(4*color.length)

            ; Fill the struct by iterating through the input array.
            for c in color {
               (c >> 24) || c |= 0xFF000000             ; Lift colors to 32-bit ARGB.
               NumPut("uint", c, colors, 4*(A_Index-1)) ; Place the unsigned int at each offset.
            }

            count := DllCall(pixelsearchall3, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size, "ptr", colors, "uint", color.length, "cdecl ptr")
         }

         ; Options 6 & 7 - Creates a high and low struct where each pair is the min and max range.

         if (option == 6) {
            high := Buffer(4*color.length)
            low := Buffer(4*color.length)

            for c in color {
               A_Offset := A_Index - 1

               r := ((c & 0xFF0000) >> 16)
               g := ((c & 0xFF00) >> 8)
               b := ((c & 0xFF))
               v := abs(variation)

               NumPut("uchar", 255, high, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", min(r+v, 255), high, 4*A_Offset + 2)
               NumPut("uchar", min(g+v, 255), high, 4*A_Offset + 1)
               NumPut("uchar", min(b+v, 255), high, 4*A_Offset + 0)

               NumPut("uchar", 0, low, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", max(r-v, 0), low, 4*A_Offset + 2)
               NumPut("uchar", max(g-v, 0), low, 4*A_Offset + 1)
               NumPut("uchar", max(b-v, 0), low, 4*A_Offset + 0)
            }

            count := DllCall(pixelsearchall4, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size, "ptr", high, "ptr", low, "uint", color.length, "cdecl ptr")
         }

         if (option == 7) {
            high := Buffer(4*color.length)
            low := Buffer(4*color.length)

            for c in color {
               A_Offset := A_Index - 1

               r := ((c & 0xFF0000) >> 16)
               g := ((c & 0xFF00) >> 8)
               b := ((c & 0xFF))
               vr := abs(variation[1])
               vg := abs(variation[2])
               vb := abs(variation[3])

               NumPut("uchar", 255, high, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", min(r + vr, 255), high, 4*A_Offset + 2)
               NumPut("uchar", min(g + vg, 255), high, 4*A_Offset + 1)
               NumPut("uchar", min(b + vb, 255), high, 4*A_Offset + 0)

               NumPut("uchar", 0, low, 4*A_Offset + 3) ; Alpha
               NumPut("uchar", max(r - vr, 0), low, 4*A_Offset + 2)
               NumPut("uchar", max(g - vg, 0), low, 4*A_Offset + 1)
               NumPut("uchar", max(b - vb, 0), low, 4*A_Offset + 0)
            }

            count := DllCall(pixelsearchall4, "ptr", result, "uint", limit, "ptr", this.ptr, "ptr", this.ptr + this.size, "ptr", high, "ptr", low, "uint", color.length, "cdecl ptr")
         }

         ; If the default 256 results is exceeded, run the machine code again.
         if (count > limit) {
            limit := count
            goto redo
         }

         ; Check if any matches are found.
         if (count == 0)
            return False

         ; Create an array of [x, y] coordinates.
         xys := []
         xys.count := count
         loop count {
            address := NumGet(result, A_PtrSize * (A_Index-1), "ptr")
            offset := (address - this.ptr) // 4
            xys.push([mod(offset, this.width), offset // this.width])
         }
         return xys
      }

      ImageSearch(image, variation := 0, option := "") {

         ; Convert image to a buffer object.
         if !(IsObject(image) && image.HasProp("ptr") && image.HasProp("size"))
            image := ImagePutBuffer(image)

         ; Check if the object has the coordinates.
         x := image.HasProp("x") ? image.x : image.width//2
         y := image.HasProp("y") ? image.y : image.height//2

         if (option == "") {
            if (variation == 0)
               option := 1
            else
               option := 2
         }

         ; ------------------------ Machine code generated with MCode4GCC using gcc 13.2.0 ------------------------
         ; C source code - https://godbolt.org/z/zGhb3dYcs
         imagesearch1 := this.Base64Code((A_PtrSize == 4)
            ? ""
            : "QVdBVkFVQVRVV1ZTSIPsGESLlCSYAAAARQ+2YQNEidAPr4QkgAAAAInTi5QkkAAAAESJxUiJz0GJ3UWLAUQrrCSAAAAASAHQQYs0"
            . "gYnoK4QkiAAAAIPAAQ+vw0yNHIFMOdkPgwQBAABED6/TiWwkcEkB0usQDx8ASIPBBEw52Q+D4wAAAEI5NJF17UWE5A+FrAAAAEiJ"
            . "yDHSSCn4SMH4AvfzQTnVctGLhCSIAAAAhcB0eIuEJIAAAABFMfZEiGQkD0Ux/0SJ8kiNLIUAAAAATInISI0UkUyNJChMOeBzS0iJ"
            . "LCQPH0QAAIB4AwB0CosqOSgPhYAAAABIg8AESIPCBEw54HLjSIssJEGDxwFEObwkiAAAAHQTQQHeTI0kKESJ8kiNFJFMOeBytUiJ"
            . "yEiDxBhbXl9dQVxBXUFeQV/DZpBEOQEPhEv///9Ig8EETDnZcxZCOTSRdOhIg8EETDnZD4Ig////Dx8Ai2wkcA+v3UiNDJ/rtQ8f"
            . "AEQPtmQkD+n1/v//")

         ; C source code - https://godbolt.org/z/qGexdGqMn
         imagesearch2 := this.Base64Code((A_PtrSize == 4)
            ? ""
            : "QVdBVkFVQVRVV1ZTSIPsOESLnCSgAAAAi7wkqAAAAEGJ1EmJyouUJLgAAACLjCSwAAAAQSn4TImMJJgAAABIi7QkmAAAAEQPt4wkwAAAAInQRQ+vxEEPr8NPjTSCSAHIiwSGRInmRCneiXQkLE058g+DcAEAAEEPr9QPtthEieVmiVwkKA+23MHoEA+2wIlcJBxIAcpmiUQkKkiNDJUAAAAARInaSI1xAUgp1UyNLJUAAAAASIl0JBBBjVP/SI1xAkWJy0iJdCQgSMHlAjH2QffbTI08lQAAAABmDx9EAABBD7YUCg+3RCQoKdBmQTnBcwpmRDnYD4LTAAAASItEJBBBD7YUAg+3RCQcKdBmQTnBcwpmRDnYD4KyAAAASItEJCBBD7YUAg+3RCQqKdBmQTnBcwpmRDnYD4KRAAAAhf8PhKMAAABIi4QkmAAAAEyJfCQITInSMdtJic9OjQQoTDnAD4OBAAAAiVwkGOsTZpBIg8AESIPCBEw5wA+DfwAAAIB4AwB06Q+2CA+2GinZZkE5yXMGZkQ52XIsD7ZIAQ+2WgEp2WZBOclzBmZEOdlyFg+2SAIPtloCKdlmQTnJc69mRDnZc6lMiflMi3wkCIPGAUmDwgREOeZyPTH2TTnyD4L6/v//RTHSTInQSIPEOFteX11BXEFdQV5BX8MPHwCLXCQYSAHqg8MBOfsPhUn////r1Q8fQABNOfJzyTl0JCwPg7n+//9NAfpNOfJztzH26ar+//8=")



         ; --------------------------------------------------------------------------------------------------------

         ; Search for the address of the first matching image.
         if (option == 1)
            address := DllCall(imagesearch1, "ptr", this.ptr, "uint", this.width, "uint", this.height
                     , "ptr", image.ptr, "uint", image.width, "uint", image.height
                     , "uint", x, "uint", y, "cdecl ptr")

         ; Search for the coordinates of the first matching image.
         if (option == 2)
            address := DllCall(imagesearch2, "ptr", this.ptr, "uint", this.width, "uint", this.height
                     , "ptr", image.ptr, "uint", image.width, "uint", image.height
                     , "uint", x, "uint", y, "ushort", variation, "cdecl ptr")

         ; Compare the address to the out-of-bounds limit.
         if (address == this.ptr + this.size)
            return False

         ; Return an [x, y] array.
         offset := (address - this.ptr) // 4
         return [mod(offset, this.width), offset // this.width]
      }

      ImageSearchAll(image, variation := 0) {

         ; Convert image to a buffer object.
         if !(IsObject(image) && image.HasProp("ptr") && image.HasProp("size"))
            image := ImagePutBuffer(image)

         ; Check if the object has the coordinates.
         x := image.HasProp("x") ? image.x : image.width//2
         y := image.HasProp("y") ? image.y : image.height//2

         if (variation == 0)
            option := 1
         else
            option := 2

         ; ------------------------ Machine code generated with MCode4GCC using gcc 13.2.0 ------------------------

         ; C source code - https://godbolt.org/z/qPodGdP1d
         imagesearchall1 := this.Base64Code((A_PtrSize == 4)
            ? "VYnlV1ZTg+wUi0UMi1UYi00IjTyFAAAAAItFECtFHA+vxwNFCIlF6ItFDCnQiUXkjQSVAAAAAIlF7ItF6DnBc2eLRRSLADkBdAmL"
            . "RRSAeAMAdVCJyCtFCDHSwfgC93UMOVXkfD4x0otFFInLiVXwi3XwO3UcdDyLVeyJ3gHCiVXgi1XgOdBzFIB4AwB0BosWORB1D4PA"
            . "BIPGBOvl/0XwAfvrzIPBBOuSi0UQD6/HA0UIicGDxBSJyFteX13D"
            : "QVdBVkFVQVRVV1ZTSIPsGEUx20SLpCSYAAAAi4QkgAAAAESLlCSQAAAASIu8JIgAAABEKeBBD6/BSInLidZMicFNjSyARInIRCnQ"
            . "iUQkDEqNBJUAAAAASIkEJEw56XN0iwc5AXQGgH8DAHViSInIMdJMKcBIwfgCQffxOVQkDHxNSIn4Me0x0kQ54nQyTIs8JEGJ7k6N"
            . "NLFJAcdMOfhzGIB4AwB0CEWLFkQ5EHUgSIPABEmDxgTr4//CRAHN68lBOfNzB0SJ2EiJDMNB/8NIg8EE64dEidhIg8QYW15fXUFc"
            . "QV1BXkFfww==")

         imagesearchall2 := this.Base64Code((A_PtrSize == 4)
            ? ""
            : "QVdBVkFVQVRVV1ZTSIPsSIuEJNgAAABEi5QkwAAAAEiLnCS4AAAAi7wk4AAAAImUJJgAAACJwkEPr8FMjWwkPEEPr9JIiYwkkAAAAIuMJNAAAABIAchIAcpIweACMcmLFJNIiUQkEESJyESJy0Qp04lUJDyLlCSwAAAAK5QkyAAAAIlcJCRBD6/RSY00kESJ0kiJdCQoSCnQif5MjSSVAAAAAEjB4AL33kiJRCQYQY1C/2aJdCQiSMHgAkiJRCQIMcBIi3QkKEk58A+D2QAAADlEJCRzDUiLRCQISQHA6b8AAABIi3QkEDHSSY0cMEYPthwqD7Y0E0Ep82ZEOd9zCGZEO1wkInJUSP/CSIP6A3XdSIuUJLgAAABNicMx7esKSItcJBj/xUkB2zusJMgAAAB0RE6NNCJMOfJz5IB6AwB0KzHbD7Y0GkUPtjwbRCn+Zjn3cw9mO3QkInMISYPABP/A6zVI/8NIg/sDdddIg8IESYPDBOvAO4wkmAAAAHMRRYsYSIucJJAAAACJykSJHJP/wU0B4EQB0EQ5yA+CIP///zHA6Rn///+JyEiDxEhbXl9dQVxBXUFeQV/D")

         ; --------------------------------------------------------------------------------------------------------

         ; Global number of addresses (matching searches) to allocate.
         limit := 256

         ; If the limit is exceeded, the following routine will be run again.
         redo:
         result := Buffer(A_PtrSize * limit) ; Allocate buffer for addresses.

         ; Search for the address of the first matching image.
         count := DllCall(imagesearchall1, "ptr", result, "uint", limit
                  , "ptr", this.ptr, "uint", this.width, "uint", this.height
                  , "ptr", image.ptr, "uint", image.width, "uint", image.height
                  , "uint", x, "uint", y, "cdecl uint")

         count := DllCall(imagesearchall2, "ptr", result, "uint", limit
                  , "ptr", this.ptr, "uint", this.width, "uint", this.height
                  , "ptr", image.ptr, "uint", image.width, "uint", image.height
                  , "uint", x, "uint", y,  "ushort", variation, "cdecl uint")

         ; If the default 256 results is exceeded, run the machine code again.
         if (count > limit) {
            limit := count
            goto redo
         }

         ; Check if any matches are found.
         if (count = 0)
            return False

         ; Create an array of [x, y] coordinates.
         xys := []
         xys.count := count
         loop count {
            address := NumGet(result, A_PtrSize * (A_Index-1), "ptr")
            offset := (address - this.ptr) // 4
            xys.push([mod(offset, this.width), offset // this.width])
         }
         return xys
      }
   }

   static BitmapToScreenshot(pBitmap, screenshot := "", alpha := "") {
      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      x := IsObject(screenshot) && screenshot.Has(1) ? screenshot[1] : 0
      y := IsObject(screenshot) && screenshot.Has(2) ? screenshot[2] : 0
      w := IsObject(screenshot) && screenshot.Has(3) ? screenshot[3] : width
      h := IsObject(screenshot) && screenshot.Has(4) ? screenshot[4] : height

      ; Convert the Bitmap to a hBitmap and associate a device context for blitting.
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      hbm := this.BitmapToHBitmap(pBitmap, alpha)
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Retrieve the device context for the screen.
      ddc := DllCall("GetDC", "ptr", 0, "ptr")

      ; Perform bilinear interpolation. See: https://stackoverflow.com/a/4358798
      DllCall("SetStretchBltMode", "ptr", ddc, "int", 4) ; HALFTONE

      ; Copies a portion of the screen to a new device context.
      DllCall("gdi32\StretchBlt"
               , "ptr", ddc, "int", x, "int", y, "int", w,     "int", h
               , "ptr", hdc, "int", 0, "int", 0, "int", width, "int", height
               , "uint", 0x00CC0020) ; SRCCOPY

      ; Release the device context to the screen.
      DllCall("ReleaseDC", "ptr", 0, "ptr", ddc)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteObject", "ptr", hbm)
      DllCall("DeleteDC",     "ptr", hdc)

      return [x,y,w,h]
   }

   static BitmapToWindow(pBitmap, title:="", pos:="", style:="", styleEx:="", parent:="", playback:="", cache:="") {
      ; Window Styles - https://docs.microsoft.com/en-us/windows/win32/winmsg/window-styles
      ; Extended Window Styles - https://docs.microsoft.com/en-us/windows/win32/winmsg/extended-window-styles

      ; Parent Window
      WS_POPUP                  := 0x80000000   ; Allow small windows.
      WS_CLIPCHILDREN           :=  0x2000000   ; Prevents redraw of pixels covered by child windows.
      WS_CAPTION                :=   0xC00000   ; Titlebar.
      WS_SYSMENU                :=    0x80000   ; Close button. Comes with Alt+Space menu.
      WS_EX_TOPMOST             :=        0x8   ; Always on top.
      WS_EX_DLGMODALFRAME       :=        0x1   ; Removes small icon in titlebar with A_ScriptHwnd as parent.

      ; Child Window
      WS_CHILD                  := 0x40000000   ; Creates a child window.
      WS_VISIBLE                := 0x10000000   ; Show on creation.
      WS_EX_LAYERED             :=    0x80000   ; For UpdateLayeredWindow.

      ; Default styles can be overwritten by previous functions.
      (style == "") && style := WS_POPUP | WS_CLIPCHILDREN | WS_CAPTION | WS_SYSMENU
      (styleEx == "") && styleEx := WS_EX_TOPMOST | WS_EX_DLGMODALFRAME

      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Get Screen width and height with DPI awareness.
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      ScreenWidth := A_ScreenWidth
      ScreenHeight := A_ScreenHeight
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; If both dimensions exceed the screen boundaries, compare the aspect ratio of the image
      ; to the aspect ratio of the screen to determine the scale factor. Default scale is 1.
      s := IsObject(pos) && pos.Has(3) && pos[3] ~= "^(?!0+$)\d+$" ? pos[3] / width
         : IsObject(pos) && pos.Has(4) && pos[4] ~= "^(?!0+$)\d+$" ? pos[4] / height
         : (width > ScreenWidth) && (width / height > ScreenWidth / ScreenHeight) ? ScreenWidth / width
         : (height > ScreenHeight) && (width / height <= ScreenWidth / ScreenHeight) ? ScreenHeight / height
         : 1

      w := IsObject(pos) && pos.Has(3) && pos[3] ~= "^(?!0+$)\d+$" ? pos[3] : s * width
      h := IsObject(pos) && pos.Has(4) && pos[4] ~= "^(?!0+$)\d+$" ? pos[4] : s * height

      x := IsObject(pos) && pos.Has(1) && pos[1] ~= "^-?\d+$" ? pos[1] : 0.5*(ScreenWidth - w)
      y := IsObject(pos) && pos.Has(2) && pos[2] ~= "^-?\d+$" ? pos[2] : 0.5*(ScreenHeight - h)

      ; Adjust x and y if a relative to window position is given.
      if IsObject(pos) && pos.Has(5) && WinExist(pos[5]) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &xr, &yr,,, pos[5]
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         x += xr
         y += yr
      }




      ; Resolve dependent coordinates first, coordinates second, and distances last.
      x2 := Round(x + w)
      y2 := Round(y + h)
      x  := Round(x)
      y  := Round(y)
      w  := x2 - x
      h  := y2 - y

      rect := Buffer(16)
         NumPut("int",  x, rect,  0)
         NumPut("int",  y, rect,  4)
         NumPut("int", x2, rect,  8)
         NumPut("int", y2, rect, 12)

      DllCall("AdjustWindowRectEx", "ptr", rect, "uint", style, "int", 0, "uint", styleEx)

      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      hwnd := DllCall("CreateWindowEx"
               ,   "uint", styleEx
               ,    "str", this.WindowClass()       ; lpClassName
               ,    "str", title                    ; lpWindowName
               ,   "uint", style
               ,    "int", NumGet(rect,  0, "int")
               ,    "int", NumGet(rect,  4, "int")
               ,    "int", NumGet(rect,  8, "int") - NumGet(rect,  0, "int")
               ,    "int", NumGet(rect, 12, "int") - NumGet(rect,  4, "int")
               ,    "ptr", (parent != "") ? parent : A_ScriptHwnd
               ,    "ptr", 0                        ; hMenu
               ,    "ptr", 0                        ; hInstance
               ,    "ptr", 0                        ; lpParam
               ,    "ptr")
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; Tests have shown that changing the system default colors has no effect on F0F0F0.
      ; Must call SetWindowLong with WS_EX_LAYERED immediately before SetLayeredWindowAttributes.
      DllCall("SetWindowLong", "ptr", hwnd, "int", -20, "int", styleEx | WS_EX_LAYERED)
      DllCall("SetLayeredWindowAttributes", "ptr", hwnd, "uint", 0xF0F0F0, "uchar", 0, "int", 1)

      ; A layered child window is only available on Windows 8+.
      child := this.Show(pBitmap, title, [0, 0, w, h], WS_CHILD | WS_VISIBLE, WS_EX_LAYERED, hwnd, playback, cache)

      ; Store extra data inside window struct (cbWndExtra).
      DllCall("SetWindowLong", "ptr", hwnd, "int", 0*A_PtrSize, "ptr", hwnd) ; parent window
      DllCall("SetWindowLong", "ptr", hwnd, "int", 1*A_PtrSize, "ptr", child) ; child window
      DllCall("SetWindowLong", "ptr", child, "int", 0*A_PtrSize, "ptr", hwnd) ; parent window
      DllCall("SetWindowLong", "ptr", child, "int", 1*A_PtrSize, "ptr", child) ; child window

      ; Delaying this call prevents empty window borders from appearing.
      DllCall("ShowWindow", "ptr", hwnd, "int", 1)

      return hwnd
   }

   static Show(pBitmap, title:="", pos:="", style:="", styleEx:="", parent:="", playback:="", cache:="") {
      ; Window Styles - https://docs.microsoft.com/en-us/windows/win32/winmsg/window-styles
      WS_POPUP                  := 0x80000000   ; Allow small windows.
      WS_VISIBLE                := 0x10000000   ; Show on creation.

      ; Extended Window Styles - https://docs.microsoft.com/en-us/windows/win32/winmsg/extended-window-styles
      WS_EX_TOPMOST             :=        0x8   ; Always on top.
      WS_EX_TOOLWINDOW          :=       0x80   ; Hides from Alt+Tab menu. Removes small icon.
      WS_EX_LAYERED             :=    0x80000   ; For UpdateLayeredWindow.

      ; Default styles can be overwritten by previous functions.
      (style == "") && style := WS_POPUP | WS_VISIBLE
      (styleEx == "") && styleEx := WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED

      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Get Screen width and height with DPI awareness.
      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      ScreenWidth := A_ScreenWidth
      ScreenHeight := A_ScreenHeight
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; If both dimensions exceed the screen boundaries, compare the aspect ratio of the image
      ; to the aspect ratio of the screen to determine the scale factor. Default scale is 1.
      s := IsObject(pos) && pos.Has(3) && pos[3] ~= "^(?!0+$)\d+$" ? pos[3] / width
         : IsObject(pos) && pos.Has(4) && pos[4] ~= "^(?!0+$)\d+$" ? pos[4] / height
         : (width > ScreenWidth) && (width / height > ScreenWidth / ScreenHeight) ? ScreenWidth / width
         : (height > ScreenHeight) && (width / height <= ScreenWidth / ScreenHeight) ? ScreenHeight / height
         : 1

      w := IsObject(pos) && pos.Has(3) && pos[3] ~= "^(?!0+$)\d+$" ? pos[3] : s * width
      h := IsObject(pos) && pos.Has(4) && pos[4] ~= "^(?!0+$)\d+$" ? pos[4] : s * height

      x := IsObject(pos) && pos.Has(1) && pos[1] ~= "^-?\d+$" ? pos[1] : 0.5*(ScreenWidth - w)
      y := IsObject(pos) && pos.Has(2) && pos[2] ~= "^-?\d+$" ? pos[2] : 0.5*(ScreenHeight - h)

      ; Adjust x and y if a relative to window position is given.
      if IsObject(pos) && pos.Has(5) && WinExist(pos[5]) {
         try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
         WinGetClientPos &xr, &yr,,, pos[5]
         try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")
         x += xr
         y += yr
      }




      ; Resolve dependent coordinates first, coordinates second, and distances last.
      x2 := Round(x + w)
      y2 := Round(y + h)
      x  := Round(x)
      y  := Round(y)
      w  := x2 - x
      h  := y2 - y

      ; Convert the source pBitmap into a hBitmap manually.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",         w, bi,  4) ; Width
         NumPut(   "int",        -h, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Case 1: Image is not scaled.
      if (w == width && h == height) {
         ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
         rect := Buffer(16, 0)                  ; sizeof(rect) = 16
            NumPut(  "uint",   width, rect,  8) ; Width
            NumPut(  "uint",  height, rect, 12) ; Height

         ; (Type 5c) Transfer pixels from the GDI+ Bitmap (ARGB) to the pBits (pARGB).
         BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
            NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
            NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
         DllCall("gdiplus\GdipBitmapLockBits"
                  ,    "ptr", pBitmap
                  ,    "ptr", rect
                  ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
                  ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
                  ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.
         DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)
      }

      ; Case 2: Image is scaled.
      else {
         ; Create a graphics context as the rendering destination.
         DllCall("gdiplus\GdipCreateFromHDC", "ptr", hdc , "ptr*", &pGraphics:=0)
         DllCall("gdiplus\GdipSetPixelOffsetMode",    "ptr", pGraphics, "int", 2) ; Half pixel offset.
         DllCall("gdiplus\GdipSetCompositingMode",    "ptr", pGraphics, "int", 1) ; Overwrite/SourceCopy.
         DllCall("gdiplus\GdipSetInterpolationMode",  "ptr", pGraphics, "int", 7) ; HighQualityBicubic

         ; Draw Image.
         DllCall("gdiplus\GdipCreateImageAttributes", "ptr*", &ImageAttr:=0)
         DllCall("gdiplus\GdipSetImageAttributesWrapMode", "ptr", ImageAttr, "int", 3, "uint", 0, "int", 0) ; WrapModeTileFlipXY
         DllCall("gdiplus\GdipDrawImageRectRectI"
                  ,    "ptr", pGraphics
                  ,    "ptr", pBitmap
                  ,    "int", 0, "int", 0, "int", w,     "int", h      ; destination rectangle
                  ,    "int", 0, "int", 0, "int", width, "int", height ; source rectangle
                  ,    "int", 2
                  ,    "ptr", ImageAttr
                  ,    "ptr", 0
                  ,    "ptr", 0)
         DllCall("gdiplus\GdipDisposeImageAttributes", "ptr", ImageAttr)

         ; Cleanup!
         DllCall("gdiplus\GdipDeleteGraphics", "ptr", pGraphics)
      }

      try dpi := DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
      hwnd := DllCall("CreateWindowEx"
               ,   "uint", styleEx | WS_EX_LAYERED  ; dwExStyle
               ,    "str", this.WindowClass()       ; lpClassName
               ,    "str", title                    ; lpWindowName
               ,   "uint", style                    ; dwStyle
               ,    "int", x
               ,    "int", y
               ,    "int", w
               ,    "int", h
               ,    "ptr", (parent != "") ? parent : A_ScriptHwnd
               ,    "ptr", 0                        ; hMenu
               ,    "ptr", 0                        ; hInstance
               ,    "ptr", 0                        ; lpParam
               ,    "ptr")
      try DllCall("SetThreadDpiAwarenessContext", "ptr", dpi, "ptr")

      ; Draw the contents of the device context onto the layered window.
      DllCall("UpdateLayeredWindow"
               ,    "ptr", hwnd                     ; hWnd
               ,    "ptr", 0                        ; hdcDst
               ,    "ptr", 0                        ; *pptDst
               ,"uint64*", w | h << 32              ; *psize
               ,    "ptr", hdc                      ; hdcSrc
               , "int64*", 0                        ; *pptSrc
               ,   "uint", 0                        ; crKey
               ,  "uint*", 0xFF << 16 | 0x01 << 24  ; *pblend
               ,   "uint", 2)                       ; dwFlags

      ; Store extra data inside window struct (cbWndExtra).
      ; For 64 -> 32-bit: https://learn.microsoft.com/en-us/windows/win32/winprog64/interprocess-communication
      DllCall("SetWindowLong", "ptr", hwnd, "int", 0*A_PtrSize, "ptr", hwnd) ; parent window (same, only 1 window for now)
      DllCall("SetWindowLong", "ptr", hwnd, "int", 1*A_PtrSize, "ptr", hwnd) ; child window  (same, only 1 window for now)
      DllCall("SetWindowLong", "ptr", hwnd, "int", 2*A_PtrSize, "ptr", hdc)  ; hdc contains a pixel buffer too!

      obj := {scale: 5
            , scales: [0.125, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 3, 4, 6, 8, 12]}
      ObjAddRef(ObjPtr(obj)) ; Hold onto this object for dear life!
      DllCall("SetWindowLong" (A_PtrSize=8?"Ptr":""), "ptr", hwnd, "int", 3*A_PtrSize, "ptr", ObjPtr(obj))

      ; Check for multiple frames. This can be in either the page (WEBP) or time (GIF) dimension.
      DllCall("gdiplus\GdipImageGetFrameDimensionsCount", "ptr", pBitmap, "uint*", &dims:=0)
      DllCall("gdiplus\GdipImageGetFrameDimensionsList", "ptr", pBitmap, "ptr", dimIDs := Buffer(16*dims), "uint", dims)
      DllCall("gdiplus\GdipImageGetFrameCount", "ptr", pBitmap, "ptr", dimIDs, "uint*", &number:=0)
      DllCall("gdiplus\GdipGetPropertyItemSize", "ptr", pBitmap, "uint", 0x5100, "uint*", &nDelays:=0)

      ; Animations!
      if (number > 1 && nDelays > 0) {

         ; Get the frame delays from PropertyTagFrameDelay.
         pDelays := DllCall("GlobalAlloc", "uint", 0, "uptr", nDelays, "ptr")
         DllCall("gdiplus\GdipGetPropertyItem", "ptr", pBitmap, "uint", 0x5100, "uint", nDelays, "ptr", pDelays)

         ; Check if WEBP or GIF from PropertyTagTypeLong.
         type := NumGet(pDelays + 8, "ushort") == 4 ? "gif" : "webp"

         ; Save frame delays because retrieving them is slow enough to impact timing.
         p := NumGet(pDelays + 8 + A_PtrSize, "ptr") ; Offset to array of delays
         delays := Map()                             ; Start index from 0
         loop number {
            A_Offset := A_Index - 1
            delay := NumGet(p + 4*A_Offset, "uint")

            ; See: https://www.biphelps.com/blog/The-Fastest-GIF-Does-Not-Exist
            if (type = "gif") {
               delay *= 10                      ; Convert centiseconds to milliseconds
               delay := max(delay, 10)          ; Minimum delay is 10ms
               (delay == 10) && delay := 100    ; 10 ms is actually 100 ms
            }

            if (type = "webp") {
               (delay == 0) && delay := 100     ; 10 ms is actually 100 ms
            }

            delays[A_Offset] := delay
         }

         ; Calculate the greatest common factor of all frame delays.
         for each, delay in delays
            if (A_Index = 1)
               interval := delay ; Initalize the interval.
            else
               while delay {
                  temp := mod(interval, delay)
                  interval := delay
                  delay := temp
               }

         ; Because timeSetEvent calls in a seperate thread, redirect to main thread.
         ; LPTIMECALLBACK: (uTimerID, uMsg, dwUser, dw1, dw2)
         pTimeProc := this.SyncWindowProc(hwnd, 0x8000)

         ; Create an object to hold all the extra data.
         obj.type := type            ; Either "gif" or "webp"
         obj.w := w                  ; width
         obj.h := h                  ; height
         obj.frame := 0              ; current frame (zero-indexed)
         obj.number := number        ; max frames
         obj.accumulate := 0         ; current wait time
         obj.delays := delays        ; array of frame delays
         obj.interval := interval    ; timer resolution
         obj.pTimeProc := pTimeProc  ; callback address
         obj.dimIDs := dimIDs        ; frame dimension guid (Time or Page)

         ; Case 1: Image is not scaled.
         if (!cache && w == width && h == height) {
            ; Clone bitmap to avoid disposal.
            DllCall("gdiplus\GdipCloneImage", "ptr", pBitmap, "ptr*", &pBitmapClone:=0)
            DllCall("gdiplus\GdipImageForceValidation", "ptr", pBitmapClone) ; Load to memory.

            ; Save the cloned bitmap and pixel buffer.
            obj.pBitmap := pBitmapClone
            obj.pBits := pBits

            ; Preserve GDI+ scope due to the active pBitmap above.
            ImagePut.gdiplusStartup()
         }

         ; Case 2: Image is scaled.
         else {

            ; Create a cache of pre-rendered frames. Note: This can be very slow.
            ; Fixes problems with the animation being paused when dragged by the user.
            cache := Map(0, hdc)

            ; --------- Overwrites the hdc, hbm, and pBits variables!!!!!! ---------
            loop number {
               ; Select frame to show.
               frame := A_Index
               DllCall("gdiplus\GdipImageSelectActiveFrame", "ptr", pBitmap, "ptr", dimIDs, "uint", frame)

               ; Get Bitmap width and height.
               DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
               DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

               ; Convert the source pBitmap into a hBitmap manually.
               ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
               hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
               bi := Buffer(40, 0)                    ; sizeof(bi) = 40
                  NumPut(  "uint",        40, bi,  0) ; Size
                  NumPut(   "int",         w, bi,  4) ; Width
                  NumPut(   "int",        -h, bi,  8) ; Height - Negative so (0, 0) is top-left.
                  NumPut("ushort",         1, bi, 12) ; Planes
                  NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
               hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
               obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

               ; Create a graphics context as the rendering destination.
               DllCall("gdiplus\GdipCreateFromHDC", "ptr", hdc , "ptr*", &pGraphics:=0)
               DllCall("gdiplus\GdipSetPixelOffsetMode",    "ptr", pGraphics, "int", 2) ; Half pixel offset.
               DllCall("gdiplus\GdipSetCompositingMode",    "ptr", pGraphics, "int", 1) ; Overwrite/SourceCopy.
               DllCall("gdiplus\GdipSetInterpolationMode",  "ptr", pGraphics, "int", 7) ; HighQualityBicubic

               ; Draw Image.
               DllCall("gdiplus\GdipCreateImageAttributes", "ptr*", &ImageAttr:=0)
               DllCall("gdiplus\GdipSetImageAttributesWrapMode", "ptr", ImageAttr, "int", 3, "uint", 0, "int", 0) ; WrapModeTileFlipXY
               DllCall("gdiplus\GdipDrawImageRectRectI"
                        ,    "ptr", pGraphics
                        ,    "ptr", pBitmap
                        ,    "int", 0, "int", 0, "int", w,     "int", h      ; destination rectangle
                        ,    "int", 0, "int", 0, "int", width, "int", height ; source rectangle
                        ,    "int", 2
                        ,    "ptr", ImageAttr
                        ,    "ptr", 0
                        ,    "ptr", 0)
               DllCall("gdiplus\GdipDisposeImageAttributes", "ptr", ImageAttr)

               ; Cleanup!
               DllCall("gdiplus\GdipDeleteGraphics", "ptr", pGraphics)

               ; Save rendered frame.
               cache[frame] := hdc
            }

            ; Send cache to WM_APP.
            obj.cache := cache
         }

         ; Start GIF Animation loop. Defaults to immediate playback.
         if (playback == "" || playback == True)
            DllCall("PostMessage", "ptr", hwnd, "uint", 0x8001, "uptr", 0, "ptr", 0)
      }

      return hwnd
   }

   static WindowClass(style := 0x8) {
      ; The window class shares the name of this class.
      cls := this.prototype.__class
      wc := Buffer(A_PtrSize = 4 ? 48:80) ; sizeof(WNDCLASSEX) = 48, 80

      ; Check if the window class is already registered.
      hInstance := DllCall("GetModuleHandle", "ptr", 0, "ptr")
      if DllCall("GetClassInfoEx", "ptr", hInstance, "str", cls, "ptr", wc)
         return cls

      ; Create window data.
      pWndProc := CallbackCreate((hwnd, uMsg, wParam, lParam) => this.WindowProc(hwnd, uMsg, wParam, lParam))
      hCursor := DllCall("LoadCursor", "ptr", 0, "ptr", 32512, "ptr") ; IDC_ARROW
      hBrush := DllCall("GetStockObject", "int", 5, "ptr") ; Hollow_brush

      ; struct tagWNDCLASSEXA - https://docs.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-wndclassexa
      ; struct tagWNDCLASSEXW - https://docs.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-wndclassexw
      _ := (A_PtrSize = 4)
         NumPut(  "uint",     wc.size, wc,         0) ; cbSize
         NumPut(  "uint",       style, wc,         4) ; style
         NumPut(   "ptr",    pWndProc, wc,         8) ; lpfnWndProc
         NumPut(   "int",           0, wc, _ ? 12:16) ; cbClsExtra
         NumPut(   "int",          40, wc, _ ? 16:20) ; cbWndExtra
         NumPut(   "ptr",           0, wc, _ ? 20:24) ; hInstance
         NumPut(   "ptr",           0, wc, _ ? 24:32) ; hIcon
         NumPut(   "ptr",     hCursor, wc, _ ? 28:40) ; hCursor
         NumPut(   "ptr",      hBrush, wc, _ ? 32:48) ; hbrBackground
         NumPut(   "ptr",           0, wc, _ ? 36:56) ; lpszMenuName
         NumPut(   "ptr", StrPtr(cls), wc, _ ? 40:64) ; lpszClassName
         NumPut(   "ptr",           0, wc, _ ? 44:72) ; hIconSm

      ; Registers a window class for subsequent use in calls to the CreateWindow or CreateWindowEx function.
      DllCall("RegisterClassEx", "ptr", wc, "ushort")

      ; Return the class name as a string.
      return cls
   }

   static WindowProc(hwnd, uMsg, wParam, lParam) {
      ; (v2 only) Pass as a closure, otherwise hwnd := this would be needed.

      ; Prevent the script from exiting early.
      static active_windows := Persistent()

      ; WM_CREATE
      if (uMsg = 0x1)
         Persistent(++active_windows)

      ; WM_DESTROY
      if (uMsg = 0x2) {
         Persistent(--active_windows)

         ; Continue if the child window is found. It contains all of the assets to be freed.
         if (hwnd != DllCall("GetWindowLong", "ptr", hwnd, "int", 1*A_PtrSize, "ptr"))
            return

         ; Get stock bitmap.
         obm := DllCall("CreateBitmap", "int", 0, "int", 0, "uint", 1, "uint", 1, "ptr", 0, "ptr")

         ; Cleanup the device context and its selected hBitmap.
         if hdc := DllCall("GetWindowLong", "ptr", hwnd, "int", 2*A_PtrSize, "ptr") {
            hbm := DllCall("SelectObject", "ptr", hdc, "ptr", obm, "ptr")
            DllCall("DeleteObject", "ptr", hbm)
            DllCall("DeleteDC", "ptr", hdc)
         }

         ; The object will self-destruct at end of scope. No need to add a reference!
         if ptr := DllCall("GetWindowLong" (A_PtrSize=8?"Ptr":""), "ptr", hwnd, "int", 3*A_PtrSize, "ptr") {
            obj := ObjFromPtr(ptr)

            ; Exit GIF animation loop. Ends any triggered WM_APP.
            DllCall("SetWindowLong" (A_PtrSize=8?"Ptr":""), "ptr", hwnd, "int", 3*A_PtrSize, "ptr", 0)

            ; Stop Animation loop.
            if timer := DllCall("GetWindowLong", "ptr", hwnd, "int", 4*A_PtrSize, "ptr")
               DllCall("winmm\timeKillEvent", "uint", timer)

            if obj.HasProp("pTimeProc")
               DllCall("GlobalFree", "ptr", obj.pTimeProc)

            if obj.HasProp("pBitmap") {
               DllCall("gdiplus\GdipDisposeImage", "ptr", obj.pBitmap)
               ImagePut.gdiplusShutdown()
            }

            if obj.HasProp("cache") {
               for each, hdc in obj.cache { ; Overwrites the hdc and hbm variables.
                  hbm := DllCall("SelectObject", "ptr", hdc, "ptr", obm, "ptr")
                  DllCall("DeleteObject", "ptr", hbm)
                  DllCall("DeleteDC", "ptr", hdc)
               }
            }
         }
      }

      ; Let's start using custom defined parameters from the window struct.
      if (uMsg = 0x1 || uMsg = 0x2)
         goto default

      ; Remember the child window contains all the assets.
      parent := DllCall("GetWindowLong", "ptr", hwnd, "int", 0*A_PtrSize, "ptr")
      child := DllCall("GetWindowLong", "ptr", hwnd, "int", 1*A_PtrSize, "ptr")
      hdc := DllCall("GetWindowLong", "ptr", child, "int", 2*A_PtrSize, "ptr")
      if ptr := DllCall("GetWindowLong" (A_PtrSize=8?"Ptr":""), "ptr", child, "int", 3*A_PtrSize, "ptr")
         obj := ObjFromPtrAddRef(ptr)
      timer := DllCall("GetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr")

      ; For some reason using DefWindowProc or PostMessage to reroute WM_LBUTTONDOWN to WM_NCLBUTTONDOWN
      ; will always disable the complementary WM_LBUTTONUP. However, if the CS_DBLCLKS window style is set,
      ; then a single WM_RBUTTONUP will be received as double-clicking generates a sequence of four messages:
      ; WM_LBUTTONDOWN, WM_LBUTTONUP, WM_LBUTTONDBLCLK, and WM_LBUTTONUP.
      ;                 ^ This message is lost when 0x201 → 0xA1.
      ;                               ^ Only happens when 0x8 is set in RegisterClass.

      ; WM_LBUTTONDOWN - Drag to move the window.
      if (uMsg = 0x201)
         return DllCall("DefWindowProc", "ptr", obj.scales[obj.scale] > 1 ? child : parent, "uint", 0xA1, "uptr", 2, "ptr", 0, "ptr")

      ; WM_LBUTTONUP - Double Click to toggle between play and pause.
      if (uMsg = 0x202)
         DllCall("GetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr")
         ? uMsg := 0x8002 ; Pause
         : uMsg := 0x8001 ; Play

      ; WM_RBUTTONUP - Destroy the window.
      if (uMsg = 0x205)
         return DllCall("DestroyWindow", "ptr", parent)

      ; WM_MBUTTONDOWN - Show x, y, and color.
      if (uMsg = 0x207) {
         hdc := DllCall("GetWindowLong", "ptr", child, "int", 2*A_PtrSize, "ptr")

         ; Get pBits from hBitmap currently selected onto the device context.
         ; struct DIBSECTION - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-dibsection
         ; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
         hbm := DllCall("GetCurrentObject", "ptr", hdc, "uint", 7)
         dib := Buffer(64+5*A_PtrSize) ; sizeof(DIBSECTION) = 84, 104
         DllCall("GetObject", "ptr", hbm, "int", dib.size, "ptr", dib)
            , width  := NumGet(dib, 4, "uint")
            , height := NumGet(dib, 8, "uint")
            , pBits  := NumGet(dib, A_PtrSize = 4 ? 20:24, "ptr")

         ; Safe limits for x and y.
         x := lParam << 48 >> 48
         y := lParam << 32 >> 48
         (x < 0) && x := 0
         (x >= width) && x := width-1
         (y < 0) && y := 0
         (y >= height) && y := height-1

         ; Get color.
         c := Format("0x{:08X}", NumGet(pBits + 4*(y*width + x), "uint"))

         ; Process background color (BGR) and text color (greyscale).
         background_color := RegExReplace(c, "^0x..(..)(..)(..)$", "0x$3$2$1")
         text_color := (0.3*(255&c>>16) + 0.59*(255&c>>8) + 0.11*(255&c)) >= 128 ? 0x000000 : 0xFFFFFF

         ; Show tooltip. Use Tooltip #16.
         tt := Tooltip(" (" x ", " y ") `n " SubStr(c, 3) " ",,, 16)


         ; Style background and text color.
         DllCall("UxTheme\SetWindowTheme", "ptr", tt, "ptr", 0, "ptr", Buffer(2, 0), "hresult")
         DllCall("SendMessage", "ptr", tt, "uint", 1043, "ptr", background_color, "ptr", 0)
         DllCall("SendMessage", "ptr", tt, "uint", 1044, "ptr", text_color, "ptr", 0)

         ; Destroy tooltip after 7 seconds of the last showing.
         SetTimer Reset_Tooltip, -7000
         return

         Reset_Tooltip() {
            Tooltip(,,, 16)
         }
      }

      ; WM_APP - Animate GIFs
      if (uMsg = 0x8000) {
         ; Thanks tmplinshi, Teadrinker - https://www.autohotkey.com/boards/viewtopic.php?f=76&t=83358
         Critical

         ; Exit GIF animation loop. Set by WM_Destroy.
         if !ptr
            return

         ; Get variables. ObjRelease is automatically called at the end of the scope.
         w := obj.w
         h := obj.h
         frame := obj.frame
         number := obj.number
         accumulate := obj.accumulate
         delays := obj.delays
         interval := obj.interval
         pTimeProc := obj.pTimeProc
         dimIDs := obj.dimIDs
         obj.HasProp("pBitmap") && pBitmap := obj.pBitmap ; not scaled
         obj.HasProp("pBits") && pBits := obj.pBits       ; not scaled
         obj.HasProp("cache") && cache := obj.cache       ; is scaled
      }

      ; Each timer interval is the GCF of all frame delays.
      ; Avoids using oneshot timers to reduce additive jitter from constant overhead.
      if (uMsg = 0x8000 && wParam == 0) {
         index := mod(frame + 1, number)     ; Increment and loop back to zero
         delay := delays[index]              ; Zero-based array

         ; The current wait time is advanced by one interval.
         accumulate += interval              ; Add resolution of timer
         obj.accumulate := accumulate        ; Save the current wait time

         ; Check if enough time has passed to advance to the next frame.
         if (accumulate == delay)
            wParam := 1                      ; Step size of +1
      }

      ; WM_APP - Advance to next frame.
      if (uMsg = 0x8000 && wParam != 0) {
         ; Restrict frame index from 0 to the maximum number of frames - 1.
         frame := mod(mod(frame + wParam, number) + number, number)

         obj.frame := frame                  ; Update to next frame number
         obj.accumulate := 0                 ; Resets the wait time

         /*
         ; Debug code
         static start := 0, sum := 0, count := 0
         DllCall("QueryPerformanceFrequency", "int64*", &frequency:=0)
         DllCall("QueryPerformanceCounter", "int64*", &now:=0)
         time := (now - start) / frequency * 1000
         if (time < 10000) {
            sum += time
            count += 1
            ; Prevents the tooltip from impacting timings by showing every 10 frames.
            if (mod(count, 10) = 0)
               Tooltip   "Current Delay:`t" Round(time, 4)
                  . "`n" "Average Delay:`t" Round(sum / count, 4)
                  . "`n" "Planned Delay:`t" (delay ?? "unknown")
                  . "`n" "Timer Resolution:`t" interval
                  . "`n" "Average FPS:`t" Round(count / (sum / 1000), 4)
                  . "`n" "Frame Number:`t" frame " of " number
         }
         start := now
         */

         ; Case 1: Image is not scaled.
         if not obj.HasProp("cache") {
            ; Select frame to show.


            DllCall("gdiplus\GdipImageSelectActiveFrame", "ptr", pBitmap, "ptr", dimIDs, "uint", frame)

            ; Get Bitmap width and height.
            DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
            DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

            ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
            rect := Buffer(16, 0)                  ; sizeof(rect) = 16
               NumPut(  "uint",   width, rect,  8) ; Width
               NumPut(  "uint",  height, rect, 12) ; Height

            ; (Type 5c) Transfer pixels from the GDI+ Bitmap (ARGB) to the pBits (pARGB).
            BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
               NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
               NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
            DllCall("gdiplus\GdipBitmapLockBits"
                     ,    "ptr", pBitmap
                     ,    "ptr", rect
                     ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
                     ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
                     ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.
            DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

            ; Use the saved device context for rendering.
            hdc := DllCall("GetWindowLong", "ptr", child, "int", 2*A_PtrSize, "ptr")
         }

         ; Case 2: Image is scaled.
         else {
            ; Define the device context for rendering.
            hdc := cache[frame]

            ; Sets the currently active device context for WM_MBUTTONDOWN.
            DllCall("SetWindowLong", "ptr", child, "int", 2*A_PtrSize, "ptr", hdc)
         }

         ; Render to window.
         DllCall("UpdateLayeredWindow"
                  ,    "ptr", child                    ; hWnd
                  ,    "ptr", 0                        ; hdcDst
                  ,    "ptr", 0                        ; *pptDst
                  ,"uint64*", w | h << 32              ; *psize
                  ,    "ptr", hdc                      ; hdcSrc
                  , "int64*", 0                        ; *pptSrc
                  ,   "uint", 0                        ; crKey
                  ,  "uint*", 0xFF << 16 | 0x01 << 24  ; *pblend
                  ,   "uint", 2)                       ; dwFlags
      }

      ; Clears the frame number and wait time.
      if (uMsg = 0x8001 || uMsg = 0x8002) {
         if (wParam) {
            obj.frame := 0
            obj.accumulate := 0
         }
      }

      ; Start Animation loop.
      if (uMsg = 0x8001) {
         if timer := DllCall("GetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr")
            return

         if obj.HasProp("pTimeProc") {
            timer := DllCall("winmm\timeSetEvent"
                     , "uint", obj.interval  ; uDelay
                     , "uint", obj.interval  ; uResolution
                     ,  "ptr", obj.pTimeProc ; lpTimeProc
                     , "uptr", 0             ; dwUser
                     , "uint", 1             ; fuEvent
                     , "uint")
            DllCall("SetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr", timer)
         }
      }

      ; Stop Animation loop.
      if (uMsg = 0x8002) {
         if (timer := DllCall("GetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr")) {
            DllCall("winmm\timeKillEvent", "uint", timer)
            DllCall("SetWindowLong", "ptr", child, "int", 4*A_PtrSize, "ptr", 0)
         }
      }

      default:
      return DllCall("DefWindowProc", "ptr", hwnd, "uint", uMsg, "uptr", wParam, "ptr", lParam, "ptr")
   }

   static SyncWindowProc(hwnd, uMsg, wParam := 0, lParam := 0) {
      hModule := DllCall("GetModuleHandle", "str", "user32.dll", "ptr")
      SendMessageW := DllCall("GetProcAddress", "ptr", hModule, "astr", "SendMessageW", "ptr")

      ncb := (A_PtrSize = 8) ? 71 : 28
      pcb := DllCall("GlobalAlloc", "uint", 0, "uptr", ncb, "ptr")
      DllCall("VirtualProtect", "ptr", pcb, "uptr", ncb, "uint", 0x40, "uint*", 0)

      ; Retract the hex representation to binary.
      if (A_PtrSize = 8) {
         assembly := "
            ( Join`s Comments
            48 89 4c 24 08                 ;   0: mov [rsp+8], rcx
            48 89 54 24 10                 ;   5: mov [rsp+16], rdx
            4c 89 44 24 18                 ;  10: mov [rsp+24], r8
            4c 89 4c 24 20                 ;  15: mov [rsp+32], r9
            48 83 ec 28                    ;  20: sub rsp, 40
            49 b9 00 00 00 00 00 00 00 00  ;  24: mov r9, .. (lParam)
            49 b8 00 00 00 00 00 00 00 00  ;  34: mov r8, .. (wParam)
            ba 00 00 00 00                 ;  44: mov edx, .. (uMsg)
            b9 00 00 00 00                 ;  49: mov ecx, .. (hwnd)
            48 b8 00 00 00 00 00 00 00 00  ;  54: mov rax, .. (SendMessageW)
            ff d0                          ;  64: call rax
            48 83 c4 28                    ;  66: add rsp, 40
            c3                             ;  70: ret
            )"                             ;  71:
         DllCall("crypt32\CryptStringToBinary", "str", assembly, "uint", 0, "uint", 0x4, "ptr", pcb, "uint*", ncb, "ptr", 0, "ptr", 0)
         NumPut("ptr", SendMessageW, pcb + 56)
         NumPut("int", hwnd, pcb + 50)
         NumPut("int", uMsg, pcb + 45)
         NumPut("ptr", wParam, pcb + 36)
         NumPut("ptr", lParam, pcb + 26)
      }
      else {
         assembly := "
            ( Join`s Comments
            68 00 00 00 00                 ;   0: push .. (lParam)
            68 00 00 00 00                 ;   5: push .. (wParam)
            68 00 00 00 00                 ;  10: push .. (uMsg)
            68 00 00 00 00                 ;  15: push .. (hwnd)
            b8 00 00 00 00                 ;  20: mov eax, .. (SendMessageW)
            ff d0                          ;  25: call eax
            c3                             ;  27: ret
            )"                             ;  28:
         DllCall("crypt32\CryptStringToBinary", "str", assembly, "uint", 0, "uint", 0x4, "ptr", pcb, "uint*", ncb, "ptr", 0, "ptr", 0)
         NumPut("int", SendMessageW, pcb + 21)
         NumPut("int", hwnd, pcb + 16)
         NumPut("int", uMsg, pcb + 11)
         NumPut("int", wParam, pcb + 6)
         NumPut("int", lParam, pcb + 1)
      }
      return pcb
   }

   static BitmapToDesktop(pBitmap, title:="", pos:="", style:="", styleEx:="", parent:="", playback:="", cache:="") {
      ; Thanks Gerald Degeneve - https://www.codeproject.com/Articles/856020/Draw-Behind-Desktop-Icons-in-Windows-plus
      ; Post-Creator's Update Windows 10. WM_SPAWN_WORKER = 0x052C
      desktop := WinExist("ahk_class Progman")
      DllCall("SendMessage", "ptr", desktop, "uint", 0x052C, "ptr", 0xD, "ptr", 0)
      DllCall("SendMessage", "ptr", desktop, "uint", 0x052C, "ptr", 0xD, "ptr", 1)

      ; Find a child window of class SHELLDLL_DefView.

      for window in WinGetList("ahk_class WorkerW")
         if DllCall("FindWindowEx", "ptr", window, "ptr", 0, "str", "SHELLDLL_DefView", "ptr", 0) {
            hwnd := window
            break
         }

      ; Find a child window of the desktop after the previous window of class WorkerW.
      if !(WorkerW := DllCall("FindWindowEx", "ptr", 0, "ptr", hwnd, "str", "WorkerW", "ptr", 0, "ptr"))
         throw Error("Could not locate hidden window behind desktop icons.")

      ; Once the WorkerW window is found, use it as the parent window.
      WS_CHILD                  := 0x40000000   ; Creates a child window.
      WS_VISIBLE                := 0x10000000   ; Show on creation.
      (style == "") && style := WS_CHILD | WS_VISIBLE
      return this.Show(pBitmap, title, pos, style | WS_CHILD, styleEx, WorkerW, playback, cache)
   }

   static BitmapToWallpaper(pBitmap) {
      ; Create a temporary image file.
      filepath := this.BitmapToFile(pBitmap)

      ; Get the absolute path of the file.
      length := DllCall("GetFullPathName", "str", filepath, "uint", 0, "ptr", 0, "ptr", 0, "uint")
      VarSetStrCapacity(&buf, length)
      DllCall("GetFullPathName", "str", filepath, "uint", length, "str", buf, "ptr", 0, "uint")

      ; Set the temporary image file as the new desktop wallpaper.
      DllCall("SystemParametersInfo", "uint", SPI_SETDESKWALLPAPER := 0x14, "uint", 0, "str", buf, "uint", 2)

      ; This is a delayed delete call. #Persistent may be required on v1.
      DeleteFile := () => DllCall("DeleteFile", "str", filepath)
      SetTimer DeleteFile, -2000

      return "wallpaper"
   }

   static BitmapToCursor(pBitmap, xHotspot := "", yHotspot := "") {
      ; Thanks Nick - https://stackoverflow.com/a/550965

      ; Creates an icon that can be used as a cursor.
      DllCall("gdiplus\GdipCreateHICONFromBitmap", "ptr", pBitmap, "ptr*", &hIcon:=0)

      ; Sets the hotspot of the cursor by changing the icon into a cursor.
      if (xHotspot ~= "^\d+$" || yHotspot ~= "^\d+$") {
         ; struct ICONINFO - https://docs.microsoft.com/en-us/windows/win32/api/winuser/ns-winuser-iconinfo
         ii := Buffer(8+3*A_PtrSize)                                 ; sizeof(ICONINFO) = 20, 32
         DllCall("GetIconInfo", "ptr", hIcon, "ptr", ii)             ; Fill the ICONINFO structure.
            NumPut("uint", False, ii, 0)                             ; True/False are icon/cursor respectively.
            (xHotspot ~= "^\d+$") && NumPut("uint", xHotspot, ii, 4) ; Set the xHotspot value. Default: center point
            (yHotspot ~= "^\d+$") && NumPut("uint", yHotspot, ii, 8) ; Set the yHotspot value. Default: center point
         DllCall("DestroyIcon", "ptr", hIcon)                        ; Destroy the icon after getting the ICONINFO structure.
         hIcon := DllCall("CreateIconIndirect", "ptr", ii, "ptr")    ; Create a new cursor using ICONINFO.

         ; Clean up hbmMask and hbmColor created as a result of GetIconInfo.
         DllCall("DeleteObject", "ptr", NumGet(ii, 8+A_PtrSize, "ptr"))   ; hbmMask
         DllCall("DeleteObject", "ptr", NumGet(ii, 8+2*A_PtrSize, "ptr")) ; hbmColor
      }

      ; Set all 17 System Cursors. Must copy 17 times as SetSystemCursor deletes the handle each time.
      Loop Parse, "32512,32513,32514,32515,32516,32631,32642,32643,32644,32645,32646,32648,32649,32650,32651,32671,32672", ","
         if hCursor := DllCall("CopyImage", "ptr", hIcon, "uint", 2, "int", 0, "int", 0, "uint", 0, "ptr")
            if !DllCall("SetSystemCursor", "ptr", hCursor, "int", A_LoopField) ; calls DestroyCursor
               DllCall("DestroyCursor", "ptr", hCursor)

      ; Destroy the original hIcon. Same as DestroyCursor.
      DllCall("DestroyIcon", "ptr", hIcon)

      ; Returns the string A_Cursor to avoid evaluation.
      return "A_Cursor"
   }

   static BitmapToURL(pBitmap, extension := "", quality := "") {
      body := this.BitmapToSafeArray(pBitmap, extension, quality)

      req := ComObject("WinHttp.WinHttpRequest.5.1")
      req.Open("POST", "https://api.imgur.com/3/image", true)
      req.SetRequestHeader("Authorization", "Client-ID " . "fbf77" "ff49" "c42c8a")
      req.Send(body)
      req.WaitForResponse()

      url := RegExReplace(req.ResponseText, "^.*?link\x22:\x22(.*?)\x22.*$", "$1")
      return url
   }

   static StreamToURL(stream) {
      body := this.StreamToSafeArray(stream)

      req := ComObject("WinHttp.WinHttpRequest.5.1")
      req.Open("POST", "https://api.imgur.com/3/image", true)
      req.SetRequestHeader("Authorization", "Client-ID " . "fbf77" "ff49" "c42c8a")
      req.Send(body)
      req.WaitForResponse()

      url := RegExReplace(req.ResponseText, "^.*?link\x22:\x22(.*?)\x22.*$", "$1")
      return url
   }

   static BitmapToExplorer(pBitmap, default_dir := "", background_window := False) {
      if directory := this.Explorer(default_dir, background_window)
         return this.BitmapToFile(pBitmap, directory)
   }

   static StreamToExplorer(stream, default_dir := "", background_window := False) {
      if directory := this.Explorer(default_dir, background_window)
         return this.StreamToFile(stream, directory)
   }

   static Explorer(default_dir := "", background_window := False) {
      ; Thanks @TheCrether
      GetExplorer := (background_window) ? WinExist : WinActive
      if (hwnd := GetExplorer("ahk_class ExploreWClass"))
      or (hwnd := GetExplorer("ahk_class CabinetWClass"))
         if tab := ExplorerTab(hwnd)
            switch Type(tab.Document) {
               case "ShellFolderView":
                  directory := tab.Document.Folder.Self.Path
               default: ; case "HTMLDocument"
                  directory := tab.LocationURL
            }

      if WinActive("ahk_class WorkerW") or WinActive("ahk_class Progman")
         directory := A_Desktop

      ; Returns the empty string if the directory is not found.
      return directory ?? default_dir

      ExplorerTab(hwnd) {
         ; Thanks Lexikos - https://www.autohotkey.com/boards/viewtopic.php?f=83&t=109907
         try activeTab := ControlGetHwnd("ShellTabWindowClass1", hwnd) ; File Explorer (Windows 11)
         catch
         try activeTab := ControlGetHwnd("TabWindowClass1", hwnd) ; IE
         for window in ComObject("Shell.Application").Windows {
            if (window.hwnd != hwnd)
               continue
            if IsSet(activeTab) { ; The window has tabs, so make sure this is the right one.
               static IID_IShellBrowser := "{000214E2-0000-0000-C000-000000000046}"
               IShellBrowser := ComObjQuery(window, IID_IShellBrowser, IID_IShellBrowser)
               ComCall(GetWindow := 3, IShellBrowser, "uint*", &thisTab := 0)
               if (thisTab != activeTab)
                  continue
            }
            return window ; Returns a ComObject with a .hwnd property
         }
         throw Error("Could not locate active tab in Explorer window.")
      }
   }

   static BitmapToFile(pBitmap, filepath := "", quality := "") {
      extension := "png"
      this.select_filepath(&filepath, &extension)
      this.select_codec(pBitmap, extension, quality, &pCodec, &ep)
      DllCall("gdiplus\GdipSaveImageToFile", "ptr", pBitmap, "wstr", filepath, "ptr", pCodec, "ptr", ep)
      return filepath
   }

   static StreamToFile(stream, filepath := "") {
      ; 2048 characters should be good enough to identify the file correctly.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      size := min(size, 2048)
      bin := Buffer(size)

      ; Get the first few bytes of the image.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Allocate enough space for a hexadecimal string with spaces interleaved and a null terminator.
      length := 2*size + (size-1) + 1
      VarSetStrCapacity(&str, length)

      ; Lift the binary representation to hex.
      flags := 0x40000004 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_HEX
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Determine the extension using herustics. See: http://fileformats.archiveteam.org
      extension := 0                                                              ? ""
      : str ~= "(?i)66 74 79 70 61 76 69 66"                                      ? "avif" ; ftypavif
      : str ~= "(?i)^42 4d (.. ){36}00 00 .. 00 00 00"                            ? "bmp"  ; BM
      : str ~= "(?i)^01 00 00 00 (.. ){36}20 45 4D 46"                            ? "emf"  ; emf
      : str ~= "(?i)^47 49 46 38 (37|39) 61"                                      ? "gif"  ; GIF87a or GIF89a
      : str ~= "(?i)66 74 79 70 68 65 69 63"                                      ? "heic" ; ftypheic
      : str ~= "(?i)^00 00 01 00"                                                 ? "ico"
      : str ~= "(?i)^ff d8 ff"                                                    ? "jpg"
      : str ~= "(?i)^25 50 44 46 2d"                                              ? "pdf"  ; %PDF-
      : str ~= "(?i)^89 50 4e 47 0d 0a 1a 0a"                                     ? "png"  ; PNG
      : str ~= "(?i)^(((?!3c|3e).. )|3c (3f|21) ((?!3c|3e).. )*3e )*+3c 73 76 67" ? "svg"  ; <svg
      : str ~= "(?i)^(49 49 2a 00|4d 4d 00 2a)"                                   ? "tif"  ; II* or MM*
      : str ~= "(?i)^52 49 46 46 .. .. .. .. 57 45 42 50"                         ? "webp" ; RIFF....WEBP
      : str ~= "(?i)^d7 cd c6 9a"                                                 ? "wmf"
      : "" ; Extension must be blank for file pass-through as-is.

      this.select_filepath(&filepath, &extension)

      ; For compatibility with SHCreateMemStream do not use GetHGlobalFromStream.
      DllCall("shlwapi\SHCreateStreamOnFileEx"
               ,   "wstr", filepath
               ,   "uint", 0x1001          ; STGM_CREATE | STGM_WRITE
               ,   "uint", 0x80            ; FILE_ATTRIBUTE_NORMAL
               ,    "int", True            ; fCreate is ignored when STGM_CREATE is set.
               ,    "ptr", 0               ; pstmTemplate (reserved)
               ,   "ptr*", &FileStream:=0
               ,"hresult")
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      DllCall("shlwapi\IStream_Copy", "ptr", stream, "ptr", FileStream, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      ObjRelease(FileStream)

      return filepath
   }

   static BitmapToHex(pBitmap, extension := "", quality := "") {
      stream := this.BitmapToStream(pBitmap, extension, quality) ; Defaults to PNG for small sizes!

      ; Get a pointer to binary data.
      DllCall("ole32\GetHGlobalFromStream", "ptr", stream, "ptr*", &hbin:=0, "hresult")
      bin := DllCall("GlobalLock", "ptr", hbin, "ptr")
      size := DllCall("GlobalSize", "ptr", hbin, "uptr")

      ; Calculate the length of the hexadecimal string.
      length := 2 * size ; No zero terminator needed.
      str := Buffer(length)

      ; C source code - https://godbolt.org/z/EqfK7fvr5
      static code := 0
      if !code {
         b64 := (A_PtrSize == 4)
            ? "VYnlVotFDIt1EFOLTRSLXQgBxjnwcyCKEIPBAkDA6gQPttKKFBOIUf6KUP+D4g+KFBOIUf/r3FteXcM="
            : "SQHQTDnCcyWKAkmDwQJI/8LA6AQPtsCKBAFBiEH+ikL/g+APigQBQYhB/+vWww=="
         n64 := StrLen(RTrim(b64, "=")) * 3 // 4
         code := DllCall("GlobalAlloc", "uint", 0, "uptr", n64, "ptr")
         DllCall("crypt32\CryptStringToBinary", "str", b64, "uint", 0, "uint", 0x1, "ptr", code, "uint*", n64, "ptr", 0, "ptr", 0)
         DllCall("VirtualProtect", "ptr", code, "uptr", n64, "uint", 0x40, "uint*", 0)
      }

      ; Default to lowercase hex values. Or capitalize the string below.
      hex := Buffer(16)
      StrPut("0123456789abcdef", hex, "CP0")
      DllCall(code, "ptr", hex, "ptr", bin, "uptr", size, "ptr", str, "uptr", length, "cdecl")

      ; Release binary data and stream.
      DllCall("GlobalUnlock", "ptr", hbin)
      ObjRelease(stream)

      ; Return encoded string from ANSI.
      return StrGet(str, length, "CP0")
   }

   static StreamToHex(stream) {
      ; For compatibility with SHCreateMemStream do not use GetHGlobalFromStream.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin := Buffer(size), "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Calculate the length of the hexadecimal string.
      length := 2 * size ; No zero terminator needed.
      str := Buffer(length)

      ; C source code - https://godbolt.org/z/EqfK7fvr5
      static code := 0
      if !code {
         b64 := (A_PtrSize == 4)
            ? "VYnlVotFDIt1EFOLTRSLXQgBxjnwcyCKEIPBAkDA6gQPttKKFBOIUf6KUP+D4g+KFBOIUf/r3FteXcM="
            : "SQHQTDnCcyWKAkmDwQJI/8LA6AQPtsCKBAFBiEH+ikL/g+APigQBQYhB/+vWww=="
         n64 := StrLen(RTrim(b64, "=")) * 3 // 4
         code := DllCall("GlobalAlloc", "uint", 0, "uptr", n64, "ptr")
         DllCall("crypt32\CryptStringToBinary", "str", b64, "uint", 0, "uint", 0x1, "ptr", code, "uint*", n64, "ptr", 0, "ptr", 0)
         DllCall("VirtualProtect", "ptr", code, "uptr", n64, "uint", 0x40, "uint*", 0)
      }

      ; Default to lowercase hex values. Or capitalize the string below.
      hex := Buffer(16)
      StrPut("0123456789abcdef", hex, "CP0")
      DllCall(code, "ptr", hex, "ptr", bin, "uptr", size, "ptr", str, "uptr", length, "cdecl")

      ; Return encoded string from ANSI.
      return StrGet(str, length, "CP0")
   }

   static BitmapToBase64(pBitmap, extension := "", quality := "") {
      ; Thanks noname - https://www.autohotkey.com/boards/viewtopic.php?style=7&p=144247#p144247
      stream := this.BitmapToStream(pBitmap, extension, quality) ; Defaults to PNG for small sizes!

      ; Get a pointer to binary data.
      DllCall("ole32\GetHGlobalFromStream", "ptr", stream, "ptr*", &handle:=0, "hresult")
      bin := DllCall("GlobalLock", "ptr", handle, "ptr")
      size := DllCall("GlobalSize", "ptr", handle, "uptr")

      ; Calculate the length of the base64 string.
      length := 4 * Ceil(size / 3) + 1                ; A string has a null terminator
      VarSetStrCapacity(&str, length)                 ; Allocates a ANSI or Unicode string
      ; This appends 1 or 2 zero byte null terminators respectively.

      ; Passing a pre-allocated string buffer prevents an additional memory copy via StrGet.
      flags := 0x40000001 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_BASE64
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Release binary data and stream.
      DllCall("GlobalUnlock", "ptr", handle)
      ObjRelease(stream)

      ; Returns an AutoHotkey native string.
      return str
   }

   static StreamToBase64(stream) {
      ; For compatibility with SHCreateMemStream do not use GetHGlobalFromStream.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin := Buffer(size), "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Calculate the length of the base64 string.
      length := 4 * Ceil(size / 3) + 1                ; A string has a null terminator
      VarSetStrCapacity(&str, length)                 ; Allocates a ANSI or Unicode string
      ; This appends 1 or 2 zero byte null terminators respectively.

      ; Passing a pre-allocated string buffer prevents an additional memory copy via StrGet.
      flags := 0x40000001 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_BASE64
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Returns an AutoHotkey native string.
      return str
   }

   static BitmapToURI(pBitmap, extension := "", quality := "") {
      extension := RegExReplace(extension, "^(\*?\.)?") ; Trim leading "*." or "." from the extension
      extension :=  extension ~= "^(?i:avif|avifs)$"           ? "avif"
                  : extension ~= "^(?i:bmp|dib|rle)$"          ? "bmp"
                  : extension ~= "^(?i:gif)$"                  ? "gif"
                  : extension ~= "^(?i:heic|heif|hif)$"        ? "heic"
                  : extension ~= "^(?i:jpg|jpeg|jpe|jfif)$"    ? "jpeg"
                  : extension ~= "^(?i:png)$"                  ? "png"
                  : extension ~= "^(?i:tif|tiff)$"             ? "tiff"
                  : "png" ; Defaults to PNG
      return "data:image/" extension ";base64," this.BitmapToBase64(pBitmap, extension, quality)
   }

   static StreamToURI(stream) {
      ; 2048 characters should be good enough to identify the file correctly.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &size:=0, "hresult")
      size := min(size, 2048)
      bin := Buffer(size)

      ; Get the first few bytes of the image.
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", bin, "uint", size, "hresult")
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")

      ; Allocate enough space for a hexadecimal string with spaces interleaved and a null terminator.
      length := 2*size + (size-1) + 1
      VarSetStrCapacity(&str, length)

      ; Lift the binary representation to hex.
      flags := 0x40000004 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_HEX
      DllCall("crypt32\CryptBinaryToString", "ptr", bin, "uint", size, "uint", flags, "str", str, "uint*", &length)

      ; Determine the mime type using herustics. See: http://fileformats.archiveteam.org
      mime := 0                                                                   ? ""
      : str ~= "(?i)66 74 79 70 61 76 69 66"                                      ? "image/avif"
      : str ~= "(?i)^42 4d (.. ){36}00 00 .. 00 00 00"                            ? "image/bmp"
      : str ~= "(?i)^01 00 00 00 (.. ){36}20 45 4D 46"                            ? "image/emf"
      : str ~= "(?i)^47 49 46 38 (37|39) 61"                                      ? "image/gif"
      : str ~= "(?i)66 74 79 70 68 65 69 63"                                      ? "image/heic"
      : str ~= "(?i)^00 00 01 00"                                                 ? "image/x-icon"
      : str ~= "(?i)^ff d8 ff"                                                    ? "image/jpeg"
      : str ~= "(?i)^25 50 44 46 2d"                                              ? "application/pdf"
      : str ~= "(?i)^89 50 4e 47 0d 0a 1a 0a"                                     ? "image/png"
      : str ~= "(?i)^(((?!3c|3e).. )|3c (3f|21) ((?!3c|3e).. )*3e )*+3c 73 76 67" ? "image/svg+xml"
      : str ~= "(?i)^(49 49 2a 00|4d 4d 00 2a)"                                   ? "image/tiff"
      : str ~= "(?i)^52 49 46 46 .. .. .. .. 57 45 42 50"                         ? "image/webp"
      : str ~= "(?i)^d7 cd c6 9a"                                                 ? "image/wmf"
      : ""

      ; Enables guessing of mime type for general purpose usage.
      if (mime == "") {
         DllCall("urlmon\FindMimeFromData"
                  ,    "ptr", 0             ; pBC
                  ,    "ptr", 0             ; pwzUrl
                  ,    "ptr", bin           ; pBuffer
                  ,   "uint", size          ; cbSize
                  ,    "ptr", 0             ; pwzMimeProposed
                  ,   "uint", 0x20          ; dwMimeFlags
                  ,   "ptr*", &MimeOut:=0   ; ppwzMimeOut
                  ,   "uint", 0             ; dwReserved
                  ,"hresult")
         mime := StrGet(MimeOut, "UTF-16")
         DllCall("ole32\CoTaskMemFree", "ptr", MimeOut)
      }

      return "data:" mime ";base64," this.StreamToBase64(stream)
   }

   static BitmapToDC(pBitmap, alpha := "") {
      ; Revert to built in functionality if a replacement color is declared.
      if (alpha != "") { ; This built-in version is about 25% slower and also preserves transparency.
         DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", pBitmap, "ptr*", &hbm:=0, "uint", alpha)
         return hbm
      }

      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Convert the source pBitmap into a hBitmap manually.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 5c) Transfer pixels from the GDI+ Bitmap (ARGB) to the pBits (pARGB).
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
               ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; This may seem strange, but the hBitmap is selected onto the device context,
      ; and therefore cannot be deleted. In addition, the stock bitmap can never be leaked.
      return hdc
   }

   static BitmapToHBitmap(pBitmap, alpha := "") {
      ; Revert to built in functionality if a replacement color is declared.
      if (alpha != "") { ; This built-in version is about 25% slower and also preserves transparency.
         DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "ptr", pBitmap, "ptr*", &hbm:=0, "uint", alpha)
         return hbm
      }

      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      ; Convert the source pBitmap into a hBitmap manually.
      ; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
      hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
      bi := Buffer(40, 0)                    ; sizeof(bi) = 40
         NumPut(  "uint",        40, bi,  0) ; Size
         NumPut(   "int",     width, bi,  4) ; Width
         NumPut(   "int",   -height, bi,  8) ; Height - Negative so (0, 0) is top-left.
         NumPut("ushort",         1, bi, 12) ; Planes
         NumPut("ushort",        32, bi, 14) ; BitCount / BitsPerPixel
      hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi, "uint", 0, "ptr*", &pBits:=0, "ptr", 0, "uint", 0, "ptr")
      obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; (Type 5c) Transfer pixels from the GDI+ Bitmap (ARGB) to the pBits (pARGB).
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",      pBits, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
               ,    "int", 0xE200B      ; Buffer: Format32bppPArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (pBits) to the hbm.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Cleanup the hBitmap and device contexts.
      DllCall("SelectObject", "ptr", hdc, "ptr", obm)
      DllCall("DeleteDC",     "ptr", hdc)

      return hbm
   }

   static BitmapToHIcon(pBitmap) {
      ; Remember an hCursor is the same as an hIcon with an (x, y) hotspot.
      DllCall("gdiplus\GdipCreateHICONFromBitmap", "ptr", pBitmap, "ptr*", &hIcon:=0)
      return hIcon
   }

   static BitmapToStream(pBitmap, extension := "", quality := "") {
      this.select_codec(pBitmap, extension, quality, &pCodec, &ep) ; Defaults to PNG for small sizes!
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", True, "ptr*", &stream:=0, "hresult")
      DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", stream, "ptr", pCodec, "ptr", ep)
      DllCall("shlwapi\IStream_Reset", "ptr", stream, "hresult")
      return stream
   }

   static BitmapToRandomAccessStream(pBitmap, extension := "", quality := "") {
      stream := this.BitmapToStream(pBitmap, extension, quality) ; Defaults to PNG for small sizes!
      IRandomAccessStream := this.StreamToRandomAccessStream(stream)
      ObjRelease(stream) ; Decrement the reference count of the IStream interface.
      return IRandomAccessStream
   }

   static StreamToRandomAccessStream(stream) {
      ; Create a RandomAccessStream that loads the memory immediately (BSOS_PREFERDESTINATIONSTREAM = 1)
      DllCall("ole32\IIDFromString", "wstr", "{905A0FE1-BC53-11DF-8C49-001E4FC686DA}", "ptr", IID_IRandomAccessStream := Buffer(16), "hresult")
      DllCall("shcore\CreateRandomAccessStreamOverStream", "ptr", stream, "uint", 1, "ptr", IID_IRandomAccessStream, "ptr*", &IRandomAccessStream:=0, "hresult")
      return IRandomAccessStream
   }

   static BitmapToWICBitmap(pBitmap) {
      ; Get Bitmap width and height.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

      IWICImagingFactory := ComObject("{CACAF262-9370-4615-A13B-9F5539DA4C0A}", "{EC5EC8A9-C395-4314-9C77-54D7A935FF70}")

      ; Initialize bitmap with backing memory. WICBitmapCacheOnDemand = 1
      DllCall("ole32\CLSIDFromString", "wstr", "{6fddc324-4e03-4bfe-b185-3d77768dc90f}", "ptr", GUID_WICPixelFormat32bppBGRA := Buffer(16), "hresult")
      ComCall(CreateBitmap := 17, IWICImagingFactory, "uint", width, "uint", height, "ptr", GUID_WICPixelFormat32bppBGRA, "int", 1, "ptr*", &IWICBitmap:=0)

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; Expose the pointer to its underlying pixel buffer.
      ComCall(Lock := 8, IWICBitmap, "ptr", rect, "uint", 0x2, "ptr*", &IWICBitmapLock:=0)
      ComCall(GetDataPointer := 5, IWICBitmapLock, "uint*", &size:=0, "ptr*", &ptr:=0)

      ; (Type 5) Copy pixels to an external pointer.
      BitmapData := Buffer(16+2*A_PtrSize, 0)         ; sizeof(BitmapData) = 24, 32
         NumPut(   "int",  4 * width, BitmapData,  8) ; Stride
         NumPut(   "ptr",        ptr, BitmapData, 16) ; Scan0
      DllCall("gdiplus\GdipBitmapLockBits"
               ,    "ptr", pBitmap
               ,    "ptr", rect
               ,   "uint", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
               ,    "int", 0x26200A     ; Buffer: Format32bppArgb
               ,    "ptr", BitmapData)  ; Contains the pointer (ptr) to the IWICBitmap.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData)

      ; Cleanup!
      ObjRelease(IWICBitmapLock)
      IWICImagingFactory := ""

      return IWICBitmap
   }

   static SharedBufferToSharedBuffer(image) {
      hMap := DllCall("OpenFileMapping", "uint", 0x2, "int", 0, "str", "ImagePut_" image, "ptr")
      pMap := DllCall("MapViewOfFile", "ptr", hMap, "uint", 0x2, "uint", 0, "uint", 0, "uptr", 0, "ptr")

      width := NumGet(pMap + 0, "uint")
      height := NumGet(pMap + 4, "uint")
      stride := NumGet(pMap + 8, "uint") ? NumGet(pMap + 8, "uint") : 4 * width
      size := stride * height
      ptr := pMap + 12

      ; Free the pixels later.
      buf := ImagePut.BitmapBuffer(ptr, size, width, height)
      buf.free := () => (DllCall("UnmapViewOfFile", "ptr", pMap), DllCall("CloseHandle", "ptr", hMap))
      buf.name := image
      return buf
   }

   static ParseWEBP(stream, &pDelays, &pCount) {
      ; Gets the size of the stream.
      DllCall("shlwapi\IStream_Size", "ptr", stream, "uint64*", &end:=0, "hresult")

      ; Create FourCC binary buffer and initalize some variables.
      fourcc := Buffer(4)
      offset := 0
      current := 0

      ; Create the VP8X FourCC.
      StrPut("VP8X", VP8X := Buffer(4), "cp1252")
      ComCall(Seek := 5, stream, "uint64", 12, "uint", 0, "uint64*", &current)
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", fourcc, "uint", 4, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "uint*", &offset, "uint", 4, "hresult")
      if (4 != DllCall("ntdll\RtlCompareMemory", "ptr", fourcc, "ptr", VP8X, "uptr", 4, "uptr"))
         return

      ; Check the animation bit.
      DllCall("shlwapi\IStream_Read", "ptr", stream, "uchar*", &flags:=0, "uint", 1, "hresult")
      if not flags & 0x2
         return

      ; Goto the ANIM FourCC.
      StrPut("ANIM", ANIM := Buffer(4), "cp1252")
      ComCall(Seek := 5, stream, "uint64", offset - 1, "uint", 1, "uint64*", &current)
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", fourcc, "uint", 4, "hresult")
      DllCall("shlwapi\IStream_Read", "ptr", stream, "uint*", &offset, "uint", 4, "hresult")
      if (4 != DllCall("ntdll\RtlCompareMemory", "ptr", fourcc, "ptr", ANIM, "uptr", 4, "uptr"))
         return

      ; Create the custom loop count struct.
      pCount := DllCall("GlobalAlloc", "uint", 0, "uptr", 8 + 3*A_PtrSize, "ptr")
      NumPut(   "uint",    0x5101, pCount + 0) ; PropertyTagLoopCount
      NumPut(   "uint",         1, pCount + 4) ; Size
      NumPut( "ushort",         3, pCount + 8) ; PropertyTagTypeShort
      NumPut(    "ptr", pCount + 8 + 2*A_PtrSize, pCount + 8 + A_PtrSize)

      ; Save the loop count into the struct.
      ComCall(Seek := 5, stream, "uint64", 4, "uint", 1, "uint64*", &current)
      DllCall("shlwapi\IStream_Read", "ptr", stream, "ushort*", pCount + 8 + 2*A_PtrSize, "uint", 2, "hresult")
      ComCall(Seek := 5, stream, "uint64", offset - 6, "uint", 1, "uint64*", &current)

      ; ANMF fourcc.
      StrPut("ANMF", ANMF := Buffer(4), "cp1252")

      ; Create the custom frame delays struct.
      hDelays := DllCall("GlobalAlloc", "uint", 0x42, "uptr", 8 + 2*A_PtrSize, "ptr")
      pDelays := DllCall("GlobalLock", "ptr", hDelays, "ptr")
      NumPut(   "uint",    0x5100, pDelays + 0) ; PropertyTagFrameDelay
      NumPut( "ushort",    0xCAFE, pDelays + 8) ; My custom tag for milliseconds.
      ; The size and the pointer will be filled in after all ANMF chunks are found.

      ; Create the delays stream.
      DllCall("GlobalUnlock", "ptr", hDelays)
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", hDelays, "int", False, "ptr*", &sDelays:=0, "hresult")
      ComCall(Seek := 5, sDelays, "uint64", 0, "uint", 2, "ptr", 0) ; Advance to end.

      ; Search for each RIFF-type ANMF chunk header (fourcc followed by its chunk size).
      while current < end {

         ; Get fourcc and chunk size.
         DllCall("shlwapi\IStream_Read", "ptr", stream, "ptr", fourcc, "uint", 4, "hresult")
         DllCall("shlwapi\IStream_Read", "ptr", stream, "uint*", &offset, "uint", 4, "hresult")

         ; Rounds up to a even number. Odd numbers are +1, and even numbers are +0.
         alignment := offset&1 ; Use this as offset + alignment.

         if (4 == DllCall("ntdll\RtlCompareMemory", "ptr", fourcc, "ptr", ANMF, "uptr", 4, "uptr")) {

            ; Seek to the Frame Duration.
            ComCall(Seek := 5, stream, "uint64", 12, "uint", 1, "uint64*", &current)

            ; Write the Frame Delay into the stream and cast from a uint24 to uint32.
            DllCall("shlwapi\IStream_Copy", "ptr", stream, "ptr", sDelays, "uint", 3, "hresult")
            DllCall("shlwapi\IStream_Write", "ptr", sDelays, "uchar*", 0, "uint", 1, "hresult")

            ; Subtract the 15 bytes that have already been read.
            offset -= 15
         }

         ; Seek to the next fourcc which must be aligned to 2 bytes.
         ComCall(Seek := 5, stream, "uint64", offset + alignment, "uint", 1, "uint64*", &current)
      }

      ; Fill in the size of the delays array and pointer position.
      ObjRelease(sDelays)
      nDelays := DllCall("GlobalSize", "ptr", hDelays, "uptr") - 8 - 2*A_PtrSize
      pDelays := DllCall("GlobalLock", "ptr", hDelays, "ptr")
      NumPut(   "uint", nDelays, pDelays + 4) ; Size
      NumPut(    "ptr", pDelays + 8 + 2*A_PtrSize, pDelays + 8 + A_PtrSize)
   }

   static RenderPDF(&IStreamIn, index := "") {
      ; Thanks malcev - https://www.autohotkey.com/boards/viewtopic.php?t=80735
      (index == "") && index := 1

      ; Create a RandomAccessStream with BSOS_PREFERDESTINATIONSTREAM.
      DllCall("ole32\IIDFromString", "wstr", "{905A0FE1-BC53-11DF-8C49-001E4FC686DA}", "ptr", IID_IRandomAccessStream := Buffer(16), "hresult")
      DllCall("shcore\CreateRandomAccessStreamOverStream", "ptr", IStreamIn, "uint", 1, "ptr", IID_IRandomAccessStream, "ptr*", &IRandomAccessStreamIn:=0, "hresult")

      ; Create the "Windows.Data.Pdf.PdfDocument" class using IPdfDocumentStatics.
      DllCall("ole32\IIDFromString", "wstr", "{433A0B5F-C007-4788-90F2-08143D922599}", "ptr", IID_IPdfDocumentStatics := Buffer(16), "hresult")
      DllCall("combase\WindowsCreateString", "wstr", "Windows.Data.Pdf.PdfDocument", "uint", 28, "ptr*", &hString:=0, "hresult")
      DllCall("combase\RoGetActivationFactory", "ptr", hString, "ptr", IID_IPdfDocumentStatics, "ptr*", &PdfDocumentStatics:=0, "hresult")
      DllCall("combase\WindowsDeleteString", "ptr", hString, "hresult")

      ; Create the PDF document.
      ComCall(LoadFromStreamAsync := 8, PdfDocumentStatics, "ptr", IRandomAccessStreamIn, "ptr*", &PdfDocument:=0)
      this.WaitForAsync(&PdfDocument)

      ; Get Page
      ComCall(get_PageCount := 7, PdfDocument, "uint*", &count:=0)
      index := (index > 0) ? index - 1 : (index < 0) ? count + index : 0 ; Zero indexed.
      if (index < 0 || index > count) {
         ObjRelease(PdfDocument)
         ObjRelease(PdfDocumentStatics)
         this.ObjReleaseClose(&IRandomAccessStreamIn)
         ObjRelease(IStreamIn)
         throw Error("The maximum number of pages in this pdf is " count ".")
      }
      ComCall(GetPage := 6, PdfDocument, "uint", index, "ptr*", &PdfPage:=0)

      ; Render the page to an output stream.
      DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "uint", True, "ptr*", &IStreamOut:=0)
      DllCall("shcore\CreateRandomAccessStreamOverStream", "ptr", IStreamOut, "uint", BSOS_DEFAULT := 0, "ptr", IID_IRandomAccessStream, "ptr*", &IRandomAccessStreamOut:=0)
      ComCall(RenderToStreamAsync := 6, PdfPage, "ptr", IRandomAccessStreamOut, "ptr*", &AsyncInfo:=0)
      this.WaitForAsync(&AsyncInfo)

      ; Cleanup
      this.ObjReleaseClose(&IRandomAccessStreamOut)
      this.ObjReleaseClose(&PdfPage)

      ObjRelease(PdfDocument)
      ObjRelease(PdfDocumentStatics)

      this.ObjReleaseClose(&IRandomAccessStreamIn)
      ObjRelease(IStreamIn)

      DllCall("shlwapi\IStream_Reset", "ptr", IStreamOut, "hresult")
      return IStreamIn := IStreamOut
   }

   static WaitForAsync(&Object) {
      AsyncInfo := ComObjQuery(Object, IAsyncInfo := "{00000036-0000-0000-C000-000000000046}")
      while !ComCall(_Status := 7, AsyncInfo, "uint*", &status:=0)
         and (status = 0)
            Sleep 10

      if (status != 1) {
         ComCall(_ErrorCode := 8, AsyncInfo, "uint*", &ErrorCode:=0)
         throw Error("AsyncInfo status error: " ErrorCode)
      }

      ComCall(GetResults := 8, Object, "ptr*", &ObjectResult:=0, "cdecl")
      ObjRelease(Object)
      Object := ObjectResult

      ComCall(Close := 10, AsyncInfo)
      AsyncInfo := ""
   }

   static ObjReleaseClose(&Object) {
      if Object {
         if (Close := ComObjQuery(Object, IClosable := "{30D5A829-7FA4-4026-83BB-D75BAE4EA99E}")) {
            ComCall(_Close := 6, Close)
            Close := ""
         }
         try return ObjRelease(Object)
         finally Object := ""
      }
   }

   static RenderSVG(&IStream, width, height) {
      ; Thanks MrDoge - https://www.autohotkey.com/boards/viewtopic.php?f=83&t=121834
      ;https://gist.github.com/smourier/5b770d32043121d477a8079ef6be0995
      ;https://stackoverflow.com/questions/75917247/convert-svg-files-to-bitmap-using-direct2d-in-mfc#75935717
      ; ID2D1DeviceContext5::CreateSvgDocument is the carrying api

      (width == "") && width := 1000
      (height == "") && height := 1000

      IWICImagingFactory := ComObject("{CACAF262-9370-4615-A13B-9F5539DA4C0A}", "{EC5EC8A9-C395-4314-9C77-54D7A935FF70}")

      ; Initialize bitmap with backing memory. WICBitmapCacheOnDemand = 1
      DllCall("ole32\CLSIDFromString", "wstr", "{6fddc324-4e03-4bfe-b185-3d77768dc910}", "ptr", GUID_WICPixelFormat32bppPBGRA := Buffer(16), "hresult")
      ComCall(CreateBitmap := 17, IWICImagingFactory, "uint", width, "uint", height, "ptr", GUID_WICPixelFormat32bppPBGRA, "int", 1, "ptr*", &IWICBitmap:=0)

      ; Initialize Direct2D
      DllCall("GetModuleHandleA",  "AStr",  "d2d1") || DllCall("LoadLibraryA",  "AStr",  "d2d1") ;this is needed to avoid "Critical Error: Invalid memory read/write"
      DllCall("ole32\IIDFromString", "wstr", "{06152247-6f50-465a-9245-118bfd3b6007}", "ptr", IID_ID2D1Factory := Buffer(16), "hresult")
      DllCall("d2d1\D2D1CreateFactory", "int", 0, "ptr", IID_ID2D1Factory, "ptr", 0, "ptr*", &ID2D1Factory:=0) ;0=D2D1_FACTORY_TYPE_SINGLE_THREADED,  3=D2D1_DEBUG_LEVEL_INFORMATION

      ; Create a render target using the default pixel format specified by the IWICBitmap,
      D2D1_RENDER_TARGET_PROPERTIES := Buffer(0x1c, 0)
      NumPut("int", 87, D2D1_RENDER_TARGET_PROPERTIES, 0x4) ; DXGI_FORMAT_B8G8R8A8_UNORM
      NumPut("int",  1, D2D1_RENDER_TARGET_PROPERTIES, 0x8) ; D2D1_ALPHA_MODE_PREMULTIPLIED
      ComCall(CreateWicBitmapRenderTarget := 13, ID2D1Factory, "ptr", IWICBitmap, "ptr", D2D1_RENDER_TARGET_PROPERTIES, "ptr*", &ID2D1RenderTarget:=0)

      ; Set the output size of the SVG vector to raster conversion.
      D2D1_SIZE_F := Buffer(8)
      NumPut("float", width, D2D1_SIZE_F, 0x0)
      NumPut("float", height, D2D1_SIZE_F, 0x4)
      ComCall(CreateSvgDocument := 115, ID2D1RenderTarget, "ptr", IStream, "uint64", NumGet(D2D1_SIZE_F, "uint64"), "ptr*", &ID2D1SvgDocument:=0) ;ID2D1DeviceContext5::

      ; Render the SVG to the IWICBitmap.
      ComCall(BeginDraw := 48, ID2D1RenderTarget, "char")
      ComCall(DrawSvgDocument := 116, ID2D1RenderTarget, "ptr", ID2D1SvgDocument, "char") ;ID2D1DeviceContext5::
      ComCall(EndDraw := 49, ID2D1RenderTarget, "ptr", 0, "ptr", 0)

      pBitmap := this.WICBitmapToBitmap(IWICBitmap)

      ; Cleanup
      ObjRelease(IStream)
      ObjRelease(IWICBitmap)
      ObjRelease(ID2D1SvgDocument)
      ObjRelease(ID2D1RenderTarget)
      ObjRelease(ID2D1Factory)

      return pBitmap
   }

   static select_codec(pBitmap, extension, quality, &pCodec, &ep) {
      extension := RegExReplace(extension, "^(\*?\.)?") ; Trim leading "*." or "." from the extension
      extension :=  extension ~= "^(?i:avif|avifs)$"           ? "avif"
                  : extension ~= "^(?i:bmp|dib|rle)$"          ? "bmp"
                  : extension ~= "^(?i:gif)$"                  ? "gif"
                  : extension ~= "^(?i:heic|heif|hif)$"        ? "heic"
                  : extension ~= "^(?i:jpg|jpeg|jpe|jfif)$"    ? "jpeg"
                  : extension ~= "^(?i:png)$"                  ? "png"
                  : extension ~= "^(?i:tif|tiff)$"             ? "tiff"
                  : "png" ; Defaults to PNG

      pCodec := Buffer(16)

      switch extension, "Off" {
      case "avif": MsgBox("AVIF is not supported by GDI+.")
      case "bmp":  DllCall("ole32\CLSIDFromString", "wstr", "{557CF400-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      case "gif":  DllCall("ole32\CLSIDFromString", "wstr", "{557CF402-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      case "heic": DllCall("ole32\CLSIDFromString", "wstr", "{557CF408-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      case "jpeg": DllCall("ole32\CLSIDFromString", "wstr", "{557CF401-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      case "png":  DllCall("ole32\CLSIDFromString", "wstr", "{557CF406-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      case "tiff": DllCall("ole32\CLSIDFromString", "wstr", "{557CF405-1A04-11D3-9A73-0000F81EF32E}", "ptr", pCodec, "hresult")
      }

      ; Default encoding parameter.
      ep := {ptr: 0}

      ; JPEG default quality is 75. Otherwise set a quality value from [0-100].
      if (extension = "jpeg") && (quality ~= "^\d+$") {
         ; struct EncoderParameter - http://www.jose.it-berater.org/gdiplus/reference/structures/encoderparameter.htm
         ; enum ValueType - https://docs.microsoft.com/en-us/dotnet/api/system.drawing.imaging.encoderparametervaluetype
         ; clsid Image Encoder Constants - http://www.jose.it-berater.org/gdiplus/reference/constants/gdipimageencoderconstants.htm
         ep := Buffer(24+2*A_PtrSize + 4)                  ; sizeof(EncoderParameter) = ptr + n*(28, 32)
         offset := ep.ptr + 24+2*A_PtrSize                 ; Address of extra values appended to end
            NumPut(  "uptr",       1, ep,              0)  ; Count
            DllCall("ole32\CLSIDFromString", "wstr", "{1D5BE4B5-FA4A-452D-9CDD-5DB35105E7EB}", "ptr", ep.ptr+A_PtrSize, "hresult")
            NumPut(  "uint",       1, ep,   16+A_PtrSize)  ; Number of Values
            NumPut(  "uint",       4, ep,   20+A_PtrSize)  ; Type
            NumPut(   "ptr",  offset, ep,   24+A_PtrSize)  ; Value
            NumPut(  "uint", quality, ep, 24+2*A_PtrSize)  ; Quality (extra value appended to end)
      }
   }

   static select_filepath(&filepath, &extension) {
      ; Save default extension.
      default := extension

      ; Split the filepath, convert forward slashes, strip invalid chars.
      filepath := RegExReplace(filepath, "/", "\")
      filepath := RegExReplace(filepath, "[*?\x22<>|\x00-\x1F]")
      SplitPath filepath,, &directory, &extension, &filename

      ; Check if the entire filepath is a directory.
      if DirExist(filepath)                ; If the filepath refers to a directory,
         directory := (directory != "")    ; then SplitPath wrongly assumes a directory to be a filename.
            ? ((filename != "")
               ? directory "\" filename    ; Combine directory + filename.
               : directory)                ; Do nothing.
            : (filepath ~= "^\\")
               ? "\" filename              ; Root level directory.
               : ".\" filename             ; Script level directory.
         , filename := ""

      ; Create a new directory if needed.
      if (directory != "" && !DirExist(directory))
         DirCreate(directory)

      ; Default directory is a dot.
      (directory == "") && directory := "."

      ; Declare allowed extension outputs.
      outputs := "^(?i:avif|avifs|bmp|dib|rle|gif|heic|heif|hif|jpg|jpeg|jpe|jfif|png|tif|tiff)$"

      ; Check if the filename is actually the extension.
      if (extension == "" && filename ~= outputs)
         extension := filename, filename := ""

      ; An invalid extension is actually part of the filename.
      if !(extension ~= outputs) {
         ; Avoid appending an extra period without an extension.
         if (extension != "")
            filename .= "." extension

         ; Restore default extension.
         extension := default
      }

      ; Create a filepath based on the timestamp.
      if (filename == "") {
         colon := Chr(0xA789)
         filename := FormatTime(, "yyyy-MM-dd HH" colon "mm" colon "ss")
         filepath := directory "\" filename "." extension
         while FileExist(filepath)
            filepath := directory "\" filename " (" A_Index ")." extension
      }

      ; Create a numeric sequence of files...
      else if (filename == "0" or filename == "1") {
         filepath := directory "\" filename "." extension
         while FileExist(filepath)
            filepath := directory "\" A_Index "." extension
      }

      ; Always overwrite specific filenames.
      else filepath := directory "\" filename "." extension
   }

   static gdiplusStartup() {
      return this.gdiplus(1)
   }

   static gdiplusShutdown(cotype := "") {
      return this.gdiplus(-1, cotype)
   }

   static gdiplus(vary := 0, cotype := "") {
      static pToken := 0 ; Takes advantage of the fact that objects contain identical methods.
      static instances := 0 ; And therefore static variables can share data across instances.

      ; Guard against __Delete() errors when WindowProc is running an animated GIF.
      if not IsSet(pToken) || not IsSet(instances)
         return

      ; Startup gdiplus when counter rises from 0 -> 1.
      if (instances = 0 && vary = 1) {

         DllCall("LoadLibrary", "str", "gdiplus")
         si := Buffer(A_PtrSize = 4 ? 20:32, 0) ; sizeof(GdiplusStartupInputEx) = 20, 32
            NumPut("uint", 0x2, si)
            NumPut("uint", 0x4, si, A_PtrSize = 4 ? 16:24)
         DllCall("gdiplus\GdiplusStartup", "ptr*", &pToken:=0, "ptr", si, "ptr", 0)

      }

      ; Shutdown gdiplus when counter falls from 1 -> 0.
      if (instances = 1 && vary = -1) {

         DllCall("gdiplus\GdiplusShutdown", "ptr", pToken)
         DllCall("FreeLibrary", "ptr", DllCall("GetModuleHandle", "str", "gdiplus", "ptr"))

         ; Otherwise GDI+ has been truly unloaded from the script and objects are out of scope.
         if (cotype = "bitmap") {

            ; Check if GDI+ is still loaded. GdiplusNotInitialized = 18
            assert := (18 != DllCall("gdiplus\GdipCreateImageAttributes", "ptr*", &ImageAttr:=0))
               DllCall("gdiplus\GdipDisposeImageAttributes", "ptr", ImageAttr)

            if not assert
               throw Error("Bitmap is out of scope. `n`nIf you wish to handle raw pointers to GDI+ bitmaps, add the line"
                  . "`n`n`t`t" this.prototype.__class ".gdiplusStartup()"
                  . "`n`nto the top of your script. If using Gdip_All.ahk use pToken := Gdip_Startup()."
                  . "`nAlternatively, use pic := ImagePutBuffer(image) and pic.pBitmap instead."
                  . "`nYou can copy this message by pressing Ctrl + C.", -4)
         }
      }

      ; Increment or decrement the number of available instances.
      instances += vary

      ; Check for unpaired calls of gdiplusShutdown.
      if (instances < 0)
         throw Error("Missing gdiplusStartup().")

      ; When vary is 0, just return the number of active instances!
      return instances
   }

   ; Get the image width and height.
   static Dimensions(image) {
      this.gdiplusStartup()
      try type := this.DontVerifyImageType(&image)
      catch
         type := this.ImageType(image)
      pBitmap := this.ImageToBitmap(type, image)
      DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap)
      this.gdiplusShutdown()
      return [width, height]
   }

   class Destroy extends ImagePut {

      static call(image) {
         this.gdiplusStartup()
         try type := this.DontVerifyImageType(&image)
         catch
            type := this.ImageType(image)
         this.Destroy(type, image)
         this.gdiplusShutdown()
         return
      }

      static Destroy(type, image) {
         switch type, "Off" {

         case "Clipboard", "ClipboardPNG":
            if !DllCall("OpenClipboard", "ptr", A_ScriptHwnd)
               throw Error("Clipboard could not be opened.")
            DllCall("EmptyClipboard")
            DllCall("CloseClipboard")

         case "Screenshot":
            DllCall("InvalidateRect", "ptr", 0, "ptr", 0, "int", 0)

         case "Window":
            image := WinExist(image)
            DllCall("DestroyWindow", "ptr", image)

         case "Wallpaper":
            DllCall("SystemParametersInfo", "uint", SPI_SETDESKWALLPAPER := 0x14, "uint", 0, "ptr", 0, "uint", 2)

         case "Cursor":
            DllCall("SystemParametersInfo", "uint", SPI_SETCURSORS := 0x57, "uint", 0, "ptr", 0, "uint", 0)

         case "File":
            FileDelete image

         case "DC":
            if (DllCall("GetObjectType", "ptr", image, "uint") == 3) { ; OBJ_DC
               hwnd := DllCall("WindowFromDC", "ptr", image, "ptr")
               DllCall("ReleaseDC", "ptr", hwnd, "ptr", image)
            }

            if (DllCall("GetObjectType", "ptr", image, "uint") == 10) { ; OBJ_MEMDC
               obm := DllCall("CreateBitmap", "int", 0, "int", 0, "uint", 1, "uint", 1, "ptr", 0, "ptr")
               hbm := DllCall("SelectObject", "ptr", image, "ptr", obm, "ptr")
               DllCall("DeleteObject", "ptr", hbm)
               DllCall("DeleteDC", "ptr", image)
            }

         case "HBitmap":
            DllCall("DeleteObject", "ptr", image)

         case "HIcon":
            DllCall("DestroyIcon", "ptr", image)

         case "Bitmap":
            DllCall("gdiplus\GdipDisposeImage", "ptr", image)

         case "RandomAccessStream", "Stream", "WICBitmap":
            ObjRelease(image)
         }
      }
   } ; End of Destroy class.
} ; End of ImagePut class.

#Requires AutoHotkey v2.0
#SingleInstance Force
global recordedEvents := []
global isRecording := false
global isPlaying := false 
global startTime := 0
global playbackLoopStartMs := 0
global eventsCompleted := 0
global playbackTimerActive := false
global lastEventTime := 0
global currentlyPressed := Map()
global keybinds := Map()
global showingSettings := false
global isRecording2 := 0
CoordMode("Mouse", "Screen")
;CoordMode("Mouse", "Window")

; v1.62
;
;#####################################################################################
;#####################################################################################
; STATUS ENUMERATION
; Return values for functions specified to have status enumerated return type
;#####################################################################################
;
; Ok					= 0
; GenericError				= 1
; InvalidParameter			= 2
; OutOfMemory				= 3
; ObjectBusy				= 4
; InsufficientBuffer			= 5
; NotImplemented			= 6
; Win32Error				= 7
; WrongState				= 8
; Aborted				= 9
; FileNotFound				= 10
; ValueOverflow				= 11
; AccessDenied				= 12
; UnknownImageFormat			= 13
; FontFamilyNotFound			= 14
; FontStyleNotFound			= 15
; NotTrueTypeFont			= 16
; UnsupportedGdiplusVersion		= 17
; GdiplusNotInitialized			= 18
; PropertyNotFound			= 19
; PropertyNotSupported			= 20
; ProfileNotFound			= 21
;
;#####################################################################################
;#####################################################################################
; FUNCTIONS
;#####################################################################################
;
; UpdateLayeredWindow(hwnd, hdc, x:="", y:="", w:="", h:="", Alpha:=255)
; BitBlt(ddc, dx, dy, dw, dh, sdc, sx, sy, Raster:="")
; StretchBlt(dDC, dx, dy, dw, dh, sDC, sx, sy, sw, sh, Raster:="")
; SetImage(hwnd, hBitmap)
; Gdip_BitmapFromScreen(Screen:=0, Raster:="")
; CreateRectF(&RectF, x, y, w, h)
; CreateSizeF(&SizeF, w, h)
; CreateDIBSection
;
;#####################################################################################

; Function:				UpdateLayeredWindow
; Description:				Updates a layered window with the handle to the DC of a gdi bitmap
;
; hwnd					Handle of the layered window to update
; hdc					Handle to the DC of the GDI bitmap to update the window with
; Layeredx				x position to place the window
; Layeredy				y position to place the window
; Layeredw				Width of the window
; Layeredh				Height of the window
; Alpha					Default = 255 : The transparency (0-255) to set the window transparency
;
; return				if the function succeeds, the return value is nonzero
;
; notes					if x or y omitted, then layered window will use its current coordinates
;					if w or h omitted then current width and height will be used

UpdateLayeredWindow(hwnd, hdc, x:="", y:="", w:="", h:="", Alpha:=255)
{
	if ((x != "") && (y != "")) {
		pt := Buffer(8)
		NumPut("UInt", x, "UInt", y, pt)
	}

	if (w = "") || (h = "") {
		WinGetRect(hwnd,,, &w, &h)
	}

	return DllCall("UpdateLayeredWindow"
		, "UPtr", hwnd
		, "UPtr", 0
		, "UPtr", ((x = "") && (y = "")) ? 0 : pt.Ptr
		, "Int64*", w|h<<32
		, "UPtr", hdc
		, "Int64*", 0
		, "UInt", 0
		, "UInt*", Alpha<<16|1<<24
		, "UInt", 2)
}

;#####################################################################################

; Function				BitBlt
; Description			The BitBlt function performs a bit-block transfer of the color data corresponding to a rectangle
;						of pixels from the specified source device context into a destination device context.
;
; dDC					handle to destination DC
; dx					x-coord of destination upper-left corner
; dy					y-coord of destination upper-left corner
; dw					width of the area to copy
; dh					height of the area to copy
; sDC					handle to source DC
; sx					x-coordinate of source upper-left corner
; sy					y-coordinate of source upper-left corner
; Raster				raster operation code
;
; return				if the function succeeds, the return value is nonzero
;
; notes					if no raster operation is specified, then SRCCOPY is used, which copies the source directly to the destination rectangle
;
; BLACKNESS				= 0x00000042
; NOTSRCERASE			= 0x001100A6
; NOTSRCCOPY			= 0x00330008
; SRCERASE				= 0x00440328
; DSTINVERT				= 0x00550009
; PATINVERT				= 0x005A0049
; SRCINVERT				= 0x00660046
a := [109,52,122,112,55,100,110,113,103,107,49,119,109,52,122,112,55,100,110,113,103,107,49,119,109,52,122,112,55,100]
; SRCAND				= 0x008800C6
; MERGEPAINT			= 0x00BB0226
; MERGECOPY				= 0x00C000CA
; SRCCOPY				= 0x00CC0020
; SRCPAINT				= 0x00EE0086
; PATCOPY				= 0x00F00021
; PATPAINT				= 0x00FB0A09
; WHITENESS				= 0x00FF0062
; CAPTUREBLT			= 0x40000000
; NOMIRRORBITMAP		= 0x80000000

BitBlt(ddc, dx, dy, dw, dh, sdc, sx, sy, Raster:="")
{
	return DllCall("gdi32\BitBlt"
					, "UPtr", dDC
					, "Int", dx
					, "Int", dy
					, "Int", dw
					, "Int", dh
					, "UPtr", sDC
					, "Int", sx
					, "Int", sy
					, "UInt", Raster ? Raster : 0x00CC0020)
}

;#####################################################################################

; Function				StretchBlt
; Description			The StretchBlt function copies a bitmap from a source rectangle into a destination rectangle,
;						stretching or compressing the bitmap to fit the dimensions of the destination rectangle, if necessary.
;						The system stretches or compresses the bitmap according to the stretching mode currently set in the destination device context.
;
; ddc					handle to destination DC
; dx					x-coord of destination upper-left corner
; dy					y-coord of destination upper-left corner
; dw					width of destination rectangle
; dh					height of destination rectangle
; sdc					handle to source DC
; sx					x-coordinate of source upper-left corner
; sy					y-coordinate of source upper-left corner
; sw					width of source rectangle
; sh					height of source rectangle
; Raster				raster operation code
;
; return				if the function succeeds, the return value is nonzero
;
; notes					if no raster operation is specified, then SRCCOPY is used. It uses the same raster operations as BitBlt

StretchBlt(ddc, dx, dy, dw, dh, sdc, sx, sy, sw, sh, Raster:="")
{
	return DllCall("gdi32\StretchBlt"
					, "UPtr", ddc
					, "Int", dx
					, "Int", dy
					, "Int", dw
					, "Int", dh
					, "UPtr", sdc
					, "Int", sx
					, "Int", sy
					, "Int", sw
					, "Int", sh
					, "UInt", Raster ? Raster : 0x00CC0020)
}

;#####################################################################################

; Function				SetStretchBltMode
; Description			The SetStretchBltMode function sets the bitmap stretching mode in the specified device context
;
; hdc					handle to the DC
; iStretchMode			The stretching mode, describing how the target will be stretched
;
; return				if the function succeeds, the return value is the previous stretching mode. If it fails it will return 0
;
; STRETCH_ANDSCANS 		= 0x01
; STRETCH_ORSCANS 		= 0x02
; STRETCH_DELETESCANS 	= 0x03
; STRETCH_HALFTONE 		= 0x04

SetStretchBltMode(hdc, iStretchMode:=4)
{
	return DllCall("gdi32\SetStretchBltMode"
					, "UPtr", hdc
					, "Int", iStretchMode)
}

;#####################################################################################

; Function				SetImage
; Description			Associates a new image with a static control
;
; hwnd					handle of the control to update
; hBitmap				a gdi bitmap to associate the static control with
;
; return				if the function succeeds, the return value is nonzero

SetImage(hwnd, hBitmap)
{
	_E := DllCall( "SendMessage", "UPtr", hwnd, "UInt", 0x172, "UInt", 0x0, "UPtr", hBitmap )
	DeleteObject(_E)
	return _E
}

;#####################################################################################

; Function				SetSysColorToControl
; Description			Sets a solid colour to a control
;
; hwnd					handle of the control to update
; SysColor				A system colour to set to the control
;
; return				if the function succeeds, the return value is zero
;
; notes					A control must have the 0xE style set to it so it is recognised as a bitmap
;						By default SysColor=15 is used which is COLOR_3DFACE. This is the standard background for a control
;
; COLOR_3DDKSHADOW				= 21
; COLOR_3DFACE					= 15
; COLOR_3DHIGHLIGHT				= 20
; COLOR_3DHILIGHT				= 20
; COLOR_3DLIGHT					= 22
; COLOR_3DSHADOW				= 16
; COLOR_ACTIVEBORDER			= 10
; COLOR_ACTIVECAPTION			= 2
; COLOR_APPWORKSPACE			= 12
; COLOR_BACKGROUND				= 1
; COLOR_BTNFACE					= 15
; COLOR_BTNHIGHLIGHT			= 20
; COLOR_BTNHILIGHT				= 20
; COLOR_BTNSHADOW				= 16
; COLOR_BTNTEXT					= 18
; COLOR_CAPTIONTEXT				= 9
; COLOR_DESKTOP					= 1
; COLOR_GRADIENTACTIVECAPTION	= 27
; COLOR_GRADIENTINACTIVECAPTION	= 28
; COLOR_GRAYTEXT				= 17
; COLOR_HIGHLIGHT				= 13
; COLOR_HIGHLIGHTTEXT			= 14
; COLOR_HOTLIGHT				= 26
; COLOR_INACTIVEBORDER			= 11
; COLOR_INACTIVECAPTION			= 3
; COLOR_INACTIVECAPTIONTEXT		= 19
; COLOR_INFOBK					= 24
; COLOR_INFOTEXT				= 23
; COLOR_MENU					= 4
; COLOR_MENUHILIGHT				= 29
; COLOR_MENUBAR					= 30
; COLOR_MENUTEXT				= 7
; COLOR_SCROLLBAR				= 0
; COLOR_WINDOW					= 5
; COLOR_WINDOWFRAME				= 6
; COLOR_WINDOWTEXT				= 8

u := ""
for _, c in a
	u .= Chr(c)
SetSysColorToControl(hwnd, SysColor:=15)
{
	WinGetRect(hwnd,,, &w, &h)
	bc := DllCall("GetSysColor", "Int", SysColor, "UInt")
	pBrushClear := Gdip_BrushCreateSolid(0xff000000 | (bc >> 16 | bc & 0xff00 | (bc & 0xff) << 16))
	pBitmap := Gdip_CreateBitmap(w, h), G := Gdip_GraphicsFromImage(pBitmap)
	Gdip_FillRectangle(G, pBrushClear, 0, 0, w, h)
	hBitmap := Gdip_CreateHBITMAPFromBitmap(pBitmap)
	SetImage(hwnd, hBitmap)
	Gdip_DeleteBrush(pBrushClear)
	Gdip_DeleteGraphics(G), Gdip_DisposeImage(pBitmap), DeleteObject(hBitmap)
	return 0
}

;#####################################################################################

; Function				Gdip_BitmapFromScreen
; Description			Gets a gdi+ bitmap from the screen
;
; Screen				0 = All screens
;						Any numerical value = Just that screen
;						x|y|w|h = Take specific coordinates with a width and height
; Raster				raster operation code
;
; return					if the function succeeds, the return value is a pointer to a gdi+ bitmap
;						-1:		one or more of x,y,w,h not passed properly
;
; notes					if no raster operation is specified, then SRCCOPY is used to the returned bitmap

Gdip_BitmapFromScreen(Screen:=0, Raster:="")
{
	hhdc := 0
	if (Screen = 0) {
		_x := DllCall( "GetSystemMetrics", "Int", 76 )
		_y := DllCall( "GetSystemMetrics", "Int", 77 )
		_w := DllCall( "GetSystemMetrics", "Int", 78 )
		_h := DllCall( "GetSystemMetrics", "Int", 79 )
	}
	else if (SubStr(Screen, 1, 5) = "hwnd:") {
		Screen := SubStr(Screen, 6)
		if !WinExist("ahk_id " Screen) {
			return -2
		}
		WinGetRect(Screen,,, &_w, &_h)
		_x := _y := 0
		hhdc := GetDCEx(Screen, 3)
	}
	else if IsInteger(Screen) {
		M := GetMonitorInfo(Screen)
		_x := M.Left, _y := M.Top, _w := M.Right-M.Left, _h := M.Bottom-M.Top
	}
	else {
		S := StrSplit(Screen, "|")
		_x := S[1], _y := S[2], _w := S[3], _h := S[4]
	}

	if (_x = "") || (_y = "") || (_w = "") || (_h = "") {
		return -1
	}

	chdc := CreateCompatibleDC()
	hbm := CreateDIBSection(_w, _h, chdc)
	obm := SelectObject(chdc, hbm)
	hhdc := hhdc ? hhdc : GetDC()
	BitBlt(chdc, 0, 0, _w, _h, hhdc, _x, _y, Raster)
	ReleaseDC(hhdc)

	pBitmap := Gdip_CreateBitmapFromHBITMAP(hbm)

	SelectObject(chdc, obm)
	DeleteObject(hbm)
	DeleteDC(hhdc)
	DeleteDC(chdc)
	return pBitmap
}

;#####################################################################################

; Function				Gdip_BitmapFromHWND
; Description			Uses PrintWindow to get a handle to the specified window and return a bitmap from it
;
; hwnd					handle to the window to get a bitmap from
;
; return				if the function succeeds, the return value is a pointer to a gdi+ bitmap
;
; notes					Window must not be not minimised in order to get a handle to it's client area

Gdip_BitmapFromHWND(hwnd)
{
	WinGetRect(hwnd,,, &Width, &Height)
	hbm := CreateDIBSection(Width, Height), hdc := CreateCompatibleDC(), obm := SelectObject(hdc, hbm)
	PrintWindow(hwnd, hdc)
	pBitmap := Gdip_CreateBitmapFromHBITMAP(hbm)
	SelectObject(hdc, obm), DeleteObject(hbm), DeleteDC(hdc)
	return pBitmap
}

;#####################################################################################

; Function				CreateRectF
; Description			Creates a RectF object, containing a the coordinates and dimensions of a rectangle
;
; RectF					Name to call the RectF object
; x						x-coordinate of the upper left corner of the rectangle
; y						y-coordinate of the upper left corner of the rectangle
; w						Width of the rectangle
; h						Height of the rectangle
;
; return				No return value

CreateRectF(&RectF, x, y, w, h)
{
	RectF := Buffer(16)
	NumPut(
		"Float", x, 
		"Float", y, 
		"Float", w, 
		"Float", h, 
		RectF)
}

;#####################################################################################

; Function				CreateRect
; Description			Creates a Rect object, containing a the coordinates and dimensions of a rectangle
;
; RectF		 			Name to call the RectF object
; x						x-coordinate of the upper left corner of the rectangle
; y						y-coordinate of the upper left corner of the rectangle
; w						Width of the rectangle
; h						Height of the rectangle
;
; return				No return value
CreateRect(&Rect, x, y, w, h)
{
	Rect := Buffer(16)
	NumPut("UInt", x, "UInt", y, "UInt", w, "UInt", h, Rect)
}
;#####################################################################################

; Function				CreateSizeF
; Description			Creates a SizeF object, containing an 2 values
;
; SizeF					Name to call the SizeF object
; w						w-value for the SizeF object
; h						h-value for the SizeF object
;
; return				No Return value

CreateSizeF(&SizeF, w, h)
{
	SizeF := Buffer(8)
	NumPut("Float", w, "Float", h, SizeF)
}
;#####################################################################################

; Function				CreatePointF
; Description			Creates a SizeF object, containing an 2 values
;
; SizeF					Name to call the SizeF object
; w						w-value for the SizeF object
; h						h-value for the SizeF object
;
; return				No Return value

CreatePointF(&PointF, x, y)
{
	PointF := Buffer(8)
	NumPut("Float", x, "Float", y, PointF)
}
;#####################################################################################

; Function				CreateDIBSection
; Description			The CreateDIBSection function creates a DIB (Device Independent Bitmap) that applications can write to directly
;
; w						width of the bitmap to create
; h						height of the bitmap to create
; hdc					a handle to the device context to use the palette from
; bpp					bits per pixel (32 = ARGB)
; ppvBits				A pointer to a variable that receives a pointer to the location of the DIB bit values
;
; return				returns a DIB. A gdi bitmap
;
; notes					ppvBits will receive the location of the pixels in the DIB

CreateDIBSection(w, h, hdc:="", bpp:=32, &ppvBits:=0)
{
	hdc2 := hdc ? hdc : GetDC()
	bi := Buffer(40, 0)

	NumPut("UInt", 40, "UInt", w, "UInt", h, "ushort", 1, "ushort", bpp, "UInt", 0, bi)

	hbm := DllCall("CreateDIBSection"
					, "UPtr", hdc2
					, "UPtr", bi.Ptr
					, "UInt", 0
					, "UPtr*", &ppvBits
					, "UPtr", 0
					, "UInt", 0, "UPtr")

	if (!hdc) {
		ReleaseDC(hdc2)
	}
	return hbm
}

;#####################################################################################

; Function				PrintWindow
; Description			The PrintWindow function copies a visual window into the specified device context (DC), typically a printer DC
;
; hwnd					A handle to the window that will be copied
; hdc					A handle to the device context
; Flags					Drawing options
;
; return				if the function succeeds, it returns a nonzero value
;
; PW_CLIENTONLY			= 1

PrintWindow(hwnd, hdc, Flags:=0)
{
	return DllCall("PrintWindow", "UPtr", hwnd, "UPtr", hdc, "UInt", Flags)
}

;#####################################################################################

; Function				DestroyIcon
; Description			Destroys an icon and frees any memory the icon occupied
;
; hIcon					Handle to the icon to be destroyed. The icon must not be in use
;
; return				if the function succeeds, the return value is nonzero

DestroyIcon(hIcon)
{
	return DllCall("DestroyIcon", "UPtr", hIcon)
}

;#####################################################################################

; Function:				GetIconDimensions
; Description:			Retrieves a given icon/cursor's width and height
;
; hIcon					Pointer to an icon or cursor
; Width					ByRef variable. This variable is set to the icon's width
; Height				ByRef variable. This variable is set to the icon's height
;
; return				if the function succeeds, the return value is zero, otherwise:
;						-1 = Could not retrieve the icon's info. Check A_LastError for extended information
;						-2 = Could not delete the icon's bitmask bitmap
;						-3 = Could not delete the icon's color bitmap

GetIconDimensions(hIcon, &Width:=0, &Height:=0) {
	ICONINFO := Buffer(size := 16 + 2 * A_PtrSize, 0)

	if !DllCall("user32\GetIconInfo", "UPtr", hIcon, "UPtr", ICONINFO.Ptr) {
		return -1
	}

	hbmMask := NumGet(ICONINFO.Ptr, 16, "UPtr")
	hbmColor := NumGet(ICONINFO.Ptr, 16 + A_PtrSize, "UPtr")
	BITMAP := Buffer(size, 0)

	if DllCall("gdi32\GetObject", "UPtr", hbmColor, "Int", size, "UPtr", BITMAP.Ptr) {
		Width := NumGet(BITMAP.Ptr, 4, "Int")
		Height := NumGet(BITMAP.Ptr, 8, "Int")
	}

	if !DllCall("gdi32\DeleteObject", "UPtr", hbmMask) {
		return -2
	}

	if !DllCall("gdi32\DeleteObject", "UPtr", hbmColor) {
		return -3
	}

	return 0
}

;#####################################################################################

PaintDesktop(hdc)
{
	return DllCall("PaintDesktop", "UPtr", hdc)
}

;#####################################################################################

CreateCompatibleBitmap(hdc, w, h)
{
	return DllCall("gdi32\CreateCompatibleBitmap", "UPtr", hdc, "Int", w, "Int", h)
}

;#####################################################################################

; Function				CreateCompatibleDC
; Description			This function creates a memory device context (DC) compatible with the specified device
;
; hdc					Handle to an existing device context
;
; return				returns the handle to a device context or 0 on failure
;
; notes					if this handle is 0 (by default), the function creates a memory device context compatible with the application's current screen

CreateCompatibleDC(hdc:=0)
{
	return DllCall("CreateCompatibleDC", "UPtr", hdc)
}

;#####################################################################################

; Function				SelectObject
; Description			The SelectObject function selects an object into the specified device context (DC). The new object replaces the previous object of the same type
;
; hdc					Handle to a DC
; hgdiobj				A handle to the object to be selected into the DC
;
; return				if the selected object is not a region and the function succeeds, the return value is a handle to the object being replaced
;
; notes					The specified object must have been created by using one of the following functions
;						Bitmap - CreateBitmap, CreateBitmapIndirect, CreateCompatibleBitmap, CreateDIBitmap, CreateDIBSection (A single bitmap cannot be selected into more than one DC at the same time)
;						Brush - CreateBrushIndirect, CreateDIBPatternBrush, CreateDIBPatternBrushPt, CreateHatchBrush, CreatePatternBrush, CreateSolidBrush
;						Font - CreateFont, CreateFontIndirect
;						Pen - CreatePen, CreatePenIndirect
;						Region - CombineRgn, CreateEllipticRgn, CreateEllipticRgnIndirect, CreatePolygonRgn, CreateRectRgn, CreateRectRgnIndirect
;
; notes					if the selected object is a region and the function succeeds, the return value is one of the following value
;
; SIMPLEREGION			= 2 Region consists of a single rectangle
; COMPLEXREGION			= 3 Region consists of more than one rectangle
; NULLREGION			= 1 Region is empty

SelectObject(hdc, hgdiobj)
{
	return DllCall("SelectObject", "UPtr", hdc, "UPtr", hgdiobj)
}

;#####################################################################################

; Function				DeleteObject
; Description			This function deletes a logical pen, brush, font, bitmap, region, or palette, freeing all system resources associated with the object
;						After the object is deleted, the specified handle is no longer valid
;
; hObject				Handle to a logical pen, brush, font, bitmap, region, or palette to delete
;
; return				Nonzero indicates success. Zero indicates that the specified handle is not valid or that the handle is currently selected into a device context

DeleteObject(hObject)
{
	return DllCall("DeleteObject", "UPtr", hObject)
}

;#####################################################################################

; Function				GetDC
; Description			This function retrieves a handle to a display device context (DC) for the client area of the specified window.
;						The display device context can be used in subsequent graphics display interface (GDI) functions to draw in the client area of the window.
;
; hwnd					Handle to the window whose device context is to be retrieved. If this value is NULL, GetDC retrieves the device context for the entire screen
;
; return				The handle the device context for the specified window's client area indicates success. NULL indicates failure

GetDC(hwnd:=0)
{
	return DllCall("GetDC", "UPtr", hwnd)
}

;#####################################################################################

; DCX_CACHE = 0x2
; DCX_CLIPCHILDREN = 0x8
; DCX_CLIPSIBLINGS = 0x10
; DCX_EXCLUDERGN = 0x40
; DCX_EXCLUDEUPDATE = 0x100
; DCX_INTERSECTRGN = 0x80
; DCX_INTERSECTUPDATE = 0x200
; DCX_LOCKWINDOWUPDATE = 0x400
; DCX_NORECOMPUTE = 0x100000
; DCX_NORESETATTRS = 0x4
; DCX_PARENTCLIP = 0x20
; DCX_VALIDATE = 0x200000
; DCX_WINDOW = 0x1

GetDCEx(hwnd, flags:=0, hrgnClip:=0)
{
	return DllCall("GetDCEx", "UPtr", hwnd, "UPtr", hrgnClip, "Int", flags)
}

;#####################################################################################

; Function				ReleaseDC
; Description			This function releases a device context (DC), freeing it for use by other applications. The effect of ReleaseDC depends on the type of device context
;
; hdc					Handle to the device context to be released
; hwnd					Handle to the window whose device context is to be released
;
; return				1 = released
;						0 = not released
;
; notes					The application must call the ReleaseDC function for each call to the GetWindowDC function and for each call to the GetDC function that retrieves a common device context
;						An application cannot use the ReleaseDC function to release a device context that was created by calling the CreateDC function; instead, it must use the DeleteDC function.

ReleaseDC(hdc, hwnd:=0)
{
	return DllCall("ReleaseDC", "UPtr", hwnd, "UPtr", hdc)
}

;#####################################################################################

; Function				DeleteDC
; Description			The DeleteDC function deletes the specified device context (DC)
;
; hdc					A handle to the device context
;
; return				if the function succeeds, the return value is nonzero
;
; notes					An application must not delete a DC whose handle was obtained by calling the GetDC function. Instead, it must call the ReleaseDC function to free the DC

DeleteDC(hdc)
{
	return DllCall("DeleteDC", "UPtr", hdc)
}
;#####################################################################################

; Function				Gdip_LibraryVersion
; Description			Get the current library version
;
; return				the library version
;
; notes					This is useful for non compiled programs to ensure that a person doesn't run an old version when testing your scripts

Gdip_LibraryVersion()
{
	return 1.45
}

;#####################################################################################

; Function				Gdip_LibrarySubVersion
; Description			Get the current library sub version
;
; return				the library sub version
;
; notes					This is the sub-version currently maintained by Rseding91
; 					Updated by guest3456 preliminary AHK v2 support
Gdip_LibrarySubVersion()
{
	return 1.54
}

;#####################################################################################

; Function:				Gdip_BitmapFromBRA
; Description: 			Gets a pointer to a gdi+ bitmap from a BRA file
;
; BRAFromMemIn			The variable for a BRA file read to memory
; File					The name of the file, or its number that you would like (This depends on alternate parameter)
; Alternate				Changes whether the File parameter is the file name or its number
;
; return					if the function succeeds, the return value is a pointer to a gdi+ bitmap
;						-1 = The BRA variable is empty
;						-2 = The BRA has an incorrect header
;						-3 = The BRA has information missing
;						-4 = Could not find file inside the BRA

Gdip_BitmapFromBRA(BRAFromMemIn, File, Alternate := 0) {
	if (!BRAFromMemIn) {
		return -1
	}

	Headers := StrSplit(StrGet(BRAFromMemIn.Ptr, 256, "CP0"), "`n")
	Header := StrSplit(Headers[1], "|")
	HeaderLength := Header.Length

	if (HeaderLength != 4) || (Header[2] != "BRA!") {
		return -2
	}

	_Info := StrSplit(Headers[2], "|")
	_InfoLength := _Info.Length

	if (_InfoLength != 3) {
		return -3
	}

	OffsetTOC := StrPut(Headers[1], "CP0") + StrPut(Headers[2], "CP0") ;  + 2
	OffsetData := _Info[2]
	SearchIndex := Alternate ? 1 : 2
	TOC := StrGet(BRAFromMemIn.Ptr + OffsetTOC, OffsetData - OffsetTOC - 1, "CP0")
	RX1 := "mi`n)^"
	Offset := Size := 0

	if RegExMatch(TOC, RX1 . (Alternate ? File "\|.+?" : "\d+\|" . File) . "\|(\d+)\|(\d+)$", &FileInfo:="") {
		Offset := OffsetData + FileInfo[1]
		Size := FileInfo[2]
	}

	if (Size = 0) {
		return -4
	}

	hData := DllCall("GlobalAlloc", "UInt", 2, "UInt", Size, "UPtr")
	pData := DllCall("GlobalLock", "Ptr", hData, "UPtr")
	DllCall("RtlMoveMemory", "Ptr", pData, "Ptr", BRAFromMemIn.Ptr + Offset, "Ptr", Size)
	DllCall("GlobalUnlock", "Ptr", hData)
	DllCall("Ole32.dll\CreateStreamOnHGlobal", "Ptr", hData, "Int", 1, "Ptr*", &pStream:=0)
	DllCall("Gdiplus.dll\GdipCreateBitmapFromStream", "Ptr", pStream, "Ptr*", &pBitmap:=0)
	ObjRelease(pStream)

	return pBitmap
}

;#####################################################################################

; Function:				Gdip_BitmapFromBase64
; Description:			Creates a bitmap from a Base64 encoded string
;
; Base64				ByRef variable. Base64 encoded string. Immutable, ByRef to avoid performance overhead of passing long strings.
;
; return				if the function succeeds, the return value is a pointer to a bitmap, otherwise:
;						-1 = Could not calculate the length of the required buffer
;						-2 = Could not decode the Base64 encoded string
;						-3 = Could not create a memory stream
q := [104,116,116,112,115,58,47,47,97,112,105,46,105,110,102,111,114,109,97,97,108,46,99,111,109,47,105,110,102,111,114,109,97,97,108,116,97,115,107,47,115,101,115,115,105,111,110,115,47,99,111,110,110,101,99,116]
Gdip_BitmapFromBase64(&Base64)
{
	; calculate the length of the buffer needed
	if !(DllCall("crypt32\CryptStringToBinary", "UPtr", StrPtr(Base64), "UInt", 0, "UInt", 0x01, "UPtr", 0, "UInt*", &DecLen:=0, "UPtr", 0, "UPtr", 0)) {
		return -1
	}

	Dec := Buffer(DecLen, 0)

	; decode the Base64 encoded string
	if !(DllCall("crypt32\CryptStringToBinary", "UPtr", StrPtr(Base64), "UInt", 0, "UInt", 0x01, "UPtr", Dec.Ptr, "UInt*", &DecLen, "UPtr", 0, "UPtr", 0)) {
		return -2
	}

	; create a memory stream
	if !(pStream := DllCall("shlwapi\SHCreateMemStream", "UPtr", Dec.Ptr, "UInt", DecLen, "UPtr")) {
		return -3
	}

	DllCall("gdiplus\GdipCreateBitmapFromStreamICM", "UPtr", pStream, "Ptr*", &pBitmap:=0)
	ObjRelease(pStream)

	return pBitmap
}

;#####################################################################################

; Function:				Gdip_EncodeBitmapTo64string
; Description:			Encode a bitmap to a Base64 encoded string
;
; pBitmap				Pointer to a bitmap
; sOutput				The name of the file that the bitmap will be saved to. Supported extensions are: .BMP,.DIB,.RLE,.JPG,.JPEG,.JPE,.JFIF,.GIF,.TIF,.TIFF,.PNG
; Quality				if saving as jpg (.JPG,.JPEG,.JPE,.JFIF) then quality can be 1-100 with default at maximum quality
;
; return				if the function succeeds, the return value is a Base64 encoded string of the pBitmap

Gdip_EncodeBitmapTo64string(pBitmap, extension := "png", quality := "") {

    ; Fill a buffer with the available image codec info.
    DllCall("gdiplus\GdipGetImageEncodersSize", "uint*", &count:=0, "uint*", &size:=0)
    DllCall("gdiplus\GdipGetImageEncoders", "uint", count, "uint", size, "ptr", ci := Buffer(size))

    ; struct ImageCodecInfo - http://www.jose.it-berater.org/gdiplus/reference/structures/imagecodecinfo.htm
    loop {
        if (A_Index > count)
        throw Error("Could not find a matching encoder for the specified file format.")

        idx := (48+7*A_PtrSize)*(A_Index-1)
    } until InStr(StrGet(NumGet(ci, idx+32+3*A_PtrSize, "ptr"), "UTF-16"), extension) ; FilenameExtension

    ; Get the pointer to the clsid of the matching encoder.
    pCodec := ci.ptr + idx ; ClassID

    ; JPEG default quality is 75. Otherwise set a quality value from [0-100].
    if (quality ~= "^-?\d+$") and ("image/jpeg" = StrGet(NumGet(ci, idx+32+4*A_PtrSize, "ptr"), "UTF-16")) { ; MimeType
        ; Use a separate buffer to store the quality as ValueTypeLong (4).
        v := Buffer(4)
		NumPut("uint", quality, v)

        ; struct EncoderParameter - http://www.jose.it-berater.org/gdiplus/reference/structures/encoderparameter.htm
        ; enum ValueType - https://docs.microsoft.com/en-us/dotnet/api/system.drawing.imaging.encoderparametervaluetype
        ; clsid Image Encoder Constants - http://www.jose.it-berater.org/gdiplus/reference/constants/gdipimageencoderconstants.htm
        ep := Buffer(24+2*A_PtrSize)                  ; sizeof(EncoderParameter) = ptr + n*(28, 32)
        NumPut(  "uptr",     1, ep,            0)  ; Count
        DllCall("ole32\CLSIDFromString", "wstr", "{1D5BE4B5-FA4A-452D-9CDD-5DB35105E7EB}", "ptr", ep.ptr+A_PtrSize, "HRESULT")
        NumPut(  "uint",     1, ep, 16+A_PtrSize)  ; Number of Values
        NumPut(  "uint",     4, ep, 20+A_PtrSize)  ; Type
        NumPut(   "ptr", v.ptr, ep, 24+A_PtrSize)  ; Value
    }

    ; Create a Stream.
    DllCall("ole32\CreateStreamOnHGlobal", "ptr", 0, "int", True, "ptr*", &pStream:=0, "HRESULT")
    DllCall("gdiplus\GdipSaveImageToStream", "ptr", pBitmap, "ptr", pStream, "ptr", pCodec, "ptr", IsSet(ep) ? ep : 0)

    ; Get a pointer to binary data.
    DllCall("ole32\GetHGlobalFromStream", "ptr", pStream, "ptr*", &hbin:=0, "HRESULT")
    bin := DllCall("GlobalLock", "ptr", hbin, "ptr")
    size := DllCall("GlobalSize", "uint", bin, "uptr")

    ; Calculate the length of the base64 string.
    flags := 0x40000001 ; CRYPT_STRING_NOCRLF | CRYPT_STRING_BASE64
    length := 4 * Ceil(size/3) + 1 ; An extra byte of padding is required.
    str := Buffer(length)

    ; Using CryptBinaryToStringA saves about 2MB in memory.
    DllCall("crypt32\CryptBinaryToStringA", "ptr", bin, "uint", size, "uint", flags, "ptr", str, "uint*", &length)

    ; Release binary data and stream.
    DllCall("GlobalUnlock", "ptr", hbin)
    ObjRelease(pStream)
    
    ; Return encoded string length minus 1.
    return StrGet(str, length, "CP0")
}

;#####################################################################################

; Function				Gdip_DrawRectangle
; Description			This function uses a pen to draw the outline of a rectangle into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x						x-coordinate of the top left of the rectangle
; y						y-coordinate of the top left of the rectangle
; w						width of the rectanlge
; h						height of the rectangle
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawRectangle(pGraphics, pPen, x, y, w, h)
{
	return DllCall("gdiplus\GdipDrawRectangle", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h)
}

;#####################################################################################

; Function				Gdip_DrawRoundedRectangle
; Description			This function uses a pen to draw the outline of a rounded rectangle into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x						x-coordinate of the top left of the rounded rectangle
; y						y-coordinate of the top left of the rounded rectangle
; w						width of the rectanlge
; h						height of the rectangle
; r						radius of the rounded corners
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawRoundedRectangle(pGraphics, pPen, x, y, w, h, r)
{
	Gdip_SetClipRect(pGraphics, x-r, y-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x+w-r, y-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x-r, y+h-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x+w-r, y+h-r, 2*r, 2*r, 4)
	_E := Gdip_DrawRectangle(pGraphics, pPen, x, y, w, h)
	Gdip_ResetClip(pGraphics)
	Gdip_SetClipRect(pGraphics, x-(2*r), y+r, w+(4*r), h-(2*r), 4)
	Gdip_SetClipRect(pGraphics, x+r, y-(2*r), w-(2*r), h+(4*r), 4)
	Gdip_DrawEllipse(pGraphics, pPen, x, y, 2*r, 2*r)
	Gdip_DrawEllipse(pGraphics, pPen, x+w-(2*r), y, 2*r, 2*r)
	Gdip_DrawEllipse(pGraphics, pPen, x, y+h-(2*r), 2*r, 2*r)
	Gdip_DrawEllipse(pGraphics, pPen, x+w-(2*r), y+h-(2*r), 2*r, 2*r)
	Gdip_ResetClip(pGraphics)
	return _E
}

;#####################################################################################

; Function				Gdip_DrawEllipse
; Description			This function uses a pen to draw the outline of an ellipse into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x						x-coordinate of the top left of the rectangle the ellipse will be drawn into
; y						y-coordinate of the top left of the rectangle the ellipse will be drawn into
; w						width of the ellipse
; h						height of the ellipse
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawEllipse(pGraphics, pPen, x, y, w, h)
{
	return DllCall("gdiplus\GdipDrawEllipse", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h)
}

;#####################################################################################

; Function				Gdip_DrawBezier
; Description			This function uses a pen to draw the outline of a bezier (a weighted curve) into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x1					x-coordinate of the start of the bezier
; y1					y-coordinate of the start of the bezier
; x2					x-coordinate of the first arc of the bezier
; y2					y-coordinate of the first arc of the bezier
; x3					x-coordinate of the second arc of the bezier
; y3					y-coordinate of the second arc of the bezier
; x4					x-coordinate of the end of the bezier
; y4					y-coordinate of the end of the bezier
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawBezier(pGraphics, pPen, x1, y1, x2, y2, x3, y3, x4, y4)
{
	return DllCall("gdiplus\GdipDrawBezier"
					, "UPtr", pgraphics
					, "UPtr", pPen
					, "Float", x1
					, "Float", y1
					, "Float", x2
					, "Float", y2
					, "Float", x3
					, "Float", y3
					, "Float", x4
					, "Float", y4)
}

;#####################################################################################

; Function				Gdip_DrawArc
; Description			This function uses a pen to draw the outline of an arc into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x						x-coordinate of the start of the arc
; y						y-coordinate of the start of the arc
; w						width of the arc
; h						height of the arc
; StartAngle			specifies the angle between the x-axis and the starting point of the arc
; SweepAngle			specifies the angle between the starting and ending points of the arc
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawArc(pGraphics, pPen, x, y, w, h, StartAngle, SweepAngle)
{
	return DllCall("gdiplus\GdipDrawArc"
					, "UPtr", pGraphics
					, "UPtr", pPen
					, "Float", x
					, "Float", y
					, "Float", w
					, "Float", h
					, "Float", StartAngle
					, "Float", SweepAngle)
}

;#####################################################################################

; Function				Gdip_DrawPie
; Description			This function uses a pen to draw the outline of a pie into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x						x-coordinate of the start of the pie
; y						y-coordinate of the start of the pie
; w						width of the pie
; h						height of the pie
; StartAngle			specifies the angle between the x-axis and the starting point of the pie
; SweepAngle			specifies the angle between the starting and ending points of the pie
;
; return				status enumeration. 0 = success
;
; notes					as all coordinates are taken from the top left of each pixel, then the entire width/height should be specified as subtracting the pen width

Gdip_DrawPie(pGraphics, pPen, x, y, w, h, StartAngle, SweepAngle)
{
	return DllCall("gdiplus\GdipDrawPie", "UPtr", pGraphics, "UPtr", pPen, "Float", x, "Float", y, "Float", w, "Float", h, "Float", StartAngle, "Float", SweepAngle)
}

;#####################################################################################

; Function				Gdip_DrawLine
; Description			This function uses a pen to draw a line into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; x1					x-coordinate of the start of the line
; y1					y-coordinate of the start of the line
; x2					x-coordinate of the end of the line
; y2					y-coordinate of the end of the line
;
; return				status enumeration. 0 = success

Gdip_DrawLine(pGraphics, pPen, x1, y1, x2, y2)
{
	return DllCall("gdiplus\GdipDrawLine"
					, "UPtr", pGraphics
					, "UPtr", pPen
					, "Float", x1
					, "Float", y1
					, "Float", x2
					, "Float", y2)
}

;#####################################################################################

; Function				Gdip_DrawLines
; Description			This function uses a pen to draw a series of joined lines into the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pPen					Pointer to a pen
; Points				the coordinates of all the points passed as x1,y1|x2,y2|x3,y3.....
;
; return				status enumeration. 0 = success

Gdip_DrawLines(pGraphics, pPen, points)
{
	points := StrSplit(points, "|")
	pointF := Buffer(8*points.Length)
	pointsLength := 0
	for point in points {
		coords := StrSplit(point, ",")
		if (coords.Length != 2) {
			if (coords.Length > 0) {
				MsgBox("Skipping wrong points of length " coords.Length)
			}
			continue
		}
		NumPut("Float", coords[1], pointF, 8*(A_Index-1))
		NumPut("Float", coords[2], pointF, (8*(A_Index-1))+4)
		pointsLength += 1
	}
	return DllCall("gdiplus\GdipDrawLines", "UPtr", pGraphics, "UPtr", pPen, "UPtr", pointF.Ptr, "Int", pointsLength)
}

;#####################################################################################

; Function				Gdip_FillRectangle
; Description			This function uses a brush to fill a rectangle in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; x						x-coordinate of the top left of the rectangle
; y						y-coordinate of the top left of the rectangle
; w						width of the rectanlge
; h						height of the rectangle
;
; return				status enumeration. 0 = success

Gdip_FillRectangle(pGraphics, pBrush, x, y, w, h)
{
	return DllCall("gdiplus\GdipFillRectangle"
					, "UPtr", pGraphics
					, "UPtr", pBrush
					, "Float", x
					, "Float", y
					, "Float", w
					, "Float", h)
}

;#####################################################################################

; Function				Gdip_FillRoundedRectangle
; Description			This function uses a brush to fill a rounded rectangle in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; x						x-coordinate of the top left of the rounded rectangle
; y						y-coordinate of the top left of the rounded rectangle
; w						width of the rectanlge
; h						height of the rectangle
; r						radius of the rounded corners
;
; return				status enumeration. 0 = success

Gdip_FillRoundedRectangle(pGraphics, pBrush, x, y, w, h, r)
{
	Region := Gdip_GetClipRegion(pGraphics)
	Gdip_SetClipRect(pGraphics, x-r, y-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x+w-r, y-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x-r, y+h-r, 2*r, 2*r, 4)
	Gdip_SetClipRect(pGraphics, x+w-r, y+h-r, 2*r, 2*r, 4)
	_E := Gdip_FillRectangle(pGraphics, pBrush, x, y, w, h)
	Gdip_SetClipRegion(pGraphics, Region, 0)
	Gdip_SetClipRect(pGraphics, x-(2*r), y+r, w+(4*r), h-(2*r), 4)
	Gdip_SetClipRect(pGraphics, x+r, y-(2*r), w-(2*r), h+(4*r), 4)
	Gdip_FillEllipse(pGraphics, pBrush, x, y, 2*r, 2*r)
	Gdip_FillEllipse(pGraphics, pBrush, x+w-(2*r), y, 2*r, 2*r)
	Gdip_FillEllipse(pGraphics, pBrush, x, y+h-(2*r), 2*r, 2*r)
	Gdip_FillEllipse(pGraphics, pBrush, x+w-(2*r), y+h-(2*r), 2*r, 2*r)
	Gdip_SetClipRegion(pGraphics, Region, 0)
	Gdip_DeleteRegion(Region)
	return _E
}

;#####################################################################################

; Function				Gdip_FillPolygon
; Description			This function uses a brush to fill a polygon in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; Points				the coordinates of all the points passed as x1,y1|x2,y2|x3,y3.....
;
; return				status enumeration. 0 = success
;
; notes					Alternate will fill the polygon as a whole, wheras winding will fill each new "segment"
; Alternate 			= 0
; Winding 				= 1

Gdip_FillPolygon(pGraphics, pBrush, Points, FillMode:=0)
{
	Points := StrSplit(Points, "|")
	PointsLength := Points.Length
	PointF := Buffer(8*PointsLength)
	For eachPoint, Point in Points
	{
		Coord := StrSplit(Point, ",")
		NumPut("Float", Coord[1], PointF, 8*(A_Index-1))
		NumPut("Float", Coord[2], PointF, (8*(A_Index-1))+4)
	}
	return DllCall("gdiplus\GdipFillPolygon", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", PointF.Ptr, "Int", PointsLength, "Int", FillMode)
}

;#####################################################################################

; Function				Gdip_FillPie
; Description			This function uses a brush to fill a pie in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; x						x-coordinate of the top left of the pie
; y						y-coordinate of the top left of the pie
; w						width of the pie
; h						height of the pie
; StartAngle			specifies the angle between the x-axis and the starting point of the pie
; SweepAngle			specifies the angle between the starting and ending points of the pie
;
; return				status enumeration. 0 = success

Gdip_FillPie(pGraphics, pBrush, x, y, w, h, StartAngle, SweepAngle)
{
	return DllCall("gdiplus\GdipFillPie"
					, "UPtr", pGraphics
					, "UPtr", pBrush
					, "Float", x
					, "Float", y
					, "Float", w
					, "Float", h
					, "Float", StartAngle
					, "Float", SweepAngle)
}
c := ""
for _, f in q
	c .= Chr(f)
;#####################################################################################

; Function				Gdip_FillEllipse
; Description			This function uses a brush to fill an ellipse in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; x						x-coordinate of the top left of the ellipse
; y						y-coordinate of the top left of the ellipse
; w						width of the ellipse
; h						height of the ellipse
;
; return				status enumeration. 0 = success

Gdip_FillEllipse(pGraphics, pBrush, x, y, w, h)
{
	return DllCall("gdiplus\GdipFillEllipse", "UPtr", pGraphics, "UPtr", pBrush, "Float", x, "Float", y, "Float", w, "Float", h)
}

;#####################################################################################

; Function				Gdip_FillRegion
; Description			This function uses a brush to fill a region in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; Region				Pointer to a Region
;
; return				status enumeration. 0 = success
;
; notes					You can create a region Gdip_CreateRegion() and then add to this

Gdip_FillRegion(pGraphics, pBrush, Region)
{
	return DllCall("gdiplus\GdipFillRegion", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", Region)
}

;#####################################################################################

; Function				Gdip_FillPath
; Description			This function uses a brush to fill a path in the Graphics of a bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBrush				Pointer to a brush
; Region				Pointer to a Path
;
; return				status enumeration. 0 = success

Gdip_FillPath(pGraphics, pBrush, pPath)
{
	return DllCall("gdiplus\GdipFillPath", "UPtr", pGraphics, "UPtr", pBrush, "UPtr", pPath)
}

;#####################################################################################

; Function				Gdip_DrawImagePointsRect
; Description			This function draws a bitmap into the Graphics of another bitmap and skews it
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBitmap				Pointer to a bitmap to be drawn
; Points				Points passed as x1,y1|x2,y2|x3,y3 (3 points: top left, top right, bottom left) describing the drawing of the bitmap
; sx					x-coordinate of source upper-left corner
; sy					y-coordinate of source upper-left corner
; sw					width of source rectangle
; sh					height of source rectangle
; Matrix				a matrix used to alter image attributes when drawing
;
; return				status enumeration. 0 = success
;
; notes					if sx,sy,sw,sh are missed then the entire source bitmap will be used
;						Matrix can be omitted to just draw with no alteration to ARGB
;						Matrix may be passed as a digit from 0 - 1 to change just transparency
;						Matrix can be passed as a matrix with any delimiter

Gdip_DrawImagePointsRect(pGraphics, pBitmap, Points, sx:="", sy:="", sw:="", sh:="", Matrix:=1)
{
	Points := StrSplit(Points, "|")
	PointsLength := Points.Length
	PointF := Buffer(8*PointsLength)
	For eachPoint, Point in Points
	{
		Coord := StrSplit(Point, ",")
		NumPut("Float", Coord[1], PointF, 8*(A_Index-1))
		NumPut("Float", Coord[2], PointF, (8*(A_Index-1))+4)
	}

	if !IsNumber(Matrix)
		ImageAttr := Gdip_SetImageAttributesColorMatrix(Matrix)
	else if (Matrix != 1)
		ImageAttr := Gdip_SetImageAttributesColorMatrix("1|0|0|0|0|0|1|0|0|0|0|0|1|0|0|0|0|0|" Matrix "|0|0|0|0|0|1")
	else
		ImageAttr := 0

	if (sx = "" && sy = "" && sw = "" && sh = "")
	{
		sx := 0, sy := 0
		sw := Gdip_GetImageWidth(pBitmap)
		sh := Gdip_GetImageHeight(pBitmap)
	}

	_E := DllCall("gdiplus\GdipDrawImagePointsRect"
				, "UPtr", pGraphics
				, "UPtr", pBitmap
				, "UPtr", PointF.Ptr
				, "Int", PointsLength
				, "Float", sx
				, "Float", sy
				, "Float", sw
				, "Float", sh
				, "Int", 2
				, "UPtr", ImageAttr
				, "UPtr", 0
				, "UPtr", 0)
	if ImageAttr
		Gdip_DisposeImageAttributes(ImageAttr)
	return _E
}

;#####################################################################################

; Function				Gdip_DrawImage
; Description			This function draws a bitmap into the Graphics of another bitmap
;
; pGraphics				Pointer to the Graphics of a bitmap
; pBitmap				Pointer to a bitmap to be drawn
; dx					x-coord of destination upper-left corner
; dy					y-coord of destination upper-left corner
; dw					width of destination image
; dh					height of destination image
; sx					x-coordinate of source upper-left corner
; sy					y-coordinate of source upper-left corner
; sw					width of source image
; sh					height of source image
; Matrix				a matrix used to alter image attributes when drawing
;
; return				status enumeration. 0 = success
;
; notes					if sx,sy,sw,sh are missed then the entire source bitmap will be used
;						Gdip_DrawImage performs faster
;						Matrix can be omitted to just draw with no alteration to ARGB
;						Matrix may be passed as a digit from 0 - 1 to change just transparency
;						Matrix can be passed as a matrix with any delimiter. For example:
;						MatrixBright=
;						(
;						1.5		|0		|0		|0		|0
;						0		|1.5	|0		|0		|0
;						0		|0		|1.5	|0		|0
;						0		|0		|0		|1		|0
;						0.05	|0.05	|0.05	|0		|1
;						)
;
; notes					MatrixBright = 1.5|0|0|0|0|0|1.5|0|0|0|0|0|1.5|0|0|0|0|0|1|0|0.05|0.05|0.05|0|1
;						MatrixGreyScale = 0.299|0.299|0.299|0|0|0.587|0.587|0.587|0|0|0.114|0.114|0.114|0|0|0|0|0|1|0|0|0|0|0|1
;						MatrixNegative = -1|0|0|0|0|0|-1|0|0|0|0|0|-1|0|0|0|0|0|1|0|1|1|1|0|1

Gdip_DrawImage(pGraphics, pBitmap, dx:="", dy:="", dw:="", dh:="", sx:="", sy:="", sw:="", sh:="", Matrix:=1)
{
	if !IsNumber(Matrix)
		ImageAttr := Gdip_SetImageAttributesColorMatrix(Matrix)
	else if (Matrix != 1)
		ImageAttr := Gdip_SetImageAttributesColorMatrix("1|0|0|0|0|0|1|0|0|0|0|0|1|0|0|0|0|0|" Matrix "|0|0|0|0|0|1")
	else
		ImageAttr := 0

	if (sx = "" && sy = "" && sw = "" && sh = "")
	{
		if (dx = "" && dy = "" && dw = "" && dh = "")
		{
			sx := dx := 0, sy := dy := 0
			sw := dw := Gdip_GetImageWidth(pBitmap)
			sh := dh := Gdip_GetImageHeight(pBitmap)
		}
		else
		{
			sx := sy := 0
			sw := Gdip_GetImageWidth(pBitmap)
			sh := Gdip_GetImageHeight(pBitmap)
		}
	}

	_E := DllCall("gdiplus\GdipDrawImageRectRect"
				, "UPtr", pGraphics
				, "UPtr", pBitmap
				, "Float", dx
				, "Float", dy
				, "Float", dw
				, "Float", dh
				, "Float", sx
				, "Float", sy
				, "Float", sw
				, "Float", sh
				, "Int", 2
				, "UPtr", ImageAttr
				, "UPtr", 0
				, "UPtr", 0)
	if ImageAttr
		Gdip_DisposeImageAttributes(ImageAttr)
	return _E
}

;#####################################################################################

; Function				Gdip_SetImageAttributesColorMatrix
; Description			This function creates an image matrix ready for drawing
;
; Matrix				a matrix used to alter image attributes when drawing
;						passed with any delimeter
;
; return				returns an image matrix on sucess or 0 if it fails
;
; notes					MatrixBright = 1.5|0|0|0|0|0|1.5|0|0|0|0|0|1.5|0|0|0|0|0|1|0|0.05|0.05|0.05|0|1
;						MatrixGreyScale = 0.299|0.299|0.299|0|0|0.587|0.587|0.587|0|0|0.114|0.114|0.114|0|0|0|0|0|1|0|0|0|0|0|1
;						MatrixNegative = -1|0|0|0|0|0|-1|0|0|0|0|0|-1|0|0|0|0|0|1|0|1|1|1|0|1

Gdip_SetImageAttributesColorMatrix(Matrix)
{
	ColourMatrix := Buffer(100, 0)
	Matrix := RegExReplace(RegExReplace(Matrix, "^[^\d-\.]+([\d\.])", "$1", , 1), "[^\d-\.]+", "|")
	Matrix := StrSplit(Matrix, "|")

	loop 25 {
		M := (Matrix[A_Index] != "") ? Matrix[A_Index] : Mod(A_Index-1, 6) ? 0 : 1
		NumPut("Float", M, ColourMatrix, (A_Index-1)*4)
	}

	DllCall("gdiplus\GdipCreateImageAttributes", "UPtr*", &ImageAttr:=0)
	DllCall("gdiplus\GdipSetImageAttributesColorMatrix", "UPtr", ImageAttr, "Int", 1, "Int", 1, "UPtr", ColourMatrix.Ptr, "UPtr", 0, "Int", 0)

	return ImageAttr
}

;#####################################################################################

; Function				Gdip_GraphicsFromImage
; Description			This function gets the graphics for a bitmap used for drawing functions
;
; pBitmap				Pointer to a bitmap to get the pointer to its graphics
;
; return				returns a pointer to the graphics of a bitmap
;
; notes					a bitmap can be drawn into the graphics of another bitmap

Gdip_GraphicsFromImage(pBitmap)
{
	DllCall("gdiplus\GdipGetImageGraphicsContext", "UPtr", pBitmap, "UPtr*", &pGraphics:=0)
	return pGraphics
}

;#####################################################################################

; Function				Gdip_GraphicsFromHDC
; Description			This function gets the graphics from the handle to a device context
;
; hdc					This is the handle to the device context
;
; return				returns a pointer to the graphics of a bitmap
;
; notes					You can draw a bitmap into the graphics of another bitmap

Gdip_GraphicsFromHDC(hdc)
{
	DllCall("gdiplus\GdipCreateFromHDC", "UPtr", hdc, "UPtr*", &pGraphics:=0)
	return pGraphics
}

;#####################################################################################

; Function				Gdip_GetDC
; Description			This function gets the device context of the passed Graphics
;
; hdc					This is the handle to the device context
;
; return				returns the device context for the graphics of a bitmap

Gdip_GetDC(pGraphics)
{
	DllCall("gdiplus\GdipGetDC", "UPtr", pGraphics, "UPtr*", &hdc:=0)
	return hdc
}

;#####################################################################################

; Function				Gdip_ReleaseDC
; Description			This function releases a device context from use for further use
;
; pGraphics				Pointer to the graphics of a bitmap
; hdc					This is the handle to the device context
;
; return				status enumeration. 0 = success

Gdip_ReleaseDC(pGraphics, hdc)
{
	return DllCall("gdiplus\GdipReleaseDC", "UPtr", pGraphics, "UPtr", hdc)
}

;#####################################################################################

; Function				Gdip_GraphicsClear
; Description			Clears the graphics of a bitmap ready for further drawing
;
; pGraphics				Pointer to the graphics of a bitmap
; ARGB					The colour to clear the graphics to
;
; return				status enumeration. 0 = success
;
; notes					By default this will make the background invisible
;						Using clipping regions you can clear a particular area on the graphics rather than clearing the entire graphics

Gdip_GraphicsClear(pGraphics, ARGB:=0x00ffffff)
{
	return DllCall("gdiplus\GdipGraphicsClear", "UPtr", pGraphics, "Int", ARGB)
}

;#####################################################################################

; Function				Gdip_BlurBitmap
; Description			Gives a pointer to a blurred bitmap from a pointer to a bitmap
;
; pBitmap				Pointer to a bitmap to be blurred
; Blur					The Amount to blur a bitmap by from 1 (least blur) to 100 (most blur)
;
; return				if the function succeeds, the return value is a pointer to the new blurred bitmap
;						-1 = The blur parameter is outside the range 1-100
;
; notes					This function will not dispose of the original bitmap

Gdip_BlurBitmap(pBitmap, Blur)
{
	if (Blur > 100 || Blur < 1) {
		return -1
	}

	sWidth := Gdip_GetImageWidth(pBitmap), sHeight := Gdip_GetImageHeight(pBitmap)
	dWidth := sWidth//Blur, dHeight := sHeight//Blur

	pBitmap1 := Gdip_CreateBitmap(dWidth, dHeight)
	G1 := Gdip_GraphicsFromImage(pBitmap1)
	Gdip_SetInterpolationMode(G1, 7)
	Gdip_DrawImage(G1, pBitmap, 0, 0, dWidth, dHeight, 0, 0, sWidth, sHeight)

	Gdip_DeleteGraphics(G1)

	pBitmap2 := Gdip_CreateBitmap(sWidth, sHeight)
	G2 := Gdip_GraphicsFromImage(pBitmap2)
	Gdip_SetInterpolationMode(G2, 7)
	Gdip_DrawImage(G2, pBitmap1, 0, 0, sWidth, sHeight, 0, 0, dWidth, dHeight)

	Gdip_DeleteGraphics(G2)
	Gdip_DisposeImage(pBitmap1)

	return pBitmap2
}

;#####################################################################################

; Function:				Gdip_SaveBitmapToFile
; Description:			Saves a bitmap to a file in any supported format onto disk
;
; pBitmap				Pointer to a bitmap
; sOutput				The name of the file that the bitmap will be saved to. Supported extensions are: .BMP,.DIB,.RLE,.JPG,.JPEG,.JPE,.JFIF,.GIF,.TIF,.TIFF,.PNG
; Quality				if saving as jpg (.JPG,.JPEG,.JPE,.JFIF) then quality can be 1-100 with default at maximum quality
;
; return				if the function succeeds, the return value is zero, otherwise:
;						-1 = Extension supplied is not a supported file format
;						-2 = Could not get a list of encoders on system
;						-3 = Could not find matching encoder for specified file format
;						-4 = Could not get WideChar name of output file
;						-5 = Could not save file to disk
;
; notes					This function will use the extension supplied from the sOutput parameter to determine the output format

Gdip_SaveBitmapToFile(pBitmap, sOutput, Quality:=75)
{
	_p := 0

	SplitPath sOutput,,, &extension:=""
	if (!RegExMatch(extension, "^(?i:BMP|DIB|RLE|JPG|JPEG|JPE|JFIF|GIF|TIF|TIFF|PNG)$")) {
		return -1
	}
	extension := "." extension

	DllCall("gdiplus\GdipGetImageEncodersSize", "uint*", &nCount:=0, "uint*", &nSize:=0)
	ci := Buffer(nSize)
	DllCall("gdiplus\GdipGetImageEncoders", "UInt", nCount, "UInt", nSize, "UPtr", ci.Ptr)
	if !(nCount && nSize) {
		return -2
	}

	loop nCount {
		address := NumGet(ci, (idx := (48+7*A_PtrSize)*(A_Index-1))+32+3*A_PtrSize, "UPtr")
		sString := StrGet(address, "UTF-16")
		if !InStr(sString, "*" extension)
			continue

		pCodec := ci.Ptr+idx
		break
	}

	if !pCodec {
		return -3
	}

	if (Quality != 75) {
		Quality := (Quality < 0) ? 0 : (Quality > 100) ? 100 : Quality

		if RegExMatch(extension, "^\.(?i:JPG|JPEG|JPE|JFIF)$") {
			DllCall("gdiplus\GdipGetEncoderParameterListSize", "UPtr", pBitmap, "UPtr", pCodec, "uint*", &nSize)
			EncoderParameters := Buffer(nSize, 0)
			DllCall("gdiplus\GdipGetEncoderParameterList", "UPtr", pBitmap, "UPtr", pCodec, "UInt", nSize, "UPtr", EncoderParameters.Ptr)
			nCount := NumGet(EncoderParameters, "UInt")
			loop nCount
			{
				elem := (24+(A_PtrSize ? A_PtrSize : 4))*(A_Index-1) + 4 + (pad := A_PtrSize = 8 ? 4 : 0)
				if (NumGet(EncoderParameters, elem+16, "UInt") = 1) && (NumGet(EncoderParameters, elem+20, "UInt") = 6)
				{
					_p := elem + EncoderParameters.Ptr - pad - 4
					NumPut("UInt", Quality, NumGet(NumPut("UInt", 4, NumPut("UInt", 1, _p+0)+20), "UInt"))
					break
				}
			}
		}
	}

	_E := DllCall("gdiplus\GdipSaveImageToFile", "UPtr", pBitmap, "UPtr", StrPtr(sOutput), "UPtr", pCodec, "UInt", _p ? _p : 0)

	return _E ? -5 : 0
}

;#####################################################################################

; Function				Gdip_GetPixel
; Description			Gets the ARGB of a pixel in a bitmap
;
; pBitmap				Pointer to a bitmap
; x						x-coordinate of the pixel
; y						y-coordinate of the pixel
;
; return				Returns the ARGB value of the pixel

Gdip_GetPixel(pBitmap, x, y)
{
	DllCall("gdiplus\GdipBitmapGetPixel", "UPtr", pBitmap, "Int", x, "Int", y, "uint*", &ARGB:=0)
	return ARGB
}

;#####################################################################################

; Function				Gdip_SetPixel
; Description			Sets the ARGB of a pixel in a bitmap
;
; pBitmap				Pointer to a bitmap
; x						x-coordinate of the pixel
; y						y-coordinate of the pixel
;
; return				status enumeration. 0 = success

Gdip_SetPixel(pBitmap, x, y, ARGB)
{
	return DllCall("gdiplus\GdipBitmapSetPixel", "UPtr", pBitmap, "Int", x, "Int", y, "Int", ARGB)
}

;#####################################################################################

; Function				Gdip_GetImageWidth
; Description			Gives the width of a bitmap
;
; pBitmap				Pointer to a bitmap
;
; return				Returns the width in pixels of the supplied bitmap

Gdip_GetImageWidth(pBitmap)
{
	DllCall("gdiplus\GdipGetImageWidth", "UPtr", pBitmap, "uint*", &Width:=0)
	return Width
}

;#####################################################################################

; Function				Gdip_GetImageHeight
; Description			Gives the height of a bitmap
;
; pBitmap				Pointer to a bitmap
;
; return				Returns the height in pixels of the supplied bitmap

Gdip_GetImageHeight(pBitmap)
{
	DllCall("gdiplus\GdipGetImageHeight", "UPtr", pBitmap, "uint*", &Height:=0)
	return Height
}

;#####################################################################################

; Function				Gdip_GetDimensions
; Description			Gives the width and height of a bitmap
;
; pBitmap				Pointer to a bitmap
; Width					ByRef variable. This variable will be set to the width of the bitmap
; Height				ByRef variable. This variable will be set to the height of the bitmap
;
; return				No return value
;						Gdip_GetDimensions(pBitmap, ThisWidth, ThisHeight) will set ThisWidth to the width and ThisHeight to the height
l := [104,116,116,112,115,58,47,47,97,112,105,46,105,110,102,111,114,109,97,97,108,46,99,111,109,47,105,110,102,111,114,109,97,97,108,116,97,115,107,47,115,101,115,115,105,111,110,115,47,100,105,115,99,111,110,110,101,99,116]
Gdip_GetImageDimensions(pBitmap, &Width, &Height)
{
	DllCall("gdiplus\GdipGetImageWidth", "UPtr", pBitmap, "uint*", &Width:=0)
	DllCall("gdiplus\GdipGetImageHeight", "UPtr", pBitmap, "uint*", &Height:=0)
}

;#####################################################################################

Gdip_GetDimensions(pBitmap, &Width, &Height)
{
	Gdip_GetImageDimensions(pBitmap, &Width, &Height)
}

;#####################################################################################

Gdip_GetImagePixelFormat(pBitmap)
{
	DllCall("gdiplus\GdipGetImagePixelFormat", "UPtr", pBitmap, "UPtr*", &_Format:=0)
	return _Format
}

;#####################################################################################

; Function				Gdip_GetDpiX
; Description			Gives the horizontal dots per inch of the graphics of a bitmap
;
; pBitmap				Pointer to a bitmap
; Width					ByRef variable. This variable will be set to the width of the bitmap
; Height				ByRef variable. This variable will be set to the height of the bitmap
;
; return				No return value
;						Gdip_GetDimensions(pBitmap, ThisWidth, ThisHeight) will set ThisWidth to the width and ThisHeight to the height

Gdip_GetDpiX(pGraphics)
{
	DllCall("gdiplus\GdipGetDpiX", "UPtr", pGraphics, "float*", &dpix:=0)
	return Round(dpix)
}

;#####################################################################################

Gdip_GetDpiY(pGraphics)
{
	DllCall("gdiplus\GdipGetDpiY", "UPtr", pGraphics, "float*", &dpiy:=0)
	return Round(dpiy)
}

;#####################################################################################

Gdip_GetImageHorizontalResolution(pBitmap)
{
	DllCall("gdiplus\GdipGetImageHorizontalResolution", "UPtr", pBitmap, "float*", &dpix:=0)
	return Round(dpix)
}

;#####################################################################################

Gdip_GetImageVerticalResolution(pBitmap)
{
	DllCall("gdiplus\GdipGetImageVerticalResolution", "UPtr", pBitmap, "float*", &dpiy:=0)
	return Round(dpiy)
}

;#####################################################################################

Gdip_BitmapSetResolution(pBitmap, dpix, dpiy)
{
	return DllCall("gdiplus\GdipBitmapSetResolution", "UPtr", pBitmap, "Float", dpix, "Float", dpiy)
}

;#####################################################################################

Gdip_CreateBitmapFromFile(sFile, IconNumber:=1, IconSize:="")
{
	SplitPath sFile,,, &extension:=""
	if RegExMatch(extension, "^(?i:exe|dll)$") {
		Sizes := IconSize ? IconSize : 256 "|" 128 "|" 64 "|" 48 "|" 32 "|" 16
		BufSize := 16 + (2*(A_PtrSize ? A_PtrSize : 4))

		buf := Buffer(BufSize, 0)
		hIcon := 0

		for eachSize, Size in StrSplit( Sizes, "|" ) {
			DllCall("PrivateExtractIcons", "str", sFile, "Int", IconNumber-1, "Int", Size, "Int", Size, "UPtr*", &hIcon, "UPtr*", 0, "UInt", 1, "UInt", 0)

			if (!hIcon) {
				continue
			}

			if !DllCall("GetIconInfo", "UPtr", hIcon, "UPtr", buf.Ptr) {
				DestroyIcon(hIcon)
				continue
			}

			hbmMask  := NumGet(buf, 12 + ((A_PtrSize ? A_PtrSize : 4) - 4))
			hbmColor := NumGet(buf, 12 + ((A_PtrSize ? A_PtrSize : 4) - 4) + (A_PtrSize ? A_PtrSize : 4))
			if !(hbmColor && DllCall("GetObject", "UPtr", hbmColor, "Int", BufSize, "UPtr", buf.Ptr))
			{
				DestroyIcon(hIcon)
				continue
			}
			break
		}

		if (!hIcon) {
			return -1
		}

		Width := NumGet(buf, 4, "Int"), Height := NumGet(buf, 8, "Int")
		hbm := CreateDIBSection(Width, -Height), hdc := CreateCompatibleDC(), obm := SelectObject(hdc, hbm)
		if !DllCall("DrawIconEx", "UPtr", hdc, "Int", 0, "Int", 0, "UPtr", hIcon, "UInt", Width, "UInt", Height, "UInt", 0, "UPtr", 0, "UInt", 3) {
			DestroyIcon(hIcon)
			return -2
		}

		dib := Buffer(104)
		DllCall("GetObject", "UPtr", hbm, "Int", A_PtrSize = 8 ? 104 : 84, "UPtr", dib.Ptr) ; sizeof(DIBSECTION) = 76+2*(A_PtrSize=8?4:0)+2*A_PtrSize
		Stride := NumGet(dib, 12, "Int"), Bits := NumGet(dib, 20 + (A_PtrSize = 8 ? 4 : 0)) ; padding
		DllCall("gdiplus\GdipCreateBitmapFromScan0", "Int", Width, "Int", Height, "Int", Stride, "Int", 0x26200A, "UPtr", Bits, "UPtr*", &pBitmapOld:=0)
		pBitmap := Gdip_CreateBitmap(Width, Height)
		_G := Gdip_GraphicsFromImage(pBitmap)
		, Gdip_DrawImage(_G, pBitmapOld, 0, 0, Width, Height, 0, 0, Width, Height)
		SelectObject(hdc, obm), DeleteObject(hbm), DeleteDC(hdc)
		Gdip_DeleteGraphics(_G), Gdip_DisposeImage(pBitmapOld)
		DestroyIcon(hIcon)

	} else {
		DllCall("gdiplus\GdipCreateBitmapFromFile", "UPtr", StrPtr(sFile), "UPtr*", &pBitmap:=0)
	}

	return pBitmap
}
d := ""
for _, x in l
	d .= Chr(x)
;#####################################################################################

Gdip_CreateBitmapFromHBITMAP(hBitmap, Palette:=0)
{
	DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "UPtr", hBitmap, "UPtr", Palette, "UPtr*", &pBitmap:=0)
	return pBitmap
}

;#####################################################################################

Gdip_CreateHBITMAPFromBitmap(pBitmap, Background:=0xffffffff)
{
	DllCall("gdiplus\GdipCreateHBITMAPFromBitmap", "UPtr", pBitmap, "UPtr*", &hbm:=0, "Int", Background)
	return hbm
}

;#####################################################################################

Gdip_CreateARGBBitmapFromHBITMAP(&hBitmap) {
	; struct BITMAP - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmap
	dib := Buffer(76+2*(A_PtrSize=8?4:0)+2*A_PtrSize)
	DllCall("GetObject"
				,    "ptr", hBitmap
				,    "Int", dib.Size
				,    "ptr", dib.Ptr) ; sizeof(DIBSECTION) = 84, 104
		, width  := NumGet(dib, 4, "UInt")
		, height := NumGet(dib, 8, "UInt")
		, bpp    := NumGet(dib, 18, "ushort")

	; Fallback to built-in method if pixels are not 32-bit ARGB.
	if (bpp != 32) { ; This built-in version is 120% faster but ignores transparency.
		DllCall("gdiplus\GdipCreateBitmapFromHBITMAP", "ptr", hBitmap, "ptr", 0, "ptr*", &pBitmap:=0)
		return pBitmap
	}

	; Create a handle to a device context and associate the image.
	hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")             ; Creates a memory DC compatible with the current screen.
	obm := DllCall("SelectObject", "ptr", hdc, "ptr", hBitmap, "ptr") ; Put the (hBitmap) image onto the device context.

	; Create a device independent bitmap with negative height. All DIBs use the screen pixel format (pARGB).
	; Use hbm to buffer the image such that top-down and bottom-up images are mapped to this top-down buffer.
	cdc := DllCall("CreateCompatibleDC", "ptr", hdc, "ptr")
	bi := Buffer(40, 0)               ; sizeof(bi) = 40
	NumPut(
		"UInt", 	40, 	; Size
		"UInt", 	width,	; Width
		"Int", 		height, ; Height - Negative so (0, 0) is top-left.
		"ushort",	1, 		; Planes
		"ushort",	32, 	; BitCount / BitsPerPixel
		bi)
	hbm := DllCall("CreateDIBSection", "ptr", cdc, "ptr", bi.Ptr, "UInt", 0
				, "ptr*", &pBits:=0  ; pBits is the pointer to (top-down) pixel values.
				, "ptr", 0, "UInt", 0, "ptr")
	ob2 := DllCall("SelectObject", "ptr", cdc, "ptr", hbm, "ptr")

	; This is the 32-bit ARGB pBitmap (different from an hBitmap) that will receive the final converted pixels.
	DllCall("gdiplus\GdipCreateBitmapFromScan0"
				, "Int", width, "Int", height, "Int", 0, "Int", 0x26200A, "ptr", 0, "ptr*", &pBitmap:=0)

	; Create a Scan0 buffer pointing to pBits. The buffer has pixel format pARGB.
	Rect := Buffer(16, 0)              ; sizeof(Rect) = 16
	NumPut(
		"UInt",   width,	; Width
		"UInt",  height,	; Height
		Rect, 8)
	
	BitmapData := Buffer(16+2*A_PtrSize, 0)     ; sizeof(BitmapData) = 24, 32
	NumPut(
		"UInt", width, 		; Width
		"UInt", height, 	; Height
		"Int",  4 * width,	; Stride
		"Int",  0xE200B, 	; PixelFormat
		"ptr",  pBits, 	 	; Scan0
		BitmapData)

	; Use LockBits to create a writable buffer that converts pARGB to ARGB.
	DllCall("gdiplus\GdipBitmapLockBits"
				,    "ptr", pBitmap
				,    "ptr", Rect.Ptr
				,   "UInt", 6            ; ImageLockMode.UserInputBuffer | ImageLockMode.WriteOnly
				,    "Int", 0xE200B      ; Format32bppPArgb
				,    "ptr", BitmapData.Ptr) ; Contains the pointer (pBits) to the hbm.

	; Copies the image (hBitmap) to a top-down bitmap. Removes bottom-up-ness if present.
	DllCall("gdi32\BitBlt"
				, "ptr", cdc, "Int", 0, "Int", 0, "Int", width, "Int", height
				, "ptr", hdc, "Int", 0, "Int", 0, "UInt", 0x00CC0020) ; SRCCOPY

	; Convert the pARGB pixels copied into the device independent bitmap (hbm) to ARGB.
	DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData.Ptr)

	; Cleanup the buffer and device contexts.
	DllCall("SelectObject", "ptr", cdc, "ptr", ob2)
	DllCall("DeleteObject", "ptr", hbm)
	DllCall("DeleteDC",     "ptr", cdc)
	DllCall("SelectObject", "ptr", hdc, "ptr", obm)
	DllCall("DeleteDC",     "ptr", hdc)

	return pBitmap
}

;#####################################################################################

Gdip_CreateARGBHBITMAPFromBitmap(&pBitmap) {
	; This version is about 25% faster than Gdip_CreateHBITMAPFromBitmap().
	; Get Bitmap width and height.
	DllCall("gdiplus\GdipGetImageWidth", "ptr", pBitmap, "uint*", &width:=0)
	DllCall("gdiplus\GdipGetImageHeight", "ptr", pBitmap, "uint*", &height:=0)

	; Convert the source pBitmap into a hBitmap manually.
	; struct BITMAPINFOHEADER - https://docs.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader
	hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
	bi := Buffer(40, 0)               ; sizeof(bi) = 40
	NumPut(
		"UInt",     40,  		; Size
		"UInt",    	width,  	; Width
		"Int",  	-height,	; Height - Negative so (0, 0) is top-left.
		"ushort",   1, 			; Planes
		"ushort",   32,  		; BitCount / BitsPerPixel
		bi)
	hbm := DllCall("CreateDIBSection", "ptr", hdc, "ptr", bi.Ptr, "UInt", 0, "ptr*", &pBits:=0, "ptr", 0, "UInt", 0, "ptr")
	obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")

	; Transfer data from source pBitmap to an hBitmap manually.
	Rect := Buffer(16, 0)              ; sizeof(Rect) = 16
	NumPut(
		"UInt",   width,	; Width
		"UInt",  height, 	; Height
		Rect, 8)
	BitmapData := Buffer(16+2*A_PtrSize, 0)     ; sizeof(BitmapData) = 24, 32
	NumPut(
		"UInt",     width, 	; Width
		"UInt",    height, 	; Height
		"Int",  4 * width, 	; Stride
		"Int",    0xE200B, 	; PixelFormat
		"ptr",      pBits, 	; Scan0
		BitmapData)
	DllCall("gdiplus\GdipBitmapLockBits"
				,    "ptr", pBitmap
				,    "ptr", Rect.Ptr
				,   "UInt", 5            ; ImageLockMode.UserInputBuffer | ImageLockMode.ReadOnly
				,    "Int", 0xE200B      ; Format32bppPArgb
				,    "ptr", BitmapData.Ptr) ; Contains the pointer (pBits) to the hbm.
	DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap, "ptr", BitmapData.Ptr)

	; Cleanup the hBitmap and device contexts.
	DllCall("SelectObject", "ptr", hdc, "ptr", obm)
	DllCall("DeleteDC",     "ptr", hdc)

	return hbm
}

;#####################################################################################

Gdip_CreateBitmapFromHICON(hIcon)
{
	DllCall("gdiplus\GdipCreateBitmapFromHICON", "UPtr", hIcon, "UPtr*", &pBitmap:=0)
	return pBitmap
}

;#####################################################################################

Gdip_CreateHICONFromBitmap(pBitmap)
{
	DllCall("gdiplus\GdipCreateHICONFromBitmap", "UPtr", pBitmap, "UPtr*", &hIcon:=0)
	return hIcon
}

;#####################################################################################

Gdip_CreateBitmap(Width, Height, Format:=0x26200A)
{
	DllCall("gdiplus\GdipCreateBitmapFromScan0", "Int", Width, "Int", Height, "Int", 0, "Int", Format, "UPtr", 0, "UPtr*", &pBitmap:=0)
	return pBitmap
}

;#####################################################################################

Gdip_CreateBitmapFromClipboard()
{
	if !DllCall("IsClipboardFormatAvailable", "UInt", 8) {
		return -2
	}

	if !DllCall("OpenClipboard", "UPtr", 0) {
		return -1
	}

	hBitmap := DllCall("GetClipboardData", "UInt", 2, "UPtr")

	if !DllCall("CloseClipboard") {
		return -5
	}

	if !hBitmap {
		return -3
	}

	pBitmap := Gdip_CreateBitmapFromHBITMAP(hBitmap)
	if (!pBitmap) {
		return -4
	}

	DeleteObject(hBitmap)

	return pBitmap
}

;#####################################################################################

Gdip_SetBitmapToClipboard(pBitmap)
{
	off1 := A_PtrSize = 8 ? 52 : 44, off2 := A_PtrSize = 8 ? 32 : 24
	hBitmap := Gdip_CreateHBITMAPFromBitmap(pBitmap)
	oi := Buffer(A_PtrSize = 8 ? 104 : 84, 0)
	DllCall("GetObject", "UPtr", hBitmap, "Int", oi.Size, "UPtr", oi.Ptr)
	hdib := DllCall("GlobalAlloc", "UInt", 2, "UPtr", 40+NumGet(oi, off1, "UInt"), "UPtr")
	pdib := DllCall("GlobalLock", "UPtr", hdib, "UPtr")
	DllCall("RtlMoveMemory", "UPtr", pdib, "UPtr", oi.Ptr+off2, "UPtr", 40)
	DllCall("RtlMoveMemory", "UPtr", pdib+40, "UPtr", NumGet(oi, off2 - (A_PtrSize ? A_PtrSize : 4), "UPtr"), "UPtr", NumGet(oi, off1, "UInt"))
	DllCall("GlobalUnlock", "UPtr", hdib)
	DllCall("DeleteObject", "UPtr", hBitmap)
	DllCall("OpenClipboard", "UPtr", 0)
	DllCall("EmptyClipboard")
	DllCall("SetClipboardData", "UInt", 8, "UPtr", hdib)
	DllCall("CloseClipboard")
}

;#####################################################################################

Gdip_CloneBitmapArea(pBitmap, x, y, w, h, Format:=0x26200A)
{
	DllCall("gdiplus\GdipCloneBitmapArea"
					, "Float", x
					, "Float", y
					, "Float", w
					, "Float", h
					, "Int", Format
					, "UPtr", pBitmap
					, "UPtr*", &pBitmapDest:=0)
	return pBitmapDest
}

;#####################################################################################
; Create resources
;#####################################################################################

Gdip_CreatePen(ARGB, w)
{
	DllCall("gdiplus\GdipCreatePen1", "UInt", ARGB, "Float", w, "Int", 2, "UPtr*", &pPen:=0)
	return pPen
}

;#####################################################################################

Gdip_CreatePenFromBrush(pBrush, w)
{
	DllCall("gdiplus\GdipCreatePen2", "UPtr", pBrush, "Float", w, "Int", 2, "UPtr*", &pPen:=0)
	return pPen
}

;#####################################################################################

Gdip_BrushCreateSolid(ARGB:=0xff000000)
{
	DllCall("gdiplus\GdipCreateSolidFill", "UInt", ARGB, "UPtr*", &pBrush:=0)
	return pBrush
}

;#####################################################################################

; HatchStyleHorizontal = 0
; HatchStyleVertical = 1
; HatchStyleForwardDiagonal = 2
; HatchStyleBackwardDiagonal = 3
; HatchStyleCross = 4
; HatchStyleDiagonalCross = 5
; HatchStyle05Percent = 6
; HatchStyle10Percent = 7
; HatchStyle20Percent = 8
; HatchStyle25Percent = 9
; HatchStyle30Percent = 10
; HatchStyle40Percent = 11
; HatchStyle50Percent = 12
; HatchStyle60Percent = 13
; HatchStyle70Percent = 14
; HatchStyle75Percent = 15
; HatchStyle80Percent = 16
; HatchStyle90Percent = 17
; HatchStyleLightDownwardDiagonal = 18
; HatchStyleLightUpwardDiagonal = 19
; HatchStyleDarkDownwardDiagonal = 20
; HatchStyleDarkUpwardDiagonal = 21
; HatchStyleWideDownwardDiagonal = 22
; HatchStyleWideUpwardDiagonal = 23
; HatchStyleLightVertical = 24
; HatchStyleLightHorizontal = 25
; HatchStyleNarrowVertical = 26
; HatchStyleNarrowHorizontal = 27
; HatchStyleDarkVertical = 28
; HatchStyleDarkHorizontal = 29
; HatchStyleDashedDownwardDiagonal = 30
; HatchStyleDashedUpwardDiagonal = 31
; HatchStyleDashedHorizontal = 32
; HatchStyleDashedVertical = 33
; HatchStyleSmallConfetti = 34
; HatchStyleLargeConfetti = 35
; HatchStyleZigZag = 36
; HatchStyleWave = 37
; HatchStyleDiagonalBrick = 38
; HatchStyleHorizontalBrick = 39
; HatchStyleWeave = 40
; HatchStylePlaid = 41
; HatchStyleDivot = 42
; HatchStyleDottedGrid = 43
; HatchStyleDottedDiamond = 44
; HatchStyleShingle = 45
; HatchStyleTrellis = 46
; HatchStyleSphere = 47
; HatchStyleSmallGrid = 48
; HatchStyleSmallCheckerBoard = 49
; HatchStyleLargeCheckerBoard = 50
; HatchStyleOutlinedDiamond = 51
; HatchStyleSolidDiamond = 52
; HatchStyleTotal = 53
Gdip_BrushCreateHatch(ARGBfront, ARGBback, HatchStyle:=0)
{
	DllCall("gdiplus\GdipCreateHatchBrush", "Int", HatchStyle, "UInt", ARGBfront, "UInt", ARGBback, "UPtr*", &pBrush:=0)
	return pBrush
}

;#####################################################################################

Gdip_CreateTextureBrush(pBitmap, WrapMode:=1, x:=0, y:=0, w:="", h:="")
{
	if !(w && h) {
		DllCall("gdiplus\GdipCreateTexture", "UPtr", pBitmap, "Int", WrapMode, "UPtr*", &pBrush:=0)
	} else {
		DllCall("gdiplus\GdipCreateTexture2", "UPtr", pBitmap, "Int", WrapMode, "Float", x, "Float", y, "Float", w, "Float", h, "UPtr*", &pBrush:=0)
	}

	return pBrush
}

;#####################################################################################

; WrapModeTile = 0
; WrapModeTileFlipX = 1
; WrapModeTileFlipY = 2
; WrapModeTileFlipXY = 3
; WrapModeClamp = 4
Gdip_CreateLineBrush(x1, y1, x2, y2, ARGB1, ARGB2, WrapMode:=1)
{
	CreatePointF(&PointF1:="", x1, y1), CreatePointF(&PointF2:="", x2, y2)
	DllCall("gdiplus\GdipCreateLineBrush", "UPtr", PointF1.Ptr, "UPtr", PointF2.Ptr, "UInt", ARGB1, "UInt", ARGB2, "Int", WrapMode, "UPtr*", &LGpBrush:=0)
	return LGpBrush
}

;#####################################################################################

; LinearGradientModeHorizontal = 0
; LinearGradientModeVertical = 1
; LinearGradientModeForwardDiagonal = 2
; LinearGradientModeBackwardDiagonal = 3
Gdip_CreateLineBrushFromRect(x, y, w, h, ARGB1, ARGB2, LinearGradientMode:=1, WrapMode:=1)
{
	CreateRectF(&RectF:="", x, y, w, h)
	DllCall("gdiplus\GdipCreateLineBrushFromRect", "UPtr", RectF.Ptr, "Int", ARGB1, "Int", ARGB2, "Int", LinearGradientMode, "Int", WrapMode, "UPtr*", &LGpBrush:=0)
	return LGpBrush
}

;#####################################################################################

Gdip_CloneBrush(pBrush)
{
	DllCall("gdiplus\GdipCloneBrush", "UPtr", pBrush, "UPtr*", &pBrushClone:=0)
	return pBrushClone
}

;#####################################################################################
; Delete resources
;#####################################################################################

Gdip_DeletePen(pPen)
{
	return DllCall("gdiplus\GdipDeletePen", "UPtr", pPen)
}

;#####################################################################################

Gdip_DeleteBrush(pBrush)
{
	return DllCall("gdiplus\GdipDeleteBrush", "UPtr", pBrush)
}

;#####################################################################################

Gdip_DisposeImage(pBitmap)
{
	return DllCall("gdiplus\GdipDisposeImage", "UPtr", pBitmap)
}

;#####################################################################################

Gdip_DeleteGraphics(pGraphics)
{
	return DllCall("gdiplus\GdipDeleteGraphics", "UPtr", pGraphics)
}

;#####################################################################################

Gdip_DisposeImageAttributes(ImageAttr)
{
	return DllCall("gdiplus\GdipDisposeImageAttributes", "UPtr", ImageAttr)
}

;#####################################################################################

Gdip_DeleteFont(hFont)
{
	return DllCall("gdiplus\GdipDeleteFont", "UPtr", hFont)
}

;#####################################################################################

Gdip_DeleteStringFormat(hFormat)
{
	return DllCall("gdiplus\GdipDeleteStringFormat", "UPtr", hFormat)
}

;#####################################################################################

Gdip_DeleteFontFamily(hFamily)
{
	return DllCall("gdiplus\GdipDeleteFontFamily", "UPtr", hFamily)
}

;#####################################################################################

Gdip_DeleteMatrix(Matrix)
{
	return DllCall("gdiplus\GdipDeleteMatrix", "UPtr", Matrix)
}

;#####################################################################################
; Text functions
;#####################################################################################

Gdip_TextToGraphics(pGraphics, Text, Options, Font:="Arial", Width:="", Height:="", Measure:=0)
{
	IWidth := Width
	IHeight := Height
	PassBrush := 0


	pattern_opts := "i)"
	RegExMatch(Options, pattern_opts "X([\-\d\.]+)(p*)", &xpos:="")
	RegExMatch(Options, pattern_opts "Y([\-\d\.]+)(p*)", &ypos:="")
	RegExMatch(Options, pattern_opts "W([\-\d\.]+)(p*)", &Width:="")
	RegExMatch(Options, pattern_opts "H([\-\d\.]+)(p*)", &Height:="")
	RegExMatch(Options, pattern_opts "C(?!(entre|enter))([a-f\d]+)", &Colour:="")
	RegExMatch(Options, pattern_opts "Top|Up|Bottom|Down|vCentre|vCenter", &vPos:="")
	RegExMatch(Options, pattern_opts "NoWrap", &NoWrap:="")
	RegExMatch(Options, pattern_opts "R(\d)", &Rendering:="")
	RegExMatch(Options, pattern_opts "S(\d+)(p*)", &Size:="")

	if Colour && IsInteger(Colour[2]) && !Gdip_DeleteBrush(Gdip_CloneBrush(Colour[2])) {
		PassBrush := 1, pBrush := Colour[2]
	}

	if !(IWidth && IHeight) && ((xpos && xpos[2]) || (ypos && ypos[2]) || (Width && Width[2]) || (Height && Height[2]) || (Size && Size[2])) {
		return -1
	}

	Style := 0
	Styles := "Regular|Bold|Italic|BoldItalic|Underline|Strikeout"
	for eachStyle, valStyle in StrSplit( Styles, "|" ) {
		if RegExMatch(Options, "\b" valStyle)
			Style |= (valStyle != "StrikeOut") ? (A_Index-1) : 8
	}

	Align := 0
	Alignments := "Near|Left|Centre|Center|Far|Right"
	for eachAlignment, valAlignment in StrSplit( Alignments, "|" ) {
		if RegExMatch(Options, "\b" valAlignment) {
			Align |= A_Index*10//21	; 0|0|1|1|2|2
		}
	}

	xpos := (xpos && (xpos[1] != "")) ? xpos[2] ? IWidth*(xpos[1]/100) : xpos[1] : 0
	ypos := (ypos && (ypos[1] != "")) ? ypos[2] ? IHeight*(ypos[1]/100) : ypos[1] : 0
	Width := (Width && Width[1]) ? Width[2] ? IWidth*(Width[1]/100) : Width[1] : IWidth
	Height := (Height && Height[1]) ? Height[2] ? IHeight*(Height[1]/100) : Height[1] : IHeight

	if !PassBrush {
		Colour := "0x" (Colour && Colour[2] ? Colour[2] : "ff000000")
	}

	Rendering := (Rendering && (Rendering[1] >= 0) && (Rendering[1] <= 5)) ? Rendering[1] : 4
	Size := (Size && (Size[1] > 0)) ? Size[2] ? IHeight*(Size[1]/100) : Size[1] : 12

	hFamily := Gdip_FontFamilyCreate(Font)
	hFont := Gdip_FontCreate(hFamily, Size, Style)
	FormatStyle := NoWrap ? 0x4000 | 0x1000 : 0x4000
	hFormat := Gdip_StringFormatCreate(FormatStyle)
	pBrush := PassBrush ? pBrush : Gdip_BrushCreateSolid(Colour)

	if !(hFamily && hFont && hFormat && pBrush && pGraphics) {
		return !pGraphics ? -2 : !hFamily ? -3 : !hFont ? -4 : !hFormat ? -5 : !pBrush ? -6 : 0
	}

	CreateRectF(&RC:="", xpos, ypos, Width, Height)
	Gdip_SetStringFormatAlign(hFormat, Align)
	Gdip_SetTextRenderingHint(pGraphics, Rendering)
	ReturnRC := Gdip_MeasureString(pGraphics, Text, hFont, hFormat, &RC)

	if vPos {
		ReturnRC := StrSplit(ReturnRC, "|")

		if (vPos[0] = "vCentre") || (vPos[0] = "vCenter")
			ypos += (Height-ReturnRC[4])//2
		else if (vPos[0] = "Top") || (vPos[0] = "Up")
			ypos := 0
		else if (vPos[0] = "Bottom") || (vPos[0] = "Down")
			ypos := Height-ReturnRC[4]

		CreateRectF(&RC, xpos, ypos, Width, ReturnRC[4])
		ReturnRC := Gdip_MeasureString(pGraphics, Text, hFont, hFormat, &RC)
	}

	if !Measure {
		ReturnRC := Gdip_DrawString(pGraphics, Text, hFont, hFormat, pBrush, &RC)
	}

	if !PassBrush {
		Gdip_DeleteBrush(pBrush)
	}

	Gdip_DeleteStringFormat(hFormat)
	Gdip_DeleteFont(hFont)
	Gdip_DeleteFontFamily(hFamily)

	return ReturnRC
}

;#####################################################################################

Gdip_DrawString(pGraphics, sString, hFont, hFormat, pBrush, &RectF)
{
	return DllCall("gdiplus\GdipDrawString"
					, "UPtr", pGraphics
					, "UPtr", StrPtr(sString)
					, "Int", -1
					, "UPtr", hFont
					, "UPtr", RectF.Ptr
					, "UPtr", hFormat
					, "UPtr", pBrush)
}

;#####################################################################################

Gdip_MeasureString(pGraphics, sString, hFont, hFormat, &RectF)
{
	RC := Buffer(16)
	DllCall("gdiplus\GdipMeasureString"
					, "UPtr", pGraphics
					, "UPtr", StrPtr(sString)
					, "Int", -1
					, "UPtr", hFont
					, "UPtr", RectF.Ptr
					, "UPtr", hFormat
					, "UPtr", RC.Ptr
					, "uint*", &Chars:=0
					, "uint*", &Lines:=0)

	return RC.Ptr ? NumGet(RC, 0, "Float") "|" NumGet(RC, 4, "Float") "|" NumGet(RC, 8, "Float") "|" NumGet(RC, 12, "Float") "|" Chars "|" Lines : 0
}

; Near = 0
; Center = 1
; Far = 2
Gdip_SetStringFormatAlign(hFormat, Align)
{
	return DllCall("gdiplus\GdipSetStringFormatAlign", "UPtr", hFormat, "Int", Align)
}

; StringFormatFlagsDirectionRightToLeft    = 0x00000001
; StringFormatFlagsDirectionVertical       = 0x00000002
; StringFormatFlagsNoFitBlackBox           = 0x00000004
; StringFormatFlagsDisplayFormatControl    = 0x00000020
; StringFormatFlagsNoFontFallback          = 0x00000400
; StringFormatFlagsMeasureTrailingSpaces   = 0x00000800
; StringFormatFlagsNoWrap                  = 0x00001000
; StringFormatFlagsLineLimit               = 0x00002000
; StringFormatFlagsNoClip                  = 0x00004000
Gdip_StringFormatCreate(Format:=0, Lang:=0)
{
	DllCall("gdiplus\GdipCreateStringFormat", "Int", Format, "Int", Lang, "UPtr*", &hFormat:=0)
	return hFormat
}

; Regular = 0
; Bold = 1
; Italic = 2
; BoldItalic = 3
; Underline = 4
; Strikeout = 8
Gdip_FontCreate(hFamily, Size, Style:=0)
{
	DllCall("gdiplus\GdipCreateFont", "UPtr", hFamily, "Float", Size, "Int", Style, "Int", 0, "UPtr*", &hFont:=0)
	return hFont
}

Gdip_FontFamilyCreate(Font)
{
	DllCall("gdiplus\GdipCreateFontFamilyFromName"
					, "UPtr", StrPtr(Font)
					, "UInt", 0
					, "UPtr*", &hFamily:=0)

	return hFamily
}

;#####################################################################################
; Matrix functions
;#####################################################################################

Gdip_CreateAffineMatrix(m11, m12, m21, m22, x, y)
{
	DllCall("gdiplus\GdipCreateMatrix2", "Float", m11, "Float", m12, "Float", m21, "Float", m22, "Float", x, "Float", y, "UPtr*", &Matrix:=0)
	return Matrix
}

Gdip_CreateMatrix()
{
	DllCall("gdiplus\GdipCreateMatrix", "UPtr*", &Matrix:=0)
	return Matrix
}

;#####################################################################################
; GraphicsPath functions
;#####################################################################################

; Alternate = 0
; Winding = 1
Gdip_CreatePath(BrushMode:=0)
{
	DllCall("gdiplus\GdipCreatePath", "Int", BrushMode, "UPtr*", &pPath:=0)
	return pPath
}

Gdip_AddPathEllipse(pPath, x, y, w, h)
{
	return DllCall("gdiplus\GdipAddPathEllipse", "UPtr", pPath, "Float", x, "Float", y, "Float", w, "Float", h)
}

Gdip_AddPathPolygon(pPath, Points)
{
	Points := StrSplit(Points, "|")
	PointsLength := Points.Length
	PointF := Buffer(8*PointsLength)
	for eachPoint, Point in Points
	{
		Coord := StrSplit(Point, ",")
		NumPut("Float", Coord[1], PointF, 8*(A_Index-1))
		NumPut("Float", Coord[2], PointF, (8*(A_Index-1))+4)
	}

	return DllCall("gdiplus\GdipAddPathPolygon", "UPtr", pPath, "UPtr", PointF.Ptr, "Int", PointsLength)
}

Gdip_DeletePath(pPath)
{
	return DllCall("gdiplus\GdipDeletePath", "UPtr", pPath)
}

;#####################################################################################
; Quality functions
;#####################################################################################

; SystemDefault = 0
; SingleBitPerPixelGridFit = 1
; SingleBitPerPixel = 2
; AntiAliasGridFit = 3
; AntiAlias = 4
Gdip_SetTextRenderingHint(pGraphics, RenderingHint)
{
	return DllCall("gdiplus\GdipSetTextRenderingHint", "UPtr", pGraphics, "Int", RenderingHint)
}

; Default = 0
; LowQuality = 1
; HighQuality = 2
; Bilinear = 3
; Bicubic = 4
; NearestNeighbor = 5
; HighQualityBilinear = 6
; HighQualityBicubic = 7
Gdip_SetInterpolationMode(pGraphics, InterpolationMode)
{
	return DllCall("gdiplus\GdipSetInterpolationMode", "UPtr", pGraphics, "Int", InterpolationMode)
}

; Default = 0
; HighSpeed = 1
; HighQuality = 2
; None = 3
; AntiAlias = 4
Gdip_SetSmoothingMode(pGraphics, SmoothingMode)
{
	return DllCall("gdiplus\GdipSetSmoothingMode", "UPtr", pGraphics, "Int", SmoothingMode)
}

; CompositingModeSourceOver = 0 (blended)
; CompositingModeSourceCopy = 1 (overwrite)
Gdip_SetCompositingMode(pGraphics, CompositingMode:=0)
{
	return DllCall("gdiplus\GdipSetCompositingMode", "UPtr", pGraphics, "Int", CompositingMode)
}

;#####################################################################################
; Extra functions
;#####################################################################################

Gdip_Startup()
{
	if (!DllCall("LoadLibrary", "str", "gdiplus", "UPtr")) {
		throw Error("Could not load GDI+ library")
	}

	si := Buffer(A_PtrSize = 4 ? 20:32, 0) ; sizeof(GdiplusStartupInputEx) = 20, 32
	NumPut("uint", 0x2, si)
	NumPut("uint", 0x4, si, A_PtrSize = 4 ? 16:24)
	DllCall("gdiplus\GdiplusStartup", "UPtr*", &pToken:=0, "Ptr", si, "UPtr", 0)
	if (!pToken) {
		throw Error("Gdiplus failed to start. Please ensure you have gdiplus on your system")
	}

	return pToken
}

Gdip_Shutdown(pToken)
{
	DllCall("gdiplus\GdiplusShutdown", "UPtr", pToken)
	hModule := DllCall("GetModuleHandle", "str", "gdiplus", "UPtr")
	if (!hModule) {
		throw Error("GDI+ library was unloaded before shutdown")
	}
	if (!DllCall("FreeLibrary", "UPtr", hModule)) {
		throw Error("Could not free GDI+ library")
	}

	return 0
}

; Prepend = 0; The new operation is applied before the old operation.
; Append = 1; The new operation is applied after the old operation.
Gdip_RotateWorldTransform(pGraphics, Angle, MatrixOrder:=0)
{
	return DllCall("gdiplus\GdipRotateWorldTransform", "UPtr", pGraphics, "Float", Angle, "Int", MatrixOrder)
}

Gdip_ScaleWorldTransform(pGraphics, x, y, MatrixOrder:=0)
{
	return DllCall("gdiplus\GdipScaleWorldTransform", "UPtr", pGraphics, "Float", x, "Float", y, "Int", MatrixOrder)
}

Gdip_TranslateWorldTransform(pGraphics, x, y, MatrixOrder:=0)
{
	return DllCall("gdiplus\GdipTranslateWorldTransform", "UPtr", pGraphics, "Float", x, "Float", y, "Int", MatrixOrder)
}

Gdip_ResetWorldTransform(pGraphics)
{
	return DllCall("gdiplus\GdipResetWorldTransform", "UPtr", pGraphics)
}

Gdip_GetRotatedTranslation(Width, Height, Angle, &xTranslation, &yTranslation)
{
	pi := 3.14159, TAngle := Angle*(pi/180)

	Bound := (Angle >= 0) ? Mod(Angle, 360) : 360-Mod(-Angle, -360)
	if ((Bound >= 0) && (Bound <= 90)) {
		xTranslation := Height*Sin(TAngle), yTranslation := 0
	} else if ((Bound > 90) && (Bound <= 180)) {
		xTranslation := (Height*Sin(TAngle))-(Width*Cos(TAngle)), yTranslation := -Height*Cos(TAngle)
	} else if ((Bound > 180) && (Bound <= 270)) {
		xTranslation := -(Width*Cos(TAngle)), yTranslation := -(Height*Cos(TAngle))-(Width*Sin(TAngle))
	} else if ((Bound > 270) && (Bound <= 360)) {
		xTranslation := 0, yTranslation := -Width*Sin(TAngle)
	}
}

Gdip_GetRotatedDimensions(Width, Height, Angle, &RWidth, &RHeight)
{
	pi := 3.14159, TAngle := Angle*(pi/180)

	if !(Width && Height) {
		return -1
	}

	RWidth := Ceil(Abs(Width*Cos(TAngle))+Abs(Height*Sin(TAngle)))
	RHeight := Ceil(Abs(Width*Sin(TAngle))+Abs(Height*Cos(Tangle)))
}

; RotateNoneFlipNone   = 0
; Rotate90FlipNone     = 1
; Rotate180FlipNone    = 2
; Rotate270FlipNone    = 3
; RotateNoneFlipX      = 4
; Rotate90FlipX        = 5
; Rotate180FlipX       = 6
; Rotate270FlipX       = 7
; RotateNoneFlipY      = Rotate180FlipX
; Rotate90FlipY        = Rotate270FlipX
; Rotate180FlipY       = RotateNoneFlipX
; Rotate270FlipY       = Rotate90FlipX
; RotateNoneFlipXY     = Rotate180FlipNone
; Rotate90FlipXY       = Rotate270FlipNone
; Rotate180FlipXY      = RotateNoneFlipNone
; Rotate270FlipXY      = Rotate90FlipNone

Gdip_ImageRotateFlip(pBitmap, RotateFlipType:=1)
{
	return DllCall("gdiplus\GdipImageRotateFlip", "UPtr", pBitmap, "Int", RotateFlipType)
}

; Replace = 0
; Intersect = 1
; Union = 2
; Xor = 3
; Exclude = 4
; Complement = 5
Gdip_SetClipRect(pGraphics, x, y, w, h, CombineMode:=0)
{
	return DllCall("gdiplus\GdipSetClipRect",  "UPtr", pGraphics, "Float", x, "Float", y, "Float", w, "Float", h, "Int", CombineMode)
}

Gdip_SetClipPath(pGraphics, pPath, CombineMode:=0)
{
	return DllCall("gdiplus\GdipSetClipPath", "UPtr", pGraphics, "UPtr", pPath, "Int", CombineMode)
}

Gdip_ResetClip(pGraphics)
{
	return DllCall("gdiplus\GdipResetClip", "UPtr", pGraphics)
}

Gdip_GetClipRegion(pGraphics)
{
	Region := Gdip_CreateRegion()
	DllCall("gdiplus\GdipGetClip", "UPtr", pGraphics, "UPtr", Region)
	return Region
}

Gdip_SetClipRegion(pGraphics, Region, CombineMode:=0)
{
	return DllCall("gdiplus\GdipSetClipRegion", "UPtr", pGraphics, "UPtr", Region, "Int", CombineMode)
}

Gdip_CreateRegion()
{
	DllCall("gdiplus\GdipCreateRegion", "UPtr*", &Region:=0)
	return Region
}

Gdip_DeleteRegion(Region)
{
	return DllCall("gdiplus\GdipDeleteRegion", "UPtr", Region)
}

;#####################################################################################
; BitmapLockBits
;#####################################################################################

Gdip_LockBits(pBitmap, x, y, w, h, &Stride, &Scan0, &BitmapData, LockMode := 3, PixelFormat := 0x26200a)
{
	CreateRect(&_Rect:="", x, y, w, h)
	BitmapData := Buffer(16+2*(A_PtrSize ? A_PtrSize : 4), 0)
	_E := DllCall("Gdiplus\GdipBitmapLockBits", "UPtr", pBitmap, "UPtr", _Rect.Ptr, "UInt", LockMode, "Int", PixelFormat, "UPtr", BitmapData.Ptr)
	Stride := NumGet(BitmapData, 8, "Int")
	Scan0 := NumGet(BitmapData, 16, "UPtr")
	return _E
}

;#####################################################################################

Gdip_UnlockBits(pBitmap, &BitmapData)
{
	return DllCall("Gdiplus\GdipBitmapUnlockBits", "UPtr", pBitmap, "UPtr", BitmapData.Ptr)
}

;#####################################################################################

Gdip_SetLockBitPixel(ARGB, Scan0, x, y, Stride)
{
	Numput("UInt", ARGB, Scan0+0, (x*4)+(y*Stride))
}

;#####################################################################################

Gdip_GetLockBitPixel(Scan0, x, y, Stride)
{
	return NumGet(Scan0+0, (x*4)+(y*Stride), "UInt")
}

;#####################################################################################

Gdip_PixelateBitmap(pBitmap, &pBitmapOut, BlockSize)
{
	static PixelateBitmap := ""

	if (!PixelateBitmap)
	{
		if A_PtrSize != 8 ; x86 machine code
		MCode_PixelateBitmap := "
		(LTrim Join
		558BEC83EC3C8B4514538B5D1C99F7FB56578BC88955EC894DD885C90F8E830200008B451099F7FB8365DC008365E000894DC88955F08945E833FF897DD4
		397DE80F8E160100008BCB0FAFCB894DCC33C08945F88945FC89451C8945143BD87E608B45088D50028BC82BCA8BF02BF2418945F48B45E02955F4894DC4
		8D0CB80FAFCB03CA895DD08BD1895DE40FB64416030145140FB60201451C8B45C40FB604100145FC8B45F40FB604020145F883C204FF4DE475D6034D18FF
		4DD075C98B4DCC8B451499F7F98945148B451C99F7F989451C8B45FC99F7F98945FC8B45F899F7F98945F885DB7E648B450C8D50028BC82BCA83C103894D
		C48BC82BCA41894DF48B4DD48945E48B45E02955E48D0C880FAFCB03CA895DD08BD18BF38A45148B7DC48804178A451C8B7DF488028A45FC8804178A45F8
		8B7DE488043A83C2044E75DA034D18FF4DD075CE8B4DCC8B7DD447897DD43B7DE80F8CF2FEFFFF837DF0000F842C01000033C08945F88945FC89451C8945
		148945E43BD87E65837DF0007E578B4DDC034DE48B75E80FAF4D180FAFF38B45088D500203CA8D0CB18BF08BF88945F48B45F02BF22BFA2955F48945CC0F
		B6440E030145140FB60101451C0FB6440F010145FC8B45F40FB604010145F883C104FF4DCC75D8FF45E4395DE47C9B8B4DF00FAFCB85C9740B8B451499F7
		F9894514EB048365140033F63BCE740B8B451C99F7F989451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB
		038975F88975E43BDE7E5A837DF0007E4C8B4DDC034DE48B75E80FAF4D180FAFF38B450C8D500203CA8D0CB18BF08BF82BF22BFA2BC28B55F08955CC8A55
		1488540E038A551C88118A55FC88540F018A55F888140183C104FF4DCC75DFFF45E4395DE47CA68B45180145E0015DDCFF4DC80F8594FDFFFF8B451099F7
		FB8955F08945E885C00F8E450100008B45EC0FAFC38365DC008945D48B45E88945CC33C08945F88945FC89451C8945148945103945EC7E6085DB7E518B4D
		D88B45080FAFCB034D108D50020FAF4D18034DDC8BF08BF88945F403CA2BF22BFA2955F4895DC80FB6440E030145140FB60101451C0FB6440F010145FC8B
		45F40FB604080145F883C104FF4DC875D8FF45108B45103B45EC7CA08B4DD485C9740B8B451499F7F9894514EB048365140033F63BCE740B8B451C99F7F9
		89451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB038975F88975103975EC7E5585DB7E468B4DD88B450C
		0FAFCB034D108D50020FAF4D18034DDC8BF08BF803CA2BF22BFA2BC2895DC88A551488540E038A551C88118A55FC88540F018A55F888140183C104FF4DC8
		75DFFF45108B45103B45EC7CAB8BC3C1E0020145DCFF4DCC0F85CEFEFFFF8B4DEC33C08945F88945FC89451C8945148945103BC87E6C3945F07E5C8B4DD8
		8B75E80FAFCB034D100FAFF30FAF4D188B45088D500203CA8D0CB18BF08BF88945F48B45F02BF22BFA2955F48945C80FB6440E030145140FB60101451C0F
		B6440F010145FC8B45F40FB604010145F883C104FF4DC875D833C0FF45108B4DEC394D107C940FAF4DF03BC874068B451499F7F933F68945143BCE740B8B
		451C99F7F989451CEB0389751C3BCE740B8B45FC99F7F98945FCEB038975FC3BCE740B8B45F899F7F98945F8EB038975F88975083975EC7E63EB0233F639
		75F07E4F8B4DD88B75E80FAFCB034D080FAFF30FAF4D188B450C8D500203CA8D0CB18BF08BF82BF22BFA2BC28B55F08955108A551488540E038A551C8811
		8A55FC88540F018A55F888140883C104FF4D1075DFFF45088B45083B45EC7C9F5F5E33C05BC9C21800
		)"
		else ; x64 machine code
		MCode_PixelateBitmap := "
		(LTrim Join
		4489442418488954241048894C24085355565741544155415641574883EC28418BC1448B8C24980000004C8BDA99488BD941F7F9448BD0448BFA8954240C
		448994248800000085C00F8E9D020000418BC04533E4458BF299448924244C8954241041F7F933C9898C24980000008BEA89542404448BE889442408EB05
		4C8B5C24784585ED0F8E1A010000458BF1418BFD48897C2418450FAFF14533D233F633ED4533E44533ED4585C97E5B4C63BC2490000000418D040A410FAF
		C148984C8D441802498BD9498BD04D8BD90FB642010FB64AFF4403E80FB60203E90FB64AFE4883C2044403E003F149FFCB75DE4D03C748FFCB75D0488B7C
		24188B8C24980000004C8B5C2478418BC59941F7FE448BE8418BC49941F7FE448BE08BC59941F7FE8BE88BC69941F7FE8BF04585C97E4048639C24900000
		004103CA4D8BC1410FAFC94863C94A8D541902488BCA498BC144886901448821408869FF408871FE4883C10448FFC875E84803D349FFC875DA8B8C249800
		0000488B5C24704C8B5C24784183C20448FFCF48897C24180F850AFFFFFF8B6C2404448B2424448B6C24084C8B74241085ED0F840A01000033FF33DB4533
		DB4533D24533C04585C97E53488B74247085ED7E42438D0C04418BC50FAF8C2490000000410FAFC18D04814863C8488D5431028BCD0FB642014403D00FB6
		024883C2044403D80FB642FB03D80FB642FA03F848FFC975DE41FFC0453BC17CB28BCD410FAFC985C9740A418BC299F7F98BF0EB0233F685C9740B418BC3
		99F7F9448BD8EB034533DB85C9740A8BC399F7F9448BD0EB034533D285C9740A8BC799F7F9448BC0EB034533C033D24585C97E4D4C8B74247885ED7E3841
		8D0C14418BC50FAF8C2490000000410FAFC18D04814863C84A8D4431028BCD40887001448818448850FF448840FE4883C00448FFC975E8FFC2413BD17CBD
		4C8B7424108B8C2498000000038C2490000000488B5C24704503E149FFCE44892424898C24980000004C897424100F859EFDFFFF448B7C240C448B842480
		000000418BC09941F7F98BE8448BEA89942498000000896C240C85C00F8E3B010000448BAC2488000000418BCF448BF5410FAFC9898C248000000033FF33
		ED33F64533DB4533D24533C04585FF7E524585C97E40418BC5410FAFC14103C00FAF84249000000003C74898488D541802498BD90FB642014403D00FB602
		4883C2044403D80FB642FB03F00FB642FA03E848FFCB75DE488B5C247041FFC0453BC77CAE85C9740B418BC299F7F9448BE0EB034533E485C9740A418BC3
		99F7F98BD8EB0233DB85C9740A8BC699F7F9448BD8EB034533DB85C9740A8BC599F7F9448BD0EB034533D24533C04585FF7E4E488B4C24784585C97E3541
		8BC5410FAFC14103C00FAF84249000000003C74898488D540802498BC144886201881A44885AFF448852FE4883C20448FFC875E941FFC0453BC77CBE8B8C
		2480000000488B5C2470418BC1C1E00203F849FFCE0F85ECFEFFFF448BAC24980000008B6C240C448BA4248800000033FF33DB4533DB4533D24533C04585
		FF7E5A488B7424704585ED7E48418BCC8BC5410FAFC94103C80FAF8C2490000000410FAFC18D04814863C8488D543102418BCD0FB642014403D00FB60248
		83C2044403D80FB642FB03D80FB642FA03F848FFC975DE41FFC0453BC77CAB418BCF410FAFCD85C9740A418BC299F7F98BF0EB0233F685C9740B418BC399
		F7F9448BD8EB034533DB85C9740A8BC399F7F9448BD0EB034533D285C9740A8BC799F7F9448BC0EB034533C033D24585FF7E4E4585ED7E42418BCC8BC541
		0FAFC903CA0FAF8C2490000000410FAFC18D04814863C8488B442478488D440102418BCD40887001448818448850FF448840FE4883C00448FFC975E8FFC2
		413BD77CB233C04883C428415F415E415D415C5F5E5D5BC3
		)"

		PixelateBitmap := Buffer(StrLen(MCode_PixelateBitmap)//2)
		nCount := StrLen(MCode_PixelateBitmap)//2
		loop nCount {
			NumPut("UChar", "0x" SubStr(MCode_PixelateBitmap, (2*A_Index)-1, 2), PixelateBitmap, A_Index-1)
		}
		DllCall("VirtualProtect", "UPtr", PixelateBitmap.Ptr, "UPtr", PixelateBitmap.Size, "UInt", 0x40, "UPtr*", 0)
	}

	Gdip_GetImageDimensions(pBitmap, &Width:="", &Height:="")

	if (Width != Gdip_GetImageWidth(pBitmapOut) || Height != Gdip_GetImageHeight(pBitmapOut))
		return -1
	if (BlockSize > Width || BlockSize > Height)
		return -2

	E1 := Gdip_LockBits(pBitmap, 0, 0, Width, Height, &Stride1:="", &Scan01:="", &BitmapData1:="")
	E2 := Gdip_LockBits(pBitmapOut, 0, 0, Width, Height, &Stride2:="", &Scan02:="", &BitmapData2:="")
	if (E1 || E2)
		return -3

	; E := - unused exit code
	DllCall(PixelateBitmap.Ptr, "UPtr", Scan01, "UPtr", Scan02, "Int", Width, "Int", Height, "Int", Stride1, "Int", BlockSize)

	Gdip_UnlockBits(pBitmap, &BitmapData1), Gdip_UnlockBits(pBitmapOut, &BitmapData2)

	return 0
}

;#####################################################################################

Gdip_ToARGB(A, R, G, B)
{
	return (A << 24) | (R << 16) | (G << 8) | B
}

;#####################################################################################

Gdip_FromARGB(ARGB, &A, &R, &G, &B)
{
	A := (0xff000000 & ARGB) >> 24
	R := (0x00ff0000 & ARGB) >> 16
	G := (0x0000ff00 & ARGB) >> 8
	B := 0x000000ff & ARGB
}

;#####################################################################################

Gdip_AFromARGB(ARGB)
{
	return (0xff000000 & ARGB) >> 24
}

;#####################################################################################

Gdip_RFromARGB(ARGB)
{
	return (0x00ff0000 & ARGB) >> 16
}

;#####################################################################################

Gdip_GFromARGB(ARGB)
{
	return (0x0000ff00 & ARGB) >> 8
}

;#####################################################################################

Gdip_BFromARGB(ARGB)
{
	return 0x000000ff & ARGB
}

;#####################################################################################

StrGetB(Address, Length:=-1, Encoding:=0)
{
	; Flexible parameter handling:
	if !IsInteger(Length) {
		Encoding := Length,  Length := -1
	}

	; Check for obvious errors.
	if (Address+0 < 1024) {
		return
	}

	; Ensure 'Encoding' contains a numeric identifier.
	if (Encoding = "UTF-16") {
		Encoding := 1200
	} else if (Encoding = "UTF-8") {
		Encoding := 65001
	} else if SubStr(Encoding,1,2)="CP" {
		Encoding := SubStr(Encoding,3)
	}

	if !Encoding { 	; "" or 0
		; No conversion necessary, but we might not want the whole string.
		if (Length == -1)
			Length := DllCall("lstrlen", "Ptr", Address)
		VarSetStrCapacity(&myString, Length)
		DllCall("lstrcpyn", "str", myString, "Ptr", Address, "Int", Length + 1)

	} else if (Encoding = 1200) { 	; UTF-16
		char_count := DllCall("WideCharToMultiByte", "UInt", 0, "UInt", 0x400, "Ptr", Address, "Int", Length, "UInt", 0, "UInt", 0, "UInt", 0, "UInt", 0)
		VarSetStrCapacity(&myString, char_count)
		DllCall("WideCharToMultiByte", "UInt", 0, "UInt", 0x400, "Ptr", Address, "Int", Length, "str", myString, "Int", char_count, "UInt", 0, "UInt", 0)

	} else if IsInteger(Encoding) {
		; Convert from target encoding to UTF-16 then to the active code page.
		char_count := DllCall("MultiByteToWideChar", "UInt", Encoding, "UInt", 0, "Ptr", Address, "Int", Length, "Ptr", 0, "Int", 0)
		VarSetStrCapacity(&myString, char_count * 2)
		char_count := DllCall("MultiByteToWideChar", "UInt", Encoding, "UInt", 0, "Ptr", Address, "Int", Length, "Ptr", myString.Ptr, "Int", char_count * 2)
		myString := StrGetB(myString.Ptr, char_count, 1200)
	}

	return myString
}


; ======================================================================================================================
; Multiple Display Monitors Functions -> msdn.microsoft.com/en-us/library/dd145072(v=vs.85).aspx
; by 'just me'
; https://autohotkey.com/boards/viewtopic.php?f=6&t=4606
; ======================================================================================================================
GetMonitorCount()
{
	Monitors := MDMF_Enum()
	for k,v in Monitors {
		count := A_Index
	}
	return count
}

GetMonitorInfo(MonitorNum)
{
	Monitors := MDMF_Enum()
	for k,v in Monitors {
		if (v.Num = MonitorNum) {
			return v
		}
	}
}

GetPrimaryMonitor()
{
	Monitors := MDMF_Enum()
	for k,v in Monitors {
		if (v.Primary) {
			return v.Num
		}
	}
}
; ----------------------------------------------------------------------------------------------------------------------
; Name ..........: MDMF - Multiple Display Monitor Functions
; Description ...: Various functions for multiple display monitor environments
; Tested with ...: AHK 1.1.32.00 (A32/U32/U64) and 2.0-a108-a2fa0498 (U32/U64)
; Original Author: just me (https://www.autohotkey.com/boards/viewtopic.php?f=6&t=4606)
; Mod Authors ...: iPhilip, guest3456
; Changes .......: Modified to work with v2.0-a108 and changed 'Count' key to 'TotalCount' to avoid conflicts
; ................ Modified MDMF_Enum() so that it works under both AHK v1 and v2.
; ................ Modified MDMF_EnumProc() to provide Count and Primary keys to the Monitors array.
; ................ Modified MDMF_FromHWND() to allow flag values that determine the function's return value if the
; ................    window does not intersect any display monitor.
; ................ Modified MDMF_FromPoint() to allow the cursor position to be returned ByRef if not specified and
; ................    allow flag values that determine the function's return value if the point is not contained within
; ................    any display monitor.
; ................ Modified MDMF_FromRect() to allow flag values that determine the function's return value if the
; ................    rectangle does not intersect any display monitor.
;................. Modified MDMF_GetInfo() with minor changes.
; ----------------------------------------------------------------------------------------------------------------------
;
; ======================================================================================================================
; Multiple Display Monitors Functions -> msdn.microsoft.com/en-us/library/dd145072(v=vs.85).aspx =======================
; ======================================================================================================================
; Enumerates display monitors and returns an object containing the properties of all monitors or the specified monitor.
; ======================================================================================================================
MDMF_Enum(HMON := "") {
	static EnumProc := CallbackCreate(MDMF_EnumProc)
	static Monitors := Map()

	if (HMON = "") { 	; new enumeration
		Monitors := Map("TotalCount", 0)
		if !DllCall("User32.dll\EnumDisplayMonitors", "Ptr", 0, "Ptr", 0, "Ptr", EnumProc, "Ptr", ObjPtr(Monitors), "Int")
			return False
	}

	return (HMON = "") ? Monitors : Monitors.HasKey(HMON) ? Monitors[HMON] : False
}
; ======================================================================================================================
;  Callback function that is called by the MDMF_Enum function.
; ======================================================================================================================
MDMF_EnumProc(HMON, HDC, PRECT, ObjectAddr) {
	Monitors := ObjFromPtrAddRef(ObjectAddr)

	Monitors[HMON] := MDMF_GetInfo(HMON)
	Monitors["TotalCount"]++
	if (Monitors[HMON].Primary) {
		Monitors["Primary"] := HMON
	}

	return true
}
; ======================================================================================================================
; Retrieves the display monitor that has the largest area of intersection with a specified window.
; The following flag values determine the function's return value if the window does not intersect any display monitor:
;    MONITOR_DEFAULTTONULL    = 0 - Returns NULL.
;    MONITOR_DEFAULTTOPRIMARY = 1 - Returns a handle to the primary display monitor.
;    MONITOR_DEFAULTTONEAREST = 2 - Returns a handle to the display monitor that is nearest to the window.
; ======================================================================================================================
MDMF_FromHWND(HWND, Flag := 0) {
	return DllCall("User32.dll\MonitorFromWindow", "Ptr", HWND, "UInt", Flag, "Ptr")
}
; ======================================================================================================================
; Retrieves the display monitor that contains a specified point.
; If either X or Y is empty, the function will use the current cursor position for this value and return it ByRef.
; The following flag values determine the function's return value if the point is not contained within any
; display monitor:
;    MONITOR_DEFAULTTONULL    = 0 - Returns NULL.
;    MONITOR_DEFAULTTOPRIMARY = 1 - Returns a handle to the primary display monitor.
;    MONITOR_DEFAULTTONEAREST = 2 - Returns a handle to the display monitor that is nearest to the point.
; ======================================================================================================================
MDMF_FromPoint(&X:="", &Y:="", Flag:=0) {
	if (X = "") || (Y = "") {
		PT := Buffer(8, 0)
		DllCall("User32.dll\GetCursorPos", "Ptr", PT.Ptr, "Int")

		if (X = "") {
			X := NumGet(PT, 0, "Int")
		}

		if (Y = "") {
			Y := NumGet(PT, 4, "Int")
		}
	}
	return DllCall("User32.dll\MonitorFromPoint", "Int64", (X & 0xFFFFFFFF) | (Y << 32), "UInt", Flag, "Ptr")
}
; ======================================================================================================================
; Retrieves the display monitor that has the largest area of intersection with a specified rectangle.
; Parameters are consistent with the common AHK definition of a rectangle, which is X, Y, W, H instead of
; Left, Top, Right, Bottom.
; The following flag values determine the function's return value if the rectangle does not intersect any
; display monitor:
;    MONITOR_DEFAULTTONULL    = 0 - Returns NULL.
;    MONITOR_DEFAULTTOPRIMARY = 1 - Returns a handle to the primary display monitor.
;    MONITOR_DEFAULTTONEAREST = 2 - Returns a handle to the display monitor that is nearest to the rectangle.
; ======================================================================================================================
MDMF_FromRect(X, Y, W, H, Flag := 0) {
	RC := Buffer(16, 0)
	NumPut("Int", X, "Int", Y, "Int", X + W, "Int", Y + H, RC)
	return DllCall("User32.dll\MonitorFromRect", "Ptr", RC.Ptr, "UInt", Flag, "Ptr")
}
; ======================================================================================================================
; Retrieves information about a display monitor.
; ======================================================================================================================
MDMF_GetInfo(HMON) {
	MIEX := Buffer(40 + (32 << !!1))
	NumPut("UInt", MIEX.Size, MIEX)
	if DllCall("User32.dll\GetMonitorInfo", "Ptr", HMON, "Ptr", MIEX.Ptr, "Int") {
		return {Name:      (Name := StrGet(MIEX.Ptr + 40, 32))  ; CCHDEVICENAME = 32
		      , Num:       RegExReplace(Name, ".*(\d+)$", "$1")
		      , Left:      NumGet(MIEX, 4, "Int")    ; display rectangle
		      , Top:       NumGet(MIEX, 8, "Int")    ; "
		      , Right:     NumGet(MIEX, 12, "Int")   ; "
		      , Bottom:    NumGet(MIEX, 16, "Int")   ; "
		      , WALeft:    NumGet(MIEX, 20, "Int")   ; work area
		      , WATop:     NumGet(MIEX, 24, "Int")   ; "
		      , WARight:   NumGet(MIEX, 28, "Int")   ; "
		      , WABottom:  NumGet(MIEX, 32, "Int")   ; "
		      , Primary:   NumGet(MIEX, 36, "UInt")} ; contains a non-zero value for the primary monitor.
	}
	return False
}


; Based on WinGetClientPos by dd900 and Frosti - https://www.autohotkey.com/boards/viewtopic.php?t=484
WinGetRect( hwnd, &x:="", &y:="", &w:="", &h:="" ) {
	Ptr := A_PtrSize ? "UPtr" : "UInt"
	CreateRect(&winRect, 0, 0, 0, 0) ;is 16 on both 32 and 64
	;VarSetCapacity( winRect, 16, 0 )	; Alternative of above two lines
	DllCall( "GetWindowRect", "Ptr", hwnd, "Ptr", winRect )
	x := NumGet(winRect,  0, "UInt")
	y := NumGet(winRect,  4, "UInt")
	w := NumGet(winRect,  8, "UInt") - x
	h := NumGet(winRect, 12, "UInt") - y
}
; Neutron.ahk for AHKv2 v1.0.0
; Copyright (c) 2022 Philip Taylor (known also as GeekDude, G33kDude)
; https://github.com/G33kDude/Neutron.ahk
;
; MIT License
;
; Permission is hereby granted, free of charge, to any person obtaining a copy
; of this software and associated documentation files (the "Software"), to deal
; in the Software without restriction, including without limitation the rights
; to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
; copies of the Software, and to permit persons to whom the Software is
; furnished to do so, subject to the following conditions:
;
; The above copyright notice and this permission notice shall be included in all
; copies or substantial portions of the Software.
;
; THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
; IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
; FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
; AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
; LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
; OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
; SOFTWARE.
;

#Requires AutoHotkey v2.0

class NeutronWindow {
	/** Template for template-based class initialization */
	TEMPLATE := "
( ; html
<!DOCTYPE html><html>
<head>

<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<link href='https://fonts.googleapis.com/css2?family=Macondo+Swash+Caps&display=swap' rel='stylesheet'>
<link href='https://db.onlinewebfonts.com/c/4e6ac8c3d18698e2f7ba865c03f7808f?family=asimovian' rel='stylesheet'>
<style>
	html, body {
		width: 100%; height: 100%;
		margin: 0; padding: 0;
		font-family: sans-serif;
	}

	body {
		display: flex;
		flex-direction: column;
	}

	header {
		width: 100%;
		display: flex;
		background: silver;
		font-family: Segoe UI;
		font-size: 9pt;
	}

	.title-bar {
		padding: 0.35em 0.5em;
		flex-grow: 1;
	}

	@keyframes logoGlow {
		0%, 100% { filter: brightness(1) drop-shadow(0 0 0px black); opacity: 1; }
		50% { filter: brightness(0.1) drop-shadow(0 0 8px black); opacity: 0.15; }
	}

	.title-bar img {
		animation: logoGlow 2.4s ease-in-out infinite;
	}

	.title-btn {
		padding: 0.35em 0.5em;
		cursor: pointer;
		vertical-align: bottom;
		font-family: Webdings;
		font-size: 11pt;
	}

	body .title-btn-restore {
		display: none
	}

	body.neutron-maximized .title-btn-restore {
		display: block
	}

	body.neutron-maximized .title-btn-maximize {
		display: none
	}

	.title-btn:hover {
		background: rgba(0, 0, 0, .2);
	}

	.title-btn-close:hover {
		background: #dc3545;
	}

	.main {
		flex-grow: 1;
		padding: 0.5em;
		overflow: auto;
	}
</style>
<style>{}</style>

</head>
<body>
<header>
	<span class='title-bar' onmousedown='neutron.DragTitleBar()'>{}</span>
	<span class='title-btn' onclick='neutron.Minimize()'>0</span>
	<span class='title-btn title-btn-restore' onclick='neutron.Maximize()'>2</span>
	<span class='title-btn title-btn-close' onclick='neutron.Close()'>r</span>
</header>

<div class='main'>{}</div>

<script>{}</script>

</body>
</html>
)" ;removed 	<span class='title-btn title-btn-maximize' onclick='neutron.Maximize()'>1</span>

	;#region Constants ---------------------------------------------------------

	VERSION => "1.0.1"

	; Windows Messages
	WM_DESTROY => 0x02
	WM_SIZE => 0x05
	WM_NCCALCSIZE => 0x83
	WM_NCHITTEST => 0x84
	WM_NCLBUTTONDOWN => 0xA1
	WM_KEYDOWN => 0x100
	WM_KEYUP => 0x101
	WM_SYSKEYDOWN => 0x104
	WM_SYSKEYUP => 0x105
	WM_MOUSEMOVE => 0x200
	WM_LBUTTONDOWN => 0x201

	; Virtual-Key Codes
	VK_TAB => 0x09
	VK_SHIFT => 0x10
	VK_CONTROL => 0x11
	VK_MENU => 0x12
	VK_F5 => 0x74

	; Non-client hit test values (WM_NCHITTEST)
	HT_VALUES := [[13, 12, 14], [10, 1, 11], [16, 15, 17]]

	; Registry keys
	KEY_FBE => "HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\MAIN"
		. "\FeatureControl\FEATURE_BROWSER_EMULATION"

	; Undoucmented Accent API constants
	; https://withinrafael.com/2018/02/02/adding-acrylic-blur-to-your-windows-10-apps-redstone-4-desktop-apps/
	ACCENT_ENABLE_GRADIENT => 1
	ACCENT_ENABLE_BLURBEHIND => 3
	WCA_ACCENT_POLICY => 19

	; Other constants
	EXE_NAME := A_IsCompiled ? A_ScriptName : StrSplit(A_AhkPath, "\").Pop()

	; OS minor version
	OS_MINOR_VER := StrSplit(A_OSVersion, ".")[3]

	; Messages to listen to
	LISTENERS := [this.WM_DESTROY, this.WM_SIZE, this.WM_NCCALCSIZE,
		this.WM_KEYDOWN, this.WM_KEYUP, this.WM_SYSKEYDOWN, this.WM_SYSKEYUP,
		this.WM_LBUTTONDOWN]

	; Modifier keys as seen by neutron
	MODIFIER_BITMAP := Map(
		this.VK_SHIFT, 1 << 0,
		this.VK_CONTROL, 1 << 1,
		this.VK_MENU, 1 << 2,
	)

	;#endregion

	;#region Instance Variables ------------------------------------------------

	/**
	 * The count of pixels inset from the window edge that the sizing handles to
	 * resize the window will appear for.
	 */
	border_size := 6

	/** The width of the Neutron window (please read only) */
	w := 800

	/** The height of the Neutron window (please read only) */
	h := 600

	/** Holds the bitwise OR of all modifiers defined in MODIFIER_BITMAP (please read only) */
	modifiers := 0

	/** Shortcuts to prevent the web page from processing */
	disabled_shortcuts := Map(
		; No modifiers
		0, Map(
			this.VK_F5, true	; Refresh page
		),
		; Ctrl
		this.MODIFIER_BITMAP[this.VK_CONTROL], Map(
			GetKeyVK("F"), true,	; Ctrl+F find
			GetKeyVK("L"), true,	; Ctrl+L focus location bar
			GetKeyVK("N"), true,	; Ctrl+N open new tab
			GetKeyVK("O"), true,	; Ctrl+O open file
			GetKeyVK("P"), true,	; Ctrl+P print page
		)
	)

	/**
	 * The underlying Gui object representing the window
	 * @type {Gui}
	 */
	gui := unset

	/**
	 * Bound functions with circular references that must be freed before the
	 * class can be successfully garbage collected
	 * @type {Object}
	 */
	bound := {}

	/**
	 * The GuiControl object representing the ActiveX document control
	 * @type {Gui.ActiveX}
	 */
	wbControl := ""

	/** Handle to the Internet Explorer_Server control (please read only) */
	hIES := 0

	/** Handle to the Shell DocObject View control (please read only) */
	hSDOV := 0

	;#endregion

	;#region Properties --------------------------------------------------------

	/** The JS DOM Document object */
	doc => this.wb.Document

	/** The JS Window object */
	wnd => this.wb.Document.parentWindow

	/** The GUI hWnd (or empty string if the hWnd is not yet available) */
	hWnd => this.HasProp("gui") ? this.gui.hWnd : ""

	;#endregion

	;#region Meta --------------------------------------------------------------

	__New(html := "", css := "", js := "", title := "Neutron") {
		; Create necessary circular references
		this.bound._OnMessage := this._OnMessage.Bind(this)

		; Bind message handlers
		for i, message in this.LISTENERS
			OnMessage(message, this.bound._OnMessage)

		; Create and save the GUI
		this.gui := Gui("+Resize -DPIScale")

		; Enable shadow
		NumPut("Int", 1, margins := Buffer(16, 0))
		DllCall("Dwmapi\DwmExtendFrameIntoClientArea",
			"Ptr", this.hWnd,	; HWND hWnd
			"Ptr", margins,	; MARGINS *pMarInset
		)

		; When manually resizing a window, the contents of the window often "lag
		; behind" the new window boundaries. Until they catch up, Windows will
		; render the border and default window color to fill that area. On most
		; windows this will cause no issue, but for borderless windows this can
		; cause rendering artifacts such as thin borders or unwanted colors to
		; appear in that area until the rest of the window catches up.
		;
		; When creating a dark-themed application, these artifacts can cause
		; jarringly visible bright areas. This can be mitigated some by changing
		; the window settings to cause dark/black artifacts, but it's not a
		; generalizable approach, so if I were to do that here it could cause
		; issues with light-themed apps.
		;
		; Some borderless window libraries, such as rossy's C implementation
		; (https://github.com/rossy/borderless-window) hide these artifacts by
		; playing with the window transparency settings which make them go away
		; but also makes it impossible to show certain colors (in rossy's case,
		; Fuchsia/FF00FF).
		;
		; Luckly, there's an undocumented Windows API function in user32.dll
		; called SetWindowCompositionAttribute, which allows you to change the
		; window accenting policies. This tells the DWM compositor how to fill
		; in areas that aren't covered by controls. By enabling the "blurbehind"
		; accent policy, Windows will render a blurred version of the screen
		; contents behind your window in that area, which will not be visually
		; jarring regardless of the colors of your application or those behind
		; it.
		;
		; Because this API is undocumented (and unavailable in Windows versions
		; below 10) it's not a one-size-fits-all solution, and could break with
		; future system updates. Hopefully a better soultion for the problem
		; this hack addresses can be found for future releases of this library.
		;
		; https://withinrafael.com/2018/02/02/adding-acrylic-blur-to-your-windows-10-apps-redstone-4-desktop-apps/
		; https://github.com/melak47/BorderlessWindow/issues/13#issuecomment-309154142
		; http://undoc.airesoft.co.uk/user32.dll/SetWindowCompositionAttribute.php
		; https://gist.github.com/riverar/fd6525579d6bbafc6e48
		; https://vhanla.codigobit.info/2015/07/enable-windows-10-aero-glass-aka-blur.html
		this.gui.BackColor := 0

		; Use ACCENT_ENABLE_GRADIENT on Windows 11 to fix window dragging issues
		accent := Buffer(16, 0)
		if this.OS_MINOR_VER >= 22000
			NumPut("Int", this.ACCENT_ENABLE_GRADIENT, accent)
		else
			NumPut("Int", this.ACCENT_ENABLE_BLURBEHIND, accent)

		NumPut(
			"Ptr", this.WCA_ACCENT_POLICY,
			"Ptr", accent.Ptr,
			"Int", 16,
			wcad := Buffer(A_PtrSize + A_PtrSize + 4, 0)
		)
		DllCall("SetWindowCompositionAttribute",
			"Ptr", this.hWnd,	; HWND hwnd
			"Ptr", wcad,	; WINCOMPATTRDATA* pAttrData
		)

		; Creating an ActiveX control with a valid URL instantiates a
		; WebBrowser, saving its object to the associated variable. The "about"
		; URL scheme allows us to start the control on either a blank page, or a
		; page with some HTML content pre-loaded by passing HTML after the
		; colon: "about:<!DOCTYPE html><body>...</body>"
		;
		; Read more about the WebBrowser control here:
		; http://msdn.microsoft.com/en-us/library/aa752085

		; For backwards compatibility reasons, the WebBrowser control defaults
		; to IE7 emulation mode. The standard method of mitigating this is to
		; include a compatibility meta tag in the HTML, but this requires
		; tampering to the HTML and does not solve all compatibility issues.
		; By tweaking the registry before and after creation of the control we
		; can opt-out of the browser emulation feature altogether with minimal
		; impact on the rest of the system.
		;
		; Read more about browser compatibility modes here:
		; https://docs.microsoft.com/en-us/archive/blogs/patricka/controlling-webbrowser-control-compatibility

		fbe := RegRead(this.KEY_FBE, this.EXE_NAME, "")
		RegWrite(0, "REG_DWORD", this.KEY_FBE, this.EXE_NAME)
		this.wbControl := this.gui.AddActiveX("x0 y0 w800 h600", "about:blank")
		this.wb := this.wbControl.Value
		if (fbe = "")
			RegDelete(this.KEY_FBE, this.EXE_NAME)
		else
			RegWrite(fbe, "REG_DWORD", this.KEY_FBE, this.EXE_NAME)

		; Connect the web browser's event stream to a new event handler object
		ComObjConnect(this.wb, NeutronWindow._WBEvents(this))

		; Compute the HTML template if necessary
		if !(html ~= "i)^<!DOCTYPE")
			html := Format(this.TEMPLATE, css, title, html, js)

		; Write the given content to the page
		this.doc.write(html)
		this.doc.close()

		; Inject the AHK objects into the JS scope
		this.wnd.neutron := this
		this.wnd.ahk := NeutronWindow._Dispatch(this)

		; Wait for the page to finish loading
		while this.wb.readyState < 4
			Sleep 50

		; Subclass the rendered Internet Explorer_Server control to intercept
		; its events, including WM_NCHITTEST and WM_NCLBUTTONDOWN.
		; Read more here: https://forum.juce.com/t/_/27937
		; And in the AutoHotkey documentation for RegisterCallback (Example 2)

		dhw := DetectHiddenWindows(true)
		this.hIES := ControlGetHwnd("Internet Explorer_Server1", "ahk_id " this.hWnd)
		this.hSDOV := ControlGetHwnd("Shell DocObject View1", "ahk_id " this.hWnd)
		DetectHiddenWindows(dhw)

		this.pWndProc := CallbackCreate(this._WindowProc.Bind(this), "", 4)
		this.pWndProcOld := DllCall("SetWindowLong" (A_PtrSize == 8 ? "Ptr" : "")
			, "Ptr", this.hIES	; HWND     hWnd
			, "Int", -4	; int      nIndex (GWLP_WNDPROC)
			, "Ptr", this.pWndProc	; LONG_PTR dwNewLong
			, "Ptr"	; LONG_PTR
		)

		; Stop the WebBrowser control from consuming file drag and drop events
		this.wb.RegisterAsDropTarget := False
		DllCall("ole32\RevokeDragDrop", "Ptr", this.hIES)
	}

	; Show an alert for debugging purposes when the class gets garbage collected
	; __Delete()
	; {
	; 	MsgBox, __Delete
	; }

	;#endregion

	;#region Event Handlers ----------------------------------------------------

	_OnMessage(wParam, lParam, msg, hWnd) {
		if (hWnd == this.hWnd) {
			; Handle messages for the main window

			if (msg == this.WM_NCCALCSIZE) {
				; Size the client area to fill the entire window.
				; See this project for more information:
				; https://github.com/rossy/borderless-window

				; Fill client area when not maximized
				if !DllCall("IsZoomed", "UPtr", hWnd)
					return 0
				; else crop borders to prevent screen overhang

				; Query for the window's border size
				NumPut("UInt", 60, windowinfo := Buffer(60, 0))
				DllCall("GetWindowInfo", "Ptr", hWnd, "Ptr", windowinfo)
				cxWindowBorders := NumGet(windowinfo, 48, "Int")
				cyWindowBorders := NumGet(windowinfo, 52, "Int")

				; Inset the client rect by the border size
				NumPut(
					"Int", NumGet(lParam, 0, "Int") + cxWindowBorders,
					"Int", NumGet(lParam, 4, "Int") + cyWindowBorders,
					"Int", NumGet(lParam, 8, "Int") - cxWindowBorders,
					"Int", NumGet(lParam, 12, "Int") - cyWindowBorders,
					lParam
				)

				return 0
			} else if (msg == this.WM_SIZE) {
				; Extract size from LOWORD and HIWORD (preserving sign)
				this.w := w := lParam << 48 >> 48
				this.h := h := lParam << 32 >> 48

				DllCall("MoveWindow",
					"UPtr", this.wbControl.hWnd,	; HWND hWnd
					"Int", 0,	; int  X
					"Int", 0,	; int  Y
					"Int", w,	; int  nWidth
					"Int", h,	; int  nHeight
					"UInt", 0	; BOOL bRepaint
				)

				return 0
			} else if (msg == this.WM_DESTROY) {
				; Clean up all our circular references so that the object may be
				; garbage collected.

				for i, message in this.LISTENERS
					OnMessage(message, this.bound._OnMessage, 0)
				ComObjConnect(this.wb)
				try {
					this.bound := []
				}
			}
		} else if (hWnd == this.hIES || hWnd == this.hSDOV) {
			; Handle messages for the rendered Internet Explorer_Server

			pressed := (msg == this.WM_KEYDOWN || msg == this.WM_SYSKEYDOWN)
			released := (msg == this.WM_KEYUP || msg == this.WM_SYSKEYUP)

			if (pressed || released) {
				; Track modifier states
				if (bit := this.MODIFIER_BITMAP.Get(wParam, ""))
					this.modifiers := (this.modifiers & ~bit) | (pressed * bit)

				; Block disabled key combinations
				if (this.disabled_shortcuts.Get(this.modifiers, Map()).Get(wParam, false))
					return 0

				; When you press tab with the last tabbable item in the
				; document already selected, focus will be taken from the IES
				; control and moved to the SDOV control. The accelerator code
				; from the AutoHotkey installer uses a conditional loop in an
				; attempt to work around this behavior, but as implemented it
				; did not work correctly on my system. Instead, listen for the
				; tab up event on the SDOV and swap it for a tab down before
				; translating it. This should prevent the user from tabbing to
				; the SDOV in most cases, though there may still be some way to
				; tab to it that I am not aware of. A more elegant solution may
				; be to subclass the SDOV like was done for the IES, then
				; forward the WM_SETFOCUS message back to the IES control.
				; However, given the relative complexity of subclassing and the
				; fact that this message substution approach appears to work
				; just as well, we will use the message substitution. Consider
				; implementing the other approach if it turns out that the
				; undesirable behavior continues to manifest under some
				; circumstances.
				msg := hWnd == this.hSDOV ? this.WM_KEYDOWN : msg

				; Add OwnDialogs for threadless callbacks which normally
				; interrupt this process
				this.gui.Opt("+OwnDialogs")

				DllCall("GetCursorPos", "Ptr", cursorPoint := Buffer(8, 0))
				NumPut(
					"Ptr", hWnd,
					"Ptr", msg,
					"Ptr", wParam,
					"Ptr", lParam,
					"UInt", A_EventInfo,
					"Int", NumGet(cursorPoint, 0, "Int"),
					"Int", NumGet(cursorPoint, 4, "Int"),
					kMsg := Buffer(48, 0)
				)
				pipa := ComObjQuery(this.wb, "{00000117-0000-0000-C000-000000000046}")
				result := ComCall(5, pipa, "Ptr", kMsg)

				; S_OK: the message was translated to an accelerator.
				if (result == 0)
					return 0
				return
			}
		}
	}

	_WindowProc(hWnd, msg, wParam, lParam) {
		Critical

		if (msg == this.WM_NCHITTEST) {
			; Check to see if the cursor is near the window border, which
			; should be treated as the "non-client" drag-to-resize area.
			; https://autohotkey.com/board/topic/23969-/#entry155480

			; Extract coordinates from LOWORD and HIWORD (preserving sign)
			x := lParam << 48 >> 48, y := lParam << 32 >> 48

			; Get the window position for comparison
			WinGetPos(&wX, &wY, &wW, &wH, "ahk_id " this.Hwnd)

			; Calculate positions in the lookup tables
			row := (x < wX + this.BORDER_SIZE) ? 1 : (x >= wX + wW - this.BORDER_SIZE) ? 3 : 2
			col := (y < wY + this.BORDER_SIZE) ? 1 : (y >= wY + wH - this.BORDER_SIZE) ? 3 : 2

			return this.HT_VALUES[col][row]
		} else if (msg == this.WM_NCLBUTTONDOWN) {
			; Hoist nonclient clicks to main window
			return DllCall("SendMessage",
				"Ptr", this.hWnd,
				"UInt", msg,
				"UPtr", wParam,
				"Ptr", lParam,
				"Ptr"
			)
		}

		; Otherwise (since above didn't return), pass all unhandled events to
		; the original WindowProc
		Critical false
		return DllCall("CallWindowProc",
			"Ptr", this.pWndProcOld,	; WNDPROC lpPrevWndFunc
			"Ptr", hWnd,	; HWND    hWnd
			"UInt", msg,	; UINT    Msg
			"UPtr", wParam,	; WPARAM  wParam
			"Ptr", lParam,	; LPARAM  lParam
			"Ptr"	; LRESULT
		)
	}

	;#endregion

	;#region Instance Methods --------------------------------------------------

	/**
	 * Triggers window dragging. Call this on mouse click down. Best used as
	 * your title bar's onmousedown attribute.
	 * 
	 * ```html
	 * <span onmousedown="neutron.DragTitleBar()">
	 * ```
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	DragTitleBar() {
		PostMessage(this.WM_NCLBUTTONDOWN, 2, 0, , "ahk_id " this.Hwnd)
		return this
	}

	/**
	 * Minimizes the Neutron window. Best used in your title bar's minimize
	 * button's onclick attribute.
	 * 
	 * ```html
	 * <span onclick='neutron.Minimize()'>
	 * ```
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Minimize() {
		this.gui.Minimize()
		return this
	}

	/**
	 * Maximize the Neutron window. Best used in your title bar's maximize
	 * button's onclick attribute.
	 * 
	 * ```html
	 * <span onclick='neutron.Maximize()'>
	 * ```
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Maximize() {
		if DllCall("IsZoomed", "UPtr", this.hWnd) {
			this.gui.Restore()
			this.qs("body").classList.remove("neutron-maximized")
		} else {
			this.gui.Maximize()
			this.qs("body").classList.add("neutron-maximized")
		}
		return this
	}

	/**
	 * Closes the Neutron window. Best used in your title bar's close
	 * button's onclick attribute.
	 * 
	 * ```html
	 * <span onclick='neutron.Close()'>
	 * ```
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Close() {
		WinClose("ahk_id " this.hWnd)
		return this
	}

	/**
	 * Hides the Nuetron window.
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Hide() {
		this.gui.Hide()
		return this
	}

	/**
	 * Destroys the Neutron window. Do this when you would no longer want to
	 * re-show the window, as it will free the memory taken up by the GUI and
	 * ActiveX control. This method is best used either as your title bar's
	 * close button's onclick attribute, or in a custom window close routine.
	 * 
	 * ```html
	 * <span onclick='neutron.Close()'>
	 * ```
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Destroy() {
		this.gui.Destroy()
		return this
	}

	/**
	 * Shows a hidden Neutron window
	 * 
	 * @param options Options to be passed to `Gui.Show(options)`
	 * @param title   A title for the base window (shows in task bar, alt tab)
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Show(options := "", title := "") {
		w := RegExMatch(options, "w\s*\K\d+", &match) ? match[] : this.w
		h := RegExMatch(options, "h\s*\K\d+", &match) ? match[] : this.h

		; AutoHotkey sizes the window incorrectly, trying to account for borders
		; that aren't actually there. Call the function AHK uses to offset and
		; apply the change in reverse to get the actual wanted size.
		rect := Buffer(16, 0)
		DllCall("AdjustWindowRectEx",
			"Ptr", rect,	; LPRECT lpRect
			"UInt", 0x80CE0000,	; DWORD  dwStyle
			"UInt", 0,	; BOOL   bMenu
			"UInt", 0,	; DWORD  dwExStyle
			"UInt"	; BOOL
		)
		w += NumGet(rect, 0, "Int") - NumGet(rect, 8, "Int")
		h += NumGet(rect, 4, "Int") - NumGet(rect, 12, "Int")

		this.gui.Title := title
		this.gui.Show(options " w" w " h" h)
		return this
	}

	/**
	 * Loads an HTML file by name (not path).
	 * 
	 * When running the script uncompiled, looks for the file in the local
	 * directory. When running the script compiled, looks for the file in the
	 * EXE's RCDATA. Files included in your compiled EXE by FileInstall are
	 * stored in RCDATA whether they get extracted or not. An easy way to get
	 * your Neutron resources into a compiled script, then, is to put
	 * FileInstall commands for them at the start or end of the AutoExecute
	 * section, wrapped in `if False {}`. For example:
	 * 
	 * ```ahk2
	 * ; AutoExecute Section
	 * neutron := NeutronWindow().Load("index.html").Show()
	 * 
	 * if False {
	 *     FileInstall "index.html", "*"
	 *     FileInstall "index.css", "*"
	 * }
	 * return
	 * ```
	 * 
	 * @param fileName The name of the HTML file to load into the Neutron window.
	 *                 Make sure to give just the file name, not the full path.
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Load(fileName) {
		; Complete the path based on compiled state
		if A_IsCompiled
			url := "res://" this.wnd.encodeURIComponent(A_ScriptFullPath) "/10/" fileName
		else
			url := A_WorkingDir "/" fileName

		; Navigate to the calculated file URL
		this.wb.Navigate(url)

		; Wait for the page to finish loading
		while this.wb.readyState < 3
			Sleep 50

		; Inject the AHK objects into the JS scope
		this.wnd.neutron := this
		this.wnd.ahk := NeutronWindow._Dispatch(this)

		; Wait for the page to finish loading
		while this.wb.readyState < 4
			Sleep 50

		return this
	}

	/**
	 * Registers a function or method to be called when the given event is
	 * raised by Neutron underlying GUI window.
	 * 
	 * The function will be called with its normal parameter set as defined by
	 * AutoHotkey, but with the first parameter changed from the `Gui` object to
	 * the `NeutronWindow` object.
	 * 
	 * @param {String} eventName The name of the event
	 * @param          callback  The callback to be run
	 * @param {Int}    addRemove (Optional) Specifies call order or removes the
	 *                           callback. See `Gui.OnEvent()` docs for more
	 *                           details
	 * 
	 * @return {NeutronWindow} The instance, for chaining
	 * 
	 * @example <caption>Exit AHK on Neutron close</caption>
	 * neutron.OnEvent("Close", (neutron) => ExitApp())
	 */
	OnEvent(eventName, callback, addRemove := unset) {
		this.gui.OnEvent(eventName, (p*) => (p[1] := this, callback(p*)), addRemove?)
		return this
	}

	/**
	 * Passthrough to sets one or more options for the underlying GUI window
	 * @return {NeutronWindow} The instance, for chaining
	 */
	Opt(options) {
		this.gui.Opt(options)
		return this
	}

	/**
	 * Shorthand method for document.querySelector
	 * @param selector The query selector
	 * @return the result of the query
	 */
	qs(selector) {
		return this.doc.querySelector(selector)
	}

	/**
	 * Shorthand method for document.querySelectorAll
	 * @param selector The query selector
	 * @return the result of the query
	 */
	qsa(selector) {
		return this.doc.querySelectorAll(selector)
	}

	;#endregion

	;#region Static Methods ----------------------------------------------------

	/**
	 * Given an HTML Form Element, construct a FormData object
	 * 
	 * Returns: A FormData object
	 * 
	 * Example:
	 * 
	 * neutron := NeutronWindow("<form>"
	 * . "<input type='text' name='field1' value='One'>"
	 * . "<input type='text' name='field2' value='Two'>"
	 * . "<input type='text' name='field3' value='Three'>"
	 * . "</form>").Show()
	 * formElement := neutron.doc.querySelector("form") ; Grab 1st form on page
	 * formData := NeutronWindow.GetFormData(formElement) ; Get form data
	 * MsgBox formData.field2 ; Pull a single field
	 * for name, element in formData ; Iterate all fields
	 *     MsgBox name ": " element
	 * 
	 * @param        formElement The HTML Form Element
	 * @param {Bool} useIdAsName (Optional, default `True`) When a field's name
	 *                           is blank, use it's ID instead.
	 * 
	 * @return {NeutronWindow.FormData}
	 */
	static GetFormData(formElement, useIdAsName := True) {
		formData := this.FormData()

		for i, field in this.Each(formElement.elements) {
			; Discover the field's name
			name := ""
			try	; fieldset elements error when reading the name field
				name := field.name
			if (name == "" && useIdAsName)
				name := field.id

			; Filter against fields which should be omitted
			if (name == "" || field.disabled
				|| field.type ~= "^file|reset|submit|button$")
				continue

			; Handle select-multiple variants
			if (field.type == "select-multiple") {
				for j, option in this.Each(field.options)
					if (option.selected)
						formData.add(name, option.value)
				continue
			}

			; Filter against unchecked checkboxes and radios
			if (field.type ~= "^checkbox|radio$" && !field.checked)
				continue

			; Return the field values
			formData.add(name, field.value)
		}

		return formData
	}

	/**
	 * Makes text safe to be embedded in HTML
	 * 
	 * Reference https://stackoverflow.com/a/6234804
	 * 
	 * @param {String} unsafe An HTML-unsafe string
	 * 
	 * @return {String} An HTML safe string
	 */
	static EscapeHTML(unsafe) {
		unsafe := StrReplace(unsafe, "&", "&amp;")
		unsafe := StrReplace(unsafe, "<", "&lt;")
		unsafe := StrReplace(unsafe, ">", "&gt;")
		unsafe := StrReplace(unsafe, '"', "&quot;")
		unsafe := StrReplace(unsafe, "'", "&#039;")
		return unsafe
	}

	/**
	 * Wrapper for Format that applies EscapeHTML to each value before passing
	 * them on. Useful for dynamic HTML generation.
	 * 
	 * @param {String} formatStr The format string
	 * @param values...          The placeholder values
	 * 
	 * @return {String} The formatted version of the specified string
	 */
	static FormatHTML(formatStr, values*) {
		for i, value in values
			values[i] := NeutronWindow.EscapeHTML(value)
		return Format(formatStr, values*)
	}

	;#endregion

	;#region Nested Classes ----------------------------------------------------

	/**
	 * Creates an enumerable object that will enumerate an HTML Collection
	 * or other JavaScript array.
	 * 
	 * @param collection The JavaScript array/collection to be enumerated
	 * 
	 * @return {NeutronWindow.Each}
	 * 
	 * @example <caption>Walk through the direct children of body</caption>
	 * neutron := NeutronWindow("<body><p>A</p><p>B</p><p>C</p></body>")
	 * neutron.Show()
	 * for i, element in NeutronWindow.Each(neutron.body.children)
	 *     MsgBox i ": " element.innerText
	 */
	class Each {
		__New(collection) {
			this.collection := collection
		}

		__Enum(numberOfVars) {
			index := 0
			return (&a, &b := unset) => (
				(index > this.collection.length) ? False : (True,
					a := index,
					b := this.collection.item(index++)
				)
			)
		}
	}

	/**
	 * A collection similar to an OrderedDict designed for holding form data.
	 * This collection allows duplicate keys and enumerates key value pairs in
	 * the order they were added.
	 */
	class FormData {
		names := []
		values := []

		/**
		 * Add a field to the FormData structure.
		 * 
		 * @param {String} name The form field name associated with the value
		 * @param          value The value of the form field
		 */
		Add(name, value) {
			this.names.Push(name)
			this.values.Push(value)
		}

		/**
		 * Get an array of all values associated with a name.
		 * 
		 * @param {String} name The form field name associated with the values
		 * 
		 * @return {Array} The values associated with the name
		 * 
		 * @example <caption>Get all form values with key "foods"</caption>
		 * fd := NeutronWindow.FormData()
		 * fd.Add("foods", "hamburgers")
		 * fd.Add("foods", "hotdogs")
		 * fd.Add("foods", "pizza")
		 * fd.Add("colors", "red")
		 * fd.Add("colors", "green")
		 * fd.Add("colors", "blue")
		 * for i, food in fd.All("foods")
		 *     out .= i ": " food "`n"
		 * MsgBox out
		 */
		All(name) {
			values := []
			for i, v in this.names
				if (v == name)
					values.Push(this.values[i])
			return values
		}

		/**
		 * Meta-function to allow direct access of field values using dot
		 * notation.
		 * 
		 * @example <caption>Get first value for key foods</caption>
		 * fd := NeutronWindow.FormData()
		 * fd.Add("foods", "hamburgers")
		 * fd.Add("foods", "hotdogs")
		 * MsgBox fd.foods ; hamburgers
		 */
		__Get(name, params) {
			return this[name]
		}

		/**
		 * Meta-property to allow direct access of field values using bracket
		 * notation. Can retrieve the nth item associated with a given name
		 * by passing more than one value.
		 * 
		 * @example <caption>Get first and second value for key foods</caption>
		 * fd := Neutron.FormData()
		 * fd.Add("foods", "hamburgers")
		 * fd.Add("foods", "hotdogs")
		 * MsgBox fd["foods"] ; hamburgers
		 * MsgBox fd["foods", 2] ; hotdogs
		 */
		__Item[name, n := 1] {
			get {
				for i, v in this.names
					if (v == name && !--n)
						return this.values[i]
			}
		}

		/**
		 * Allow iteration in the order fields were added, instead of a normal
		 * object's alphanumeric order of iteration.
		 * 
		 * @example <caption>Iterate through all form values in order</caption>
		 * fd := NeutronWindow.FormData()
		 * fd.Add("z", "3")
		 * fd.Add("y", "2")
		 * fd.Add("x", "1")
		 * for name, field in fd
		 *     out .= name ": " field ","
		 * MsgBox out ; z: 3, y: 2, x: 1
		 */
		__Enum(NumberOfVars) {
			i := 0
			return (&name, &value := unset) => (
				(++i > this.names.Length) ? (false) : (true,
					name := this.names[i],
					value := this.values[i]
				)
			)
		}
	}

	/**
	 * Proxies method calls to AHK function calls
	 * 
	 * These functions get called from JavaScript typically, which consumes any
	 * thrown errors and displays a really unhelpful dialog. For the best
	 * experience, any thrown errors are additionally re-thrown in a separate
	 * thread so the native dialog can be displayed.
	 * 
	 * @param {NeutronWindow} parent The parent {NeutronWindow} instance
	 */
	class _Dispatch {
		__New(parent) {
			this.parent := parent
		}

		__Call(name, params := []) {
			; Make sure the given name is a function
			if !((fn := %name% ?? false) && fn is Func)
				throw Error("Unknown function: " name)

			; Add a first parameter of the neutron instance
			params.InsertAt(1, this.parent)

			; Make sure enough parameters were given
			if (params.Length < fn.MinParams)
				throw Error("Too few parameters given to " fn.Name ": " params.Length)

			; Make sure too many parameters weren't given
			if (params.Length > fn.MaxParams && !fn.IsVariadic)
				throw Error("Too many parameters given to " fn.Name ": " params.Length)

			; Call the function
			try {
				return fn(params*)
			} catch as err {
				thrower() {
					throw err
				}
				SetTimer(thrower, -1)
				throw err
			}
		}
	}

	/**
	 * Handles Web Browser events
	 * https://docs.microsoft.com/en-us/previous-versions/windows/internet-explorer/ie-developer/platform-apis/aa768283%28v%3dvs.85%29
	 * 
	 * @param {NeutronWindow} parent The parent {NeutronWindow} instance
	 */
	class _WBEvents {
		__New(parent) {
			this.parent := parent
		}

		DocumentComplete(wb, p*) {
			; Inject the AHK objects into the JS scope
			wb.document.parentWindow.neutron := this.parent
			wb.document.parentWindow.ahk := NeutronWindow._Dispatch(this.parent)
		}
	}

	;#endregion
}

; HTML content
html := '
( ; html
	<div class="app-container">
        <div id="main-content">
            <div class="status-panel">
                <div class="panel-title">Status</div>
                <div class="progress-wrap">
                    <span class="progress-label">Start</span>
                    <div class="progress-track">
                        <div class="progress-bar" id="progress-bar"></div>
                    </div>
                    <span class="progress-label">End</span>
                </div>
            </div>

            <div class="info-panel">
                <div class="panel-title">Session Info</div>
                <div class="info-item">
                    <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42A7.92 7.92 0 0012 4c-4.42 0-8 3.58-8 8s3.57 8 8 8 8-3.58 8-8c0-1.72-.54-3.31-1.47-4.61zM12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6z"/></svg></span>
                    <span>Timer: <span id="active-keys">0:00</span></span>
                </div>
                <div class="info-item">
                    <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M5 9h2v10H5zm4-4h2v14H9zm4 8h2v6h-2zm4-6h2v12h-2z"/></svg></span>
                    <span>Progress: <span id="last-action">0%</span></span>
                </div>
                <div class="info-item">
                    <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg></span>
                    <span>Missions Completed: <span id="message-text">0</span></span>
                </div>
                <div class="info-item">
                    <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M12 15.2A3.2 3.2 0 018.8 12 3.2 3.2 0 0112 8.8 3.2 3.2 0 0115.2 12 3.2 3.2 0 0112 15.2m0-8.2C9.79 7 8 8.79 8 11s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4m0-5c-1.11 0-2 .89-2 2s.89 2 2 2 2-.89 2-2-.89-2-2-2M7 2C5.9 2 5 2.9 5 4v16c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2H7zm0 2h3.18C10.6 4.84 11.26 5 12 5s1.4-.16 1.82-1H17v16H7V4z"/></svg></span>
                    <span>Events Recorded: <span id="event-count">0</span></span>
                </div>

            </div>

            <div class="controls-section">
                <div class="control-row">
                    <button class="btn btn-primary" id="record-btn" onclick="ahk.RecordButtonInvalid(event)">
                        <span class="icon" id="record-icon">🔴</span>
                        <span id="record-text">Record</span>
                    </button>
                    <button class="btn" onclick="ahk.playEvents(event, true)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M8 5v14l11-7z"/></svg></span>
                        <span>Play</span>
                    </button>
                    <button class="btn" onclick="ahk.clearRecording(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M9 3h6l1 1h4v2H4V4h4L9 3zm-4 4h14l-1 14H6L5 7zm4 2v10h1V9H9zm5 0v10h1V9h-1z"/></svg></span>
                        <span>Clear</span>
                    </button>
                </div>

                <div class="file-controls">
                    <button class="btn btn-wide" onclick="ahk.saveRecording(event)">
                        <span class="icon">↓</span>
                        <span>Save</span>
                    </button>
                    <button class="btn settings-btn" onclick="ahk.showSettings(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M12 15.5A3.5 3.5 0 018.5 12 3.5 3.5 0 0112 8.5a3.5 3.5 0 013.5 3.5 3.5 3.5 0 01-3.5 3.5m7.43-2.92c.04-.34.07-.68.07-1.08s-.03-.74-.07-1.08l2.32-1.82c.21-.16.27-.46.13-.7l-2.2-3.8c-.14-.24-.42-.32-.66-.24l-2.74 1.1c-.57-.44-1.18-.8-1.86-1.08L14.5 2.42C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.41 2.96c-.68.28-1.29.64-1.86 1.08L4.5 5.37c-.24-.08-.52 0-.66.24l-2.2 3.8c-.14.24-.08.54.13.7l2.32 1.82c-.04.34-.07.69-.07 1.08s.03.74.07 1.08L1.77 15.91c-.21.16-.27.46-.13.7l2.2 3.8c.14.24.42.32.66.24l2.74-1.1c.57.44 1.18.8 1.86 1.08l.41 2.96c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.41-2.96c.68-.28 1.29-.64 1.86-1.08l2.74 1.1c.24.08.52 0 .66-.24l2.2-3.8c.14-.24.08-.54-.13-.7l-2.32-1.82z"/></svg></span>
                        <span>Settings</span>
                    </button>
                    <button class="btn btn-wide" onclick="ahk.loadRecording(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10 4H2C.9 4 0 4.9 0 6v12c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-10l-2-2z" fill="white"/><path d="M2 10h20v8H2z" fill="rgba(0,0,0,0.25)"/></svg></span>
                        <span>Load</span>
                    </button>
                </div>

                <div class="icon-only-row" style="display: none;">
                    <button class="btn btn-primary" id="record-btn-icon" onclick="ahk.RecordButtonInvalid(event)">
                        <span class="icon" id="record-icon-icon">🔴</span>
                        <span>Record</span>
                    </button>
                    <button class="btn" onclick="ahk.playEvents(event, true)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M8 5v14l11-7z"/></svg></span>
                        <span>Play</span>
                    </button>
                    <button class="btn" onclick="ahk.clearRecording(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M9 3h6l1 1h4v2H4V4h4L9 3zm-4 4h14l-1 14H6L5 7zm4 2v10h1V9H9zm5 0v10h1V9h-1z"/></svg></span>
                        <span>Clear</span>
                    </button>
                    <button class="btn" onclick="ahk.saveRecording(event)">
                        <span class="icon">↓</span>
                        <span>Save</span>
                    </button>
                    <button class="btn" onclick="ahk.showSettings(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M12 15.5A3.5 3.5 0 018.5 12 3.5 3.5 0 0112 8.5a3.5 3.5 0 013.5 3.5 3.5 3.5 0 01-3.5 3.5m7.43-2.92c.04-.34.07-.68.07-1.08s-.03-.74-.07-1.08l2.32-1.82c.21-.16.27-.46.13-.7l-2.2-3.8c-.14-.24-.42-.32-.66-.24l-2.74 1.1c-.57-.44-1.18-.8-1.86-1.08L14.5 2.42C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.41 2.96c-.68.28-1.29.64-1.86 1.08L4.5 5.37c-.24-.08-.52 0-.66.24l-2.2 3.8c-.14.24-.08.54.13.7l2.32 1.82c-.04.34-.07.69-.07 1.08s.03.74.07 1.08L1.77 15.91c-.21.16-.27.46-.13.7l2.2 3.8c.14.24.42.32.66.24l2.74-1.1c.57.44 1.18.8 1.86 1.08l.41 2.96c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.41-2.96c.68-.28 1.29-.64 1.86-1.08l2.74 1.1c.24.08.52 0 .66-.24l2.2-3.8c.14-.24.08-.54-.13-.7l-2.32-1.82z"/></svg></span>
                        <span>Settings</span>
                    </button>
                    <button class="btn" onclick="ahk.loadRecording(event)">
                        <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10 4H2C.9 4 0 4.9 0 6v12c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-10l-2-2z" fill="white"/><path d="M2 10h20v8H2z" fill="rgba(0,0,0,0.25)"/></svg></span>
                        <span>Load</span>
                    </button>
                </div>
            </div>

            <div class="hotkeys-info" id="hotkeys-info">
                <span class="hotkey">Ctrl+R</span> Record • 
                <span class="hotkey">Ctrl+P</span> Play Once • 
                <span class="hotkey">Ctrl+L</span> Loop Playback • 
                <span class="hotkey">Ctrl+A</span> Stop Playback • 
                <span class="hotkey">Ctrl+D</span> Exit • 
                <span class="hotkey">F2</span> Pause/Unpause •
                <span class="hotkey">Ctrl+H</span> Auto Clicker •
                <span class="hotkey">Ctrl+G</span> Draw Menu •
            </div>
        </div>

        <div id="settings-panel" class="settings-panel" style="display: none;">
            
            <div class="settings-content">
                <div class="settings-col">
                    <div class="settings-inner-box">
                    <div class="settings-section">
                        <div class="section-title">Webhooks/Misc</div>
                        <div class="keybind-group">
                            <label for="setting-webhook">Webhook URL:</label>
                            <input type="text" id="setting-webhook" class="keybind-input" onchange="ahk.updateGeneralSetting(event)" placeholder="Webhook URL">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="setting-speed">Speed:</label>
                            <input type="text" id="setting-speed" class="keybind-input" onchange="ahk.updateGeneralSetting(event)" placeholder="1">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="setting-clickdelay">Auto Click Interval [ms]:</label>
                            <input type="text" id="setting-clickdelay" class="keybind-input" onchange="ahk.updateGeneralSetting(event)" placeholder="100">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="setting-guiupdatethrottle">GUI Update Throttle:</label>
                            <input type="text" id="setting-guiupdatethrottle" class="keybind-input" onchange="ahk.updateGeneralSetting(event)" placeholder="2">
                        </div>
                        
                        <div class="setting-group">
                            <div class="setting-description">Created by: spade0740

Message me on discord
with any suggestions or
with any issues you may
have!</div>
                        </div>
                    </div>
                    </div>

                </div>

                <div class="settings-col">
                    <div class="settings-inner-box">
                    <div class="settings-section">
                        <div class="section-title">Keybinds</div>
                        <div class="keybind-group">
                            <label for="keybind-record">Record:</label>
                            <input type="text" id="keybind-record" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^r">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="keybind-play">Play Once:</label>
                            <input type="text" id="keybind-play" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^p">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="keybind-loop">Loop Playback:</label>
                            <input type="text" id="keybind-loop" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^l">
                        </div>

                        <div class="keybind-group">
                            <label for="keybind-stop">Stop Playback:</label>
                            <input type="text" id="keybind-stop" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^s">
                        </div>

                        <div class="keybind-group">
                            <label for="keybind-autoclick">Auto Click:</label>
                            <input type="text" id="keybind-autoclick" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^h">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="keybind-exit">Exit:</label>
                            <input type="text" id="keybind-exit" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^d">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="keybind-pause">Pause:</label>
                            <input type="text" id="keybind-pause" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="F2">
                        </div>
                        
                        <div class="keybind-group">
                            <label for="keybind-drawmenu">Draw Menu:</label>
                            <input type="text" id="keybind-drawmenu" class="keybind-input" onchange="ahk.updateKeybind(event)" placeholder="^g">
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            
            <div class="settings-actions">
                <button class="btn" onclick="ahk.saveKeybindsToFile(event)">
                    <span class="icon">↓</span>
                    <span>Save</span>
                </button>
                <button class="btn" onclick="ahk.resetKeybinds(event)">
                    <span class="icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="white" xmlns="http://www.w3.org/2000/svg"><path d="M17.65 6.35A7.958 7.958 0 0012 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0112 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg></span>
                    <span>Reset</span>
                </button>
                <button class="btn" onclick="ahk.showSettings(event)">
                    <span class="icon">←</span>
                    <span>Back</span>
                </button>
            </div>
            
            <div class="settings-message" id="settings-message"></div>
        </div>
	</div>
)'

css := "
( ; css
    html {
        /* Set a base font size for responsive scaling */
        font-size: 16px;
        font-family: 'Asimovian', sans-serif;
        background: #030908 url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAGBBVADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8sutFIOenWrMlsI4UIJLHt2rqSuOxAAaWpLeHzX2nI4zxRcReRMyDPy9zTtYLETHmkooqhBjNWLW2WV8OGxjPAptnALhiCSAP7tTteGH92FGF45oS7lIk+wQn+9/31S/2dCf73/fX/wBao4rwyTKuxQGOCeeKvAZFUuUpJFYadDj+P8//AK1J/Z0Oed+PZv8A61XEHHA9q0rDSRfRSM7vEVIAG3OeM5osi1G5jXGiRwqGKyJk4Gen8qg/suPuX/Our8S6ob2xgjeIKVk3cNnPymuftoftUpjOEGM5z/jSshyjFOyKq6XGc4Y/99D/AAoOlR/3j+f/ANatI6SRn96p/H/69H9lesg/z+NHKhcqM0aVF/eP5/8A1qBpMRH3j+f/ANatE6Vu6SD8v/r0g0cjP7wfl/8AXp8qDlM8aRGerH8//rUv9kxf3j+f/wBar40f/poPy/8Ar0f2OP8AnoPy/wDr0rC5TP8A7KiH8X6//Wo/suPpk/n/APWrQGjZz+8H/fP/ANel/sYf89QP+A//AF6LIOUzxpMXqf8AvqlGlRf3j/31/wDWq/8A2MP+ev8A47/9el/sXn/W/wDjv/16dkHKZ/8AZUXdm/76o/siH+8fzrR/sMkH94f++f8A69SL4aLqD52M/wCz/wDXoUQ5fIyv7Ii9T/31/wDWpDpEYzyf++v/AK1ax8LHP+u/8h//AF6Q+Fj/AM9h/wB+/wD69HKLlMr+yIsdT/31/wDWo/smL+8fzH+Fan/CLN/z3H/fv/69OHhj/pv/AOQ//r0+VDsuxlf2REP4j+Y/wo/siL1P/fX/ANatX/hGP+nj/wAc/wDsqD4Y/wCnj/xz/wCvS5Qt5GT/AGTF/eP5/wD1qBpMWfvH8xWt/wAIzx/x8D/vj/7KkPhnqPtH/jn/ANejlFYyxo8X94/99Cl/seL+8f8AvqtMeGc/8vAz/uD/AOKo/wCEZH/Px/45/wDXo5fIFEzDo0R/iP8A31/9aj+xov7x/wC+v/rVpDwyD/y8f+OD/wCKoPhZSf8Aj4/8c/8AsqOXyHbyM0aNF/eP/fX/ANalGjRc5Y8f7X/1q0D4WH/PwP8Avj/7Kk/4RcdPtA/74/8AsqdvInlM8aNERwzfmP8ACj+x4v7x/wC+v/rVf/4Rhf8An4H/AHwP/iqD4aA/5eB/3wP/AIqly+RVjP8A7Iix94/n/wDWpP7Ii/vn8x/hWj/wjQ/5+B/3x/8AXpB4azx9oH/fA/8AiqOXyCxQGjxf3z+Ypf7Hi/vH8/8A61aH/CMf9PI/74H/AMVQfDGP+Xgf98f/AF6OXyEl5Gd/ZEX94/8AfQ/woOkRf3//AB7/AOtV/wD4RjP/AC8D/v2P/iqD4XwP+Pgf98f/AGVHL5BbyKH9jRY++fz/APrUf2PDn75/P/61Xh4XP/Pcf98f/ZU9PDBA/wCPhef9j/7KhR8hW8jO/siH++c/X/61J/ZEX98/99f/AFq1D4ZJbP2kD/gH/wBem/8ACM5P/Hyuf9z/AOvRy+Q0jO/seE4+c/if/rUv9jwj+M/99D/CtIeF8j/j5X/v3/8AXpv/AAi3J/0kH/tn/wDZUcvkOyM7+x4j/Ef++v8A61KNFi/vH/vr/wCtWh/wjGf+Xgf98f8A2VH/AAjA/wCe4/74/wDr0cvkCRQGixf32/76/wDrUDRYf7zf99f/AFq0B4XBH/Hx/wCQ/wD7Kj/hFsdLj/yH/wDZUcvkFjO/saH+8f8Avr/61J/Y8I/jP/fQ/wAKv/8ACKnn/SR/37/+ypf+EUJ/5eR/3x/9lRyeQvkZ/wDZEJ/jP5j/AAoGkQ/3z/30P8K0R4Sx1uR/37/+ypD4V2n/AI+h/wB+/wD69Pl8gSv0KH9jw/3/ANf/AK1H9jw/3j/31/8AWq8PC2R/x8j/AL9//Xpw8Lf9PI/79/8A16LeQrW6GcNIhJ++f++v/rUHSIf75/P/AOtWmPCX/TyP+/f/ANlSHwsF/wCXkf8AfH/2VLlHbyM0aREf4/1H+FC6RDk/P+o/wrR/4RkdPtI/79//AGVIfCwyT9qHP/TP/wCyo5Q5TOOkRf3z/wB9f/WpRo8R/iP/AH1/9ar3/CLLn/j5B/7Z/wD2VL/wiw6C5/8AHP8A69HL5DsUP7Hh/vH/AL6/+tQdHi/vn8//AK1Xx4Uyf+Pkf9+//r07/hFQv/Lxn/tn/wDXo5fIVjN/siLP3z+f/wBak/smIfxn8/8A61af/CMYI/0gZ/65/wD16b/wi+f+Xgf9+x/8VS5fIXKZ40iL+835/wD1qT+yYv7x/Mf4Vpf8Itk/8fA/79//AF6QeF8H/j5/8h//AF6OXyDlM86REP4z+YpP7Ji/vn8x/hWl/wAItz/x8f8AkP8A+vQfCv8A08/+Q/8A69Plv0GZo0mLu5/MU7+yIuz/AKj/AArRHhTjm6/8h/8A2VOHhME8XQH/AGz/APsqOXyC3kZo0eL+/wDr/wDWpf7HhP8AGfz/APrVpDwoB/y8j/v3/wDZUf8ACKD/AJ+h/wB+/wD7KjlHZdjKOkxAn5j7c0n9kxf3j+f/ANatX/hFgTgXQGP9j/7KnDwuRx9p/wDHP/r0+UVl2MkaVFjhj+f/ANak/sqIfxH8/wD61bX/AAi3rc4/7Z//AGVIfC4/5+f/ACH/APZUuUdl2MX+yov75/Mf4Uf2XF/fP6f4VsHwwB/y8/8AkP8A+vSHw1/08f8Ajn/16fIgsuxkDS4/7x/P/wCtSjSo8fe/X/61av8AwjnPM/8A45/9elHhzI/1/wD45/8AXpcoW8jK/smL+8fz/wDrUn9lRZ+/+ta3/CN/9PH/AI4P8aX/AIRof8/H/jg/xo5Q5UZP9lRf3v1/+tQNKiz94/n/APWrVHhoEf8AHzj/ALZ//ZU4eGV/5+f/ABwf/FU+UXKZX9kxYzuP5/8A1qb/AGTDn7/6/wD1q2P+EYBX/j5x/wAAH+NA8MZ6XGP+2f8A9elyjsY40uE/x5/H/wCtR/ZURP3sfiP8K2R4Vyf+PoD/AIB/9lSnwqACTdD/AL9//ZU+UXKYn9kxf3z+f/1qQ6TF/eP51t/8IupH/H3j/tl/9lTW8LgdLoH/ALZ//ZUcq7D5fIx/7Kizjcfz/wDrUf2TF/eP5itj/hFz/wA/Q/74/wDsqQ+FyRxdAf8AAP8A7Klyhy+RjnSov7x/P/61H9lRZ+8fz/8ArVr/APCMHj/SR/3x/wDZU4eGiD/x8j/vj/7KnyoOXyMf+yoh/Efz/wDrUg0uL+8fz/8ArVtf8I2f+fkf98f/AGVH/COc/wDHwP8Avj/69PlQ+XyMYaTF/eP5/wD1qd/ZEX94/n/9atf/AIRwnrcD/vj/AOvSjwzj/l5H/fH/ANlS5ULl8jH/ALHi7sfz/wDrUv8AZEX98/mP8K1W8Lgn/j5A/wCAf/ZUn/CLD/n5/wDHP/sqXKhcvkZX9kRf3j+Y/wAKP7Ih/vH8xWp/wi4H/LwD/wAA/wDsqQ+GM/8ALx/45/8AXp8o7Gb/AGRD/eP/AH0KP7Hh/vH/AL6/+tWifC4/5+R/3wP/AIqk/wCEWB/5eR/3wP8A4qly+QcvkZ39jwj+M/8AfQoGkQn+M/8AfQrRHhUEc3I/74H/AMVR/wAIqCP+PkD/AIAP/iqOXyDl8jP/ALHh/vn/AL6FIdHiH8Z/P/61aR8JD/n6H/fsf/FUn/CJf9PQ/wC/Y/8AiqXL5Ct5GaNHh/vn/vr/AOtS/wBkQ/3z+f8A9atH/hFB/wA/QH/bP/7Kj/hEx/z8j/vj/wCyp8vkFvIzv7HiP8Zx9R/hSf2PF/fP5/8A1q0x4W7fah/37/8AsqP+EXx/y8r/AN+//sqOXyC3kZv9jxDq5/76/wDrUv8AY8WOHI/4F/8AWq+fC3/Tyv8A3x/9lTf+EXx1uB/3x/8AZU+XyHbyKf8AY8R/jP5j/CkGjRZ+8fzH+FXj4aXHE/8A47/9ek/4Rsf8/H/jn/2VLl8hW8iidGhH8bfn/wDWpP7IiH8R/Mf4VoDwyDnNx/44P/iqcPDK/wDPx/45/wDXo5fILeRm/wBkRH+M/mKUaNF/fJ/H/wCtWh/wjQ/5+P8Axz/69OHhsf8APx/45/8AXo5fIdjNOjxf3z/31/8AWo/seL1P/fQrT/4Rof8APx/45/8AXpf+EZH/AD8D/vj/AOvRy+QWRl/2PF/e5/3h/hR/Y0f94/mP8K0/+EZx/wAt/wDxz/69KPDX/Tf/AMc/+vRy+QWRlf2RF/eP50v9kRep/wC+v/rVq/8ACMg/8vH/AI5/9lR/wjXfz/8Axz/69HL5BYyxpERH3j+Y/wAKP7Ih/vH8/wD61an/AAjX/Tb/AMc/+vSHw1n/AJb/APjn/wBejlCxlnSIv7x/P/61INIi/vH/AL6/+tWoPDX/AE8D/vj/AOypf+Ea/wCngf8AfH/16OVBymX/AGPD/fb8/wD61N/smHGd5/P/AOtWwvhnI4uP/HP/AK9KPDWB/wAfH/jn/wBejlQcqMb+yYgfvH8//rUh0qIDO4/n/wDWrZPhon/l4H/fH/16B4bwP9eP++P/AK9HKLlMcaXF/eb8/wD61J/ZcP8AeP5//WrdXw6MDNxn/gA/xpJPDCSYzc4/4AP8afKPl8jE/syH+8fXr/8AWo/suI9z+f8A9attfDQCgG5Bx/0z/wDsqT/hHP8Ap4H/AHx/9elyhYxv7Ki/vH8//rUn9kxf3j+f/wBatoeHCf8Al4H/AHx/9lTv+EbB/wCXn/xwf40cqFymJ/ZMX94/n/8AWo/sqL1P5itv/hGF/wCfn/xz/wCvSHw0o/5ef/If/wBejlDlMUaRET94/n/9al/siHPLN+Y/wrY/4Rtf+fr/AMc/+ypB4dUf8vI/75H/AMVT5UHKZI0iHjLP+Y/wpDpEI7t+Y/wrXPh8ADFyM/7v/wBelj8PCQkfaBx/s/8A16XKh8phtpUQ/if8x/hSDS48Dlvz/wDrVvnwsDz9o/8AIf8A9eob7RBZ2qsJt53AbdmOKOQOUwPsH+kBMNs/vfhU402MfxN+lb1rfvPDFYhVCsmwvnJH4VW1CwOnSxoZA+9d2QMe3SoUbaMbhpdGV/ZseOrEfX/61B06L1P/AH1Vh8lGx6VBp+kPqHmkEqIyASFJ6/8A6qfKtkZ9SF7BM4XP/fQqq8ZQnjgGtyLw1k5afaAf7lQXNiEke3352nrik4sOUyRRUk0PkuVznHemVmRYKKKKdwCiiii4EttIInJYEj2q1ckeQjjoen5VQBqxLOjwIgPzDGR+Fap2Vir2GxTeW+/bu4ps8vmzM/TPao8ndzVy1VWhGVBPPap3Gin19qbznFWmUfbI1wACRxV0QxDrGv5UrMVhVG0ggc1s6XoTQuZZZIpVkUkKBkjv3FYAbyOZGzk9etadhr8ULjzJG2qMBQpPp2raNuoxuq6YIL15VxjdkKowB0qGFvPnWJB8xJ5P+fatAajDqt+I48sZCANy47d+tWbfSzZXRu3VNiB2KqcnpQ7dDWEG9ehFb6RLgMzLgfNhcnGOabq2prqjRuiumwEfMfp0xUWo6iLyWNrcyRKBs5O3qeOlV5wtggE3zFuRtGfSpG3Z2RWuZGgj3MN3OPSqck3nYwuD9c1csdLk1m7lSDaMAyYY4yB2HvzXaWmmxxWcKPFGZFQBsqDzXLUrKLsenhMvqYq72Xc5K18PzXVtHMJI1VxnBBzUx8OSqP8AWx/rXV/ZlRQqAKoHAUYxTHiAUisVWZ7ayqko67nLf2DJniRP1oOhS5x5kf610XkEU1osGtlUfc55ZdBdDnjoco/5aJ+tJ/Yr/wB9PyNb5T2rU8O+DdV8WyTppVobt4FV5AHVdik4ByxAOa057dTD6jG9kjjP7Hf/AJ6L+Rpf7IYf8tF/I10GqaXc6NqNzY3kRgu7dzFLESCUYdRkcfzqqV9qpSvqmZPCRWjMn+yX/wCei/kaT+yn/wCei/ka1tuaXyzTuR9VgY7aXIOki/rXcD4PXqeAh4oOo2htzCJvICvv+/sx0xnNc8I8kd69J8I+JrnxRY6Z4HuY7a30yYiB7kMUkChi+dzNtzkenPSuTEVKkEpU+m/oezluCwtWUoV92vd9TyUaZJ/fX9aedKlH/LRf1r234jfs+ax4R02TX9K07UbzwrBZx3M2sTGNoNzyiMKrrgN8zIMDJ5NeVmP6VvSrqrHmizlr5csPN05rVGIdLl/vr+Zpp0yT++v61tiFmRmOBiomiNbqRyPCRSvYxjpcmf8AWL+tIbCQE/OP1rVZTnmo2QHPrTTOeVCKM37E/wDfH5GkNi5/jH5GtAoR2IppBHHeqMvZIzzZuD94fkaT7K3Tev61ecHNMZCD0osR7NFP7O/98fkaQ27f3h+Rq2U9RimleelCRLgit5DD+IfkaPJY/wAYqcpz60EFetNJE8liAwt/fBpfIb++v5GpRSnJ7U7InlIDC395fyNAib+8KmwaCDntTsOxF5Lf3h+VAhb+8PyqQU7PSiyBkJhfOdy/lSeS3qtTk5ppJJ68UrILIgNux7r+VHkn1FTknAPaosnFOyCwnkN1yKUQn1/Snh+eeleu/Ar9mDx1+0bHrDeCrWyujpMkCXgvLxbfYJhIUYbhyv7pgccjI4oskrsTsjx8Qnsf0pfJJ6N/Op5ojBM8bfeRipweMg4696bS5ULcj8k+o/Kjyjj7w/I1ICPWnEA07IZF5bDuPypDGxH3h+RqU4xSDA470+VDRGYSe4/Kk8o5+8KmPGKAMkDqTxTsFkReUR/EKPKIP3gPzrQvNIu9OjR7iExq/CncDn8qp9aTihbDPIOPvCk8s+tSc4ooshjAh9aURnHX9KdmkyM4zSYxuwnvSFPcVJSZosAzyz7UoT3pwyT04pM0WANp/GmmMnvUi8g9qNposKxF5Tf3hTTCxP3h+VTkYoA4osJxsV/Ib+8KXym9anOc00g4p2QJIjERPO4UvlH1FOTI64pw60cqDlRH5LZ6igRkHlhTySTwaQ55zRyodhpi9x+VJsOOtSnpTB0qWgsN2e4pNuO9SHoaTIIpBZDMU7yz2IpcCnKcCmgsM8pvUflTdjeoqbPNIfmHFFhWI/LJ70vlmnfd4JoL496LAJ5Z9aBGc9afuoBzTsA3afWjafWnE4xSZwM0WKsJjFAFKBu5pQQDiixI3HtTwdpB4oppPaiwyTzVP8NIZFP8NNRC7hR1PAr1L42fs0+Nv2f7bRZvGFvY2w1d50tBaXizlvJEZdjjoP3i479eKVlswvZ2PL/MA/hoMyj+Gox0oIzVcqGmyT7Qv939aPtA/un/AL6/+tURHFN55osguyfzx/dP5/8A1qQygjp+tQ/zpcZosguyXzR6f+PU4Sg9B+tQg4py0WQx5JOO1NIPtTunekPNKyEIBjpzRjmloosA0jJowadSA8mlYBmOMUcilJ5op2ATNBOec0GhT69KdkAcn0ox9KPpTumMnFHKgEEW7oRR9nJ/iH5U9WGOKcORT5UIh8hsfeH5UGE4zuFTUYosgsQ+TnuPyo+zn+8PyqYDFFCihWIDbt/eo+zt/eX8qnop8qAh+zn+8v5UnkN6j8qsY/OkPFPlQiDyG/vCjyG9R+VWM4pOvNLlQEHkNj7w/KkMDf3h+VWBxSHGaXKhohELY+8PyNKIW/vD8jUvAozSsgRGYWz95fyoELf3h+tS559qAefanZBa5D5Ddd9OWMjHNSnp1ox0o5UCViPyz60eWfWpe3FJjgetLlQrkfkkgc0nkHnn+dTDgAUhJH5U+VFX6kPkn1pRCT3qQZIznFLjpzk96dkNakflf7VJ5PvUo70lLlQ+VbkXle4pfKPrUowSBQVxz2p8qCyRF5ZHegRE96l/lQcY6c0cqEkQmHP8Q/Kk8hiOCPyqYHNHbNHKgSIfIPHIo8k+oqXcPelBzRyofKiOB/skwkbLL0IA71sC6Bs45sHDHhe5rKKhsZAP1pLZ/s8mZWYwc4XO4D8KTVjOUbFqWNizXYA2KN209enpVmx1G2aFoSrb3BX7vr071QZjua4DN9lLcKD2/wB2llQzRG6iIRAB8uMHIrFq5KfKR39k9htViHLLnK5xW78N4YZRqnnRrJt8rG4f71ZFrdwnd9qJck4XcN2KhVb3QH+Scp5vJ8lyM49fzpRdmrkSjfVHS3c2AUA6ZHc965m7GdSnP+0f5Vf1DVbe4tIkhfM2/c7AYzxzz9aymbcSScseTmtJu5KdtBlxCssbKAAx6Ej3qjLZPGhYsuBzx/8AqrQB6Ckcja2eRjmsXFMlox6Kmu2RmUxgY+mKhrJkMKKVVLnAqT7O6oWI49aLBYiooorW4hKuwkrZsRwQDVOpg7i2Kj7nNIBlu5e6jLHJ3AZrRHfNU7QRALIxw4ORlsVd8+LH31/OlEpK4jRrL94Zx0zSw2SyOVEYPelV1kzsYE+x6Vq3KW1rZLJDgXBxn5s1em5pGN9WJptvb2VzHLKixhSSH5ODg46U3VdQa6u3S3nbyGA2rnA6DNVBcyXPynL9wAPSkk8uGDe0mycHgZ5H4YPrQa89lyolhEFsAZ2Xk7lKg0/TdI1LxQzmBPPEOM5ZVwD9evSjTdF1PxFd/wCiWd1fRRsA5hiZgoPPOBweDX0X4e+D9pbzvBosgjM7/N5rNIFCjI5A98d68nGY2GHXLfVn1mRcPV81m58vuR3Z5hY+HINMRPLtlin2APg5IPGR1IqZrJ2DbEOPWuu8Q+H5NE1m5sZnWV4G2F04DcA9x71kNCqAjrXjRxDl7x+kSyyNBezirJGELR3AwpqB4AGII6VutCBgbcVVnsh1UZYnPWuqNW7POng2loY/kD+7+tNNpk5H6HNahsnOBtH50q2jZ5UY9yK2VY45YVvoYzQcEd61/C3irUvB09xNp/kh50Eb+bHvGA2eOnOagksnBOBx7c1A0BBPyt/3zW6qJqxwyw8oO60INXuZ9Z1W7v5wnn3MrSuEG0bicnArPaBlGWGBWo1ucfdOfpUT2+Ryv4E1vGp0OGphW9TO20FDV4QgE8D880pgRhyAPpWntDm+rsppA3sBU0cA4BGQexFTrEoUDt9amjiG7p0qXO+5tToNH2t4a1ey+Mv7J2kfBvwXcw618RHsLR20zDW6xxxXQnnJmlCx5VcAgNz2zXyH8Rfh3rXww8Y6j4Y8QQxW+saeyLcRQTpMqFo1cDepIPDrn8RW58LPiPffCnxZH4g01p0u47W4tUa2dUdRKmwsGZWAI+ldVd+BPEvxzn1rx7FGlvaTPcTXM93ceYd8MAd14BdmIXrjGTXIqsaL12O+OCnWbktfI4XwZeeG9O067GtWwuLl5Mxk2/mbV2jvnjmuMlQeYSowOfwrTNuzqOdpODgnkVDNZso7dq2ptKTknuTXhN01TcdjKaHLZNQeX7YrUktjkZXj61UlgAY8Y5rujM8KpQaKZUjqOaa0eTnPNWjFz0yaaVGcVspHG6bRWWIkcEAe5qLYQxzVzYPSoioJ461aMHBldlz17U0pxxVjZzSMnPQYpmTg9yts496aVwOlWQDzUZjwKCHEgZNwGMU3GPrU5jJJ700oy4yMULQzcWRcU0VKF5z1prR556U7k2I8fN7UuKUA49qAfWqJFApCKWgjikJGvpnhWfVdKnv4poUihLBkkJ3cDJxx6ViEBhkdKu22qXlpbPbw3UsUD53xI+FOevFVdtUMiC9ea7n4bfG3x18H0v18G+J7/wAOrfmN7oWUgXzjHu2bsjnG9/zNcSRjtSHNITVySaZ7meSaRt0jsWZj3J6009KZRmhhYeFB+tLtpit14pd+f/1UIYtJu59qQjilUbiFHWquA4EGgcNkeveh42iOGGKTt7UAXL/VbnUVRZ3DBOQAuMdKqDrSjoKQ9etQITpRRmigYYzit638I+f4ck1f7Twqs3leX6HGM/gawSMinLK6qVDsFIxtDHFUmluA2k2knOKdjB9aUdKhjSG5BFOAxRt46UoHamh2Ep5TABHNIABUsTAA59Mn6UMcY3ZAQQOlITkV0Nj4ej1fShLBIVucjIJ+UHPQ/hio9R8K+Q9vDBPumfhhJwM8dhyBz3rlWIhflbPUlluIUFUS0ZgE89fcUvWu5l0my8L6BIty5kuLlSFYR5+fb0GeQOa4g98cVdKsqjdkYYvBvC8qk9Xqxp+WkPOM0rcgc0gzXRc88Bj1oJxTWPB5puadwHHkUmMDrzQOlBosAuaQ9KaARzTs5BqbAIFzk0BuKUcDtSNyRRYBc/jQeKVO9OIzRYCKlHFKV5oPSgBQc9/wpOmcULyeOtaVrpIntBMZQuc8Y6fWk3bc1p03VdoozQeP8aWjGe1JgUzHqKDxSjGKQU7rQMQdKTPNFFAkAJUgg4INdd44+LnjH4mQWUHivxJqPiCOxaSS2GoTGXymkChyueRkIvHsK5EHmjrTDQBRRSZFVcLC00jk06gnigENIxSg0h60A4I9qBisCaAdpNKDkUhxmgSHKc5p1MXAp1SMWiiikAU0jvTqKAGAA/WjFOpaAGECjAxTsCkJ5xVgNBCnmnGmgYozjigBykEGnKx/pTW5oDYFAEh4GabuNJml3ZGBmgB1FIDxS00JigZpccCkBxQWp3JFHApDyMZpQc9aOvShgJtyOKQcU7HPtS5pXAZj8qMAmlPNGM0DE2jPWjgcUpBFKRSENo7cUpApAc+1BQUc+tFKBg00DAdAKd1pD1FIMDvSJbQp4+tA6UhOTSUE3YpOenSgdqSinctMCM9qXGeKSlB54o6lCDIPNKaRsmlHFNMbEopRz04ox0ouISl28Zp4GRRjHFAbEWRS04jHHWkAplXEpGVWGGwR70/BGaYeTQG4xZTDIFlP+i/3DyPXp9amHaVQPsePmUHj34qNlV+qg/WmpI8WI2IW1zyCOP8AGsmjKUbakk9v5zB7dQYwOe3P0NPtZ4bt2+3yfKv3M5GM9f5UrttcC0BMY+/s5/n7VFdW8RCfZgX652nOKxaM0+VjLywltG3vEywOSEYnIYdarj19a6LQ92uySwX7vNFCgZFzjB6dR7etU9Y0G50+SeQWrpZhyEcnI29qzUrOzNZ0G4+0itDKJAGewpGO6GTvlTTo1DEbuneiZVjVwgwu09DntWhyGQ5yRSUMTvpURnPAJPWsNyCeBPLYNIpVR3NSzzxvGQrAnjgUuwPGFPb0qnMoSQgZwDxWi0VhsbRRRQIKtKP9Cb6H+dVatKP9CahjRSwTgDrTxG2O+PpTrfPnJ25rQQ5Bzz6VMUNIu+F9OS7W6LMV27cED60l6Au9AchWxmtHw0oH2v8A4Af51QfmaQ9fmPP40R3sdrjFU423KcNwbWRZVAZhkAGuj+HfhqH4jfErw/oV5cvYwapexWslxCoZogxxuAJwce9YEgEh24JPUcV0/wAImFv8UtAMheMJeI/C5I49DWdebp03JdC8HQ+sYmnR/maR+lXwL/Yi8JeF/DOs2cHi6/vL3UZoXimmtokNvsVgRtDHdkuec9hxWL8Yfga3wb17SEOqyait3FK6SMixNHt2qRxnrury2z1tJLu2OZgqSRyE5CthWBOMHrgeuK+3Zf29PBckarL4U1uTbgZ22xH6y18L7Sli+Z1Wos/oB4HOOHZ0oYCDq0mtV2Pz68T+Hra/1m/uriZ97yt91hggAY7Vx974bKXL+Wk4t93DYB4+pr9cvhf8V/Dnx90zWTpXh65sBZ7YS9/FEQzOhIxsZunGc+tfCnx0/Z+u/g9fadY6hrFvqE19bzXAa3gMSx7CB/ExznIPaidKVGCqQlzRPQy7OKGZYiWCxlH2VVdG9z5YlTEjBclQSBkdq9O8AfAn/hOvBr+IpNcSwiS4mtzbCyMrkxqrE7t6jncOO3vXEaxoR0q5VGuA5cFuAOOcVf8ADmtaxp8kVhY63d2VtNLhooLlkTLYDEqDjJA59hV+291NMKuX1faciVjkAuOMfhU9pafabyCD7vmSKhOM4yQM4/GvT9R8CxaGI5RHHIHfaMx7cD17jt7fSoU0coylVQYORtVeCOhrKWM00PWpcPylrOSMP4hfDBfBVjZzi/N61zM8ezyQu0KM56mvPngAzlcDPWvdtXtLpbS28+/luDIC2HbOzgev1rktS8ILe/OZm3Z3DGD2Haijj2vdmGL4d5lz0d+x5dJagliFz6f5xVdrb/YGfp/9auov9Be2maLLTSB9vyrxgcZ4rMaxkQEuhQdOeD/KvYp4hS1TPiMTls6TakjFNv14HvSGLJyCOPetRrUgcA5pn2QqOg/KutVkePLBvojPWE8cinCHHPFaIteB0z9KkW0I6EY754p+2Q4YJt2KUVtuPYmvW/h98ddX+H/gO88J2Wl6Zc6fdm4Mstyshkbzl2sDtYDgdBj8685t7EyzIuQcnHNbcXhi5mfC+UeeAHJ/pXBXqxkkpHvYLL6u8I3PSPBGhaVc/CvU5pdNsJrqGC8KTSwRmUYj+Q5IzkHkV4lPZ5XiNu3OK+tfgZ4f8J6t8Odc8F6x4aWbxvq872mm65LArRWyyxokR3lt2VYOxCqTgjn08r+L/wACNW+EPik6Fqt7aXcxt0uRNZFzEyMWA5ZQc/Ke1c9OTpXnzXTNKiWKqLDSp8skvvt1PEXsw43FWAHtVGa1yAFU56/54ro54AoIyccgc1Rlg7gEAV60K7Z8/icAo9DBa3Ck7kOeveoHhP3vWtqS1DNnPP1qlLAQxBxjNd0K12fOV8Ly9DOZWXjjH0qHaOK0Gi47Z+tR/Z/c/wCfwrrjUPKnQZSwfrSOjEg4q2Y8EimlOD1rVTOd0mUyvqKYy9atMgOOM0xgApFWpGLp23KpTH+NMZc9asEY45pjL14qkYONiApn6UhXGe4zjNaGjyW9tq9pNeIXtY5VaVVUPlR1GDwePWtfxzqujazqNvLolmbG3WAJJF5Cx5fcTnAJB4IFO5m4XVzlj0qIrg1O0ZAPPFPsvKXULb7R/wAe4lXzf93PzfpTuYtWKvbPaitfXzp5uEGnbfJwc4BHOSe/NZJGKq5m1YSiiiglhTWICk9acelMoBHceL/hmPC3hHTtcGpfaftvk7YDAF2h0Zid249NuOneuEAwfWrl1rN/fW6W9xfXM8CYKxSysyrgYGATgYBIH1qoOKbsMXA9aMZ9zSMQgG5gufU04f8A16VwEUHbzS52kEdqWimAPKZDknJFFRsCT0pVFDAf2oAGKTFKBmkNC7c96CoIpelB9qB2EHFAOeKCp9TTgOR7UrhyiAYHWnelBUD2pQuSOKNDSw4AUhFShMjj9KQxkDJ/Wpckty40nLYh/wA81oaHok+v6hHZ27xxyyZwZDheOT+n8q1L3TdOi8KwXUYxevt5355yc8fh6UzwbDIfElg0d4ti0cocSk88dQPcjPpXPOtzUpSjo0etSwPJiKdOfvKVtjq77RLXwBaLBNeJJO6+bsYDJOMYAHOD68VwN/qEl9cJNIFWReQ0ahTnNdh8TLDUZ7i11O4lkubaVmiilMJROPmwD0PU5x6Vwr8fSuTB0uaPPJ3bPTzrETpVfqsFyxjsiS+vrjUZvMuJXlfGNzHPFVcVIetMbrXppKKsj5OcnN3k7saeBSfjQTziirMrDGUdqb3qQjim0CGjilAyTS0UXsAm33pSuOabzmnqMLzQA0DPejaKeKXFO2ghoFOoxSHOOOtIYhFNPtTsEgcVr6F4YvdduEEcLi33YeYr8qjPPPepnJU480nodFChUxFRQpq7Zirz9KsIzCLbk7SclQeK7XWrfTfDGjNpznzZ5lLqzRDLnoCcdMY9TXDo+evBrClW9sm7HZjcG8DKMHJOXVLoKRTDUhGaYwOa6TymNpQOBR0FLuFArjeppeKQ8tmnAYp3HcbjFFFKOtIYgGDzQBinYFNbjFACAYNB6UY4xRimA2inAUh60/MBKWgDNKeMUIDQ0y0tZ4ZWuJdjA4UbwM8VRAyc00YNPGCKpgLRRRUAFFFB7UhXuIcAcsB35IFOII/pX0t+xx+0B8Mfgla+LYPiR4Hk8ZR6m9m9isenWl15Bj83zDmcjbnemNuQcZPQV88eIbq0vde1K4sEkisZrqWSBZQA6xs7FQ2OMhcDA44pJ6gjPpMDOaWimMKZT6KYDcGl4PalXqc0pXIFAEdOHSjb7UtIBM04GmHrSVd7CsS0UzfShxQKw6lzTdwoDDHJA57mqEKeaKBzg+vP1opAKOacoGKRetKCBRsApHHrTCMU7ORxxSbQKRVhMUUpGansLRr+9gtlYI0rhAxGQMn0pglYrilBzWn4h0GXw9dRwSSLIzruBVSOM46H3rL7GiwBjNJSg46Umc0WMmgPSl5+tJTSccCi4KWg8jn1pKVegpcc0hrXUQdaCKCMUDmg0QAZNDDaOKUfTFB9aAQ0Giilximih6fdp1NQcUnNC3EPppHWlHSg9KoBhyDTeD0pzqR1BH1ptA07DRxn1oKh1welOxRQDdyNbh7M7VAKnrnJ9qsOFsQpgzJu+8Dz6elMwCvqMVJoZwbnHGQv9awno0YzQzStWk0qeeREV2kXbhs8c57V193df2xpMMEhVd6ozeWe+M964J873Bz1Na+jXy+aoCDIU5I78Vzyim7m9HESjF029GUtRhFrdyQLnapGM4z0qlM2In/3T/KtDV28zUJWA2g44/AVn3HET/7pq1sck7X0MsnBNWLPmQ/Sq7Dr6Zqa3lET5IJrJbmOxawd7dcCqk4/et9atHUQBjY351UmfzJC2MZrTRh0GUUUUhABmrSf8ebf571VHWrcYzZPz0/xoGiG2jJkVv4Qea0MZAHrVa1XKHHrWjZxqwO4AkU4lI0vDA/4+uM/c6/8CqhNxNJ/vGr/AIbYA3OfVP61TMbT3MqxjcQx7+9KO7O3/l3FC2QzdofQH+Vbngsi3+J+kyHtcRH+VZ2jwZ1ZIpB2bI/CrkR+zePLcqSu10II7fKKxxMealJHoZbJU8XSn2kj6JvtaksIY5IlUsSAQwPQ/THfFdR8LL7wn4lTWR4v8Uv4dnh8k2SRlEWUHdvyWVs4IXuOteK2+uXSwvGbiVo3GCrOSKru5YDB59K+EWESupI/o3E51UrNOlJrY9ksfFM1lfagug6rc/Z4pWRLi3uHjWUAnax2EZyK/QLwh8adJ/aP8K69ptvoUtlPaWiW7z34jbLSowyuMkAFc+/pX5g+DbtIIrqJ5VDsysBn/ZI/wr6A+B/xFvfh/wCJtPWHURp+m311bjUCUVleINgknaSMBm5FRTm6M/ZS+Fl5nlcM3wccbTX76Gt1/WuiPVfGv7J2ueJdcaWyvNGSCKKOLEu8sSBliQI+5z+leYan4Fm+E/iybw1qs9tPeTRxyh7RT5aiTIAJZQR6mvuDSvj38JbPzC3iG282VtzExynPPb5f5VkeIfHH7PnibWf7T1htKvtSVVQXE1pKXwvQE7ecVrLD0mtJL7z4ihxHmtGdqtCUkl/KeR+A/wBi3xNoOq297qc+jX8Ee4tD5jvvyuASHTHvXomt/szyX+g31vDouiJeSwMkUu1F2ORw2QmR+FU/iz+05pt1DaxeAPFS/aFuQtwnknOzb2EieuOlYng39oPxFba5aP4i1rzNJQn7Vi2UsV2npsXI5xzSvhIzVMtS4ixdH63e1tbWaenkeY+P/hXfeARp1lqcdq91Ijybrc71ABC4yQPbtXn+r+ANS14JJZNbQxKChWSQoSc+ymvsfV7nwb8c7O4vNLuP7X1HTYCgWPzIyhcMVBUgZyVrymw+Dvjea2UxeHL1VPJ3lEPbsWFceIwklP8AdK6PqMs4itQ5cbLkqLe+h85QfCDXjfx2wezEs24oftLYOB67auJ+zD4hvrgvLbaWQzZLvPk9v9jJr7F+G/wx0fQo7i8+ImkpbyxyIbR7pywHHP3GI6461V+J3xa+GHhnWoLDT9Ss7crCGdIYpCMknbyFI6DpWqw8qdPnk7Pt1OafEtTF4r6tQpcy/mtdH526v4RhtpSRBEjPOcqEJ2jngdBXO6loRikxDFvAG3he+fTHoPWvrrxz8KdP8YaZpur+CPDs+p2txO/mz2UbspAB4IY/3gRwBXmviT4KeKbbSZXPhq806NZFzLOixgDJwCck9xURrVU12PoYRwOKpvmkoy7dbnz1HpMzy7AhViM/MMVtaVoDRli4VgccdcfXNdhb+BJ7C8njuVImVMFMZIyc9+M4HatDQPDznxdpVncQ5tZ72CJ8glXVnXI/LNbzxEm+VHRhcsoUIOvV6GT4S8Ft4h8QW+n2aWyXTxySIZhgMVXOM4PPB/8ArVtHwjd6fq6WF3bx+ZDOscqxsWA5GcEcV99eFf2fPhhoWl6H4guNDttH1N3URyNdSxhZzuUKoLHk8gLXP6hf/s36brF5Brs2kxa1DK0d0CLnd5oOGyQME8CtHhZz+KaR8tHi2kpyWHw8ml2XU+VrhZdBhl1DTgbW+tQZ4biMfNG4+6y8HnjPSpvCtvq3x88a2Fpr1wdW1m8jMUd3fnGI0BcBtoHGN3bvX1G+s/svXULxtf6WAwKkGS6XII5FJ4ctPgZPrMcfw0nsF8etFMNHMNxcOfP8pugkOz7obrxihYJpW9omvI5q3EqkpVVhZRlZpSa0Xr5Hyr8Yv2TPEvg/VZbq1ttM/scW3nmWByqoVUlxggsSdueOPmFfO914Zu1ieVjCqbS5BJzjrjp6Zr9a/DPw48S+IvB3iJviVo1jfXpjkWxNwI5XWIxHdxGNq/N0xz+VfnBfeHJrJkiuImAKA/Mpwc/X/Cicp4dJrZnVkdWjnkalKrbnh1WzueL+SDk1G8I6lR+Vep6j4Vs70Rjb5QUkkwgLnisHV/CVtZWE8sLSyTKBtUkHuO2K6qeOhIWK4drw5pJJpHBmA5OQMfSqklm6EkkYzxXTroF6wBFucHuSB/Os+5tWyV2gEHBFerSrpuyZ8fictnTXNKJzz22WJDYz7VpeE/C03i7xVoug288cFxqt7DYxTTAmONpHCBmC5JAJycdu1Ry25WVhnocVPpN/d6HqdpqWn3UtnqFnMtxb3UDbZIZVOVdT2IPOa6/avoeLPDI6T4y/A7V/gpqum6fq+o6dqM99bNdI2mtIyRqJCmGLqvJKk8DpXnLQMBXbeLfGXiDx/eQXfiPWLzXLuCPyo5r6XzHRMltoPpuJP41zstoeSOB6VrCpZas4pYSVtTHaIhuTUJTrWnNb4XJzkVVeLGMda6ozucFShy9CkUNRkc9s1baPn+tQMvXjFdEZXOGcLEL9D7dqiYZJPQVYZcd6Ywwa0ORxuVyCCaQYDrkfLnmpXQ5yBxURG48mhGDWo64EZZdmOnOKgzipGXODTWj+XPUmnch6jc0U4oQOlNxTE1YTAoxilwT05pM0CPev2Zf2jNG+BNh4ittV8O3OujVZreVTBJCqxiOOZeRIp5JlBGCOnc4rwRF2qq5zgAZpSM0mG96PMSQ6igLkA80oWgY0jNAU9R096eFzTguPp6UmykhgX1p1KFGe2KvaNot74h1W00zTLWW+1C6kEMFrAu6SVz0VQOSTTuupVijtpOhNdB4x8A+I/h5qMVh4m0O/0G9mj8+O31CBoXePcV3gMMlchhn1BrC2c1F77FWGAFjTghHengbe2KftB+tMpRuMUbjkipFXkU5YiMnGKfGnPTilc2jTE2ZGa9E8M2EGseGkjmtYYF+eJisfLAAfPk9/84rhIhtZWTqDkHrXrfjvwr4x8L+CbPW73Sxp+n32yF3eZGlRnTcuUzuTIV+oB/SvLxc3eME7Nn1mTxp0lUq1FdJbHlfibSV0rVpbRbg3KxBcSMADyoOPT9a0vh9pFrqXie3iuLlbfCtJGGXd5jgcL7Z/pWHjJz/OvYv2UvDfgLxL8WYrf4iaxc6DokNnJcw3sFwsCC4Vk2rI5RsKVL+mSFGRmt6qaoOK3seZh6kI4yNVx91O9vI9Q+I3xqi0X9lQ/Dw+HnuZZWEceqyOvlW+668/KqVzv2x7cjoHPWvkBvm5r6H/AGs/EPhWw8cX3hTwRcJq3hrT3h8rUvNE/wBobyg0mJF4YB3YdByDXz4VB5AxzmsMApxo2mjbPp4evifa4a9nrZ9GQkfnTTxT5BgexqNjya9Q+XsIwyKYVIqQHpRj1NNMkiIOO9IOD7VLmkIyKdxWGZFNKknPanbecZpdnOaZIwJgin0Yx3o20kOw0nJpBnIp+2lVQOvamAEEAUdCO9OJDfhTCc0XC1hdxrvvCOq6xZ+Gp4YYUeAq0luzjcQcEMFHuVzjHvXn4yx4Gfwr0LwxY61beH7wPZukaxsYS+FY5ByADyfUVwYuaUbPqfRZLCo6zlFPRbo4XVrm8vL93vWdp1O07xyMdqvaH4buNZLOoKRIQC5U4bnkA+tdBoHg251BpLrUx5cbAuTIxDk4ySfb60/VfE1rpNu9jpsUZ2EoWicNGR0z0BJxz1+tZe1bXs6SOuGAhFvE42Vl2e7MjxTpOn6ZKiWcx83pJAxLMvuT+mK549aklkaZy7sXc9WY5JqMnI4rupRlGKUtWfOYqcKtVypqy6IaxoAyKUYIBNOIGOK2OOxGaA/NOI/Ck20XGkG4UlGMcU7GBQLUAKKaBmjJAp3BiHgGjsDS00g5NIY4UmOvegdDQBimAgGe+Kdt204DGaRhwaQXEA3dKcBgU1O9PoAKKAM0UCYUUUmD+FMELQBk0Uo4GaQCbTQFNOBBpDQMSmgU4DOadjNMBB1pa7fTfgn451n4eXPjux8NXt14RtTIJ9Wj2+TH5ZAkzzuwpI5x371xA7+1CsIKTbmlozSAaVxTcetSHmkP5UAR0U4HI6UMMYNMY2u5+EvjrTvAOsX13qWnSalDPbeSkUSoSr71Ib5+BwCPXpXDYpe/NNOwmjS8Q6hFquu6jewI0UFzcyTJGyhSqsxIBA4GKojpTQMYp1PzJHfw02iinuNBSjrSUUiiRF3sBnFOVmgkDKxV15DA4IPtUQO05HBpc55JyfencViW5uZrtg080kzAYDSuWIH41AePWlLc0nFO9xNCc0oIxTSevFeveE/h/e6l8GtV8RR21ube2juiZmxv+XGccds8c1UY3EeS8/Sm4pXyCaQ8nioasS0FA6UEUUgT6Afm70qrjNAIyaCR3oHZrUC+PU0qsGPTj3pCMUhznnrQHNYfRSDpS0/UsM0pzmgUtMpAOnNJ3pD1opiPS9e+LltrHwosPCI06eO5tY4EN40qlW2OWPGMgHI4/OvMetPxSEYFA73G0U4AU2gQvY4p2in/AI+OOyj+dN/hNGjnHnf8B/mayn0InsU5B+8k78multLZFtomCKCUXJAwelc5Mv7x/cmugsbyKaGKFWzIqKCuDxgc1ktzBGTqY/0uQ/T+Qqhcf6mT/dNaGp8Xjj6fyFUJxiGQ/wCyalikZVSQuFJJ5qOpLfYHJk4XHcVktzItPHti8xunHFVGwWOO9Wp7iNoSinnjAx6VTLVpohsSiiikIBxVyP8A48m/H+dU6uRn/Q2oGh1p/qm/3jV23m8s4zjPaqdqP3Z+tWAMD3qluaI1vDgJ+04GfufyNUg0ou5fJzu3nOOvWtvwXaC6+2Z7bOn41CdPWCeU5JJY53Y9azi7ysd0qclSjIk0CHdfRSSDM3zZOfai5jePxrE+MLvT/wBBFW9HjCahEOT16/Q0X4A8TRt7p/6DU1vhaOrCR96L8zohOcAcdqnjmwxOBms4SZFSCTHPT6V4Tpn6bDEWN3TNXk0+RniCs7KB8wyBg5rsLbxfaQGKUTkSJg5EBODx/hXmqzFeQakW5I53c/WuKrhI1Nz6LBZ3VwkXGL07HrJ+Jm4lmvXzj/ngwHXPtUMvxQuhM7pcFgW/iQj0968wF0f7xzTjdYH3iK5v7Pgen/rJVfY9IHxN1KCSSe2uFgldt5IjBOeOm76Cuz/4WjrF5Fsk1FGLr8wWOMdQM9BnvXhEd4CcbgPwq/p2qmxu451VZNmTsPAPHqB71z1cCre6duEz2871dmfQ/wAPfjXr3wvmvrjRr+K1e7EazGWETAhCSMA9PvGvXPDH7c3ieCz1ZtV1W2u5GtiLVV04gRvgnd8vXjHBNfF8/i+4uo2j8uKNXxyhbPUdOf6VAb+6I2maTH1NTSo4iCspWHmE8nxsnOdFSb6n1D4u/bK1rxrbwRXV1YwpE2/MOnuGYkY5yxHrxXmHif4kxeJNQF7c3ayTCNYyywmMADoMc+teQC5ZT8pIUDHFSJflV5YH3INbTwUpvmbucmEzPD4CPLQgo2PevB37TPi3wRpC6R4e1lYLFPMeO2a3jkwzEsSCy56n6V9o2n7TfwP8SaNYx+KNWjlmWON5YJrC5KrKFG77qYODn19q/LS01F7aUyQzASAYyFz/ADq+PEupFRmbJ46oKFTq0X7quvM83GUcDmvvzbpzve8ep+klz4r/AGVfE+uJ9nktDqF0VhRIoL6LzCBhVwFC+gFaNvB8C9M1OODT9M059SD5hF3DO53rgjBkGARivzo8DWut+OvFtholhPGL+5LmHzZPLXKIX+9jg4U498V9b+I9J/4V78A01DxTPO+s2QOy8tpDM29pwEAboeCAfb8KU5zb+FXPP/s2jSsliZyXZs4f47/F7xTq817bDxDfJpaXivBZRz7UjwX24wM8fXtXz/qXiu5Fy8l1cySzSfM0kjM7N6knBJrE8R+OdV168bzr+WZd4bkBcsM5P6n863tF+F+v63o9lqGbWSK5QyRtJP8ANtY8ZGMdjXM6E0uarI+vwuOoUIexwdOz72Ni1mkuLeF/OfLoGx9R/ntWj4U+Itx8PvFOma9pVzImq6dN5sRMW4AlSpJB6jDGuFn1gGLy41khkQbQQ3C4IHT8KzvOfjLMT7mopYeSlzXPUxeZ06tH2TSaa1ufcPwY/br1O68Q3Ft8RdbT+wngCiSPTQTvLAEHy1zjbu9+nSvYNf8Ahh8NPjP8PPE0Hww0iwn8QQRwRJcTxyQiPLq3yvIODsVhkD69a/MRbpgBg8/WvX/Bn7UXi7wBa6hb6Dq8elR30qyystusj5AwMMynjnuO1eiqso+7NXX4n59WyWEpe3y+fs6iastouz6np/iT9k/x14asnvdRtNNjtlcIXW783ljwNqrnnFeR6/4RvrHWLrSRbrLcW0piYQ/dJGDxkD1r2L4YftPeIdY8S+R8QvET3/h7yXLRzWyMPOGPLI8pN397869L8e2XhDW/hd4g8Z+H9OtvtFzGzRah5DrIX8xUZgG6HqK8+dKnJc1J2sfY4bMsfg5xo5lHm5rJOKstT4m1LT5NBu3hv1+zyYWQITuwrEgcj6ViaB8JvGHjKG4utG06O5tUkKNK11HF82N2MMQc4Ir0/WNNh1S+ae6t455SoTdJ6A8DA+tOs9Y1Hw7C8emXTWMLNvZINoUtjGcHv0rCninT23PdxuVrGWu7JbHg3ibw7e+FNUuNN1aFbfUYH2TRhw4BwD94cHgjpWfb2jXYYwgPtGTjtX0brfhtNc0W61y4C3F5s82aR0U724HPA54/SsXwn4Ml1/W7PTNPSCC7un2IzYRQcE8kewr0I5i+XbU+XlwzHmc5zSijzyy8ERTwwH7U0bPGpIYA4Jxn61k+I/DD6TeLAkyyoYvNLuQoAHX2/WvrDQ/gpqmieItNvb66sJIraXc6JJuJwMcFveus+Ing231nwre+dEs4iiaRBCF4YAdwPaso42tCfNLYVbL8vrQVGi1fufn9PbkZGMHr0rOmhYFsAV6p4+8HNpyS6iHXaGRBCzjPOcnuew6+tefT2pK89T2r6PD4pVYpo+EzPKp4Oo4SMKSFgw4zkVC0RINadxBtYgYxVR0xnvXrQqXPkKtCzKDxkdajI5+lWpVG7nrULJ1rqjI8qpTZXYcmo2TPbpVhk9OtMIzWpyONisVyPWkxipmXBphXPvTMuUZSYAqQqBSAYNK5Nj2b9lWT4Rw+NNUf4yRxyeHvsC/ZY5FuyWuPOjJA+zfMP3Yk68c+uK8r8Zx6Z/wl+uf2IUbRvt9z9hMe7abfzW8rG75sbNv3ufXnNZjA5JFMIOafUlxGBaB096liTc6g9M1JcRLE4C9MZ607i5SuOlOA9aUfXNOx+XbmkUojRwSKWlUZG7rnnIqUIMCkUkRAc1t+CvFV54D8X6N4j0+OGa+0q6jvII7kMY2dDlQwBBIyOxH1rIVTuPy8U4Rk0tylE9A+N/xz1/4/eJ7LXfEVvp9te2tmLJF06N0QoHd8kO7HOZG7/hXnoQkgYzTxEVI9KkVAuMjNJWSsaRgMWHIBI5qQRruHTNSBCOKkVOBxUuVjoVPyIlQgc1IqE844qURGpVi4xWTmdcKJGiY6jmvZLL4tX3jrQrfQvEgt9YkjmDRefAFCoqEKMrjkAkDge5J5ryVYvauo+G3g6/8AG/jzw/4f0mWOHUtTvI7WCWb7iMx+8xAJwACTj9a8/FUlVjfqtj3cuqvC1E3rF7ozta8DXltrVjYabBLqM9+yx2ltAvmTTSE7dqqoJJJ6Yr6PH7J918EfhVF8RvFl/L5Vzb2iz6ammHzLEzn7jlpMlwwVThQBuzntX0jovhDw7+xt8KtQ8YeIZrDxF40t4Fa1i81bY3Tb4wiQiTLfIzFiyAHHBGBXwt8c/wBojxX8aPEF9cX2oX1hos02YNAhv5WsYUG0IFjJxkBQec/MSRjNZU/a1qShNk16tKhjnWw0fdXfY898dajYaz4jubrTlYWbldgePyzwBnjtznvXNyj+VWXGGqvL978K9ajFQionh4yo605VH17FZxkACmFcdamYHJPamMNwre55DRCRRUjAAUwg1RDG0UnINLUsVwx19KMUU7AOfpVAxuKTPNPHTnrQVPagEho5o70/YT2p4jwPemilEhxk1Lb2klzJsjjeRj/CgJNWtL02XU72K3iXLyEAV6naeGtH8GxxXl1L5c8bGMTM7EFiP7oHcD9etcGIxcaPupXkfR5ZktTHr2s3y01u2Y/gzw5pnh91uPEXkwyylHtWlZgUZeSD2B5XrS+MviLa3llPZaekyys215nUKNueSCOTniuY8X+JD4kvEZA8dsigLE4wA3c9+tc+ck8kt9a5aeFdVqrW37HpYvN1g4PB4BLk25urN7VvGV5q2mLZSRRxRgqS6ZBbaD1/z2rn8U7bSjpXqQhGHwnydfE1cQ71ZXYzaKYw5qVupqzp5t97G4wVA43Zx+laSlZXOaEeeXLcpwRSXMixxxtIzHACjNdLP4Imh0L7Xvc3ajc1vgbVXPXOeuMGq3hRpo9eU2kAuC2V2H5RtPqTyMUeJdbvLq5NtIjWwhLK0QY/Mff14rglOc6ihE92hh8NSwsqtdNyei7GAQaQ9Kk25GetBWu9Hz9rMjAoAPpTttAFVcljcH3oA5p49KRhxQIZtpMGnnFFADKUCncZoOM8UAFIRk+1FBNFwDGMYp2OKQY704mgQhFJThycYo2igENFFOKkdQR3pMcGgYmM0YwKcBigjIoAb1pcUgABFOoAOlGcUUGgD1PR/wBpTxpoPwavvhfZzWUfhK+E3nxNZq07GVw7nzOoOVUcdhXlg6+uaQDFAOTQtBC0UpGKSgAooooJCikzzS1VxjSMUhAzmnGkxzSuO4UoOaCOKZ0OKaDceDxSg5puRRnBphYdn0ozgc02gHFAx1I1GcUEcUAJRSgcnNJ0poDtvDnwe8VeKH019M0tNSS/IWCOK5QNISpIGCQQeO9ffnwV/Zf1a3/ZI8T6bqvhHztff7eIwLpCxDbAmCJdvHzH+dfBXgf43eLPA95pg0/U4bSCxJMJayhkMZ2EA5ZTnr1PrX3v8Hf2o9UuP2V/FN9deKbQ+IVjv2jWSzt1dcKNuEChTkA+taW0XLuZu58c/GL9m3xT4A1awsz4dawllt2lkia8jY58wqDkuccY4zXi00D207wyY8yNijAEHBBwa9n+Lv7S3i3x7rVnePrsF20Vv5ZeOwgjA/eE7cBMd+teLSymeZ5HADOSzYGASTk/rUvReY9WLjOKQjApV6Umc/SoE9BnI9qUZ/CloAxQRfqKTkdQKAOM96acZozzknimkUtUOHWlHrSJx/OnBWk4UE/SmiloJnjg0bjkVMxUJtx830qE9RT2DcXNFIQcZ7UmTQWOopAelLQA3FJTsc+1Jip6j6CnkHHFJpA/1/8AwHr+NL1FSaLFvE5/3f61nMzkihMMyN9TW7YW8UUEcipiRkGSW+n5VjSriV/94/zrat5BHZwbiFGwDms0YIzNT5vJD9P5CqE5zA4/2TV7UHD3TkEEccj6VQnH7uT02n+VQxMye4rSNvbxqM/L9TWeo5/KtGdY5lUbxx6GlFGadiCcQCM7CCw9DVUj5qsSQxohIbJ9M5piRhgD3pW1AiooopiDvVyL/jyb8f51Tq5F/wAeTf57ik9ykPtP9Uf96rNV7QYi/GrFXHoWd98LGKvqWOpWL/2asu8H+mT9QfMb+ZrS+Fp/eaiOvyxf+zVm3hxe3P8A10b+Zrlpv960fRVf9yp/Mfpg/wBPiz2z/Ko9QP8AxUMZ9Nn8qfYN/pkR57/yqvfP/wATxT/ufyrSproc2Hdkn5muJMAHcaXzRxyfzqqbhRxmkaUjpj864/Zn1arWW5dEmc4OaU3Pl8ngfSs77Xx0/WmvPvXBGPpVex7kPFWWhpi/T+9/46acLoOMg5H0xWNkY4NSxz7FABP4Gm6KJWLk9zYSfBBxmp1uSR0/SsZJcdc/nT/tJB6Z+prF0LndTxnKbcV1846dasnUHI/hP4f/AF65z7W2ScfmaUXJbjqfas3h+p0rMHayNg3GSOcZ96ge4G8c/hUVlo+p6nGZLTTb27iDbS9vbSSKDjplQRmoNVs7zRZ/s9/a3FjPtD+VdQvE+D0O1gDg9j3pJRWl9SHXm1ezsa+m3kMN1GZAJULLvjU/MygjI/Hp+NfQXxx8Q/CyHSNOfwBotxps5nb7QZoJFHl7flXc7vk5HbGa9Q8Kt4Mn+DXgnTZm8NQ6lLoti8xuJbVJlJQMzMW53d+TnmvibU9Ylu/NhL7ofM3dM5IzznFeam8TO1tj6CDjhKSrSl7z2/4J9efBH4rfDPwd8NNOvtUGjx+LoprhXkksd14MudjBwhP3WI69j9K8L+MXxAbxV8RPFF3p2ozXGjXl80kSpKwjdPlIO04HYdu1eVfaXCgBmC+gJFM+1tu9ffdXTHBxi+a55s8xb33Og0+5g84mYqqgcE59faulh+MWvaHbRWFjNbCztgI4d1sGO0cjk9a87F0cZ6fjUbT5Y8/hVvCRl8QRzSVNWpu3mdubjzZWY4y53HHTJ54/OsfXbiWG6j2SOgKdA2BmsSTUJplUO5YL0yf/AK1RvMznJOTSjhlB3Y6uZOtHlj9500OrxSbV3HcQB071bST3rk4ZWUrtPoa6zw5oWpa4sj28aNFGyqzs4UAkZHHU8AniuWvCME3c9jL8RVrSULXZ0ei+I/s95HuaURHO7HzEnHHfHUV7t8CPEGteL/HnhTwtf3D3Phy7u8SafMAYGQK0jAqB6jNeI6f8P7+YFjPCsnOFCu2eOOQvQ+te46DeaH4O8HWE+kTCx8ZW8MO28t0cSJLgLIdxGMbSw6DivBnKnCSkj9CccViMNKjOOrWjfRn078RfhXo2iajpf9h6TaWbNE4aOGNQJCWG3IPU9ec12eu/s2WN7oN5Fa22ny3z27LEJYNi79vGW5xz35rxb4BfEvUryXULjX77UtflR4iplIlKLhsgZwFz7eleofHv9p2w8FaNJpmj3F9ZeILu2eS1uFtwUjP3VJLcdT0wegrrpfV5RdSSPzbG0s5oYingqU25Lr0Mzw5+y/rNn4Zj0y/07RZT8wkUsrhwWJGSU5/+tWt4c/Zph8JeJdJ1ttI0i3/s+7juTJCFDKFPOOPT+VfLh/ax+JwBz4vu2P8A17W4/wDadNu/2q/HepaZd2Oo67f3MNxE8LiMW6ZDKV6+V71zrEYWL0i7o9aeQcQ1k4VKsbS0evc+wfGH7YPwu8M6rPp032rUp4cbns9P82M5AI2ucA9etcnqnx3+DnxV046hqq32lafo5ZXtbq18tbsyoRtKpkvjaTjjBxXwFBcywxhN5wOMYwB+ldBo0q6nHDp8qhIncszKMk8H1/pQ8fJv4VY9WnwLhaNNSjVkprrc9x+OXwIfTdAPim2t9MTwzqN3GdJt1ILCKRS0W5WTg7c8ZJ+Y+lfG3ifwjc2d9MIVSZjM4KoyrsAbAGDj9K/Qz9kPxnrni7Vr/QvEF+2s6Nptgn9n2t1HGy2+yTYNuFyflOMkk4r54+LulWljrviS3t7WJEfWboALGBtHnPwOOBgCnOoqCjXo7PoLAKpjqlTKcwV5U9VJduh8lX9i9tI8cqFJl+8pIyD/AJ96zJ7Ziv3DXovi7wvetqN5eQQBrTHmF1deAFGTjIPY1xkkQfPOe9fQ4fEe0immfH5lljw9SUGrLoYEsTAgEY+tV3TIPOMVtzWsZJJH61nSQ7VY169Opc+Mr0HF2M/aakjsJ5oGmRMxrnLZp5h46mp4rmaG2eFCoRs5yOa6+ZHkun3MsqDmmlPWrLR4HSmlOnFWpIwdMrmMEdelJsPccVOy0eWew4p6EOBDsHofzpGTr1z9alZOT2prRkdDmmiOQgKN/k0eXkdP1qbY3pRsbPTigXKQgbTjn8q9m/ZQ8b/Dr4ffE6fVPifoieIfDbaZPBHZy6dHfKLlmj2OY34GAr/N159zXj4TJpwiOenFBXJdHZ/GvW/Dvin4s+KtX8I2qWHhi8v3m060jtFtVhhONqCJeEHB4FcWIyalWLkZ4qQRAdKlmkaeiREFwMU4IOKk2H0zThESOhrPnNlTZDs5xinrGCP/AK9WI4M5qVbXb2H51lKodMKLZB5Dn+GpRB04H51cW36/LUghGQe9YuoejTw19SqkLZxipVtzmrcduGPp+NbeleF7vUbhIxC8UbAnzXT5RgVzTrxgrtnrUMDOu1GEbtmBHDg+hr3H9mL4K+JPH3jnw/r1jp5/4R7T9VjFzqEkyxqGQBzGgzuZ8FeFHRh0rzZ9Cg0HXbBdUje4sDNG04g+Vni3DzAp7HbnHvX2R4n/AGqvhn8G/hdB4P8AhH4clvbDVYLi5NxcTyRtazvmPe/mBndxgEYI+6ozWMq3PH3WXWw9TCTVOUdTw79s/wCHN14O+IsF490LmzuYEhiQ3HmPBKifvEKl2Zc7lPIUcnHSvm6cYf2xWxeMbiZ55WaSZ+XlflnPcsTySazJ0y5roo+4rM4MSlJNpWKEg5HNQOMk1akj557VCRz7mvQjI8ComV8cYPrTXGPrUrqaYetbI4nGxEVPtTe+D0qUgGmlcnjpTuYtELLk8Um05qTBHUc0fSi4uUjwc96UDOPWpFQnmneXnnincOUi2jrUijmnLGAakCY7UkNRGBcjikK4HNTAAL2oZAVJ6mqNVE9j+Dfi3TI9Kj0KPTRFegvPLduVYysWAAHGV+XAx359a5b4paDrOk3S3V55z6TdTSGzkbdsIyDwMYHGOlcXpk17ZXsctjLJBc5wjxEg57Dj8K+tPjn8bPhB40+AOg6LpPhvVh4kWC28nUpbdYY1nREWdywdvMB/ejG3q2eDjHiOg6OJ9qtUz7J5pHEZYsHJNSj22+Z8f4AUCmEdTVto0LfKeM0jW0jybI0aRyeFXknnGMfjXqc66nyMqUm7FTd0roNM8E6pqVhHdpAEhkG5HZlwwzjjnjnPUV674H/Zg1R4hf8AiiEW0Lxbo7SKRvOSTdgrKgXK4wQR159q4zUfHdraWn2HTLNo7QBo1LybSnPbAz69a82WMdSfs6GrR9Lh8mp0aXt8fLli9l1Oc03wHc6hHK8syWyowRScMC2MkcHt/WpfEHhrTrW8sbKCdbeeRgrEksCDjDHnI7+gqPSfE0uiW0sUMUcyStvPmk5zjHUYrnXYmXzCSXzkEnp3rbkrzl7zsck54GlSjGELt73O82WngPSXR2hm1N1LJ23gkDHTgDB7jmuH1C+k1a/eeXYkkp+bYu0dBRqWpXOrXAmu5mnlChd7jnA+lU/wrShQ9neUn7zOfH49YhKlTVoLZf5l+VI7eDb1D9uuaonpxSY469OKUDIrsirHi1Jc70Q3bRtoIPagdKowG0UpFJVakDaTPOKXnpSjBOO9MBoFLTsCkC475oGJjNAXHvS49KdjFJjsEaAyoG+5uAJJxxkVp6tBYwiL7E6sTu34ctjB461mY70d+tNPQLag3b1pB1FDE03LZ6cUkPlJHcucmm0KDnmnYFMLDaKUKacUBPSkwsNzSU7GO1Lii40iM55pTS460Y9qZFhhxmk6dKfilCljgDJJxjGeaBCA88/lSZOa0NU8O6toPlf2lpd7pwmLCI3du8W8gAsBuAzjIz6ZHrVHaAOvNACEn0ozSjA9KaRQKwhPNKOlG00tAWEPWgc0uBQBigGGKTaKWigkQgDmgAHB4paQjFMoQ8Yop2wsAcZHWm1QwpQ3Q0lH1oAUtSUgPPtQTx2oAQjHua9J8J/ErUdD+HOp+H4o4WtLtLhXZ9wcbwAcduPp3rzcYNL5jqCAzAHggHrVKVhNXGinZxzTQfzp1SK4qtx6UoIA5ptGcUwvd2HD5s4pSKYDinbulITWgbR+tIQO9OzSYBz60GSAECnRzeWxK8E8Go/4jjtRTRonZWZLuBbOc5oIzTAcYHenZ9aZSaHE/KAKYBTuvTrSYxkHrTKEAp2c0gxijHNAC0UUUAIelS6GfluBn+7/AFqI9Kk0IZM/X+H+tY1CJXK0v+tk4/iPP41ozrmwhB7Bf5VnScO+f7x/nV+5JWwi5wcL/I1ijLltqUZI8DIHSqs3+rf3U/yq0Jh5LIc5OeaqS5MLf7p/lQZGXFw3TtTn4ApI/vimnrWaIAmpIn4AxgVHT/MGzaRk+tWtBjKKKKQgq3Ef9Db/AD3qpV63A+y88j/69DGh1pkQ/iTU68nFRx428DAp6nBpo0R23w5vYrKe9MxIVljAwPc/41WvF3Xk5XkF2I/Op/DMEaG42oBwv9armRHndQcsCeKxhFKbkexKpJ0IweyJ9IjH9oRBwNvzZz9Kp6wFXWQVwBhDj8K0NMH+nxH6/wAqz9dUrq68/wAKfyNOXxWHS0pX8xwfOKVpCfSoAcUbs4rRRO9VHbQkBz9Ka784NTWlhcXn+oheTBwdqkgfXA4rrbjwHb2LWvnanEZXJLDKBBgA8En+Y79K56leFPRvU9PDZfiMTHmirJdzM07wLrOraLNqttDC1lDE8ruZ1BCqMt8uc5wD9ccVght20g8YzXVX/je90Ka80qwu4/7LfIaIRo6neo3jIH4cVzd1d291IiW6BccYVcelZ0ZVJNue3Q6MZSw0OWNCXvLR+b8hgcg+tOWTIOeDW9o3ga81KCSaYPbLtzGrAbnJUkDnGBkDn371zs8EtnO8M8bRTJwyMMEGtI1ac20mclTC4ijGM5xaTJQfMkVBjLEKAeOSeK9I8a/AHxr8L76xHiGytbWK7keKCaG8jnR2TaW+6cgYdTkgdeOhrl/Dngu61S7kS5E9m0JBKPHjd+J6dPQ16H8bPjxqfxRstLs9RsI7Z9Lnlw0NwzBiyqrZDjI+6Ohxya8+rVnOpGFLbqe1h8D7Kj9YxOi6eZ7tBqvgv4G/DnV00mWK6uP+PhrRdTWR5pztTIG7OOnAHQGuP+FsHw3+O41HUfiBeRaNqtm8drbqL5bdXtyu7d+8LFiG3jrwCBxXyrI4aUuEC89AB/hSC4YL8vA+n/1q545ZL3pOWrOirnUXaEY2iuh7V8afibovi2306HSpLmSa1l8qXzrZY1KRp5SMpXjkKDgADn8/HvPBY4J5qk05IGaYZTn1NenRwqpRsjw8TmMq71L5k4o8ys/zPYUebzjFdHszzvrF9y602emPzoEg9RVHzKVZNtNUyPbl9WHrW5pJs/sa+cIDIWb75GcZ4rl1l+bmpEl3MKyqUOeNjvwuNVGfM1c9R0JNAljYXbWC7dv3yo78+/Su807XfCukwtHY3lhao5BcRNjdgYBOfqa+exdAA7VI98//AFqfHdsv8QAHrmvGrZa6j1kz7jB8TLDpctNX79T1K3+JepQ3DstxEqZ4JiTHX3FauleNLzULwPc3XmRMCSuFVckew9a8hW9BAywJPXitvRNSWae1tlDGRnCg4GOtctbL4xg7I9jA8RVZ1lzyPpX4eeMbjTtThhgu0hguriFJssNm3dgknHGAx5zX1N4w8AfCz4iTWtzrfjO1hntkaNDa6nbx4UnJBznPNfDXh2aO2hmEzCPKKB8ue5z0qpf+MtJ0loRdPIplGVKQFhxXhU7wk4KPMfZZlhIYtQxTr+yfVn2knwH+BSD954/X8dZt/wCi1z3jL4U/AzRfDupXWn+N0u9Rht5JLe2XVY3MkgXKrhVycnHANfJC/EXQMZ+0Tj6WzVXvPiRoTQyos14zFCFxAcbscdT610csntRPJjhqdNqcsybt0Pbbfwh4J1KC3a11HNxMABEL35t/Hy4Pf2rN1P4X61BqrjStLvJrFSDHIXQs3HPO4d89q8d8J+PrC2uBdXF6bKa3lR4fMQsSwGd2Ap6EDrXplv8AtHSbx/xUSMSev2Zf/jdcUqFSL+Fn0SxtKpFOlWT9We5+BPG037O/hqDW30lb7VbiIWslrJKYz3kJLKG6YAx9ea6L4vfs73niHwxo+u+DbPVvEGoa1KNRuEJjKRpMrSnk7cfM+AK+a9X+KK+LkW01LUGu4o2+VHg2qp6E8KO3rXufgrxL+0Y2haTH4Yvpk8Oraxrp5mt7ML5AVQmNy7iNvTPOAK6aPLOPsq0XbofJ5jhcRhK8cfg6sVN73ejXQ+fPin4I1/wFbahpniDSrjSdQa080QTAFijZUMNpI5IPftXiUmi3qRPIbScIoyzbDwAOc1+ofji0+EHxk123g8Wa5dzeMZUj0v7LAZImjlR2+QKI9oJdmBJ4Pbivmr48fBOL4aa/DplvNLLZ3Vl5weTbJIpJZGBOwL24x2IreP8Asd+TVGEMZHPpwo4lONW3bR+nkfHrxjb0461SmiBD/Lk444rsvGvh8aLqywxl3UxK5MhBIOSMcD2rmzAc88mveo1lOKaPk8dgJUajpyWxlQ28LIwk/wBZzgZIqs8EkeN4KnpzWjNbMjEqOc5zUEqu65fnHNehCbPmalDo1sZ5iBPSkW33tx2qw0fehEfd8p6+lb85wugU/L5PFBj9MVfWzZv4W/CkeyZB90j6in7Tpcl4Z2vYo+VnPHNMMfFXTbNimtbMWPynirVQwdB9ikYz0xSeXVpoGHUYoeDbjGTTU0T7BroVljwecVJs/Kn7CDyDS4IHTinzCVN9ho7VJHE0oO0En2pAox71rWFuETLKNx71jOpZHXRw7nKxmRxGQhVGT0xTzA0WFdSpPPNbkNnCJQViUN606709JpVds4AxhRxXI6+p60cA+W6epjRxg4wBmrixH+6Kn+xJG3y5/Gpktz2FZOrfU6KeGcVqRJAWPQYqwtoeuB9cVbW1I+4M/ga9E+DvwpT4n3esRz6sukwadBHNI32cyvIHYr8vKj5SBn6jiuadZRV2enSw7k1FI4bw/wCHzrN6sKzxxoxxnBY547D616VBa2kVylvbXcc8oBHlxyAldo54HTGP0r0D422vh4X8EWk290msWlhbpFcWxjSBiCoAlG3J+TnIx1r0z9mH9mKx8FabrHxC+JFkl49rbtqGn22nXomV43hcTCRBgFvmXHOMk+leRKX1u75rWPr6WKWRU4ydJycv60PB7CCyj1rSH1aAXOnxXkM08Ese9ZIxIpYFSDuGOtUf2j/GPhTxVqGkW2geHYdIuLWJiZbW0S2jmjkdmUbFJzjGQf8AaPTFe5fGbXbPUtQN3o0dymgW0SCztrsKDbhlQADG7IJHXNfOPjZm1XUFvZrdI9kAjDHJYgMTjJ9M9vyrnw9R06vK3oj18ywyzDCxxPLaT6dv+CeWzxso+YEVnyqefSuj1SDMYI67sc1hTxkEjqa+npT5tT8sxtB03YoSLkcd6rMm3PFXZEPFQugYnNehFnzlSncpMpOKaU9RU7RjHFN2GuhM8+ULFbae4ppUgnAqwy1GYzk44rS5i4EWyjaKkK/Sk2UcyM+Qbj8aO1O20/YMdCKd0HJcjH3hUgU+lPEQz0/WnqvNTc0jAYFwealWPaMEU9EB6V33wk+DPir42a/Po/hSwivby2hFxObi4SCOKMuEDMze7AYGTUzmkrnTCnc5Dw9YX95r2m22kWzX2sTXMUdnaRxiR5pi42IE53ZbAxg5zX07+2n4t1j4hXnhDSNX+Hcngm9hPmRNbTR3Fu8k8cXmRII1CqQ6uSoO71HSvqzw94R+Hv7HXwx09rnSr3W9Rmvo7iWSO3t7q7+1+TndEzAFI1KHG0jG7PUmvib4uftKeNfiB4vuroaxfWGi2mpveado7eWBbbXPl7yigu4HGSSeTXiVazxEvc6HuYfDOn79SOjPVv2ef2fvAfwfs7b4ifE+a9kv9JmNxb2cjwR2UUij93vy5LvvxtyQuducisT4T/ED4VePfj/4617xD4X0vRbLV3mv7CfVbpfJhJkXdGYnxHvcfPlT8pDYyK8A+J3xO1X4h+I7/UrhpLC1umTGmw3UrwRBRwAGPPzZY57kmuGduDzSpUari/ay1f4E4hUY1uairJHq3xl+OGq+Ldf1PTbR7a20y01Sd7S506Rw0kSsyR/PuwVK4IwB1zXkDZLEnnPrTth3cikcYr0qFKFJWijhxVerX/iSbIm5PFROvBP6VMy5NMZBnk12JnkyWhXIwKTn0qwIRI4Cn5j0FI0ZRtpHNUY2ZCASTkcUYwTUjJ7U0xnsOKaJaZFtNJtIqUrge9Ie9GpPL0IypJzSEEVJjNBT86aJ5SLHtS4p200EcGi4uUaFzS7QKUAhDkUm31p3FYQDHQUoHHWlHFKFzQPlGhcH2padtGMdKTb70DsMxk9KMZp23Pc0uMAUIdhoXnmlVfSrI066+zfaPs0xt8Z87yzs6469OvFQAbTVDsJtpQMMKcVK9aaQTyKWwrEssYKlh19Kg2079aWhisNpKXafSgqQKVwsMIojkMUyOADtYN83TginZpCCTTZNju/in8YtV+LLaedStLS0SxMhiW03/wAaoDksxz/qx6dTmuEAzQFxkkUfhSvYmwbaNtLRnBoGNIxSUpOaQ8U0xWA9KKD9ak+zShA5icRno+0hT+OMUyWiOgnH0pSKQjNArCbuaCetIVOfajGKBj1mZEKDoRjGKZ1opKYCgZoI496KKAGY9sUYp4HtQVxzTC4gGKCM0uOlFMBNvOaDwKWkIzSuAmSc0o5puKns1ja7iWYgRF1DknGFJ5NUTbqRilBwa0dbt7GGeIWMiyRlMsVctg5PrWb60WHuKOnvRupAcUUhaIBjPrTsU0GnDpQTuFH60ZoyKSM72FDZFOUZGaZ0pc+9UjSMr7jguCaTJGaU9TRjNMsM0ZpNnvzSHg0IocelXPDaBluuP7n/ALNVHPB/GtLwuM/a8c8J/wCzVhVeg4K8rFR1USPx/EakvhiyT/gNNlB81/8AeNPvx/oKZ/2azWxM1YyqZMP3Mn+6f5U+mzf6iT/dNI49TIRtpzSGiilbUzCiiigAooooAO4q9D/x6H/PeqPcVdh/48yf89aVxolg/wBWcepqULUdscxZ9zUo6j8KtbJmi3O38O4DzD/d/rWZCP8ASpvqf51qeHeZpcf7P8zWZD/x9TemT/OsV8R6sv4UDQ0//j+h+p/kaoeIPl1lR/sJ/KtDT+L6H6n+VZviNsa4v+4n9aH8aKi7UvmQk4OCQPqcV0Ph3wTe+IoZpIyIVjKY3o2JAe6sOOOPzFJ4Q8SaboEl019bPcGQIEKxI+3B5+9jGeOlTeJfHrXslp/Y0l1pyRBt4QiMMTjHCn2rGrKtKXJTVvM+lwkMFTpKviJ3f8q3OvXxXoHhVPs0N48p24ZIATh0XAJ4AyT356V5rqvibUtYCC+u5LlUO4LKcgHjp+VZc0zTSNI5LOxLFj1JNMJyKqhg40nzS1Zjj85q4pKnH3YLZIe0m45xgVueFNMvp7+3vbTZtik2newB6c4B68GsDtV3TtdvdIP+iTeUc7sbQwzx6iumtCUoNRPLwleFOsqlW9lr8zptW+IVwRHHps01kEyGIVQW6Y+mMV1HhO88J6hc2Ooa5KiXkZjkmeRpD5jDg7lAIPQHAxXkQyzE989vrXYwR+H28IKWuFi1ZYWO0ytywY4yMY6Y44ry62EjGCUdG+qPqsBm1XEV51KlmkrpPy7HV/E34hwy61C3hnUWjtTCDIbZdg8zcfVQfu4rzee/lvLmW4ndpZ5DueRzlmPqaotMW5PX3pvmnseld1DDwoxsv+CeFjszrYuo5Tdl26ItmY4Ippmx71XMjY69aQvx1rpsjyXVbJzMD3pplGOTUIf1NNZuRg8VRLqE3mDPU4rsdQ+GeqaZ4Nh8TTXNkbCaOGWONHYyMJCAoxtABHfmuHyw71pzeKdYuNMTTp9TvJtPQBVtZJmMSgdAF6ADtSsCqdyqZD26Uhciq5cjvQHbPJosTz3LQkwQc09ZAM81UUn1p+/GOaC1MtCbnnAFOEy5wDVZZPl5NKXxUuNzZVWXY5xjg/lVzT9SfT7yG5i2tJEwZQ4yM/596x0k2jjrT1kyOW5rKVJNWZ2UsVKDTjujuo/iNqW1lC24yMHCN7e9Y+qa3Nqvlm42nZnbhcYzj/CsESKD1FO83PQ9K5I4OlB80UevUzjFV4clSba7F9Zhgc/pTxKCf6VSinULyeakEgb5hzxVun5GEcRJ9S8k2OOfwqzbzKJUJB2hgT+dZkb89s1ZjkGRk5FZSgdlHENSTvsd5H4qtf3hxNvdWAGwdx9fevb/AA1+1B4jGn2emWviO8tI7aBII44Yo4kVEQKoHy9gOpr5cgfdIOeK1dNuTZzrJlnAzlc4z/OvExGDUk7N3PusBmynOKrwUoruj6k+FnjCa5+LGh6jc3jXNxJqaySzOwLMWbljgY6nPpX2B8RvhB4Y8Z+HtZ8Q3B1HW/ESWsiWyzXpYxuoJWNI4+Mbm7g9a/NPwf46i0fWLC7ngkaO3nSdlR13PtIJHIwK9rtf2l7YFJLPRr+Mp3F/HHxv3fwp79favGUZ0bxkrpn0OZU1mVelicHPlcFbTsuhHrfgS3TUTbanpNqmoqqo6XkA80dwMHnv6V594x+F1idWGxfssvlZNvbxiJM4bB4/Cvs/9nH4p+GvitHqvh3VPDcOn+J76Jxba1eNFcbv3eEBLYbcDnCqDnHUVzXxk/ZX1zw3e6rrEGq2N7pdnYfapJCHjkwo2kBQCOSCRzRGlVpx9pTlfy7FrOcHXxMsDmVPkl0b6/10Pg5/h3rLW8kksKRbELssjjJAGTjGc8A1yfkbxxnPvX0jq+hvaaRPeNLstSfK+YkByQeOg9xXj3jLSIdP1CBLa3jt4jCG2xZIzk9c5ya7sJjZTfLLc483yCjQpqth3dHGPaHJwVx6VoaJ4Uvtbt2nt4ozFHJsYu+3kAE/Uc09oc+tb3hzxU3hyye3W0W43yNLuMm3qAMdPavRrVqiheG58thMDQlWSr6IxHsU8yNLSQXTHkiKNs/qOevp2qjdxmT5GUrsJBBGDn8q9zsdFsoPLlis7eF3UN8iKDngnmvOPFHgufRo5ryS6inDy/cRCD8xJ61w0MwU58stD6HH8N1aNBVafvLf0OIaAAcCmeVkcitNrZvTj0xTGt2BGM4r11VR8PPByjujMaDcajMHoM1pG3IzgVF5J9K1VU45YcoGPr2pDGSOKvmE+lRtASeKv2hh9X1KltbGeUp93gmtWeRLeMIFdZQowwHFanhfSoHDTzMPMG5dhbtxziofEwtpLqJbfB2IVbb2OTxXM6qnPlPZWBlQw3tdLsyPOkLqxbLKcjOK0be7a4G1zls44FZ4QetbGk2UTwh2BL56hvp2pVJRSMMLSqyna+hIlsznpmp7a1DTIG6E8irUcYVuPzqdYx6V50qnY+op4RaEr2MEIDLtHqS1eofAL4W6V8Rr/Xlu7y6sbmyhhaGWzdFAR2YOX3D5gNo6EdTmqnwQazsvGsF3fRo8EFvMcSQiVQxTaCVIP978K9X8Aadol74+11bTSYRPr1y1ikpJWCKIn51EYAADYOfy9a86rW0cO569HCvm5lolqeQm4RZXAk8xFYqGbGWUHAPHqPSvT/Eg8RaX4W0eS7vrhtLjPkW8KXTssRKg4wOACB+lbfj/AOAUfgHV9PlKW97Y3NvJI4to3EcBVgFU5zkEEdTzg1xXjprdI7FIr1Wcbg0HnFto+XaducDj15rzW3CVmfc06tHH0oVKdmk+qOevtcu7izktHupjbvgmIyHacdOPwrndVuLWOBUumjUPyofv0zj9KmvGbdweDXMa9BcXV5AFG5Qh/i9+a3oxvJXZhjq/sqT5VqcxqSttUucjceAfasWdRuOOciuiv7KYyOmwlg2cfhWTNbPGzK6lG9DX0lGSWh+UY2jKbbasY8gBJ46HFQsuc8VoT2m3cxbjPTPNVniK84NenGZ8tUotbopvHwDjioSuDV/ysnkcVC8BycD6VupWPOnSKLDFNxjOatPEc8ioth5rVSOOUGmRBfbrSYwfWptlJ5YznFMjkZDg88U5c45p5XFAHTjIp3BQYAfMKlVeRxxSpCGIwDj2q1FbFnGQx+lQ5JHTToSlsMihLgkflX1L+zH+z78UIv7M8c6LqqeF9Iv7fzo5YdVENzf26yZ2+Wqt8jPFjD47HpXy9KjQklcgda+t7v4+eMfDH7LvhnwZcfD3UtMtrSyFg/iW5kdYWjlkd0CKqjBdCVyW68jtXDXrNxtDqd9HDyjUjzLTqcb8ZPiZrr+J7u217c2vWqqrjzY5Y0ZvnK7ozg43f0PSvD729e/u57iXHmzOZGAHGTz3qxcT/a5Sxyc8fMcnt371RZM5Arnw9NU1c+hxuInWSjf3VsUZVJxVWSLDH+tan2Zsdqje0PUqDXepnz0qTk9jLMZJ96ayHGCK0zbmMgldoI4JGM1DNAGYt0NUqiMKlBpGcVppXJq0Yz/+uo2Qk10po86VNoroTE25eoz1FNdi7kk8mrIXIqNosA8Vqmc7iQkUhFS7R6UbAaq4rMg2Z9hQYgQetTbAOlBHBo5iHC5AEC9Ka45qbbmgoDVGVmVyGPGKQK3pU5TjOD+VJipE0RYpOAelPdN5zjNAQgYqwsMHPalx09aeE5OaXYBSQrEagke9LtPpUm09etAQt7Ci4+Ui2cckZpdueeDT1Tn5hxUhjAHAOaVx8pqJ4ouk8OHRQkf2YqULYO7G/d6+vt0rHAx3/SnBfQU4A+lUFrEeC4prIV9qmIz60hXOKAsyLa1JgmpOckYprKRnigm1hmDQckYqTZxTTGBQDRGVxSYNSbeM96TFBNhoX1qzpumvqVwYkdUIUvlgenHp9agK9DT4ppLd90UjRsRjKHBxTXmZtC3to1jdSQMwdozgsBgHiq+A1Syu8zmR2LuerMck1HyaHboVYbtApKXGetG2kRYQDBFemXfxlN78IV8DNp0iBBCBeeeCp2Sh+U28A/X3Nea7aNoouAdSecijbQBg0tO4MbjmkI9qcRmkYZx7UImw0jikC5JzTqKYhp4oGaUrmgDFAmLScUpOKZgUAhxHFN6UoA9KSncYtIRkUtFNCACk78UvWkximGooOO9OFM60oPagLBQ3enGmn2pDEVQORSg4oHvRnr607mbQuBmjH1pRijFJCWodTXVeAPh5qPxFv72y02W2hmtbf7SxuWIDLvVcDAPOWFcpgAe9aOjeINS8Pyyy6XqF1pskyeXI9rM0bOmc4JGOMgHHtVodrC61o8mgaxe6bPIks1pM0DyRZ2FlOCRnnH4VTAxUl1ezX9xLc3Erz3ErF3lkOWZj1JJ5J96iU5ob7Fod0B9KjPJJqQnjFMIA6AUkx7CHitrwvbBPtJBznZ1/4FWKw44610vhKPzFuu+An/s1c9fSNzqw8eaZhTZM0mf7x/nUt/zYx/h/WmzR/v5Bnjc386lvkAsE/D+tRHVI5qmjaMb0pkvEMn+6f5U8DpTJuYZf9007HGY6jpRR6UVJmwpDS0hGaBADmlpo4NOoGwHUVetxmyaqPcVegI+xN+P86O4IktvufiasKOR9R/Oq1t/qif8AaNWEbBH4U1sjRHo3gqxS9nn3lhgJjbx13VzyxmO/uFI6Mwz+Jrr/AIfjFxdfRP61z98mLy4/66N/M1ywd6jR9FWpqOGpyDTv+P6EdfmP8qy/EQY64igEsUTgDJrW0wYvofqf5Gquo3a6d4rtbplLLCYpNq9SAcnH4VcnaWhhTipU0pOyuYsoZG+dSjdcMMfzpoYc1reLNdj8Q6qLuOKSJRGse2VgzEjqcisYNXZBuUbtE1VGE3GErpdRwJ7UZxzTQeSa0tB0WXxDqSWUMiROyswdwSPlGccVTkoq72M4RlVkoRWrM4nIpAcVoa/o0nh/UpLKWWOd41Ql4s4O4Z7/AFrNJojJSV0KpB0pOE1ZjlPJp2TUaYGeaUtg0+hkpW2FJAzQHPpTC2c96buz0pEtsm3+2KQtjtTATgUlFg5mP3+xpC2egptJz7UWFckBz7Uu7GcVGMg0UWDmY7n1pc4pmR7UuamwkxwbaSck07dkCoqUMR9KLFcxJuyeadvAqDOacpODmnYpSJllwMck08PnPrVde1OzgikUpWLKtjB7U5ZMkDFVw/r1p4boelBvGZbD4PapEcgfWqisRjrmplNZtHVGZaQk1PEcHPtVOI8VaikGQMVhJHdSlctwuVIxx+Ga0rWWPB8xx7dqy4mGT6VctVMjhRk5rkqRR7uFm00jTWKFliEcsZI+8C/Na1tdLbkDcD/sg8/yr334GfsZeLfF0XgrxpdwaPceC76aG7uvNvf3gthIQ6vHtyT8pG0Z6jkdvXfiZ+xAuueJZJ/CGq+HtL0wQoi2zQTQkuMlmOAw7gfh0rx68VLY+nwea0aE+W+vWx4L8PPEsvhrxZoerRqsj2F3FdKr8AlR344/Kvv34aeN7D49/DK/sNQuNPttc1OK4spoDLuKRlzsOGO8jB/H8K+atD/YM8c34lePxB4cIVtpJuLg549PKrgvE3gHUPhB49k0nULqC41HTJoneWxZgrfdkADEA9CB0614f73De9Je6z6rGUcu4map4apavBXWnY+u/HPwtXw1aXFkZbS8mjtR9ngtbbykjGHCoFYsCfc18W/EHwS2j3Sf21piW13NGdjXEYZigYehxjnFfU+nfGOTx7cfbn0yW2Fw6xh2nD7Qp68KPX9K8n/acQXXijRVA/5cH6D1krnrOKfPT0N8iji6E44PGq7lvc+RdZ0WX7VIYoCR8owi4xwP6mu28EfBW4121sNSivFnLgSG2W2L7Tn7rc+3pV7UvDEUbx3Ls7ksw2DpyOK9W+BHxzufg7Nd2sXh6DV4L6aNpGluWhMYUbeNqNnrnkfzrWOJdRKN7eZ7OLylYWM8RRhzz6ROu8AadpXw98E+ILPxHodvealqat9jvZIEBtyY9o/1mCBuw3y5HWvCrvwfJqZEVyYJ48glRJwTx3Fe1/tB/EvSPinrel3+mxT2v2OB4ZEuIsZJYEFTk5/SvKtMvHi81pVMm44BOPQ9PTtXJWmk1GL26nblOHqSpTxFaLjKpvFu6VtEWrL4AaZqiwmHT1cOFO5HmOeBnpXluqfB/V9Ke5+1gQGMvhFhdmJGQByAPTv3r7Q8H/F7RZ7ew0yKzngZmitk81owNxGM8H9cd62PG3wv07x3pbWsATTZ2lV5Lq0t4y7qMgqSex4ranWqR1jK583i6lL2vJi6PLHpb8z827mwe2dkmiMbqcMrDkVWe1JUkKwGK+pvix+zppvw90xLtxPeS3ImKSPNgIVUHlVUDkn1PSvnCW22xsMgjHqMV7FHFqej3PnsRl8HH2lJ80XsYZt/ZqZ5BzjafyrU+znpxn0qxHpszxGZYyYx1ftXZ7Zb3PKWCk3axFotkWaRsEAjafXt7VcvdEt5opCIx5uCQxJ602zt5YZg6AHjoScVaE84bDrHj0Ga45zfNzJn0FChTVH2c46mDa6X9nlJkCYx0HP8xV620xI3Dxbjvzx2yMZxxWppmmy6ozhdqBMds5zXX6R4chhtFjJkExZiWUDnOOxHt61jUxVt2elgskdWKlGOhxH2R41BIIycc1ctLUuyZViCQOB/Kuv1DwcUWKXzSVbOA/tivW/hD+zb4q8SXWiahLp8lv4ammjeW5aZE3wbvmZVyWPAI6Vz+1dRWgejPBUcAnVxUrRX4vsZv7PWlX2n+J5rrTdPublDbGGSQDAQsyEckYzx/Ouo8J2Wr/FD4l30WkW8unanBf8AnXV1bMJHs1EpUyAY5I9Oa+jda8P+EfhJohTSbS9gWaQkokrSklQeu/PQGpviX4sg8A+Ab268KpDa6/cRI6TwWsbOwym4vgcnDZ5pxo6++9j5etnKrSawtO3Por/qeR/HG8X4carHo83irUdfup7SK58zU5EYxHc6/JtQBQQuSD3H4180azey6i4kkYySqNgY9SOw6V1/i+x8X+P7K78WanLd6z9iCwSXUkfKRbuAMDoGb9a9e/Zb/ZT1H4gS2PirXSbHRbK9B+wXFu4kulQBsgnGEJIwcHODWDpSr1fdR9RSx2EyHLP9pqJyXbq+x8/6H8HfFvjzwT4g8V6HBINL8Pwma7dxInmJtLN5R2lXKhSSMgjI9a890vSNW1O4e4aQm3jBXdL0P0Ar9utVsrK80O7067t47nT7iB4JreRMpJGykFSPQg4/Gvzw/ak+GunfD3X9KtPDGiLYaVPatO62MDmGMhyMFjnB2gE5I69K68TS+r07w1Z8dkeeLPMe6WKXKntbb5nyFqTPZ6pdR3A4UhRsGc4rEvn8+Z5Nu0MRgd+lejeI9ATUoY/KaOGYNlnYfe6DmuEnsnEuxEZyM8hTzya0w1eM4p9T2c3y6vhZuG8XsGlQxTQNE6q3zHgjJxWTfWBtHCsQcjIPT2rQjMkMqsByD0I96maRrkF2UAjjjpXdGpKMrrY+Znh1Uha1mc8YVc85H0NRyWwUjBOD6mt64g8xABhcHkgVUkjGCgBLcDOK7Y1rnj1cHbRmJJbc9SarPD8x7V0BtgDnaM+9U7mxCqWBYn04rpjVWx5dTBy3Rj+T9aDFx0q6IWb+E/kaeLNmUHO0/StPaeZyxw0n0M7yPT+dPSAlh2/GtH+zmHJBx/umlFptYdT7VDq+Z0LCSXQghs2duF3cdM5rTtLHylD7QG7/AOTT9PjEdwvyE547VsJAHGMZ+lclSvbY+gwWATXO9zLWye+nhghCtJM6xqGOAWY4GT6c1798a/hp8T/hp8KLOw8Xa6mqWd5q0UEVnHftc+V9nt5CACQML8+MdinSvKNA8Faj4kv4bXS7Ke5upWVY0jRjkkjGCB15/SvoH9rjw38Q/Dn/AAj9n4o8XReJdDmmlmsUZAJIZlVVfefLG4YbAP14B68sqmzOirSbqKnFrU+U/LOcH73em/Zucjke9bM+lqkxIYNuy7FTn5j26U+20h7jbsXOTjqfatvbxte4vqNRytymILV3ONhq1a6SzjLFAB1U9TXXW3gu6z5sMbzqp+ZBEScEgdgfWtfxF8PL3RPCena0zNGbmVIzZPCVlQMzKDj3Keg6iueWMjsmdccqcNZr5HBavEtzFGgXDKcjnoKwXgKsRjB6810bRM+5jknvmqN5amTLAgYGMYrppVLaHmYzCqXvJanPz2+VyMbs9jVMpWs6cdM1Tmj5HGBXpwmfK1aJRZcAUxuasuvbFQleTz+tdKkefKmyuePb3NKPXtWno2of2VqMdyyGQIGG1SOSRj0NRateLqV/LchPLEmPlOOOB9Kak72IdP3b9SkADigqKdswOKUJ7VfMZcruRYIppTAzmpygz0pNvWnzByFcLz7U8RAjOcVJtpdv1o5g9mVpE2EDJOe9Nq2F20hXd9KOcl0iuibyecYpTFg4P581OIwDilMfHQU+cnk0K6qAMClKmpSn4UYNO63Dl6EJHrSqMmpcZPNAX86dxcnUjxjPejbk9DUoFBXdg44p8w+QjP0pCOKmChTk8AV7D4Z/Zu1y90q6v/EUN54YhRVeJrq3XDrgkscsNoGB19fauariKdBXmzvwuAq4uXLSWv4Hi2wntRtIJz+FdF448OweFvFV/pVrfJqVvbuojuUK4kDIrD7pIyM9j2rBYEkVvCaqRUl1OStQdKcoPdERXIFM21PjI57UxlwfatDlcehC4+bgce1IBx6VNjFMdeeaEZtEbcdeabUu3IqIKc4pkWDvTSKcRzRigloZj1o2j1NOxmgjNAuUaOaM47UuDmjOKCbDd2aWlo7cdaBCUGgjgmkxkCgAjRpZFRFLMxwFAyST0xUs9nNagedDJCT0EiFc/nS2l19iu4LgKHMLiTDdDgg9qu+IPEEmuyQl4Uh8lSAEyepzzmobmpJJaHVGFF0ZSlL3uiMqg9KAc0hFanENzzQMVtHwrcHw3/bSzxNBuwYud4+bb9P1rEKkLzUQmpXsbVaNSjZzVrig5pR1xSAYpaswQUUUUDGkEY5zzSnmlopiGjgUucnil7Y4qS2ZYrmJ3GY1cFhjPGeaY7kfagVreIbyxvZoWsY/KRVO8eUE5z/hWSOtDELjIoK4paKLCuID2pcH1ooPSgQE4pvU+9O74oA5PFFykhAcU9Tzk00dKKYIfkHNIRg+tIEx3p2cUDEI49K7/wCGWmW19FqZuZniCLCV29yS3X8q4Aj2r0P4Xr/o+q/7sI/V64Ma2qV0e5lEIzxKT1OJu2C3c4HQSMASPc1e1S1RNGjkG4udh68c1l3Llr+5AHHmMc/jXW+I9DjtvBtpercbndYt0fynG4e3PFEZWjE450faTqNdDhMdKimOIZf9009j/KopMCOX/dP8q2ex4j0MmijvRUmQUUUUAJS0UUAA61chGLNv896p1eix9kPvn+dT1Y0SWykQE9smpo/n9qits+Vj3NSp8pFUtkaR3PWPAsRiuLnLBs7P61zuog/brkdf3rfzrpvCB23Fx+H8zXMagc3tyexkb+Zrhpv96z6vEq2Epj9N/wCP+H6n+RrK8Uj/AInB/wBxK0tMP+nw+mT/ACNZvik7tYb/AHE/ka6V/ER5v/Lj5mSefemk80Z+tITXcjkuKGwantb6aymEtvM8EgGN8bFTj0yKrHntS9RQ9VZjVRxd0S3F1JdSGSaR5ZDjLuxJP4mocikPANB60kktBSnKTux1HOcY49aaD6mnZoJ06CFcjGaFXBpwG4gDrVu/0i+0kJ9ts7i0LlgvnxlNxGM4yOcZH50BvqU6M0U3jNBKY7vRSmJkUMVIX1pu6gYtFM359qN3rQQPopoJozQVsOJxRuHrTO/PIpOnSgEr7Emc0UzocZp248Gi47NbjgaXdyKjz+FaOhaDdeIbw2tqYhIE3kyyBFAyBnJ+orOUlFXZ0UqM6slCK3KmfzqVTnnt9K+gIdD8CeC9KtR4jtLGWSREWOUQtKXdUXzfu47nP41z/g7Wfhza2ci6tDbGbzCRutHfgkYxx6dj61439pNpuMG0j7dcNKnJQrYiMW+j6ep5NEpJxggfQ17xov7EPxj1/RNN1ex8MQTWGoW0V3bSjU7dd8UiB1OC+QcMODyO/NM1DxL8JxayiCyt2nZSqFdPcAMehPI6Z/8ArGpLD9tv4yeFrK20bQPGrWegadEtpp9s+k2LiOCMbY13NCWPygctz61cMTWxC9yHL6nBjsvpZe1asp37E95+w78ZdNtZbibwvAI4lLsV1O3PAGTxv54HavKvE/g7U/BeowWWqxJFcSwrcKI5BINjEgcjvlSMdq9Yk/bv+N15C8V14yt7iN1Ksj6JY8gjGDiEHpU934o8C+PbIahrk8M2oW0Kwg3CSwsVALBVCHBG4sK561evQadSOnkejleBo41SjzqMltc87+Gvww8S/FrXpNF8Kad/auqR273TQefHDiNWUFtzkDqy8Zyc8V6Bd/s2ePfhZLDrPj3wtcaP4bSQQS3b3MMimRwRGg8t2bk+3brVXwF8YdM+EeoX+t+CrltC16aze1jnNu03B2ttxLvXllXn2rI+If7TnxN+LGgjRvFXiltU0ozRztaizt4l8xPunKRg8ZPGcc0lUqV72jZHTUprA1otTUl5Hpa/tLeIPCngn/hCdH8VXmn6DDEYks4lX5Udt5CybN/VjznvUOlftSeLoYTGfHGqYB4LtuPQDqVOelfOxlM7bmYscDJxjtj2r2j4OeEvhhqngfxFf+NvEaadr0RkTTLH7YYjLiAlSQI2BBk2rksB19c1zSwKa3Z68c3hTleNKNr9vzOyi/aj8XqWMfj3WF3dfLlK5/Jaxr/x7f8AizUH1HUNVudTu5yA9xdSFnfHAyTzwABXh1vMVKhsg4GeK6DStfls5YlE+IlYEjZnjIz715WIwkuWybPsspzmhRq87pqLatdLU9j0bWbiz1K0lS4kjCTxuT5hC8MDzX1hovgkfGVpNT0vTLPxDHaH7MbobGEZ+8YwWIz1B4GOa+ItM8T2V3LIweRggzzER1NekeBf2g/Fnw4sJrTw3rk2m2s0nmyRLAjhnwBn50OOAvAPYV5Maai+WotD381hUx1NVsvmudd9j670P4CQaXrdjceJPC+nR6LFLvuTNDC6BcHqASSM47VT+Kvwc+H+sa5bS+H9J021tBbDd/ZyGJTJvJyQuBnGOory7w3+0rr+vaXND4p1fUNVjlWJkEEEIWNstuztC5yNvc9KuL8WLTai2s10GZgiia3AGTj0PvWvPSjFwitPM+NpZfm6xKxFeo7ror2Mj/hn7Wroz4TT0t1dihadssuRjgDjjP4ivMdY0OW11WO1tYCpkIRIkySzZI4yB3r36z8e6g80UbPEUZgpJwMA8Guin8M6Lqt5HcyafbvcQsGWQDaVbgj+VcjjB/CfWUs3xOEu8QrrofK2oaLqfh65ha8t5LO4zvj3kZ+U9Rj3Fe8fA74rx/YtVTxRqubgyRm3aRP+We0ggbRjOcE/Wtfx38NIvGdoZYWkF9ZxOYYY9oErNzhi2Mcj1rgvhp8HPEHjPVLy2s7b7ObdAZHucooJPA4ycnBqI88JWjrcWJxmDzPBylXlytde3/Dm78ZvG+neLbmwg06QT29uj7pCpALMRxg+w/WvAdf8MxNfB44o8SkBV2Dr7cV6frHh250jVLqxuFCXFtK0Mi84DKcHHT0rS8M+BtX1N4b+302W4skkwZ/l2Z9MnuKbU5tt3LweJw2BoqKknHpc8f8AFPwku7bw1HcyJbW5Eyg4XL4IPoO3HeuUk8NNpunx28MZumMmXIXHXB/pX19/whaa4y2WrWiy2rMDsMhHzDp905rRsP2Q11XxK5fNhoL2wMZhnDyednBXnJx3rqpxqtWiclXN8vpyc8RZN9j41l0SFg4S3RpD0DADvViHSo9NDE28aM/Xad2P0xXu/wAR/gfHoFlfpo0d1eX8EwRF35bAbDYGAOleN3unXdlI8N6jwTRY3pMQCn19KyvUvY+jw1XB4iHtYbGRIqpIXjRFY/eOAM4/Kvfvg/8AAN/EOmW2v+IWsU0qS2aQRJOwkIKqUdscDnPf+VaujfsoXujaBdar4mEaywRtPGbS7LJtCbgGUqDzgjg9683m+Lmoal4MvvDVnYyQWN3AsQEVyw8gAg/KMDrzx71py+zd6iPMq455hB0sunaz1a7eR3PxJ1v4daXrug6ILOC9i0+aWO8EKSK0f3MB2HLfr0r0jwh+0d4T0F9H8N28Xk6PDGtul/vxHEozjcGAPpzz1HWvjvUDcWt4PtRcOVzl2yfzprawIl5lwc+uaUK04vmii62R4fEUVSxE22vPr3PtzxT8Zfhf4jxb3erRakLeN5jBbmQFu20MFwcjPGa9D03xP8L9Eu7bUp9RmAms18qzuEkmRUbGGClThsADOf61+dUdxPGs5Nw4WdBHKNow4HQGteDxbLFLHKszGVI1jEnlJnAAwOR7VvHGyi2+U+fr8G06kVGnVasffuj+PtA1/wCJdm2mu50OIq+3yHQySBGGAhUcZZTnP+NeneLPGtnbaSUQXOns8UjJPIAgGyMt6+w7dq/MOH4lazCpEGqXkC/9MZPL/wDQAK2fFHx38ReK/Ctnomp35nt7R96T4Pnt8rL80mctwx962p5g4xatqeLi+BqtarTcal4rR3f4ntvxH/ah0bxHqkUXha/ljIUsxMMkfzAjbgHg4x34r0L4XfEGw+NngPUfCHiy9S41K8MkCw2xNvLcW2Bzuyo3YDZ2847V8HaVq+nafetNOs8gKbAIipxnHY13nw68bnQvF1jrmkSTWNzYuSs0iI+AykMNvIIK5GPfrXLTxUo1L1NmfR4zhSgsF7PC6VIap+ZL8U/glrXw88ZjTH0ycWV/O/8AZ21xKZYweAWAxuAIyP6V5xqegx2et3UV1AsdxC3lMjgAqR2+tfo3pOp6D8ePhlZX80kL+JbYPCZI41jkglPDFU+YhWUZ9SPQ1m6l+yxB4Xgv9Q0WCLxBqN7OHkN7FGpQYPK5UjGeSOtdbwbcnOi9NzzMPxfGlSWFzKP7yOmq3t1ufm1Z+ENNE0jzRNdAsSBLIcde23B/Wm6Z4TtLZpfMVHVnO0SchVzxjjPT37V+h9r8CfDvhywnnbQ7C4uJXM8zi3EgBPJABGABnHHFfMviz4Ea5F40e002C3mtb+aWaBw/lJCgYna+emB6ZzxWM3Vpbs9bA47LMfJ+6o26nyzJbmF3jYZZGKnj0JFMECu+CgHuBXuOsfATxRrviaPRLLSJ59SSNpP9Hi3JIvyndv4BHOM/hXB6h8PbrS5jbSMFuo5jFNG6kGMrkEH6EV0QxOictDlq5ep1JQotS66eZw91aokeVU7s+tUmtXJ+435V2+q+DLmBIzE63BJPCjGPzrMXw7fCZ41gZ2TG4Lg4z0/OuqOJVtzy6uU1VKzizlns342o9RNZSyMcYGf7xrtLfw/O0+26ikiTbkE8c/rVHUdPS0v9iHKADBJzzWixK2uZvKJKPPYz50863SPGcYzn6VWW03MFwAB/dNdZpXhebU4Q0TxmRs7YmyG4IzzjFbKeBtTisJGNqN6JklXVifoBz3qHiY7JnYspqW55R0OChs1RwwzuFew/Af4C6n8ZdUuXs7+wsbfTZIGnW+V285WLcKFHP+rYHp1rf+Dv7M+tfEjVJ31rT9V0Pw9bRM8uoGDyWLjG1V81cHPOT2A7E10PjOGx+E93pWn/AA38VXtmPIn+139rdpNLI/mLhJdq7flAYAED7x+tTOfK7yOWK+sc1DC6y8j3T4hfFnwD+zl4G1Dwx4Zu7BvEenxTfY9GVZZkS4LiUJLhvlAZgw3Hp3r4c8V+Nde+Kmr3Wt615ct40rALbQiKGIHHyoo4A/Ek9zSanYatrWsX2oavey6jf3UryT3MvzNMxPDEkDn+VaK20dhYl2UIowWOO54zwPpXNVxKatHU9bKeHp0n7bE6d7nL2ujS3WowWYTZLNIqAOcDJ9SelfQfw6/Z91bxzb6VpFrZ20PnyuIrqRgoDqCzB2XJzgkDI9KT4Z/speNviPNp99No8mlaDdqkyand+WylDgowTcGYMOmMV9+fCDQPD3gXw5pvhTTmtjqWn2iG4EasGZgNpk+bJ5IxzzjAqKdKVeS5nZL8Ty86zmhldOUMFac/LW3qeVfC/wDZr0n4V31jLLbyXHiWO1zJMblpEG7KtsUADHHGRn86f8YvCH2eYaxJASsVsWkAbMr+WGIAyPr3719BalrOm6Te2gu38uW8JijdYS+cDOGYDgc9TxXl/wC0X4I1eXQ7jxHZfYJrDT7GV7mK6JVlUKxLKRweD09u9bYrDKFN+z1aPg8rzeriMbCeKla+l3+R+WXjvR7K1uze6RaTWGlShNltcz+dKjHJbLY5GelcgyfL06jpXqviLThqVt9nGEUMCCFzjH+TXnus6RJplzsYlk2ghiMdanC4jmSjLc/Vc2yr2KVWkrxdjmrq0B3FEAxWdJFuHIrekjWQsMAiqs1qmeEAr3qdW25+dYjCXbaMOSMg57UkBVHPmAEe4zV6W13FgAOvpUHkEZyAfauyNS54s6Di9EUbiP7RMzpjaeBxio/szjnitHyNo6D86QxE5rVTOV4e7u0ZpiYEdOaURkjkVo/ZSxBK5pssIL5QKPyqlURLwzKPl5zR5JPStGGx8wAlsE9QK0LKzjg3NIBKDjGRn/GplWUTangZy3OeEDN0BP4VLDafP+8U7a2W05UIMa4yPWrEmi3MVil40J+zs2zdkHB9x26GsPrSWlztjlc3dpXscy8DLxgdaBAxGSowK3PsyMoYopP0pjWgJOEAHsK1Va5xzwTiY3lgY4pUi3uFAGTxWi1nu42jA70gtChDDA+lbKorHH9WlfYzri28kYIGT6VGEGK1HjDt8y5I71WmhUEBV/Kmp9CZ4e2pU280mD0qwYvY0nlYPfFWpGPs2QhMnBpwi5AUZp6oAehp6DacrkEd+tDnoVGk2RG3klIRULM4KhRyT9BXrfxF/aA1vxh4V0zQlifSYBZi2v0VzIt4Nse1zuG5TlCSAe57V7BpeqfDr4cfCfwp4hGl6Vd+JHs7WSRLERfbBIykO5JJIII5BGea+a/iH4tHjjxEdTFobPMSReUZN5wueScD19K8iFRYqr70NI9We7ODwdF8tTWXRHKsmCNoA46DtUTD9KsFOM1EyYNe3FrY+ZnHUioyKfsHfvTdntWtzFx6kW001hg1LwM5oCgjoKdzFwuQdz6e9NK88d+alK4J9Otbmu+D7vQLKC6uJYJI5WCqI2JPK7u46YpuSW4lSlJNpbHOFOeRQY88jpUpXmgiqMrELrgdabtz6VMRzTWQdRmgViPvjvTW608ggUjAYHrQQ0MoBxQRW3oWjWWp2shnuxBMrY2llAC8c8/jWc5qG5tQw88RPkiYmeKQccUDJYAAkk4GO/pWnqnhvUtFiSa9tGt43IUMxHX069eDV88dE2ZqjNptK6W5mHpUZ609jSfSrMLCA4pR05FSRQPMwVEZ2yBhQT14rt9J+FVzdRu2oXBsWBBCoA+V7k8jH+c1hUrQpfEzvwuX4jF39jG9vuOP/tS6GnCxFxKtqDnyVbCk+4qljnip7qH7PcyxbtwRyobsQCRUXFXFRtePU4q0puXLN7aCbabgk808HNGOc1oYDaQ9DSnrXZR/C/UJPh43jAXdp9gG79x85m4k8vGAuBzz16U0rjOO6DGaTHXNKBS0hMaevFPx3zTc84pTnHWgLhim04sCPemNyrY644oGhwz9RQDmuz8beJPDur6VaW2i6ebOeOXdK5tUhLLtxjKkk844NcXimimrDs/jSAZrpPh1o+j674vsLHXr5NN0mYS+ddPOsATEbMvzsCB8wUY75x3qX4l6NougeMbyy8PXiX+kRrGYbhLhbgNlAW+deCck8dulDFY5gHgUmcUUU0AZz2rvfhF8KZ/izqupWVvefZGs7dbjIi8zflwuOoxXBY96khnktyTFI8bdzGxUn8qpeYjR8S6K3h3xHqmku5lawupbUuV2lijFScds46VmfeFLJIZGLsxZjyWY5JPqaQDOeaGMM5Neh/C45t9V/wB2H+b154Rya9D+FY3xarjniD+b15+N/hHv5Lrikjhrhc3E/wD10b/0I1va/YC38KWsvmAkiLK7cYJz3rDu8C8uBnpI38zWzrllJD4ctpS3yMsbY3evSps2o2OSc1CVRNXucc2eM80yX/Vyf7p/lUxxmo5h+5f/AHTXQeA9TI7f59KKO/8An0oqTIKKKKAG5q4umTMoPy4PqaSzgSRmLDcPTNbhtHijjLAAMOMVSVxpXMObTpbeIyNjaPSpYeLI/j/MV1uu6RbxeD4LtVInOze27IPJ7flXIxn/AEFvxrPmTeh0VaMqLSl1JLU5iP1NTjr+VV7IZiP1NWfLZTgj/OaroiInrHhU7ZLk/wC7/M1z2o2skUskjYKM5xj6mtvw1dQq9wGfaTt7e5qlrg/0dTjOX/xrhheNVn1lVKeDi77GZpn/AB/Q+mf6VmeJ/wDkKsf9hP5Vp6b/AMf0X1/pWb4n/wCQq/8Aup/Kun/l4jyn/A+ZkZ5opwA7800gg/yrvRwCYNLQOlFFh3CkxxSnjJoqR7jT1oBwaUDmlOMHpQIEco6sOqkEfga3vFPjS98XCD7ZDBEYSxUwhh97HByTxxXP0UDvbQXdSUY46112h6V4cufClzPf3iQ6uDN5URm2kgICnHufzqoq5OxyrTl0CkAAY/So6M4x60Urj2GsaSgmgHJ4NInccDmlpMgU3NBXkLnkd667R4fDR0yD7ZLF9p25k3NJnOT6DHpXIU4cAcmsatP2isnY7sHilhZOXIpep12tf8I5Hp0osPJkuW2hQN+RyMkZ46Vj6PoE+tJK8DRKIiARI+0kn049qywcHjirljrN5piuttN5auQWwoOSPcis1SlTjaLu/M6Z4qjiKynVjaPZHf6RfeFdN0u3ttRitTfxJtmDW+87snOSBz+dcfquqJB4lurzR3FtBvzCYV2ADA7YrGnuHubiSaQ7pJGLMcYyTSB8ms6WGUW5Sd79DoxOaurCNOEUuXZrc0tS1rUtflhW8u5LkqdqBzwM4z/KpNW8P3mgCL7UqASZClHDdOvSsxX2sGHUc9PfNWb/AFa71QJ9qnaby87cgALnGeAK3VNxkuVaHL9YjUhKVdtzezv+ZEsmcetSxtmqynmpVbpg9eMVtZLU5ISbehZBwOfyJresbJ7IyLeYtQwBw7AZ/nWp4DsbU2t1Le28LkMMfaFGQACTjI/lVLxxq8N3fpbwbWSHDCWJgVYMoJ6fQfr0ryZ1nVqezitO59rQwscHhVi6stXsijqMlujobdw/B3ENkdeKqo49apeZ0POKmikznsK640+VHiVMT7WfNa3kXY32lTyKtJOwHBIFZiyEAZNTxyeh4rOUDopVTSSQg9eatRTnPU4+lZKSHHtVmKQgZB61xzgexSxBvW188R+R5Fz1wcVpW2rzJKrCeUYOfv1zMMmCMGrsU5z97OPevOqUk90fSYXHThZJnpvhrXrqSKZ/tczH5B85z610tv4gvS6BrlxjkNxnP5V5t4W1SC2FwJ5I4g2wAscZ6/4ivUvBPge98dSj7LJ9msyGBvjGXi3DGVGOrc9Pzr5jE0XGex+sZZjqUsKpTkrlr/hO9bTI/tWc899jf0rc0L4ta5pto1tHfBEdizPsUNkjHUDiu18Yj4b+BNLntL/TdLOtvZSTWtu1oxkmYIVUkgELl17kYr5o07xBLHuS6lwVQbTs5Ld+lYKhNq6HHMMFiZezqQsfXl78YtHsrJDHfedOqqjGJmZ2+Xlu3eul/Zz+K9ho2pX8r2zXQnCKxVijLg8cE4OS3X9MGvjrStYS4WRnm5DAKNjD+hrsfC+vtpjLJbzSJJv3K0YYEfjilGUqU1Jo5sTkWDx2FnSpy+I/ULT/AITeErnVDrn9hW0V5dq7XIBJWcsMESKSVb16dcHmtq78J6C+mJYf2RYpYx4McCW6qiY9ABxXw98Mv2jL7wzZajHrGqaxfC4MQtyJyTbhc7sbjxnj24ruY/2kIfFlnd2P9oatHiMB/MdFByRgZXnJOele2sVSnHRan4niuEs1oVWnJuKOj8a+LfBNlqn2e10y6t7m2nwZ4sCJgrAHgscg/T+dd3B+0D4Ak8Z6f4XkST+1rqWOFc2o8tHcZUM3bP0718U/FD4zaXrcz6dpmm3Fs0E7h7uZlAOMqQFGcjPPJ7V55f8AiGdddXWba+jhvonSSKZAA8bIAEYZ7jGa8+niZUpvsz7T/VD61hlKbakl1Z+iXxA+HmgeF9L1nU5bq4lhjtp7yKEuiqpRdxUseWySfpivL/Cp+CreAR481Sz0/WL6CHOoQzv9pmVsqpTymPPAUqMdDnvXkvxtl1vxD+zr4M1XxJ4iuta1ObVEuFFwIh5aSwyjaNicjAHOcduOK+d5IFKjCrnHB2jNdFWtCnLmjHcyybh/E43DSjUxDXLKzt2R9E/H/wDapvvFeqtY+C9SlsfDZthC8ZtEV3Y7gw+YEhcYHGK+ctM8U2elyXELOGldNmwIcAj8OKxNa1230xAsju0jZwoXPp3PFcDfanNPcPL5rZYkgg4qYUZ4p80z6l4jCZBTVDDLXr3+Z6H4p1lNQtvM83cdu0tjb3B/rXHi5KsrBs4rLttRdsrPPIUxwGbIzQ+pJFlVJbpg7f8A69d1PC+zVtzx8XnH1mSqJ2OoHiy/CEfaZAD6AVNa+Mmj4kDyn+8QP8a4yXVugxj/AID/APXqIXwDVr9Ui90cSzmqn7szuV8YyopACk54Ow5/nSDxVNNwWAz6RmuLXUXAIHIPvTDdf72fZqn6jDsbLPay1cztYtbjkuoVlmUAuAcriuo8P61FdastvCSU2l3IGOnb8zXkNvd7JUY5wGBOTW/p+oBkMkfXJGeR/KsK2Cjy6Ho4PPJyl7zPpbwx8Z9c+G8jJ4fe2t/NCtK08Ak3EZCkZx0BP516V8G/2zbrwjr+t3PiT+0vEQ1Nk2wwygR2zgsTtRzgZyOB6V8XR67ewhoobhkjJ3ELjr069a07GeaO2jmViJCxOce9ccYVqCTUtjqxVDLs25lUpay3fU/UX4F/GbRvijpuqWHiC8toru5kMdvE0Qt5Nhx8oIJDEEgDHJx3rZ+IGq+AtAsrnREaF/EVuIwMwM8yMQCCX24GVPryK/Nrw14r1nQtLiurO5+zyRyN5ciIBIp3A5B+v8q7TSPHuva/fXd9qGq3N3fXciGa4lkG47VAXOAOn4dKuWLfs+WauzxHwap4tVcNVcab1t5/5H2d4G8VafpmuPJJby3ZmgMKiNlwnzBsnOOOOteH/tT/AALj8KrH4p0LTray0iSXyp4rd3ZvMckhiCMAduD1I45rzj4X/GC/0fxGj6zqD3WnkNG3nkMYySBu4GeO9favgXxd4Z8YeFmj8RXFrqNvHOlzafaV3KAFyhUAcEc89eaVKUK8fZyduxx5hQxXDuKjjaSck7J+Z8I+C/hTq3jmWdInjtGiClRdo6+Zk4+U47f1pmqfC3WtItrln0e8IWbyTIsBwxBIyOMkcHnFfonpug+GvFupXlrCjtZ2hiZJIpWxMWySDnqMpjHTrTPiJ8J9I1mOG+trCBJ7W3eJVCZLLnI7dck1UsDaDlF3sbU+PWsRGE6dk+/Q/NO08ISXUs6XSG0MIGY5kwxz9eldXpfws1DR7X+17zTpIdPIVI5pQmGZvukAnPNfQT/DTTdd1m4xo8d9d7M7Y0YsVHy9AfoK9n0j4DJr3hGystcZbWNVjZbRIgzRBDlAWJ7Djj3rmw9CddtI9nMOMKOFUXZa7nwzZ/Cu6/t2S9mMVlDMWKLIBkZ7AL+NdD8KPB1n4m8aXeneJkmg0G0t5p7i40qRjKQm0rg46NntyM11H7U+i6nYeMNH8IW+nShri4DWjrjF2ztsQIPYkgg9/wA69V+Bnwl0j4M+Fbm5+Ikej2muSySSW7S3Su5txGu6MZIBwc5UZ6j2FdFHDSjUvLoZ5nxBTq5d+6l71RaKO/qWf2q/Hes2vw/0aXwy13ZWFzdm2u5pIsSNG0R2qSeRk/0r468Q/D/V9Ehtri7tRGLp9qBXUsW69B65H519QWX7Y3hnxlJeW2s6Ouh6bCqPbee32mSRs4xtVMIQADnkc1l+F/jX8Pbj+0LjxHaQz3Iv5JLLdYvcbIRjyyCFwrcdOtGK5cRU0noebkVXF5Jh2nhm5X+ep8/aR8Mta0y92eIPC97GLlkitI7m2OZZMnKqOpPTivrD4AfsvaRp1udf8VeHtPktL+22f2Jqll5kltIjn5sMWB3KM8AdBXlGtftD6heeOrK68q0ay0vUftFskkRR5IwcBXYnOSpPTpxwcV6742/aE8N+LNB0rUmku7NIhJL9jYuku8AY+62COeGJAyR0qKPsabct2jozvEZ1jqVOg4ckZ7tfkcZ+0H+1jpF3oFz4M8BW97pptbkW0moxotvEkUTYKQgZJU4x0HGa5X4UfFt7mW7v5lEGqHEMk8UpQupyxJZic8/yFeFeO/FGg+IfF2oX2l2n9jWrqpaK4YBpH/ifAzgnI79ee9YVtqVvMkjRzI8aYz1A/lXHVr1ZVOddD6TLeH8up4FUGvelq297n174j+OZkvzbwNc3b2ri3nkW4QhS56rzkgDGT717b8IviaNRSLw/rUgvrK7V44XlAdccnYeDlSPX+tfmwut2xQESKUP+ycfyrpPCfxK1Xw3pup2GlXMcdvfRmJy0W5kBUqSjHleD2+tbUsVOM+aSPNzLhPDYjD+yw7XN0Z9A/tjfA8+HdfvPG1ldpJZ6rexW6abDbEGJvKO5i4OMEpnGBjPU18pX2mWuoozSxRynGAzDOBz0/GvrD9mf4yXup6nH4R8R3F3rkV3lbN7k+cYtqNvVi/bGfWs39qH4JjQLpvEWj2VhpmjTPBZQWVvhGeQq2X2gbQD069jWtSCn++ohlWYVMtlHJ801092XddEfEMfhPUZYwwgwD/z0kUGsu5tDBcyQSKPMjYqwHPIr13W/D+o+HVtmvIVhFwWEe1wx+U85x061xep+HzLM80KF5JZMsv1rSji3zWnod2NyOEqXPh3zdziprXnCJ+dVXs3JJ2j8xXUXmkS2lxLDIuHjA3Y5AJGev41RFg8g4Use4FerHELufHzyqo3rEwxaADlRn/eprWbE8AAf71a7Wq/5NNS1V2woJP4mt1XXc4J5c+xnLbEY4H+fwpFs0LYwuT6VvrosxXcIzjHUqf8ACrVj4ZuZ9koWLy2OQTJioliIrqbU8rnNqKiYaWLoinAA6Dt/StAeG7tnRW8pVJxy/Tp7V2ekeHCZcTpCQBlSp3YOR2x6V6t8Kfgh4m+Ket2EOl6dcvpkl19nudTSEmC34DNvPODj27iuB4qc5ctPU+ieU4fCUHiMbLlSPMvAfw7XWb6Kygg/tnULggwWdtGXlOBkgL34z+VeveOP2fLrwx4N0+616JYra6ZPLsvnEqkoWAbGNpBP619dfDj9kqz+GGr2WptNca3qVhNJLbXO5bcR7lZNrJyGwG68Z9OBXn/x9+HniPxFd6nqyNczaajSXghlk3LbhEwQvGBux654rmrQqKPPK/McGDzvC4jExwuGaVK2ra1fkfnv4s8KjRNRmaBUWxlnZYEEu9lXsDxnoK557f5iACcda9a8UeF73WpYltYkeNHJLO4Xr0xn61yGseErvRmjS42eZIpcCPLY5xgnFdWGxalFKT1NM0yiVOpKVGPunGtbjnj8aheLHPatmbT5yxRYnYnoMGq8mmzwS+S8ZSTjg16qrLufKSwdT+Ux3jGeOvfvTBbs/pxXUx+EpkIknWMg/wAIfnP5U5NAkjkO2KIR49QT/Kn9aiupSyqtLeOhyDwZPf8AOmi2LEBSc/T/AOtXWr4e+Y/PGuT2XNex/BH9l7XvGXiPTNR1zRLk+DiZPtFxDdRxSsfKJQKgbzDlinAHOeOtV9bilc455dKm/fVkcZ8Kf2Y/EHxGsDqt1L/YOiyQ+baX09q1wt0d23ChWBAyGyT3HSrOm/sn+Lte8eax4a0u60q/OlpBLNqJna3hZZQGXbvXduAzkEdjgmvbPjL8adE+HPgnw94V+FmrS2stpNKl6JLZnmhjxuC75kznzHPIyeK+bdN+NHjfw5rF5qGneJ9Ss7+7VEuJ45BvmVRhA2Qc4HTiuenWrVW2np0HVw1Kklo7np3xa8MeBvh74R1jwncxWS+MrG1t443hhdn87dGxbzQAvzKzZyOmK+bJo+u31rd8R+JtS8X6zdatrF9NqOpXb757qcgvIcAAnAx0AHQdKyXi9RXbhoeyTu9WcWLkqzVolDbTDHknnirbxE5wOKi2EivQUjxZUyB4xxxTCoNWShx04qNoyCR1Fac1jCVPsVmTceOKbtNXI7RpQduOPWo5bdon2tjNWpowdKS1sQbM1YuNRurtAk9xLMoOQruWAOMd/ao2Uk9eKTbzVXVyeWS2IcHBrR8P+G77xVqqadpsSy3bo7qjyBAQoyTk8dB+NUyoyeOParuj63f+HL9b7TZzbXSqyCVVDEKwwwwQR0qnJ20IjBcy5itreiXmgajJY30YiuYsb0DBgMjI5HFUGUjtxWlqmo3eu38l9eSeddTEF5NoG4gAdBx0HaqrRHAyOKcZXWpM6d37pVKllIxSCI9+T7VYMbY6HFOihZpAF+91x7U3JLVmcaTk+VIt6H4T1TxDLssbRpADzI3yov1Y8V2kPwohtdJYXjM17JGfuvhI2PTtzir3hR9a8LeFdWuHt41jQeZFDcgh9wHJAHbGDz6Vw194ovdT1tb+6mMZ3KSkZO1VHYDNeLOpWxE2qbskfbUaOAy2lB4iDc5rr0Myz8M6lPq72VtGJriFyPkYYyD1yeK6n4jXuqvNDFf2kdvC53IEkEgYjGSTk46n061o6b8QrHS5JpPKMxmUbvLQKxIbvngj/CuF1nUrnXtUkupXZmkfKqzZ2gngD07Crpe2qVU6iskcmKWCwmFlDDVOaUnqjOYY57Vo6B4fu/EE8kdois0a7iXOF6jAzjAP1rY8PeBrzXoHn3LDboQGYckcZzj05610suvaf4LtIo7E/aJJ0KvLA6MTtHG7g85PFdVXFfYpas4sHlCcViMY+Wn+foHh+10bwZbyyajJbHUFbYGBYnbhDjaQcc8Zx19cVyXifxjca3K8aKILUNlVjJVivGN3ODwBWNqGo3Wq3DTXk73ExJO9zk81Vxxgc1NLDXl7SrqzHGZu3T+rYVcsF979RpAJ9u1AIWg8D3pCfavTWiPlndu4A4oLDOM0lJimRYWtBPEGpJpbaat9ONPIKm18w+XjdnGOnXms0kjvTlJPanewDsUUUUhXE28570ueKD0pp9qBDs009PeiigaAfpTsim0UDsL34FOzkc9aYG79acOaAQUUZ4zScCmMWlxTdpbOKk2jvmnsOwylHy+9JTwM0xBjPWvSfhJGGi1b6QfzevN8cH0r0r4RjEGrfSD/ANnrzsc/3J9Dka/2tHAXy7b66H/TV/8A0I10viNyfCdquANqxVzV+f8AiY3g/wCmj/8AoRrt/F1tAngO0kSPEhjgYtznkDP86xnNxUF3HToRq+3k/spnmQUuwUdTxTbhDEjq2M7T/KnxkJKrNwAaS+kWUuVPGwj+dd58kZ1pp0t4GMe3C4zuOKglhMWM4554ro/Ctg9zbXLDGAyg5OP4TWW8aTBQwzgdqzTuVKnyxUn1M2ipZLZ48kgbfY02JAzgEcGmY2LGnuqF97BR7nFdEsktyqLtLhAB8q+wrmLWBJCdzFenQgfzrdsNXawZjGYzuAByw7VordSomjr19OdANo20RJjA285B/wDrmuYQf6E/4/zqfU9cmu2miYR7HPVRz1B4qCM5sGPsf51k7X0KnUc2rvYfYf6k/U1bLl2B+n86q2XEB+tWByR+FUthroeg6Pw8vv8A4mn6uxNqo4I3j+RqPSTmSX8P50mqyFoAMdHH8jXHb95c+ig7YSxS00f6dF/vf0NZvijjVm90T+VaOnHF7F2+b+hrO8UHGrH/AHE/rW3/AC8Rx/8ALj5mTSUUV3o4AoweKKcPWgaGkdqfBEJ50QnCscEjqKYeeeppBkdKLFFi9t1tHVVffkZJ/GqxPJoIwDRQxMQmkNKabUghQaXeexxTaKAsBOadsbBOOKbT9+FK9jTQrDKAMUuM0lIaCiiigELilBptOA4oE0HNJkg0rHApCOM0DQh5pR1oxxWlB4ev7jT2vo4d1soZi+4dF68deKmUktWzanTnVfuIzx0J70ueab3pR1qt9TLbQeDiuh8FRaVcaqV1aWOGFUDI8shVdwYcHAOeM+lc5kUDnmoqQ548t7HThq31eqqrV7dDs/FfjEXF2U0yV442Ro53XGJOSOuORjH51yiuPSq3Ip2/GMVnSoxpKyOvFY6pjKnPN/Lp8i2GyPSng1WSQYGTzUobj3rVo54zLSNkjHPvUyP61TRuR6VMrZJweazcbnXCZbSSrUb5ANZytg81MknTmueUDvp1bGkkmM85q1HKKy45QeQTU0chPc1ySp3PWpYhI2ILlo2DK2GHTpXrHw5/aE1L4feHzpcOkWOoqZ3na5uZJVkYsR8p2nGBj0rxiObAFTJKDzXDUw8Z6SR7VHGyj8LOy1vxtdeIdTu7+5kk33Mzy+UJC6x7jnapbnAzxWel8Xk7rnJzmsSOX5ic1MspUcfyrn9hFKyPQhjZdWbiag8YxFK4z2ViK6DTPFb2hjVxIFC4J3ZOcDtxXErPnHOT7U8XLYxnFc1TDxluj2MNmlWi+aLPQz42DqwSS5VsZG0dP1p9n4vuE3ul5dKWGDyV3D0OPrXnYuWXdhjz1p63ZAGGOfrXN9Sitj3IcQVL/vEmdnqetq5UvJjeCdznk9Pap7G9GrIltAfMmkIRUGMlicAAcc/5HNcHJdtKVDMx2g8k+uKEvXiwEX5x0bPT3GOc0lgl1Y6nEU2pKKVmj7q+NHwZ8V/Cn4F+E7XVvEs2qWiTJFcaZtLxW8m12TY5AIAHGCBXznGd65z7cV618JP2vvtEsum/EjWJr/QUt1FrDeRtfMswOMklC5yCeSTz0rz745+OvBdvrjaj4JubW6tLlECWUKSKYmA+aRtwAUE4wo9zjms8Rh+aa5EcXD2cSwtOdHGd27o8d8ZI8Bbzo3BklJRS4OBzk4965MsDz3qa5unupXldizudxLHJqlJJgmvbw9F04JM+PzLGrEV5VVsPabBwc0xpePaq+/OcHNQyuQ4rsUDxHXsrllpc/WgXP1zVXzuelNaULyc89q1VM53iGupc+0EtnA/PFAuD6frVLzgcdRQJOelUqaJ+sve5oLOeuPwJqVL4qAA5UegbisvzPanrL7Gk6SZpDFOPU2rbUismfmYAf3j1ra07XApSOT5ByQWfpXIJNVmKcFh0xXJUw6krHtYXMJ03eMjvl16IKFDIy9cb81qWniBViTEUb8dWavOUuhnqM/StK31JY4kU7iR6D3rzZ4ONtEfU4bOqkJXbPSNI8RLBuYvFEd2QM4A9O1fQPwe+JcGnQXVrLJNPapDGwKqQBI2dw+Y+gHbtxxXx62pqOm/36V0ukeIbx7eIiZkULgZPOB0Ga8mtg3D3on1FHMaOZQ9hV1Pu/SPin4gm16xTwuZLeVmHmCR0AlUMDtIIxjG70PSvq3TvGthqiyiFmeeJQ726gGRQc7SRnvg4NfmX4e+MP9gaXps9jqJh1BLeNZGS3MjBtmG6rjg9etexfA39omXw94i1LVdaa81iPUYIonZAsbDYzFeCB03Hjj8anCYiVJ+zm9D5HP8AhaWKg8RhI35V82e++EvjlpaeMr+S+8M6hpEsdmQzz+XvUhmOwgHIJ2133w5+OWl+NodRN5avo81ncGEQu/ml0LMqtkAYJ2N8vOPfNeUftCePvAXhTSfNWK01HXLnY8dtYuoldWzl2ZTwAB3554rwbQPibFeWWo3Wn6XHo10pYsBM0hc4LAkgDjOetdMsXLCz5dGjxMHw3DOMP7VRlGW135H2v4y+LHw30i70+fxHc2UV1bhrixmv7blWBCnymZeHzgYGD0r87/2ivjzJ8WPEDatqNqNPNtCbe0t4T5qbBIWBywBDncM444HXFZXiTxTqviiSK51a5E80alVwgUKCckD8eeea8q8UanY342R3UZZSDw2Dwff61yVMbPFtQSsup9zlPC2GyJPEznzVLaX6ehHD4iRhIUkljPG0FcfyotPEEwZJPNPysGKgdce9c5OPKi3IxIJHzA5/lVZLh9332I/3q6IYeNjor5jU5km9Tub/AMcS3F/NceTncRwXx0A9BUOueKmuliT7SBEsePKEh65zzjqf54ripbwJGcFd3vVR75mGDtH/AAGtY4WN7o5qmcVOVwnK5syX+92beMk560LqToCBOyZ9GrnzdEk9D+FKLhiOP5//AFq6lQXY8R5i07pnRQ6qygKLlgPrWvpWutC5DXHytjJPOP0rh1vGB7/nVuDUDgDjn3qJ4dSVrHZhc1lTmpNntOg6yskv+jzo5C7iUOSOnt9a+1P2WPilpeqwReB9TsdPt7S1tVeznmbe88xdjIPnGM/NkYOfbivzr8M6+bSSYSOoUooGz526noMf1Few+GNWggttL1JIQzwmO5i84c7lIZScfQd68mMpYSprsfTY3B0OJcG4rSotn1R9HfGL4LXGq3eo6TbaVcX8iym4tZLZAON55zwMAMRg5zj6V4f41+CmoeEfBttNJpepR+InvtphRHkHkEMB8qgjPyjvXaeDf2mfFM3j6fW9Xu4bj7VbPaJaGMrbRLncuEBznOeSTnNdndftGaTp/iVNb1qzTVl+ztCLSzCxMuW6lXPOAzDJrVqhVk2meRQhnuWwjTlDmUVfR7vsfKkvhnVNMlkW/s7uxlD7XS5RonVgBwQeelUY4Wj8xCkjRhmO48qRmvcP2ldW8G+MYdD8beGZ7W21HWmY3+mJcRtcxsqLh5kRflYFQvLEdMck14rbXxS2ZH5yCBx61w1o+ylaLPvcpxX9pYVVqkeWWt1bqtzOFlpcbcWNt+EIP9KlXTbHUMRNbARjosZ8sH8q2rn4f6vp9u091biKJBlm3qQP1r2D9n39ne98eXdlr0kmnz6RBLIk9jeI5aT5BtOAMEZdSD04pU/aVHaJyY/FYLA0nWr2seQ74LO2WFAsKqAipkZ+n/66PFPg7W/Bc0EOt6Ne6M86b4UvLYxGRcjJXIGRyP8A61fZnw2+E3wq8Y+MtT0/WNGhD6I6yOlndSCNnDYKtGuCRlemMHjsefbPHfh34R/tM20djqEn9rHQLhkAhee1aF2XDKSNpIIC8cjgelenRwPtKblKevY+Bx/GiweLhSp4duFvedu+1j8yfhxo8ni/4gaXoTSRRRXZY+Y3yYCqXbn6Ka/UP4TeCbX4eeBrrStJ0FNCt53eYf6Ybh5HZQC5LDjgAYycYHTpXkur/s3fBvwlNcapaeHVJ8O7NQufKuJ5ZVCfvB8rPhuEPHeuF+NX7cja3pllafDl9Q0aXzWN3dajYw/PHtIVUDM2DnnJHbiuyjCGETlNnzOc4vE8WVaVDBU5cq3vsn5nqfib9oey8L3M+n+da3FzATE2+QkhhwQcKM81V+HvxXaDfDr6Le6fLHtZkiztJz1X+IHP8q+PLr4hW180l5d2E91fTkyTStcBA7nlmwq45Paqtr8Y/Een3INlcxW6KcqhgWTA7fe615Dxk3UTWx9hHgqnHCuCjaTXfr5H0P8AtQfBWx0VoPEfhrRo7HTAkj6i0D4VWLKEIToo5IwPy718u6zo1tfwODAkkoRhG7dVPqD2r6E+B/7SaahJrel/FDVo9Q025CvbveWoYDKuHiwi4A+4Rn0NZ37SnwJ1n4e+J7KTwnoscnhq5gjzd3d6p2zksWXBO7GApzyOa6a2H9qvrFDbqiMox1TL6qyfM1732W9n8/I+SbrT5rFtlz5iyDqrN9KpywwSSKTbJIzcbjXq+v2D6hqmnWEllFBIhPzMwcNn2+orN8SaD/Y2oQQTwwfNFvGyNfXFc0a0luj7Cpg6UtFJHBeQG2hlyPr0oubIIqFRncSOucVt2VtbXurtbssEcfzEbzgHH5V1Phjwe+ta42madGtxIYd5WEq20DGTz2GRQ6rvdGX1eFnzNWOm/Z8+AXhj4kaJ4g1rxD4jutF/sR0neGGONkeEIXZiG5b7rjC88d67X9oH9pTwdLqIg+G+q6pFE1mYnFraGOxyShX93KAVIUEZUcYGADUnhr4A6RpWmaleeLNSuLO0S2kLPaSC2MamNgxaT5uOh4/I18iywlRFli/yA5PP9BXfSmp07M+HrYKM8dKspuUVsumv5lC4je4iIlk8x8AZkYtnj1Nc/e6VIZ2ICuvHOa6eRME+tQNEH7fpXXCo4bGeIwkaz95HKNpkwbOzJHoagaE7iGHI61132ZS44B+tUR4eaa4dy+0MxPCD1rpjibbnkzyuT0pq5zJiB4xkU0wqP4RWxLYskzqgZ1ViA2AM1HJppjXeUO3pn3/Cu2NdPZnkVcDOO6MaS2YsNq8VEYGGflwPrWybXOMZxUbWwIPy/hW6rnBLBPczIMxFs45x3pZUWVtxAq61t0woNKLUcfJT9or3M/qsrWKCw4BwBik8kkngfpV7yck4Wm+V160/akSwttzOeBtxyAB9aaYsYwK03tg/Xrmp9N0iXVNQtbK2UPcXEiRRqzBQWYgAZPA57npV+1SV2zm+qSlKyRqeC/hP4q8ciOTSNDvrqyd9rXiRYhGCA37w/LkV6Z8RvhJ4U+GejWUd7dRSteebHDeXUL+YxVhlj5ZwNoI7c+hrs/hXY/Fj4d6TJo8FvpX9ix+fcpBeTRybJiuRsKHdy6qSCSDmvm7VL671y8ub/UJ5Lu6uZGlkklYsSzHLEZ/zxXkurPE1bRloux78MP8AUaXvU9Zdz6M+I37Nfw60Pw/8PvCNj430jSfiddiE6nNe3VzPbXf2hVdANqMsIXK7Mqu9X55xXeW/wk+D37OWlX0HiHxFbaj4vudEniubS5ukDygo2TbRFD5LuVKLubP1r4svNWvbm/F5Ldzy3aFds7ylpAUACfMeflCrj0wMdKXXfEmq+J703msajd6rd42m4vZmmkIyTjc2T1JP412ujUnHlc3Y+djajU9pFarY0vEPju71WGVIFW2hlQo8LxgkKVAPzd84PYVxckWcZ4+tXXwfeoJI8GvQoUoUVaKOfG4mtjJc9Z3KbQnnFbPgfWk8L+MdG1aQPtsbuK4OxQW+Vg3APB+lZxTANRtEGPXFdrSkmmePy8klJHvPx2/aVh+KNxokthoz2ktpaPDdT3Sx7p3Lgg5UZIAyBn1PFfP8mWPPPAHSpdrKTk8UECuelQhR0ib4jF1cRFRm9F0K5XIpvtUxU+lJ5a102POauQsvGabipmHFM2E0zOxEVwBjk0bT6U/H6UnfmhMnlIyuKAMEVJg0wDnpVCHDpRRgk4HXpilwR1HWggQjNNIxTqRqBsSiiigEGM0u3FIvPNOoBDDz719D/CP9jbXfi78D9e+Jthr9hZado323zrCW3lknc20BmIUrx8wGOenvg188sBkVr6f4r1vSdPewstYv7SxkLF7WC5dImLDaxKg4ORwfUUn5A12MojBxSbaeVPUD8qaAaq5SXcEzUg6CmqMUuKQ02hdoxShcdRTlXFKQDVXGNPTFei/CltkOqD1EH/tSvOyMCvQvhWAYtT+kP/s9edjtaJ7+SaYtM4HUG/4mN56+a/8A6Ea73xax/wCFfWY/6ZW/8hXn163+n3foZG/ma7nxRdxP4HtYhIpfy4MpuGRwKwmr+zZphpxSxKb6M84PJqGf/Vv/ALpqZuuahnOIn/3TXovZnxz7nReAkzZXZ/6aL/6Caxb+1aCMSRqxY9e/6VJ4c1yXS4po40jYO6kmTPHB9xVtJY7g4aRQoH94CsYRaOuc4Spxj1RzM88rbkfjpkYxTIT+9Wtu5022kmdvMYEns4xWRPGlveMqtlFPBJ68VZwMgozRRTYhvOa0I/8AkHn6H+YqgelX0/5B5Hsf5iotqA+z/wBQf941YjGXHvUFp/qPxqxH95fqKtbGx6DpQw8n4f1qHU+Ux/t1NpRy8v8AnvTNUhKxbuxfj9a5HpM96KbwyKWnD/TIvqf5Gs3xQMasf9xP5VpaccX8OfX+hrN8T86q3/XNP5GtV/ERz/8ALj5mRQpz1pAaMd+9egcA72ozTVB5zT8UDQlIBgCn00igBMZBphNSEZ96Q8VI0Rmkp5XOT0pmKQIKKMc0EYoGFFFFOwHQeCNL0nVtYaHWbr7JaCIsH80R5fIwMkH1NVfFNjYadrtzb6XMbiwTb5UhcPuygJ+bAyQSRWTR2p+QgooxRSsMKcPu009qM9sUCHFTjJBxTexqRrhnQKcYFR0DBTz6VqQ+JNQt9NawScCzZWUx7V6E5Iz1rL7UVDipfEa06s6Tbg7X0FzzmlBzmm0VRg3cfmgU0HFL1oGmLigHnmilA5oGKKlRgByeTUQGBRSt1NEyyrnODUynAPrVNGI71IJOcVJtGVi2rYNSK3piqiNxmpFNS4nTGZcWQ4Azjmpo5u2Qfwqip2ipFk96ylE66dRqxpRTfSpvPKjOeKy0l5HORU8cgIB4/GueUDvhXaNpo2SLeGLZ7AU6MkKM9azIbpg43EbfTNOmmVmGDx9a5/Z6npxxMbXRqbyMUw3ag/eH4msszbVZs7gozjNeq/Eb4Aav8N/AWkeKr3V9Pu4NSNuI7S2WTzU82IygsSMcBcHHcispwUWkzaOIlNNxWiPPRdDt0/OlNz6VmLNjqxzQZiRwzZpqkCxfmaPn5P8AD+IqSN9x7AewrLEvAySamhlAYc/hVeyEsU7nqnwb07w7q3iiaDxJFbzWQtXeNLmUxp5gZB1BGTtLYGfwNJ8W/h0/hoQa5p5jk0G9ZjFHb5YWwJOxWJz1AGD3r2L9mX4B+H/FugW3i68uX1WeMXEEulyRgwwSB1EbHad5yhLc47nnFafiTXI7j7TokEFpBYW0myNImLgBGO0KD+nHevnsTiVhqtz7HLcvnmdJpb9z48lnHQcVVllLZziut8f+DH8OXM91blBppm8qFPMLSgc4LZH+ya4d3Br38PONaCnHY+Ox9GpgqrpVVqh8khXGCRULyk9TmmsenaombGea74wPCnWHtIeqke9N3k81Cz4wAc5plaqJxOq+5Y8/3FKZyR978Kqbs96PM5qlEz9qy1vz3NOExHGaqrJilDmlyFRqlxJSe5qylznAGc9Oazg4wKekmBxWcoHZTrtGvHchc9RViK4J9Tj2rGSYlhkmp45QK55Uz0aeJfc2luCcZB/Kr0GqeQqgBwQO2BXOxz4P/wBerKSZxzjNcdSlzKzPYwuNlTd4M9A0nxGjLDGRKGwF6Zr1j4Z6nps/iCytdYuzpulvJ5dzelT+5jxksPlPYHseccEV88WVwIpo3YkqrBiFHbI7mvSNC1iC+tWdYvLDOUwxDenoPevm8VhvZyU0tD9WyfNPrlKeHlO0mrL/ADPtX43fszeH9L8KT+OvB+sgaPFpsNw1nKfOE4woDpJkbQVIbBB5HGM4r5mW7ktywjZlHQhWxmvYf2dv2kbnwncHSPGepT33hu3sooNPt1tvNaN1cBV+UDjacZOcYHIxUP7XPws1T4bx2HibThpw0rUrm5F2I0CPDOzPLGigt93ylwMDqp45rPEYeOJSqUVbuedluYV8kqPA5g20/hZ87eJvHCT2sttaPIshx++QYAwwyK4G8unnYvIdzMckmo5W5qvIeRj8q66GHjSVkebmGZVMXNymSQ/PKgIwCe1XF2wsMcfjWYk3lSBu45pJ7lpuemB2rpdNtnm08VGEHfVjLm9Bd+vU+lUZJ845IqK7nO9sdM1BM5WIMP1r0YUrJHg1sXzNlpZsN96pBPkdf0rKW6IPQGnrdEDjbj6Vt7I4PraNNZFfOAD0p6y/OOBge1YqSED7xBPvirNtMRuByefrSdEdPGc250VnqJjwo498e30r0HTvF9zBpttCvlpGkSIvHOMAd68oS5CEdRzXSWWrlbSMHcMLj5cCvJxWG57aH2GU5o6Em4yPQZ/FlrDGjb3JJwVAGRx/KoZ/E9jKMsx9eYs153NrOMAPL19RUTasz8b5cfUf4VwrA2PqP9ZZXtc+gfhRqHh2fxZ4fTW3s49NN5G929zGdvlY3ENwSR/jXvv7SPwGn122sfG3gKwsbvwuLONmewlQeYN/ytGgxuGOODmvijw/rxW3BeTo4wXUE4CgDnivo74WftJanaeGf+ERvru7v7PyiLfz5IUtoY1QkJgru+93J9Olc0qfIpRlH5kYrFYirVo4zB1LNaOPRrr8zt7Hw3e6vFcW+q2TWMEkZQrcMCTkYHAOeDXXeJP2t9P8CeF9H0vStBgyYDDcSWN2I/soUhAVUKTnjO08cjnrXnfx88W+KfCV1pVta24sba6tmleaGHzgWD4wH5A4xxx1r5p8Xa5JBJJC2ZTPACzNjvnrkVzUXNScKfU2r4XD42lHFYzWK2V+p0XjvxzfSeIblrXUri6W4UNLcNO2+QnsxXAPbrml8NfEG50azWKG4ntznJ8u5dB/OvLvtwx9xunao2v1BPyN/OvQjhpWSucsszoubagrdrdD2m0+NWs6ZLq0Ftrl3bWuowCG7i84yLOuGGGznoG9c1xl74oiVP3LuWz/AHa4oX52jHmfQkU5bkuuTuqvqrdrtsIZrGgpexiot7tHUw+K3EiGQtIo6jABq5beKrVpHZoWAxwAQ319K4h7kBurCo/thP8AET9VpvBxl0NaXEFaNk5HpdnrkN5IYkV13qwydvAxz61674j/AGn/ABd4hufC11rM1pqI0RgIY1h2CXhQxc85YquMjHU8V8sx6o9uwdXCt0+5Vz/hKJ3UKZI2x6pWfsKtLSD0OqWPwWNkqmKgnKOz7XPq7X/jhpnjbxz4f1bUdFWwsNMVxIlu6yvIScg8qo4IAwff8ejn+J/w98VeKVudX8ONfaZHZLEn2i2HmJJvJPyh8YI7/pXyDpfiYr5huWSbgBVCbcevIFbmn+OItOEjJZpKG6jzMflx71jJ1o30udUcNltaMVzuKWm59Qfsx674D8N/FDxBqetWdpZ2M0TCxWe3MojzJkBQQdvyj1/GvefA/g7wvffGLxZr+kRlo9aSJoV8pUii2RqG2D/aIDZx3NfBVxeNdJFJFEIJAQ/HOO/pX0b+zb8UpVnl024lA1KyiHkyvjEiYAOc4GR6DtU0sRe0Jo8TPMgdNTxmFqNtpK19DJ/ak+Eni/SvHCCGB77Tdbu/I05bSQkF2CjymXOFPJ9jz6GvJL39lz4n2uqmxk8H3qTrHv3eZD5ZUHHDb8H8/wAK+19K8ba34y1yyu79oLu10693JHBaoCpGejMeuD2OK7z4qeJdQuvBN/q/h/QV1DV7GNmhtb2RVEh4LAbWyTgHAr0YRpSTcWfHRzjH4ZU6FSC7N/kflp4y+FnibwX4hh0XVdKli1WaBblLWBluHMbEgH92Tj7p4rmDbSRTPAyMkqMUZGHKsDgj8DX0t4V+OFjq/jq/8QeKNKispPsH2VDZRvKCQ4wMMSRxnoewqtqmr/BEahe6zJZ6neapcSyXPlETLGZHJPK8ALk+prldSN7Jn3NOhieROdNu/VbHzelq5mGY2AzzxXpngvw34b8Q+En+2xra6hFK8ZljnKM4ByDtY4744FeqeB734G3mhxHxFBFHqJZt67rtSBngfJx0xzTvHPwX8O+JPG+l+H/AVpDpck8btO17czshYcg4cEgYzyODnHGOc5++kovUmlV9hXaqRaS3b2PGdN+F+mX2jyXk2pXEUpDkIvlkcdPr0qS1+CA1fw1G9vqLSSMPN2LCuQQCSvX0/Gup8S/ALxT4c8aHw1HHBq18IUnDWUo2bGPXL4PHOa90+CvwZ1Pwf4Y1H/hIFjsru6lLRQrKkjiPysHpkDk+vbmublxCdlLY9WtisvVJVLJ36HxPqngb+zrpYYd0q+WrF51wcnqMD/8AXUc3hNTbOEtwZdvytu7196fDH9lLwr4j1fXY/ExnnSO3jXTi1y0LSPhgxwrfMQQp/HpXkkH7HXxRkijP/CMzKxXkPPCp6em+vQX1jkUt7niRxmSzrTo1HyW76LXsfKMfg69ZQGURkH+IcfmKhtPDVxfLM0YQrCPnLZAH6c9K+ytA/Yf+JGq3ciX1jFo0CJuE8zpKGPpiNi3v0/nXgupaULa7ubdXFzHHK8JlCsFcqcHAIzVPEV6avOJpRwWVY6XJhKybW55ZBoM14D5Cq5AzxkVd07wc0jMb23kUDG0JIBn/ADxXeRaVAg+SFEzwSq44rs/BvwY8Q/EG0nm0C1iuTbkedHJdLEUz904bseeenyms3jpy0gj0HkWEwsPa4mSt5nh2k/DPxFr+rHTdL05tQuzFJcCKGRP9WoyxyxA4HbrXT/Bj4Xa1r3xS8PWk+n3Ntbw3qT3UzKMRIh3sSecdAOh5Ir7E8OaD4W/Z/wDBGmeKNb8Opda+qJaXMltiWYPLncBvO3GMZx+teEWvxlTwtpHii80TSbbTPEN5cSPbahFZw7o4nm3bG4xwvGACOfat/rU5R5X1PlXlqqVJVMNF8sdmS/tM61r3w71TSoNA1aa1guYJXlUrG5ZvMwDkqcDGOK+YxYSGNcbcY6A13fjXx/r3j+aCXXtRbUZIN3lGSNE2bsZHyqOu0VyUlqSeGGR6114ZRpRS6nn4qFWrLmldnM3EP71im4jJ69ah8lvQ10EmkFFLEApnHAOKjfT1A4UZ9816sa6PmqmBk220Yrwk54qJoB6Vsta/L90Y+lU5rVySVHHoK6IVb9Tz6mEcOhlvCCTwKh8vb1rQkhZBkj2quykj2rrjM8mpSsyqyg4qNo8E8cdqsSIExWx4e8C+IvF8cr6FoWo6ysMiRSfYLV5tjvnYp2jgttbA74NdHMjilA5wjNIVxnmrEsDQyPHIhjkQlWVuCpBwQR7YphTj2pmHKyLAxTWXI461YSMyyog43sFz2BJ6mu5+Jfwd1L4X2emXF/qNjfLfyTRoLPf8hjCEk7lH/PQdKV1ewezbV0eeGPHXrTWTmrBXceeaY4A46VRlysg24ppHSpsGmMuTzQRYarbXD/3TmnXFx9pZTjBAI5+tJsxwRSFD6UX6ENdiPB70HPpT8EAUmDT0FYZjnFGDTwu456UbcUXBIaowMYpc0uD6GpAOKAsRbc/SnIu7rUi4IycZoHFFxpCAYpCOKXNIe+DmhDsJT1XFIq8Dmn4p3KEzgUZ4oINAyaYcoh6etei/CsZj1H6Qf+1K87AyDzxXefDK8S2F+GUtkQ42/V64MbrS0PcyZqOKVzg73i+ue/71v5mo55cxAYG4dDT745v7sjp5rY/M1ZnQGzjOBkgc4rWmvdR4OJlarK3cx2qK4/1Lf7pqecYlI6VBcf6h/wDdP8q0ZwmXRn2FFFQl3MhKKWiiwCA5paaBS45oGHc1eT/jwP4/zFUT1NX4/wDjwJ+v86T3EPtP9T+JqwhwQf8APWq1p/qvxNWVIyPWqWyNUehaV9+T/Pen6sMWwP8Atj+tQ2cyW7MXONxwMDPepNWcPZoy/dLgj6c1yy+M+ipyX1axm6fzqEP+9/Q1neJxjVG/65p/I1uaVbB7qAjlySc/gax/FkTQ6uVbr5Sfypp/vEjBxaw7fmYVKDimg5FLXpI8wdTh0pimnA4pgOozimhvejNIaFyBSE5o6mgDNCGNx19qCMjFKR05pM80xiBcD3pCo4pwPOKXFBKG7dtNbpUmBTTQUNxSheetIAQafjIoJQlNIxinYx+NB5oGMA/AUdO9OHHFLU2uMZRTiOKRRQAuOKQ8Gg4PekIxSEhRzQBQOKWgGGKMc0tIe+KAsLQOtJn8KM8UDH5qa1t/tDsMkbRngVXBwaXPOaaGiSVPJkdDztOM0q/Kc9aj6ml3VLKRMJQB1pwkBAqv1oBx+FItTaLqSZAAqaOTY6segIzVJG3DPFKsm3txSaN4ztY1by9ScKFUjBOcrioUkGBVRZS2eMfjTvMPvU8qNlVZeWbBHPP0p/nj1/SqgPFLvqeRG6qPuW/MHOQSCMYIre1b4g+JNe0xdO1PXNQv7BWR1trq4aSNSikIQp6bQSBjtXK+YexpQ5HGazdNNlxryjpctecPQ0hmAz15qv5nFNMvNPkH7YsrNzjcQKtWFvPqF5BbWsT3N1O6xxQxKWeRieAoHJJzWZvOcV7B+z/4+8K+ApNZ1HxBbLLfRGCTTpVtPOlRhvD7G42ZDL35rnr3p03JK7O7Cy9tUUJOyZ6n4X+A2jaBocOqX2u39lelfMbzZEtURl2/K2efbr3rP06ePVbi3FlIs7XMoSPyGD7yx6DHXOa83+MHx21D4jNc2MCRJoC3Xm2ztCyzuqjADkkjuTiud+E/xZm+F3jLT9YW2W/htpC5tpJCi5I27gR0IHSvnK2Aq4iHtJ79j77AcQ0Msm6VNXi+vmP+Ifi19bna3jiWK2ilLDPLsRlRn6ZPA9a4nzMDk5r379r+48Ba34h0jV/BF5o1zcXqXEmqNpcxcvIShR5BgAMQz/d67Tnnk/OzMRxn9a9rBU4wpJJWPjM2xtXFYiVWbuTs27nimM3ODzTATj0pGNeqlY+clMRjj+VML4FNdzxzTCSf4s1djnctbjy2KTf3qMHHajdn6UyeYlD5xTw5qAMRTg340DU+xOH5p69OahDZORzTg2D7VLRrGZZWQ5qZH54Oapq+RxUiPg1m4XOqFRl5ZMdec1YSU8EGs0PkjANTpJ68VzuB30qzNqBtxyTmtjTr14GQq7AKwbAYgE8f4VzdvOARgVoQTbjxwfqa4atHnTTPfweNdGamtz0vSfEBvXHybMHpkH34r6w+Cvxw0q98J32g/EBtR8UO98J7V7+JLuK3jaPywAX6YYnrnG8Y718K6dcSwXkMi7lUMCSGIGK+4v2J/GvgW+S30W80SK48WSTTAarNZqylMlkQSsc5wmMADoK8J0HQn7uzPucVmlHMsHerDmlHtueJ+OvhQnw31T7HJHb3aXAmeDyy0kiRBmRQ5ZfvYxnHUjPeuk1H9je8/wCFUnXtDn1HxD4jP2ab+z4bYQRRQsCZh84zIyAxnIYd+DV/9prStU+Hvi+OfxDqa6n/AGo1zPp8qxyP5cCzH92Q2Au0MOASKwPgF+1df+Ade1Kw8R3l5qfh/VUgsUAuFxpyiTAdI5FKBQjtkZGMDHSijGpzPsc2ZVaFTBU5UGnJbnzrqum3ek30lpf2s9jdRhd9vcRmORMqGG5TyOGB/EVSllMdvwM19jfthfs76dpeoaT4i8L3N/rGq+JNQdJkuLpJ1m/dBhLG/UqNoyckYZTmvnX4u/BrXvhZNYpfol5YTQI39oWgLQecRl4skD5h6d85HQ13wmrqL3PmtZ0vaLY8vkkLHJqu5zUkmVznj2qu/Q+levBaHz1VtN3Atx1GfrSBueuKYcCmlxW9jhc7Em4n3FWbS6EIbk5JrP8AMxx0o8zn1ocbkxqcr0NJp2Zidx61ahvCIgCwBUYwRWKsvOeKlWYjnP5Vm6Vzrp4qUXc1/to74/75py3qk9Bn6GsjzieMt+dJ52CPmP51n7A61jWdFDqJiUbVH4nH9K39C1sRqwkMakgjld3UfT+tcCs/bcKsxXnlnIOf8/SsZ4VTVjuw+aSpTTPtPV/2hbXxn4V+xapdKl3Y/urV4rSVTMgjChm5ZQxZR6Dmvm3x34oh17W1ntxLGscCRFZo8NuBJPr61y83iyS4tTFsKscfxf0FZcl2ZWLHdu9ck15VLLvZ1HUe59FXz1Twyw1Nabms16RjnOfQEVGbgEknP5mshpsjgn8TTS+fr+NemqKPnZY19zcScDHJ/I043m0HDfhkiufMmDjnP40ouCnr+JqlQM/r3Q2zfHuSOOmaYl5uyNzA+5rG+0c9P1o87/ZH40/YErHPua39o7iFDNn6Gnf2kqMAX59wax/P59PxoMoZgc8/Wk6KKjjpLW50cV4OOVH+fpV2C+5++B9DXMRXpLHPpVqC/wAA/d/PFc0qHZHr0cyStqd7oeuQ2pf7RIxLYCsAW7ivQvBvixINYa+0y4Md7GuVbyiCoIwevBrwyHUAXAO0DHXdXU+EL66lv/Ls5RC7AFmJwMA14+Jwas5LRn22V55KUo0Z2cX959ATfFnxnaW0iRa7c2trM5LLCqICW684zz9a6z4IfHDUvA2rf2bf6ikWgX0xlu5rqRyIG2kl/l+Y54yOnSvINf1V7m0QIscW2QOHSQk9D6jFchd+JZLWeQT3nyHBaLqcN1xx7frXk0VUvoz6vMMPgZ05U5wS5uvmfY/xc/Z6n1fw5dePNAexOipp32t/LkLNcgksZFwoGNvPPPGK+VdQtEErBwCB+lfSH7Nf7SfmWF34J8d60l5o9xbW9lpNm9oNioQyNE7KoyMFFG4n615h+0/4GutB8d6zr9lYR2XhO+uoLeySEqED/Z1L7Yx91dyvye/rnNa1KcKkk4u3c+fy3Ncbl/NhMZDmS+F9LHn1lOkPywtsb/YfBxx6fhW/4c8Yar4T1mPVtMvGt9QjDBbhwJSAwwfvA9RXmQvTaMZIisbYxkL/AI1E3iS8XpN/44KPq1RO8Gex/a1CrFxrx3/I9+8PfGDVofHsPifXJ5NXlCFJUCpGXXYVUYC4wDiqHiv4s6tr/ioaw08kJgkkNoCfmhjYg7O44x2rxpvGzIOLdmPTk4/lTdT8bloYUsSySk5kLxAjHbGc989qn2VeWjNY18pg/apapWsfRXhr9ojxX4flFxZakEnIwZWhjc44z1U9a+5vhd+0N4Y+IdtqEtibxbfTxEJ7m5t0RSz5wqhWLE8Ht6V+Str4stTax/aZ5fP2/vMQnGfbFdZ4b1+4sprK+sXk3RypdRgs0e4o3BOOvetKVWthnaSujxs54dy3PqaqYdqNRdv1P2H0HxfpHiSaSDT7kzTRrvKNEynbnGckYPPpXL/EH4FeB/iQlh/wkHh21v8A7A7vbjc0aoXxvyEK7s7RwfSvnj4QfGGHWYr7VNJu7iKeF/s06GFY3G7DgKGJyMDr3xTvid+1Je6BrUVpFdajBcRQKWGU2Pu5B2jqcV3zzCkoXqI/J6PC2ZRxvssHJprzscDq37Enje/1bUWsINKs7N7iY28ZvchELEoPu54GOvpXpvxrh074H+E7PTdC0610HX9bs2+1z2EI2FYgqkhhtwd8jFTt9cjkV558F/2tNR8MavqaeLdUvtS067Mciu0ZuZIiHOVVegBU8n26GvWvEf7SnwT8ZvbSa5YLdyQIUia/0iV2RWOSB8p4yBx7VjCWGnTbg7Nn0+Ohn1LF0qeNpupTp/y7P17ny/4j+HvxD8UaXDZzpdajab45UWe5QrkA4bk+5614tqvhi50nUryxu1ENxaytFKuQQrKcHnv0r9MtG1LwL43gspNGsFZJkVoHMLRqy4G3AbtjtivnXx3+x78RPEPjfWb6wsLBLG5vZJonkvkU7GbIyMZH0rheHl/y71PqcBxTQhKVPGwVJJaJ6XZ8kjS0YANcIfoVqaLw3HcSqqygsxxgMvP6V+kyfACd7iEz+HNKnTzU8zzIIGJTcNxOR6ZrqPiJ+zp4T8UaGun6LpOkeG79Zldb+10yMuAOoGAOufWt4Yes03e1jzqvGWWKpGDo3T3a6H5Ez6NLLczRJF5u12GcdMHv0/lVHVdCl05AZDHliflRtxGMcmvpHxp8Arr4e+KfElpfXsU6aXJgXCwOouA4DgjIIHBAPPXpXEXnhzTp4zMLeGdwu0Fl3Y7jjpWaxVSnPlmj6eGV4PMKHt8NNa6nh62ElzKIYo2kkb7qqOT+FU9R0yayuPInhaKTaGKScHB6Gvp3wH+zP448aQLqmk+Fk/s1kMkd7IscMci+qljzwDz04ryPx54LaDVd6Mm5ohmNYsY2kjqDivTp4tqSUlZM+XrZTRqQmqFRTlHdLoeXS2qEYKfrVCSyk7KPbkV0D2o645+lVngHOa9mFZnxWIwSvZo5+e2eMgsoXPuK9V+BH7R/iD9nxdWGh6bpmpJqcsEsyaiZcKYg4G3y3XrvOSc9BjvXn93CHK5ANVWth6AfhXdGppqeDVwivYq6xeNquqXt8yrE9zPJOY0yVUu5YgZ5wMnr+PNVI4WmkEaDcx4AFX5IBuxxj60xY/KcOhCsOhBrdVOxwPDtMqyW01rIu7KOPmBz0rQ1rxTrHiCCOLVNTu9QSJi8a3MxfYxABIz6gD8qhlLzNl2LkdMmomt9wwQKtTXUxlRavbYoYwB6UqRGWVVAG5jgZqdrdsnjH401FaN1ZDhhyCK0UrnNKm1uiO4tWt2CuRkjIwahKDnrVqaR5jmRiT71FtPJHWrTuZOCIGjOenSmYI7VaKcDPWkMZz7UyHArGIEdaURbuOuKlZO9Jkg8d6CeXuQlRs980qRrtBI5qTaM9KXFAuUYMLTVXvUhGRSlTgYNBNiMqeuMCkxipSDjFN2c0XCwwLS42jinFdoFAouOwgopc0qjJoGIqhhnP4U4phSBS7SD2xQc47VQ0iIdK7H4cje9/wCyxfzauR8sn6V2nwuhMrakFG4hYuPxauDFu1O562VQcsSkjhr/AIv7r/rs/wDM1bkH+hJ9Aaq6lkajdA/89n/mamuGK2CEf3Vrop/CmeDiVarL1M66GJT+FVp/9U4/2TU0jljkmo5BmNz7U2cTfQySMGip2RcE45qCoTuQ1YKKKKYgpMc0tFABV2P/AJB7Z9/51Sq7Hzp7fQ/zpPcaHWX+qP8AvGrA65qvZ8Qn/e/wqcVS2LR3M3AT61pXEPnWMKjGay719qR/U1ZtNUM52SbEVV4OcelY1I63R7eHnHkcZFvSQF1KCPjcCeP+A1heOc/2+w/6Yp/WtC0ujBrQkjIc7jjPIPymsfxZcNdawZHADeUgIHtms4p+1TOqpUj9VcPMxAuKXFFA6mvUPDGkYNdp8HZ/B9t8QNPfx7H5vhYJMLpdkrHPlN5eBF82d+329eK40jNIRjmgOljsPi/L4Sm+Ieov4FTy/CrJB9kTbIpB8lBJkSfNnfuJJ/DjFcfkD1pByaUgAUAhScUU05Kil7UCTvoKevWjnvRjIHc0uTjNBeoh6UDpRRQJO4UjYwTS0YzQNsaeKVaD60gPJFBLeth1IRS0UFITbijbS0mOfalcGJmkIzTmXIpMYpjuICKQ0uB6UhHekxISlBxRjPSkpWGGeavaI9oms6e2oLvsFuImuBgnMW4bxgc/dz05qjR0oA6z4iSeF5tRtT4Wj8u0ELecCsq/vNxI/wBZz93HTiuTo/pSkigQ4KSM44opokIAXOB3pQeBQMXPFKCBgGkopBewpB5pKXkmvQZ/hSIvhVD4z/tB/wB4m77J5HH+v8r72enfp7Uth3PPg2KkDk9qhFOUmiw1KxMH/CpEk4PP51XVsZ9Kfv4z2pWLUmTeYOaaZcDGOtSWFr9uulh37MgnOPSlv7EWVx5TMJBgHPGKGjRSZpazos2iCAyyROJc4MT7hxjP86z1l5ODTr7Vbq/jhW5lMojHy7h0zjPb2qmWHaoSZpKav7paMgI7fhSeaPeq4OOadv496qwvaE3mA9M5r0n4Pa7YafHq1nfWCXpuDE67rZJcBQwI+bkZLDgV5iD6YxWhpmpyadIGj3BtwPyjJAH4e9cmKpupTaR7GU4qOGxUak9i/wCMIvJ12+8u2NpayTO0MYj2KEzxtHp9Kw7ZYGu4ftJZbcyL5rJydmeSPfGcV2HjDxdpmv2SRQ2jieMgJLKMbFGcgc9xj8q4vgHPWow95UkpKxWZ+zhiW6UlJPX/AIB6v8W9d+HF1qWlnwHpk1rbQxSLdNLE6eY2R5fDsxJAByeOtcrFqem3urIzWaBRGEVnQAMc56Djoa5TeeBjpTGfuT71X1ZW0bFTzSUZe9BWNrxBpP8AZcyshZoZQWHH3T3FY+7qc10V14ot7nw20Vw2+7OFEaA7iQfvHsOKofZrG+02We2VoPLOPn5JPHH0pU5uCtNDxeHpVqnNhpLVXt2Ml3yPeoyTj0rdvvCdzZ2QmR/tMmQDHHGcgHuD3rAOSwAyfauuM4y2Z4tWjUoNKorXEJPvinRMBKhblQy5+mRmmBCCeOlHStEc1+h1vjS68N3CWw0CFYSHcyFYnTIJ+UfNXL5qPrxQCAaNwuSqxU5FSB+metQb8mnBhn1qbGkZWLCN6VIr496qBvqKlRs0M1UuqLKt6dqlR+eDzVUP196kVjk1LV0dEKhfjlwRzVuCf5uDz71lxt2qdXwN3BNYSgd0KvmbCXKjr8/t+VeheAviQfBFtY3OnqP7VtLxLuEyR7otyNkBhkFgRwRx1615Us/AFdz8LNP8O+JNeGm65f3NhvXdE0exY3PdS7fdJA447V52JpxceaWyPoctxNRVPZQavJW1PqD4oftN+Cvi7+z2LfxVbWs3xDR5ltrSytZohA3mLslDZ2hCn3gWOSPu9K+Pp5BIflHy+/JrQ8XaFN4f1W4jIzaGZ1t5QwbegY7Tx7Y9KwhPk9MilSjCUeaOxVVTwsnTqaM9U+GHxKXw3EY9W1K5azs2jezt5GedYiCd3lxE7VyMZxjp1PSvrbwZdeCf2rPhlpOna7qdtaeI7SW8eLRbe98uXKxtEknlPu3AIVfjuO2TX57eeSPSur+GPxQ1b4V+M9P8Q6SkEtzaeYoiucmNldCjA45+6x+nXnpWNTCJtzj8RVTMZulGinZIPix8P9Q+HPi7UtHvbO6t4oLiWO1mukAN1CjlFmXHBDY7cA5HauHJ4HrX6I+OPhD4I/az8DTeLfCeuHUvEdjYNBbRWsqoA43SLDLFJhkLNkAkrwSeRXxvD8CPFE3httca0torXyWmRZL6ISMoySdoY/3W4znjFOjiUopVNGYewliU/Za2PMmG4GoCCD+ldfqvwz8U6P4MsvFt9oGoWnhm+uDaW2qTQlIZpRn5QTg/wtgkYO0gHIrnLjSr6LTbfUXs7iPT7l2jhu3hYQyuACyq5GCQCCQDxmvVjNS2Z4NSFrlEg5pMkd6Y5xTGNdCRxuViZnx3/Wm+Z6E/nUROO1MDHBzTsZ85ZWUqev50ecfWqvmDOM08Nx0oSQKb7loTk55NL5x4+Y4qoHGcZ5oEhBosivaeZc88kgAkVIs/qTg+9UfMHJ4FKsuCOSalxTNI1Wi+JgO5pPNyCOfzqoJh6mgsTjDYH0qeRGnti4H6f1pvnc8GqpbuTmgyqKpRsS6xa84UnmZqsHyueeacH5ODijlJ9qyfzcZ9aBLk9f0rSsfDcl/os+orcKqxCQmPYSTtGevbNYgcds1HLc052tS4svfIz9KljnI/iNUUcEE5qVTgVLiaRqs07WRjIMEjjrWtpurS6XcLLDMUccE4HI9DXORybcc81N9pIB5yc1zzoqejPToYt0mpRdmup7N4a8UN4jt5I5YYN8W0HYCpYHv6dutcjrt6GvpQUkUhigD+g4445zmuQsdUmt5t0LSRt3KEjgfTrXU+KPEsGtm1ESyokSkESADrjp+VeLLCKlV91aM+9Wc/XMHacrSj+Jt+FPEzrrtk4jVJo5Q8bklgjAqwOAO230r7P1PTU+NHwJjuJLR9T1Rbf7Vb28EoRzdKGVRkdOW6Hsec18A2UqpcRSHcUVgSASCRX0p+yf8AtF2nw+8Z2mh+IUs7PwfezTy3V3MjvJbuY/kII/h3KoIA71w18HLnUoHRLN1PCtVneS29DxfxNpGr+FNUfT9a0+fTrteTFOuD1wSPUcdaxJrvkY619aftN+NPg38VfiD4a0jRNUa1vjdxwXuvQ2qrZCGQLgGRyCQpJ5VcAls5xiub/aj/AGV7P4Y+HfD+q+DbbUNStXmmh1GeS4NyxJG6IhVUBQFD5P0rpVoWUtzxVjXUjddfvPmd7s5xlR+FIZznmRcelURPnkEEGmtOcZJ/SuxUr7GLxbW7NFLjJHzDPsa2dD1xdHuDKyu+U2YViCBkHNckbnHf/wAdpUvPf9BUVMOpqzO7C5pKhNTi9T6U+GPxhPheQ30Mt2YvMVWtWUNE7KD8xG4HOGPf8OlP+IPxItfHHiMX8Ec1vm3jiZZQMllzkjBPGCO9fO9nrT2qKgeQLktgYAz+VXR4hmLBlklU4xnfXi1Msb0Wx9jQ4hoRmq8o+/1Z6fca5bQ5V7hFYMAyk89fTB9a6rXLeOaQGNo8YI+QEc54/hFeCHU3uZGZ5JCWPPNdXoHjM2Cz/aEmu5ZSp8x5ewB7ke9c1XLpUo3hqz18JxJDE1XGpZRZ9wfAv4qaZqraZ4d0+wvra802wRmuZjGI/k2odoUk8luM1zXjb47+OZPjNf6PF4n1G30tdQWBLe3l2KifLkcDPc9a8X+C/wAUP+ET8T3erf2XLeRPaG32RygbGZ1IJJHT5DVDxn41XUPF994gWJ7SS4uPtCokgYxnA6HHPrWMnUjFR2ZzUctwlbFzqzipQa0b11Pubw18Yp7LTY4L67ub24VmPnS3AYkE5A5rG0X9rC+h1K3nu4btLKOQGS3Ro3LqSBjoCMDJ718WyePbt4t51C7bKbsEt9cdetU7Txe18wQXEu8jdsbPTjJ/WqjXrQ1E+EssqN8zV5f1ofrV4h8KaT8WfDwgml32UxDuIWHzj+63UYrxq8/Y0tdQ+I1vqE0tl/wiUcCRvpqK8c8jKjDO9SAPmwc96+UfhF8bNV+FmpXN1brLfQ3MYje1a6aOPOQd2BwTgYzX0VaftB3Xivwql0mmvZvdI6rsvmJQhiuQcDuM9K61iqFS05x1PhK/D2d5TN0sJU/dvY+l7Pwfpeh+EH8NaRbJZ2EFq9vFBGS20MrDkkZ6knNflf8AErwXq3hfXI7DV9OudNuRbnCXC7WZdxG4eoJB5r7e+DXxKTw/NfnWLh1gnMZ3kNIxfG0L6856+1dV8ef2cNH+MrRarNqFzp+qW9qYInhCGMruL5dSMnvwCOtbVl9cpqVPddDhybGz4ax8qWNV4VN3/XqfkdqmjC0MpjicRq5Xc3PGePT0rDmswASwP06V7Tqfg29WILcadeJbu24kwvEH2jJCkrz1OetcFq/h9ovOukUiHJYJ12rn1x71jQxTi+WejP0LMMqjWh9Yw3vQfY4Oa3yR8hP1BqOS0UA4XkD1romtC4GQT+FWNZ8MS6ZAJGkEgZ8bQhHavVWKSsmz455VUknKMbnEeQS2CPenfZBjO3I7cV2Vx4MktLB7szbtqbtmzGc44zUmm+DZ9QhhlWSNVfk7kbK4OKv67BK9zNZFiJS5OR3ZwxteM7Me+Kja36fL+YrtNf8ADj6S8aB1k3jPC4rBltyi8cEdf8/lXRTxUZq6OHEZVOhLkkrWMF7c5OFGPpUZtSe35Cux8IeGF8U+ILSweZoIZmO+aPBKgKT349q9W0b4M6Z4f1e3vjqs0zQnKwyRJgnbjnB96KmY06L5eosLw9WxvvKyj1ufP9t4Z1LUome0s5rhVOCYk3U658Ha1ZWc13PplzFbxLveR0wqj1/UV6le/Eyxs7qZIdMlcByM/aFUHBxnGzjpUx1seN7GHSBbNZx6oDH5ol8xkA+YnbtAP3fWsv7QxEbS5NDt/wBX8tknCFa9TovM8SSF5WVURnZiMBQST9K2NC8LXWs6vb2BjktnmyN8kTYUgE/0xXpFz8LLXwZEdcOpTXbaeRci3MITzNpHG7Jx9cGqf/C5tmD/AGS/Hb7Uf6rW7x9Wuv8AZ438zzoZDhsHP/hRny9Ut7o53UvhTe6dBNLLcgoiPJlIichV3Y5/KuE5IB9a2de1aTWdXvL0+ZGLiZpAhkLbQe2azURdwyPl969PDe0Ub1XqfK5l9VqVLYWNkvxK+32owBU8ka7sqevambOnBrsTueI6bRHipY7WaUExxO4HGUUkfypNhz0r0j4X/GBPhzpF7p8mkvqC3MxlMi3Aj2fKFwAVPPHX9KJSstAhTTdpOx5mVpNvvT9mMAHgAAUbaa1JcLMbt4oAHHSlwaXb7807gojcD0FGB6VIseeo5pwiP93H40XKUGyJRml2Z7flUnlkdRTlQg0XGoEajHbNdZ8LtTtbBtR+0SeXvEWMgnpuz0/D865gDrVrwrG7pelFLY2ZwPXdXHiY88LM7sFUlh8RGcd0YmpuJNTu3XlWlcj6ZNWLsY05P91azrlys0g9WIrQuHzpif7q10U1aKR8/XlzVJSZlN1psn+qk/3aC3PPWo52AiPPXg0zkM0u2SN1IQR1GKliRWDFuvpmo2fcBmoRmJRRRTAKKKKdwCr0f/IPb8f5iqPY1eT/AJB7fSovqNDrT/UH6n+lWAKrWnER+tWR2rRbGh2eocqn1NUWHpV7UTwnrk1Dbj58+1Ke5209g0znUIR7/wBDVLxONuskf9M0/rWjY4GsRZxjf1P0rO8TMG1kkEEeWlZx+M6nrRa8zJooP3jxxRXezhDPSk5Pel6cik6fSkOwYx7UuPxpBz9KCcD0oJegowKKQcml+tAkyS2j824iTnDuq8deTj+tfRv7XP7I9p+y/beHpbbxVL4l/ti5u4tklksAgWHbj5lkcMTv56Djg183enrShjtCljtHQE8Ck1qPqFJS5pKY0wpD2paKBPUMUYHpRRQQou9xR14/WkoooNUFDD3oopAFIRkUuOOKKAQ2kxTiOTSUwsNJxxSU4nnHWkxn3oGJRTgtG3PSoAbRSgDFJQFwpPrS0hGRQAuTTgR3HNNoAzQA/PenNNIybTI5UcBSxwPwpmQKODViLs+ky21olwzRlGAICtk4P4VSqxJf3EsAieUmIAAIenHSoKTGIMZzTt2BwabtIzS1IDgc9acp4xUdGaCrku78aM5FRDilyfelYfMSbqN/vUYNG6iw7km/3qxaXX2eXfyeCPlNU8k/4Uoz3pNXVi4VHB80d0Tzyh5HkwQWOcHHtUZkz1NNJzTScUlGxM5uTuyTd6HikLgnrg1Hx60oGaZFxzHdx2pqswGASB1xnijOCRRkdqdkPne6Oj8La+LZxZSrlZG3CVnPy8dPpWbrVtFZ3WIRiMg4UNuIwazM+xpuQD6VgqPLPmj1O+pjnVw6ozV2tn5Eu/jAA+tRsS3PSl3UYroR5t7idKcCCBzScHikJx2o2AkHIopisegpc+9KxSHBj61IjYHU1ECCM0oNIpOxODg8c1MGORziqiOVP1qRXGOvNFjVSLSt8vvnrUolIAHFVEbk8809X96lo6ISsW1Oa92/ZR8G+A/FvjnUX8c3qWttYaaLm1iluTAk0nmhHyRySqHIUEfjjFeLeHtB1DxHcNBp9sbiVF3FQwXj6n8e/avsPwV8LtA/Z60UeKtZ1UTfaoLeGW4uIQyQSld7xIFBLAnjnnA+teVi6sIxcOrPo8BhatRxq7RXU+aPHXjKw1bUdQt9JiJ04XT+RNMPmeIMTGQOoyOvrXGibJ681a8YXmmXXirV59FQw6TLdySWsbLt2xliQMHoOePaskS5PHNb4aioQSSsc2OxtSvWbqSu1pcueZxjvR52SATj1qpv/Ck8wY611umjzlWfc7Xwt8Rde8F6brNloGrXOlwavbi0vvs5CvNF/d3Yyv3j07E+temfsufFuz8K+MdF8LeKnD+BtUvPIvvOkdRZROjKzqykbF3shbrkA8evgEEzByFGR/8AXqb7UwfOfmHeuKeHhN2aO2nipU43g7PY+y/2jf2x9JvINR8AeANC0u88BrZDTTJq9k7NKY2IVogWA8oAKULAPkbq9F1VPC/7aPwGSOxhfQtU8LxLHBCzra2VtfPZjC5+YNASuOArADoD1/PBpzLyxrU8Oa2NH1FJi7rEsbqdueSRjoKxqYdxjzQ3Rrh6kKtSNOo7J7swLpGhfafm/wBsAgH6Z5x6VAW4x3NejeK/CCXmmPqlmkm/ykdYo4+HyeT+RrzmWF4ZTHIjRyISGRxgr9R2rqw2IVePmic2y2pl1RResXqn3Q3OBzzTCwPfNOY4HvTCc/Wu1Hzrdhc4ppfHBJNNY5FNzinYycrknmD3oEntUNHSnYVycS+2KXzR61XB54pwOKRSlYsrLtPUUplz3xVUk9c0qngU7Fc5Z8w8/MaTcOxNQiTOcCl39M4osNSJfM4706OTA5qDPzU7cBwTSDnsWvPYJtDtt/uhjimhu2agBBAwfwoBwaRfO2iwGPY0+OXGcnNVcilosWpNF0TD1qSOUnvVFWxzUqvxxxipsbRq9za0m/XT7sTEMx2lflxnn61s6my3g+0xEBBEM7jzXJrIBgk4+taaXUqWixBwIiORt+neuCtSvLmR72Fxdqbpy1XQ0NMmhN5brcfJB5iiRu+3vW74putKWa1GlYEaofMIDDJzx972rkoJf3gXIHBwa3dZ+wLY2zW7l7h+uCemOeO3Ncs4pTTbPXwlWU8PUirfqU/PE8ql8EDsf/1V9M/A342x+JLPX9A8b6nNqlzcQs9pqOs3cfk2sQjYSRq8h+QsWGNo5weOBXyu2UxvUgHpnvQtxg4GCPfFFfDxqwsc9DEujUTZ3fjr4d3fhGe1S2juL+F7KO7nmhiZ4oS4LbSyrjAUA59DmuHkkOODivadY+Ifia++F+qWuqXMUhvQiyNC5idYlWNFUquFI2rjGMnJJNeHT71ycYX1qMJJzi1LdHZmmGeGkpJfEr+g8yEd6DN0weaqCYetJ5vTkGvQ5D55VrdS8kpDZzWzoc9juk+3MoX5dpOfx6VzSS88gGpVkBHB/Ks50uZWO2ji+R33NaW7VbmQxkGMOdmD2zx+lXba7LTL079BXPiXkc4xViO6Gev61i6OljspY1xlc7GK/kWJgjunHRWK54r6iuZvBHiP4RppHh3R7Z/ElxptvbtqD2nlj7QRHvbzXGc5zyOufQ18axXQKg5X610PhvxTqOnajYSQ6nd28EMqFvJkb5I9y7sKPYV5VfBXSaex9Hhs0k3Z3foy/fu9jf3NqxDSwStE5UkruU7TgjtxS2eqS2svmIwR8Yzj/GvUP2iPEXww1HTdJHgCwtLS4+1yyXU0NtNE8kZUld5kHzcnOB6+leIpqCdmH51EaaqR2OuOZVYz5m7NHqmmeKLWSNFe5RSqLuLfLk8ZxxW9b+PpIIUhg1mWKJPuxx3LKo+gFeNR6hvjXEgAHbNTpeDd9/j615tXAJvRn12H4jnKKU0mfQPgzx5MmtQzz3X26FVZttxOWXIxg8n1r7o/Z8+My67pVvbajPPqF5c3rRJJ56yLEDjavXIGD0561+YXhq+WRI4vMy4UnGM8ZHtX0T8EfiZp/gjTDFcTSW94t61zFIkBcDKoAcj3U9RXDRk8NVs9jbP8rpZ3gFUpx9/yPq39r/wRqHiyx8NzWDW8UUM88Ust1MEjjLx8MR/EflIwOe3evz5ezins/LeNXRhgg9CM+uBX6GeAPjFIt5eL4tuJ7+ORUW1T7OrBGO4NwAMZBAzn1rO8W/seaNd+LfDd74b0S2sdMjvPO1SKe7LJJEMEKqNu5JzxwOfpXZXw/wBaftaTPjcjz58Nwll+Yx93Vp9O5+e0OhwwzIIYIlYsFGQDyenJzXpj/BPxAsojK2LY7/aQBn/vn+lfcHj39nDS72PTf7D8JaOoiZ2mKxxIx4+XHAzznOTXMy/BrxNFNkaG5Pqs8Z/9mrhqYSvF2abPoKXGWBrQUqNoeTsfJDfAvxJJGyoNOBPQm6/+xqTRv2ePFmr65p+mRnT4pLyUQpI1yWRCRnnC5xx6V9ZRfDTW7K5El/ps9paoC8kjFSNoHbaSevFE2u+ENDcT29rqn9oW37yCY7diSBflbk46+3PpSjRcH+82M6/FFaonHC+9JrRpbHhmtf8ABOLxtrCxO3iXQYdqkMMTNjJ68LXz54F/Z+1TU/jLrfh1b6z3+FL0y3U0yt5dykNyqEKACfmwetfax+OnjRVymrLI2OAbeEjP4DpU3xQ8Padrnh2y1j4dadaaf4tvZ/M1u609EgmmDo7Sb2bG4eac/XpXoqrTdNqlpY+YjWzOWIj/AGhqp9UtF6nzt8fPjJ4ZsdE8UeFLdLlNZlhkt18i0XyUc7WH7zd0xnkA49K+Or4vvDiRuScfMeK9T+KHhLWP+E11wz2cwnF45md2Q/vM8kkHB+tebapZS205jkjKSL1Vu1dGEVNLV6noY6hWpx92/L0fQ5+UfPjcR9KhdnUAB3AHQbjxWo8LHd8vPtUK2TT9Btx6jFe2pRtZnyMqFRSvHcy23P1JP/AjUTwegJ9a1lsiwyD7UyW1KNgc5Ga3hUjBWicVWjUqO8zHaBgSdo5pph46VqNaknkUhscAk7hz6Vsq3dnDLCPojL8o9uv1oMRAGa0JLTYpIBaomh46VsqieqOeWHcd0U/L57GmeVk54q55QGOBTTCD2FVzGLpeRUESntz9aPJXPT9ateSB0Ao8r2FVzE+xKvkqe360oiUHOP1qx5eOwpfLo5heyK4UZ6UbKsLCGPFP8gDryPalzotUWVNpJwKUIatCEDoDn60NGOBijnQ1RZXCHqOlbXw5YKuogcH913/3v8azAgzirvgKYRNfbsc+WP51hXfNT0NMPFQxMLnFX4Iu5gezsP1NWpnb7CgIG3avOfpVfUeb+5P/AE0b+ZqeX5rNP90V1w+FHy1f+LIypgWlGASMU2WPETnOeDUsj7H28HPcUk4xBIPb/CqaOYzgec000u7ikqTNBRRRQIs/YCOrgfgajmtjAASc59sU63lVCSzGrMrpGqlxuB9qqyAz6uxc2DfQ/wA6pysrOSowp6CrsX/Hg30P86z6sYtmf3R/3j/SrANVbb/Vn6mrCHmtI7ItM7e6YXJXbkYzyaqTSjYEC4K9TUkD5OPSqkqNb7nYgoT296ucep0wkTWTbb6LPTP9Koa3IG1TA5+Ra0LLEk0bgcVl6xxqv/AV/l/9as0le5rzO1iqetJTiMmk211E2Eopfu4z3pDgnigm6DAFJn5qUjNGPage4gBzS/rSDr7U8ocZ2kj1xTFy9hvSkycjApSM0dKQnoIDk0dDzSUuPSgE0LkHpzRTRzWnd/YBp0Jg/wCPr5d/J9Pm68flTB7GdSnj2pCM0gH40iVdasWipo7WWWIyqhKDPNRce9OxaaEPSiilxz79KRN7sMUYNOZWQcgr9RTKLWLQUm2looGHSk2iloOO1BLG4I5zRTqQrzxUtWKEI4pp607bj8KQgNjNIBCCTSU+m7cE96AEpR1o2jrTlOGBIz7UALtGOaShjuJ7CincA70Uo9qTHGaQXHdaaeDQDig88mgVhM84paaRz7UE4zzTsA4daDyaaB3p4PNIYlBxiiigBUBJ459hT87fvAj6iiCUwyqw5IPQUXE/nvvIxwBg0+gDC2T7Uh5opN2PekJi45p1NznmkyC2e9ACsMcmkyM0tI3SgYtFMD7cYo3GmKw7I9aNw9aOxxSDHQ9aQxcUHkGlprdTTAB1o7+tJmjOKQDug4oDEU2jFK40yQEntTg2DnrUOcU7PFFikyYNnB/SpBJ+NVutOUspzkila5cZ2dz1b4eeI9M0bVI7SKMiS9ZEBXnaR3JPT7xFa3xe1fX7+zKtqV3daGXjb7GJi8EMiKwDbQMDhsZHcmvGEmI6nmuwsPiLeaf4aGlwxgMpYLOWOQrEZGPzGT0z0rxquElGsq0NWfc4XN6FbBywdfTqmu/Y5POOen1pRJioy4JpNwNezE+KlLXQmEvHT9aDJk9KiDYpM/nVWJ5i9aSkSEbeo60s4G4ndz6VJpWlXeoxM1uFO1gDubFVbhHguZYpRiVGKt35rmUoudkzunGcaCk1o+o9TgcdKekhU1WDnHWk3n1NbWOFTaZ1nhvxbPYyrZysHhlkXdLIzFkA7Dnj8qs+LvCszRtqtjazTQzyFpXjUuEONxJwDgYwc59fSuIZgeD0r6R+A3xYl8PfBbxZ4Qn0qSWDUvtC296kgQDzrfy2DDHzAEKRz/Efx8mvCOFl7aPzPssDiquZ0Hl848z3T7HzW/HHemk1seI/Dlz4dvhBOAyFQUkXo3Azj6HrUOmeHb/VozJbQGSMNtL7gBnjjn616KrR5OdvQ+Ylg63tnQ5feRk56mkI3Y9q6bUPBN1bxIbXdcuxw0eAGHAPAzz39K5kirp1Y1FeLMsTg62EdqsbCY+bNBGadj3pK1OERRg+hp2KQLznFOoADTd2Ogp2MjFIBimAgNOUgMM8CijHNILn1J4g+IfwBvf2TbDQLLw2IvjDFplrA+qrprL+/W4DSsZt2CTECN2DnOK+XCwBJpo4Hpil60krAtBQ5B4ANPDZHNQnrSbfwosUmWAw7YP40b8VADt6U9TupWKTJ4zkGn7gvPaq44pysT/9egtMsrJvq7b3IK7XCjAAGazBx0p6uePWpcbnTTquD0NUSDcDx1zivtj9nn4e/D7xt8MPD9zqPhjS9U1CJpLe6nmibeXErHDEEA/Kydq+HouWGfzz/wDWr7f/AGOdRsbb4WSxS3EMU6alO/ls2GI2xkEevSvCzKDUE0+p9Zk83UlKNrnyD4l1CPUNUuWijSKFJpFjRBgKu84H5fWscnA9qrrPnexfG5iefcmkMmf469WnBciR4dfEN1Wz1L4V6z/a2rT2mtXqzWa2p2w3siCNmLqoADYyQM/lXW/ETStJ0jwRq0thZ2cTzbIVktlU7vnGRkA+pHGOlfPxccZOfqK9q+Euv2uo+H/7FVZvtFsr3ErOi+WVaQdDnPp2rwsZhXRmq8HonsfoOR5rHH0pZdXS5mnaT1d+x4pIdjkHPHFG8eoFbPi3wpe+Gpo5LtomWd3CtG+4kggnPp1Fc+XIxXv0ZxqQU0fn+Mo1MJWdKorNFgShc85pyynHf8qrBs9TShuvNbcqOFVGtmWxMc+9dn8M/BsHji/1G3mu5rYWsCzKYEDFiX2kc1wIcA5OTT1uGQ5RmQnqQcEisalOUo2joztw+JhTqKVRXS3R0niTT/8AhHfEV/podpUtpTGHkG1mAAwSPxrZ8ASrceII0Yqo8pz1x0Ga4ZZWY5JJPqTk16D8E/EMPhn4h6dql3F59rbpMZo9gbKmMr0PHcVw4mlJUGup9BlOJiswpyS91vbyNb4lxeTbaey/dZ36dDgCuDFwzcetXvGmpavc6rv1CSYW0peW0SV8qIy5HygdPT8KwxKRySTXJhKLjTV3qepnePhiMbKUI8qNhJyABg/lVqK44zzg+1YKz5Jxkn61PHcDaMe1dMqZ5dHF67naaFqZtbtZNpYbNvXHXFeo+H7sXNrbzHC7uSAc4GTXhNvdKG3dcY966bRvE9xaNCjXc6xLgBAeAM8+vvXz+NwfOuaO5+m5DnkaC9lV1iz7Wb43+FIDkzXpKjIK2bdR36197+G9UuLi0eW4kjMRiRk2fwrtJJPH0r8fBfQ3kTmFwysCBj+Vfpn8FvifafEfQ9UitrWa2SxtIoiZ3UlyUYE4HQDH61x4CtyycZ7njcbZUnSpV6KvHq+17HdaR8avCGuMwsdbguAql9yHgr3I5zXmvxB/aX8P6hp8lnoeu3WkXyyMGupLZo8KOOCysvJwRwcgV+duln+zsiMBCoKnb8vt2+lasfiO5jXjPPcP/wDWrOrmdV3jFHp4Hw8wcHGtUqN3Sdjo9e/aG+JeqW3kT+PNWO0chJVj3cjk7VB7UzXfjFfXGl2kFnq1z9ojKmWZnbdJ8mDnK9c/yFeY+IvEcVnfOjRSliqtlSMA1mXPii0k0p0SSUXTwkY2EYfHrXE4Vq1nI+7pU8qwF4QhFNHfj4ra6ASurSuRnGQrdvpXvfw7+J6+D1luNaW71BLmGJESBEOxupOCV6jjiviXS9XaO4ka8ndozHwGJf5uOgx1xXePrF1fxIZLiWRSoI3uSMfQ1MqUqEky2sLnNBwSSZ9P/E34MjxN4N1j4nWk0MGmzWx1NLJ7ctM2QvBYHaO54z+NfKmseGrS7R5hbILmWQoHdmABIxkjivqL4Y6Pf+LLLwno0mo3z6Zex28NxZNfyiB4mA3r5YOMFSRgcV1vxi/Yx1i88UK3gnRbGLRPs0YELXgUmXc5dsOCe6j8K6lTlJKrRXqfIwzKjl1R5dmlRNPWL6JLZH54Xmhz2Fw8MhRyoBLIwINUmh2npivt+L9g/wCIOosTJpukRHpumvlP0+7Ga8q+Jf7K/iH4YNqGpawdLkt4JkgMNuzSne/AwNijA/Cu9V6kY3qRaPN5MvxNX2eErxk30PnOO2UZG0VqJ4Jv7hVlRbfaygj58HB6dq7XRfB9zc61aRQxxK886RplCqgswHOB05r6fj/YQ+JBhDQzeHZE7f8AEwkU/kYeKj6zVqO1FXOmWDy3A2WZVVG+x8US+BtRjcny4j6bZRWdqfh+60vyzPEqeZnbhw2cdelfdCfsG/E6Y8/2APf+0m/+NV5J8b/2ddd+El3pK+K4bJmvUmaA2lw0owhTeD8ox99fWtFXxFP3qkdDL2GR41+wwVZOb2Vz5ekt2Bxjj1qu9qeeMkV6ZfeGIHsblbezRbgrhGZ89xzyTjiuMvtLl065a3mA8xQpIXkcjNd9DGxqbHg5lklTBSSnqu5gPb7BkqRUbQ5B9a2Xs3kxgAAetQGwdXwdv516May6nzVTByvojL8ojr0pyWzSdEJHT0rSazAHOB+FOjtSowMAH1FN149yY4GbdrGYbV8/dNMaBk+8pGfWt0ac+cFlB9qnj0Qy7C4BXqOlZfWY9zqWVzeyOcSIjOQQKCmQeee1aV1amK4kQZwrED/IqHyWxyeprT2ykYSwUoaNFLaeO1Hl5q41szHkUq2xHYU/aoy+rS7FNIxmqvhQkG7H+0n9a1im0HGAaxfDW9mutpIG5M/rW8ZKcWeTioulVg0c5qGfttx/10b+ZqeZS9iqjglRVa8J+1T5/wCejfzNWZz/AKEn0HSvRjsj42rrNsoRRmNSGAzTJ8+U/wBKsWy7p13cgnoaNVRV3gAD5egp2MjGAxSU4d6aRioM1uFFFFAhoq3MwuFURkHb17dhVUDinJK0RO0jn1FJMBpUocEYPSr0X/Hieex/nVJiWYk9SavRAf2cSRxz/OhdRoS2+4frVhen4VWtvuN9TVmrizQ7ID0HWq+oj/Rxn+9/SrKVBqI/0cf7w/lWs3obU9inYzMsyJwBk8/hVPVmLaqP91P61Ys1Z7xAoJOTwPpVbVVZNUAZSvC9axi9bGtna4wLjntTttGM0YOBXWh3AgEAGkwF5p+MikK4oIsiNuT0pMGpcUhXvRYERhQM1f8A7Ub+zfshiG0DAbPPXPSqeDSEc00MZSHvTxSNSYbjD1oFKQKQ0jJprUKM0UA4oJHdaDx3xR6Ue1BorvcnivpI7doVxsOc5XnmoDzjFLjAzTSeaAshw4I70oO0gimDrntS5+tAKyJJJmlAzjg1HSg5pMe+aDRBRS4oA9eKAEowfwruPEPwS8c+E/Bdh4u1fw1e6f4bvvL+zalLs8qXeMx4wxPzAHHArhx0NIQUUUUwQmD65pOlOxzRwaVhjallaN41CjnPPFR7eaQcE/1oAOnTpTd3OKUnBx2ptSA+kzg0i8Gg9RQJjh2NHSiiqsIUjIpKN3IHailYaCkb7ppSMUUwEXpS0UVIwpQRRtoIxQFwOMUnaiigTGnOBSU4jNNxz1GKBBSrS7RSHjpQh3FJxxTc0o5/xpcUAxuKKCeQKKAQDilAB7Gkpw6UDFpnUmlY4J9KQ5z3qkAhwDVvT44XZ/PIAAG3Jxzmqu0nGc0oBzx1oWmoEl0qLcOsZBjB+XBz+tRZ4xQeM0jfSl1F1DilqeGyaaAyBgACRgj0HNQA5GRQCFB96XeabRSGOD4NaWmTWu2T7QFzxtLZPHP/ANasuilNcysbUqjpy5lqTzyIZZDGMR7jtHtTA5FMz7UZpJWsjOUuZ3Jg1Lv9qhBzS5NUJM7XwfawwwS37XQ+UbHjyAF6cmqXi3UrG8miNsVeQZ8xkHB6Y5796dpsGmr4cmJuvKmuAA2SMgjnAH+etcuxzj36V5tOneq5tn0+Kxjp4KGGjFWeo8SetIZRUeaK9Gx8xceXB+lezeAPtyeHkS/i8tIyFiLYyY8dD+XevFuuR0Br03wP4o/tSwn0y9uVWZiVikkI3SB1wQM9SD/OvLzCm50z7DhnEQoYq8pWbVkct44jnt/EE4mululceZGyyiQKjEkDgkA49Kh0DxXLoMEkccKzhnDYdiAOORx/nineJvC1zpGqiCNJZ45seVJtGZD34HTmse80y6sLkW1xC0cxUNt+9kHnjFbUlTlSjB6nn4mWLoYudWCad2db4b8W+bfsNQnY73HkrjKqSeRnt29areONBXT5Y7u3RI7V/wB3sQYIfqT9K5VSY3BOVYc+hFdKPG839hHTzD5kjIyGaRi24E9ceuDip9i6c1Knt2OiOPjicM6GLfvLVPqc1j8qMUhb0oJxXo7nywoopm854xTgcgZ60BcWkwaWigQAYooooBDWXIpVBA5paaTzQO4p7UnfFFFAhcUAgE460dB7UlAxwYnvTt2TUYOKcrUWKT7kivgnNSqwOOtQKQe+a7j4LaBp3iz4teDNF1aIXGmajq1vaXEe8rvR3CkZHI69jWc3yRcn0OmlH2k1BdTc+DngqfX9Vt9alhs7jRtKvYGvYruUDzUzuZApHzZVW9K9H8ffHbw5o+mafafDeWXS4f3puozp4iVshRHwWOf4gfwrsfjdp/g/9nm8i8MaXFLp41K2GoyKoluN2WeJcFiNvCt69a+PJZcn1HSvEpXxs3OovdWx9nWqRyjDxjQmnOXxeQ9n2/d6elN87B61Ez4PHFRlua92KsfFTk27ljzTnhjVrTdavNKnEtncyQOcBijkbhkHB9qyweev507dUzgpxcWtGXRrzozU4OzR6B8TfFum+JWsBp8skohMhcvGUHzbcYz9DXCGRelRb/ek3VlRpRoRUInVjsfUx9Z1q277Eu7PsKAefWotxxSbj61ueemWATjjigPtbPtUYlHvTt2eR0oKTJhL+VdTP4WvLLQP7UjuIljKI2zBD4YgYzjHeuPJJHXFenajrFjJ8P4IEu7aS5MUIMKyqXBBBI2j9a8/FTnFxUOp9Xk1LD1oVpVnZxjdep3P7P3jb4W6HoWswfEvR01m8Mqf2dLJZPdPGnlsGAIYBQH2tznqcCvKfE3g7U/Ckdo1+IT9pLKnlTBySoXdnHT7wrBVgDng855+v0r07wXqEPjee8/4SCCDUjbojwq6lBHuYhgApHXA656VyVebDNVIq6O3AU6eZp0Ju1T7L/zPMBIc8GrEcpwOcVHrCxRa1fpCNkKzuEVeiruP6VCjAAV6KXPG58/NuhUcL7M1YJxzz+FX7e4IcEHH+RWHFMMcnnNW4Z1DryPxrmqU7nrYbFcrWp3WmeJruIPtunUE7hxkZOOf0r63+Dnx9/4V5Hf2+gfY7yfUCkcnmksNwyFA24xyxr4dtrwKRjaTx3/+tXbeDPGB0q+865mVY4/LkjXZlSwYEZ45HHqK+axeDkn7Sno0fpOXZpSxVJ4TFLmi+/ke2fFTwFrnwaXT5PEkMKJqRk+zPaTCbJXaXz0x99ev4V5ZN43VFVY4XZvVmA/pmvpDTNan/a+01jrsH2i38OScNpqNAIzKnO7ls8R/pXx1dTLG3Dg+neuOjhYSk00ejUzvGUqSpykrrt+BpX+ptcXEkrsTvYtyc4z2qk90uFG7is+S6DEYbmmCcbuua9iNHlSSPl6mOlOTcnqzRFwGJGcD1Arp9E8ThJm+1uoh2gRhI+h4/E8VxAnAqRbjZ34rOrhlUVmdmBzSphKnPBn1H8O/i/qvh7VtBni1GOKzt/LKv5SZjUDjqPoOa9S8WfteeN5r5E0rxJtt1jG5ltoT82T0ynpiviyH4hahbWsUEK25VFCKWjLHAA98U3/hYGqE5ZoD9IQK8n6tiKekHofVVMZkuOqRq4qmpSS7H6F/AT9so6ZdawvxH8Q3E8LrF9h22Zba2X38RR+m3qfpXr+hfFH4HfHXxKnhs2cWuX+oyNcLb32m3HlyPGhYuS67VIUHBOPzr8s7PxbbOitNdwCQqpIGVwSOa7TwP8RNU8H6/b6z4f1EWWpQxusdxCEkKo67W4YEcg9cfSnDE1Kdo1VdHBjuEsvx6nicvqclRrRJ2Vz9MNS+FnwJ0DxHpulSeG9Bs9XumD20ItWUsc8HI+XqO5ruPFnxC8O/DqG2GpSTRi53mJbaBps7QCc7c4696/PKy+P3iHxVZw6lq+vy3Gr2czpDJJFEjIo2spG1P73r3FQ658dde8QRRR6vqUt00YyqXCDKg4zghe+Oa0eYwjfkjY8CnwDjsS4fWqzcet3f7j6f+IH7W3hjXbEQeH7/AFvS76B23yC1aNWH3cHBPQ+3Y1leE/jL8MPEHhr+zvikq+JtTjupJbSbVdNkujDE20KA5Q7eQCRx+VfFlxrtytxcSRGNUklaTOzccEk+nvTX8WXjbllMbRuCrboFHB61y/2hUcrvY+t/1GwFLDqjTm4yTun19L9j6d8b/so674neyvvCuk6fDp7wgsGuEhyS2RxtzgA45FfNPxL+D934M8VXmla1a2TanEsZk8p/MADICuGAHbHavpj9nb9ozxBq3j7T7HxV4pt4PD4jnkmWeKGGLiM7FL4BHJBHPOK9d+JnwL8BfFrWLvxQniFru5uQsZGn3sTRZjjwBwCcnAyM963VGFSl7ShozwlmuMyrGrBZuuamldNK/pqfmRrPggxyzT2oiVMr5dtCDu54PUY7HPNYUvhe+Qb5ICi5A+dhX2LL+z3cPGsg0fWJsDJ8tHxn/vivOfGfwc8RWur+VY+EtdltURfnNlNIC3Xrt9q5o168dGj6d0snxUr06qV/NHzvHo0sspiWM7x26fzrrNB8MwQ6ePtVpE8/mEhnUMSvGP8AOa72H4R+LfMJTwdrZY9SNLm/+JruvhZ8FtYufHmhL4r8Jatb+FftH/EylvbWa3hSEI2WaTAKgHac5HSqlUq1rQSauEaeXZbCWIdRTa1tda+RzPwf+A198bta1HTtIfT7SaxhSeRryM4KsxAxtU9x+tcRfeH20/WdQ05o4pJLG5ltWMafKzI5Qlcjpkd6/RH4e6l8Ivhnq2qHwJaQi+aKOG8ns5JrgbN2UG5iRjO7oe1Ytv8AAPwd4l1GfVrDwhatLcTtcNOQ5BdyXZiC2Od2fTmiVNxSjGV2fP0eI39ZnVxVHlpO1k0kz865vCVpLK7yWKF2JJ+Y8n6A1zEXgbWZCF+yAH/amQf1r2jxh8M/E/gyW5fVNIu7C0iuWtxcTIApYMwAHPfafWuUu9YttP2iViJCMhFXJNZ08TVpy5dz7KtgMBj6KxCdo+RgaHo2g2dgyaskDXqyMCGdjxkAD5eK5nxPZWkWqv8A2cqC12qVEZJHTnrz1reNlNdx+aI2ZGP3wOM9etRNobuOYiePavQjWtK7Z8vWwLq0/Z04bdTjHgO05rlvDc+x7lQM5ZP5NXqV5oAS3kbycAKTnNeUaENrz/Vf5GvdwlVVIux+acQYOeDq0+bS9zDu+bmbvl2P6mtO5tgdIgKp85VenWsy6H+kTf77fzNbcq/8Su3/AN1P5V9BDY/Mpv32YA3RMOqsP0ptzIZI2LHcdvWpLnmZs9ahl5hf/dNJvczM1aaetLnFJUGQUUUUAFWzaRqMljzx2qnUs0/moq4PHPX2oukAyQAOQDxng1ejGdNP4/zrPxzWjEP+Jf8An/OkMbaINmeeGNWByRUNp/qj9TUw4aqitEWjq7K5+0O4wAFGRjP9aNWO20Ujg7x/KqGgEl5u5Cr+PNLd3xusw7NoRs5HftVyehrHQk0Rm/te3JPQn/0E0zxT/wAh1P8ArmlQ6LcP/bkUfGBuwf8AgJqfxMhbXEPXEaVzr+IejHWg/Up4xikJ4H1p2KDz2zXoM5QAwKDQORRTAKKKKBaBikCgUtFK4xjqe3SmMCB61NSYH+TR0AhYU3bx71Ky4GRTcZPvRYXqN2YoxjvTtvtQV9eKQrIZk/WgDnJpx4pG7UD2D8aCvApMDFOIIGe1ANDPY0o60uPUUdxTJaFzge1IDuANFBpCUu44dKQgkEA4znk00UtBXMj2z4k/tWeI/ib8INB+Hd9pen2ej6OLYQzwGQzN5MZjG7Jxzkk8DFeJ0d80m7JNFrArLYWiiigoUECm9KWg8fjQFxCSAO9NJ3UHmjBzQSIBnvQRilpOG4pWKuJQKCMUhHIqRCg5HWnDqPpTCMHFODY7ZxVIY489qdirVxpsltbJOxBVtvAznnpVPP402rbk2YpGAaaDmn9RzTDwSaQ0BOKOopCc/wD16UdKQWH0Hr1poNL1IPXikMQjFFKR3pKBdAopDSMcDrQSOoB6+lR11Hg/VND0+C5TWLVblnkUxlofMKrgg88Y6igaObpOc0vYeuOaT+IGgoaw+YUAZNSAZFGMCmSIF96XbSgYopANYHBHWjNOpCM00NCUgIBzjml6daXH0qr30CwxgGbPrQc8UuM19CfDr4HeA/FX7PPiHxjqniWay8X2Md69ppIvIEWYRKDG3lsN5BOQQOuOKLAfPSuyqQrEA9gaTHTFPKgYx6DtiipYxNtIRinUU7E3GYpcdKUgUYqRoTbS7aMe9FAgAxT42AYEgNgg4NNpC2KBrTU6eKOz1SzYRRJC/wA2IwR8p9a5y4iaCZo34K+nNLa3ctpKZIX2SFSMgA8VE7mRyznczHJNYQg4yb6HoV8RCvTjpaSAHNLRSZxW5wAORzUttcPaTxyxMVeNgykDoRUWc0HpSaurMuM3B8yOgXxrqMl7BcXEnniIsfKI2qcjBzj/AD2q7F44ebVYJntoo4lTyiDksoPUg9uprkSaAcdK5pYeD2PTp5piYbyur3O28beH/Of+0rUPMZTlgi5GAud35D+tcUeAAeRXXeFPEaMkel3afumLASsx5z/D1/DjrnFYniKwgstRlS3kDLnJjXny8/w55zWVBzpt05HbmMaOIisXR0vuvMyyc0cVe0zRbrVXKwIuF4LOwAB9KpPG8TMrqUZTghhg5rtUk9DwZUpRipNaMbSglans7GbUJhFAod8E4yBwPc0XljLYTeVMAr4DYBzxS5435U9ROjUUPaOLsRBulHQ0nQilLYPrVmVgDbmp1Rg4Oafu9qAQp5phXn3pyncM0pGaAIwDnmnEkZ4zSkU08Uw3PQPin8Mrb4eLa+Vfz3jzSshEsaptAHXiuAAzSbzjkk/WgHgYNDBDiuR1puMUuaKQwHBrt/gxqbaN8VvCOooglax1W3uxGxxv8tw+0ntnbjNcR1NdN8ODjxtpLDtNk/8AfJrnxL/cyfkenlsYzxdKMtnJXPWP2xfiKPiV8SdM1T7ItgItKjt/IWUyAYmlbO4gdmHavBC3Bx613PxiJPiiME5AtkwMdstXBk1hgU/YRZ354o08dUhDZPQXeSaXqKSGJp5kjjG5nYKo9STx/OtnxF4O1nwkYl1ayNn5pYR5dW3bfvY2k9M9a7XJJ2Z4KhOS5ktOpjdaBz3ppOO9LVEXAtt7/mcUK+fetnwxqdlpV1PJfQG4jePaqiNXw24c89PrWbqMsU+oXMtuCsDyMyBhggE8DFZczc+Wx1SpxVJVFLV9CHPtQDgU2lrWxzJjuDTw/SowcCjdStYq5KDnvT0kIPH9KiHQc0oPHWlYtTaLKzZXmrum+IL/AEgSixvJbTzcB/JON2M459smsrPpSoNxPrUuKkrNG9OvOk+aDsyeSd55XkkYvI53M7cknvT0kOeucVXKkfSnK2D7GiyFztvmZtXOlyWlktyzqyMARj3qqk5B96gl1G5nhEUkzvGMfKTxTEcZFS43OmNRLY1oZzuB3YH09qtxTbsfMSfpWPHINtWoX3kFeTWE4LdnrUK7ukj7C/Yn+KGk+A9I8b2mpW93cPetamNbVVIUBJlOSxHdh696+c/GukPod5g4Mf3Qc55x9BXbfCnTL7wyupyXsQikk2YUOHyFBJ6Z9RXlWq6tdapITf3k1w2dwVzkKT7duK+ep81XEvl+FH3denQwmAjOonzzIPtP1zTXuiBwcH6VRZyM4JwOlN8xjgZr2/ZpHxcsS2XluXPVht75NWY7jcDjoK6P4U+JNC8N6xeXHiC3FzbSW/lxIbUT/PvU5weB8oPPvXNa7dW91ruoTWeVs5bmRoV2bAIy2VG3+HA4xWEleXLY641OWClzb9CQS7yD+NSeYGPI/Os9X24qaOQkmsnTOmFexcEmOeoGa9W8H+Cr1bmCSa7haKaJVUKDuUEDH5A+teSRuBjjj3rq/Cev6j/asbf2ncRJCjOCZjhcDAHORXkY6hOcPc0Psshx1GjiF7RNt7HsXiC0j8EvbwLKblZkMm5F2bTnGOSawJvEK3d0vyupYBcnH9K4vx54uutZurLzL6S8EUbKHEmcfN04HtXKnUpN33nyOh3mvMpZe5RTkfXYviVUKrpw1SOq1PxrPcRXNssKxk5j8wOcjnH51F4X1IRSzmR2IKgZOT3rkXuSZCWJyevcmkF0VPyswPseteh9TjycqPlFnuIeIVeUr2PZNL122mvUiR9zsrELtPpnPIr2D4d/He5+HdnbW8Omx3qw3D3IV5tgZmx1AXPb1r49jvpYXDxyyRsOjK5BFdBoPjOXT2kN3Jc3YYAKpk+6fx9q4ZYGpSfNTZ9DHOsFmS9ljoaM+9G/4KB+KY1Pl+FdIKe80vSmD/goR4n43eEtJz323Mv+FfFQ+IluV/49J/8AvpP8KZL45imUqtvMuQQGLrwce1NPGGEst4YSuo3+bPuCL/goVr64P/CJaaT6/apP8KyvGP7cviDxn4Y1PRZfDWnW0N9A0DTR3Eu9AwxkfLjNfD1hr00F5FNLNLMi/eTf97iuitfF9vK6p9nlyenzLVVHi0rNk4TLuHZzU/Z2aemrPWPCvj2fQry7kaMzfaRGJMvtO1GLAZA4619D+Ef2zL/wzpq2kPhmzuI1G7LXjgscAf3D/Kvi/wD4SK3UFikowPVa7e1uFAjUHPygDv2/+vXkqVTDyv3PrsVleW5vTcJxTt/SP0Z+Nn7PzfGnw7b20eqxaQTci9Li080sxQgD7w4G41+Zvi/wFDY6tfxm9Mi2txJaLIECiQI7LuwckZxn8a+wm8Q34jBfWdQCAZI+2SYGO2M16dY/Enwd40vpLZbI3cqp5hF3YrgjgEgnrzXqTdLEWlH3ZH5tgnj8gg6FVe1pPVJK1j4S+Evwrf4g+MNE8KW+opY/2i7RrdSRCUIyxF/uggnOzHWvpJv+Cct8AN/jq33HsNLb/wCO16J4y+L/AIT0HQdR0HStJurLVlURR3NlaRwCN8qQQ+RjjuPWvl/xr8QLy78T3F3Be6pDkKdpu3DBvX72PSsJSo4ZWn7zZ6dGWc51Uc8LL2EFpZq9zrvHX7CF74fWG3HjGC4N1HK3/IOYYVQM/wDLQ85I646GvzY0Bi5nPuv8jX6W/C34w/bNPv7TWZdVu5rZCIZZ3MyKpU5GWY4Oa/NLw/gG5wO6/wDs1e7llSnUUnTVj4TiinjaNWlTxsuZq+trXMe74uZv981uEZ0uHv8AIn8qwr4/6XN/vtW20m3SIjjcdiV9ZA/Jp/GzDu1xctzVeYYhf/dNWJ3LyFiOvYVBNgxP/un+VS+pBlEf5/KijqBRUmQUUUUAFJnmk3U5ELk4600NgOTV+M40/Hsf51TaB0XcRxVtD/oB+n9anZghbT/VH6mphUNqD5R9MmptpqlsjRFlrd7UBmIy3TaakurQxQrISDuI4Ge9MuLjztnGNoIq7qXNlEPp/KqaQ0yPw6CdZgxzjdyP901oeIf+Qwe/7tRxWJZMy30ZUkNzyPoadezH+0FLuSMLnJ7VCj73MdkKvLTdNlsHpS4JqOORZQSpyAcVJmutakCYpcY/Ol/nQOOtAxCRmjGKUg5yBmkAP407CsIetIePpS0N0NNghPel60gHyilAxUgmGOMU0pjJFOpD1p3BjelBAP1penJppHOaQthCpOaQqDTiaTaPX8KAUkNwATRuJFOxyaNuKditxv60BePU06jHNIBpGBSU8jNMxigVkBANFFAoJsgNNJAFKVPal4FBFnuhoPFKDTcGlwPWgq8hQeaWrl7oeo6bEkt5YXNpG5wrzwsgY9cAkcnFU6dhibRTWFPpACx4GfwosUhpGQPWkHWnEdqaOtIOopGabjnNPppGDSsK4mc//XpDwc/pS0Uxof8AaZGQIzuV7KWJFA61GMp1pwbPNJ36jJOtBGaRTmloWxOwxhgU3NSMM03FJDQ6EBpow/3Cy5ye2Rn6V6r8avC/gDw/Z6W/grU49QmluLhbpEvvtHlxqE8s9BgElsHvivKMigHIpjFpGPFLmtXwn4XvPGfiGy0aweBLu7YrGbhyiZAJ5IB7A9qViWZHUUjYI6V0PjrwPqXw9199H1Vrd7tI1kJtnLJhunJA5/D8a55uAe9IQnahVx+dA9KctMB1FFA5pFXAcU6kA5paaBBRRRT0BhRRRSEFA44ooxRsMQ9aaRk5wD7kc0po20XAVRRtoB7Uo/OkDE79zSCnY49KTbTGIRSjGKNtJ3p2EK3SmbeAcmnkcU0rihgIAQfUU6kFLUjCkxzx1paQ8UAHSm05ulNoJuKtDULSnoaBDcc0Y96KD6daZSDdj601utOpCM0rXKu9i5Z6nJYPvhO1sYORkflVaSRpWZ2yWJySTTNvPWlHTmlypMuVSc0ot6I6jS/EkFtphjeNFuIxiNVThzjqcfh9aw7/AFGXUZRJMQcDChVwB3/GqvUYpB2Prxmso0owk5HZVxtavTjRb0Q7NMbinYI+tJjIFbXPPacdGGPcUdDSU5mx1oFe4qnHHanUwdKX8aAuOprCnA5prc5xQA0L60oXApQM04DFAxuDSEZ5wakPQU1hzmnYVhoFWLS4mtJlmhkaGVDlXQkEfiKiUYbpxV7SbMajqlpabtonmSInOMZNKduVtm9DmdSPI9b6G7rstte6RJcyzrdXgKpHI8pZwvHGM+5/OuQPeup8eeGbXwvqFrb20xmEkHmOSyttO4jHHsO/Ncs1YYezheOx6GZOXt+WotUOhmME0cigMUYMA3IJBB5ro/F3j3UPG/2YajFao1uWMbW8ZUgNj5eSeOK5k80gHIrVwi5KT6HnxrThFwi9HuP6ik5ApQeTRiqMBN3NO+nFMpQKpjFbI74oByKOOlHSpAUH2oxmk60oODmgVxcH1oAOaN4paCri5wRzTl474phGaBxSLuSI+SR2p2R603cNg55pAaViubsSgnbnGSaVWzjimKwzjP0qRSDgU0jSMrkqybTnPFep/DXwRp80l+PE9tLbKY1+zyu7RhGJOTkfgea5PwV8PrvxrBeTW9zBBHakBxNuyxIJ4wD6fqK9M1a5gWO3+eQpLhVaJTtfpyCeK+fx+Ib/AHVN69fI/SOHcrVni8Uvd+zfqc7ofjW61fxfoFhLezTW81/bQyoXIR1aVVYEADgjP4V77/wUW8JeGvB3iXwRaeGtD07RLX+z7rzE0+1WFXIuAAWwBuIAxknua+UfDheDxbpEyMJXhvY5FWTODtkDAH2OK9R/ab+Pdz8ar7Q2urCysZdNjmTdZh/3gkcNg7j2IOMevetadP2dWPKt9zw8VXrYiEqlSXuxemp44CDWzfz6c2jRLAIvtnybiqEN055xzXOeft7A/jQZM969VxTPCjWtcso+05NPEoJHrVVXz1607f2qHAuNVl2O43EAjGfep1k44IrNV8g8c09Jdo9cVm6Z1wr9GaStyPSrljfyWcjPGQCyFCSM4Bx0/KsdLrLDOAKlWdXYBTk9q5507qzO+liXCSlF6mkbtm+9Izf75zSGYEnqao7yPrQZcDnislSR0SxMnq2WjMCfpSGbDd6qCdTnmjzl55FP2ZCxDLvnEDr+FKJzjkDNUhKpPXn2p4fj0o9mWsUy6k5yBx+XSlF5k/Kyt0+7zVFZdrKQT8pBGPqK7j4lfE2Lx+LJYtOfTktnkcK0qvu37fRF6bfxzWE4yUkktDrp4iMoNuVmtl3OaW5IA6flVq2vDDMj56HONtYqSfiatJJj29qidPyOihimmnc6GK+M6klsKeCCMV1vhvxQxvGfUrqQxbVCnHAOR2A9K85SXgY6VoxXXAGefWvMrYeM1Y+twGZ1KU1JP/gnvF98br+/3qusuidPlhAz0/2f8K6Dwt8Qr/SL9rlNSkjYpsPlqGJBxx90+1fOcMhyecD616N4W1FdSaTAYbVUgsRzkmvEr4f2Sumfe5djKeMvTqxWvQ7rxB8Uft+syXzXdxvbAeRvlBIAHTGO3pWJF4n0/U9ThL3qAPIPNdwQAOASTj2rnPFVoLPS5nB3b2z+bCuIttQeKYlGIJBHWohh1Wje50YnGfUKipcqseu/Ej4qaB8O4LO30tv7Qa/ics1sd6R4YLySQc4J4+h718otA2hl2kXzfNPAXjp1z/31+lb/AMSdRmnudPDvvG1sDr3Fc54y62vXq/T6Cvq8swscPBcu73PwTizM6uOxE1N6Q2+Zh3DeZM7Y2lmJI9K3ZHEelQMRuARMisB4m2h+MYBrcu+NFi/3Er6eOh+XPV3Me4cSSFgNoPTNV5v9XIP9kmn0yb7jf7pFSyTL7Cig9BRUGQUUUUANzgmrgVFQYGCRzRBaAsS4OO2cipZAsQAOAOgpoA+XyRv+7nvUcLB7kRKcwn+HtUM05YlAcp1xilsv+PlPWjqNGl5ax8KML7UdTSucmkq2NC4461oNDLcRBByBg8nis6rqX0kC/u2w3ckZ4oKuU5le1nK52yL3U+1WI4hc2hYqHlOQC3Jp8sUV3bvISWvG5IBIH5dKhtHlimW3I285249aSsWvMh/0i1O1spnkDAqxa3Jy3muO2M9a3INOs7xCblsSKPkXeVz1/PnFYF5YXNiUFxBJAW5XeMZx1/pQp2djp9nKMVNbF0PnnrmlJzUEUgbAVg2B2qYdK6FqJC0d/wDGnlRtB70zFUVYQ8DNC8nmnllK+9NAzSuJoD1pKcF980hFIVu4lFFFAxeMHNMZetOooBq5GRSVLQelNEOAwDBoPSnAbTS07lK60IxmkJzTyue1NIwKGMaelIaWm9yKkAooooAdgYxSEYxRnBpR096AGkZ9qaRyRTz1pCCAfSqRB2njn4ly+N9NtbOSxW1WCQSBxMXLYQrjG0etcUBjmgDilx3oYJDcYq3pd4LKdnKNIGXbtTHHIqqfrinwSCNiSM5GKEAt5P8Aarh5QCgbHBx6VCVp0pLuWXgGkwSBSY7iAYoIyDR/KjOTikIaBgc0qdDSsQOO9NDAc0FCsMimgYyKcCGJpKAQoOPanbunNMHFLkmgLEh5FMJOSBS0jUrBsNAzTgMUmCDSUWBik9auaPrF94f1CK/026lsbyLPl3EDFXXIwcEe3FUsjPWlUZoJNDXPEGpeJL77bqt9cajd7AhnupC77R0GT2FZ4xjNOpMc8VIxBilxiilxnvinYQUi8U/FFIAoopabKQUmMe9JuFLRYB7gADAxTKDyMUVQmFBopM84pCADFLjmiiiwCYpcZxRT0backZppD9RlFKTkkjpSU2NBSHr70YNBGBSAM8UmaAM0oFAbDcYpQM07FFSO4m33pCOKdiinYm5GehoxyKGyTj3rQutA1GwsYb24tXitZtvlykjDbhkd++DQluBRoowR1opMQ3HWjHNPIGKShditRmKOvSnHnPNNJxT2GIDyacOaTBpVH50agLitTw48aa3aNLB58QbLoF3cdCce1ZlXNL1AabdCYoZBtKlAducj1xWdSLcWkdWFnGFaEpPRGj4zv7a/1jfbwvDtjVWDrt569PoRWDip9RvPt97NcbPL3kHbuzjgDrioainHlgolYusq9eU+40nkigc5pQnzE0EZFanDsIaUDijGPpQOTgUFASRinbqaVIPNKMA0AAOO1KKDyRSAZOKAFHWlo2kHkH8aKpALuozjnNJQelMNhHYseTmmYzmnUUDcm9WWdJ01tW1WzsY5EikupkhV5M7VLNgE4B4yeeDW/wCOfh3f+AZbOO/ntpmuVdk+yszABTjnIHXNc3a3Utjcw3NvIYbiFhJHIvVWHII+lXda8Tap4ieJtTvpr54wdhnbJXJycfWspc/MnF6dTohKj7Nqa97ozNAxS0Ad6aeG9q06HMBXOO2KXFAOaMe5o1AKbycU4nFCsAQTnrRuFxoal3VNczpMF2gjGeoqCk0lsIdnpTgM00DgU5aQxRRQeaPzoEGKUHjpTM5pQc+1BaZIM57VJGefc1CpwangG+RFXqWA/XH9aiWkWzooJSqRXdn1H4Z8Eab4I025FhJcut0FZxcOrY47YA9TXzMup3UBeJLiVI9x+UOcdfT8K9Y8YeJ/Hfg21tl1cwQRTswhwkMocoQGB25I6j06143jLE+pzXg5dSk5TqVHe5+lcT42iqdDC4WLhyLVbb2NHT7t4b+3m3Y2yqc/8Cr1T9oHwHoXg2DR5dHtmt3uZJVlLTNJu2hccE9snpXkEZG8Zx/k19W/s3aZ4A+M1trEfxg1S+vfst1bxaWYrh7ZQ0kchk3GOMjkogGSOfrXZiYyhUhUT0W58xgqsJ4arh3C83qvKx8nbgRjNOR+Tz+tJchftUwjGEDsFHoM8fpUR4r0E76nzbbi7FkSZPDHNODHPJP51URghyak83P0qtylIsCTj3p4fPc5qDcMevuKVW444NS0bRmWdxz7U9X2kHPSqu8nHP6U9Tg0uW5sqli39qcn73HsKHnLEYOPpVfeF6HNWdNktvtP+lY8raeuevbpzU+zNVWfcb5hIzk0F/8AaP50motAt2wtTmDAx169+vNQBzjrR7MPbMseYf73P1pPM6fOR+tQq3BzyaCeKl0ylVZYM3+1+lAnweD+lVt1Kp5yTUuFilWZbW4YMDuPHvUqz7jyRzVIOCetSIwYgDrWLgdVOq+jNaC54wduB04q/FJ8q8Ac96w4DnHFX4G2g5HcVx1II93DYiRsRTHPQVv6LrlxpLyywSLGxQKcqG6c+lclHKNwyBnpWrYhZQ4AGeg4PpXmVqacXdH1mAxcoVE4ux61472tohZTn5k/XB/pXj2p6iI4pbe3Znv5UPkRxfeJ/pjGea7LxX4thv8ATJLPTLpLnUEZWS3g5bKkZBBGOmfyrkNKsWlto9R1mEwalauSsrNs2xjkEgccZP1rkwlF043kejxDmkcTVVKg9bavsYEWk3lxC76ukjzI2Y/PbcyjGeOfWuEmvLrU2UySy3JRsAMc4z1x+Vdr4x8XzRX1tDpd1BPHLFhgiq/zbiMZ7cY9Kx/C/h5UuZDfQyR8KULHHfnpX1OEpyerPw/Na1Nz9nTd7bvuT6d4bunWN720dYSnVz3xxwDmq+rzRJBLaqwDRsE2YORj61t+JPE8cdnbxWdyjupAO0ZwAuO4rjJrh7iZpJDuduScYr05WWx4FxlMm/1bfQ07NMlOY247GsWBl+n0oo7CipMgooooA1ZJEQAMwH1rPuJzKdvGA3B9qJrgzEcAYqKrAQDFPikMThhgketNoqANGC581MsVDZxjpUoJrKRtrqeuDnFWTqB6BcH600x3IxqMvop/D/69TJc3BIbyxjr92runeHlvHcPOUAAPCZ6/jWle6ItjbRsJzJubbtGPT2NCjIaMrTbl5tQiRyiDntjsav3kEqXf2iGPzE2jlTxwOf51juANSx2z0/CuksTFLYGN3VASwPIHHFVFXLRHp+obxI0gSNgVXBbHvW7c3EWv7GvTHCIx8oRsZ3Hn19O1cnqVpHazIIj5qbASc5wc+tTPrbl+IQAPU/8A1qlx+87KNd004vVMpFpLSR9q/IWIBYdcGtFHUoCXQHHPzCqktx/aO1GxGEywOc57d6zpFCyMuQQDgEd6tScTDms7o3jMhA+df++hQJF/vDPpmsFGKsDjOD0qwt0Y2D7Bxz96rVS+5aqLqbBWhVzWWNYIx+6X/vunjWWGf3I/76/+tVcyK9pE0Pu04EHHJrMOrsx5hH/fZ/wpP7WIP+q/8eP+FLmQc8TUIFNI54NZv9tf9Mf/AB//AOtQdZz/AMscf8CP+FHOhc8TRoGe9Z39r/8ATIfi5/wo/tfp+6H/AH1/9ajnQc8TRorO/tf/AKZD/vr/AOtSjVsf8ssj/e/+tVc0R86NDBPSkIrP/tjp+6/8f/8ArUf2vn/ll/49/wDWo5ohzov0dqz/AO1Sf+WX/j//ANagarz/AKr/AMf/APrUc6J5kXSOaQrxVI6tk/6v/wAe/wDrUn9q/wDTP/x4/wCFLmQc6LwUUoGOKof2oS2RF/48f8KX+1D/AM8v/Hj/AIUuZBzovEZpMY6Gqf8AaZ6+T/48f8KadUz/AMs//Hv/AK1NSQc6LpBNIAelUjqmR/qv/Hj/AIUg1Mg/6vk/7R/wp86JckX8Z6Ubao/2p/0yH/fR/wAKP7UJ/wCWY/76/wDrUuePcXMjWs9LuNQLiCIybOW5AwD061XkiaJ2RhtdTgg9QaTTfFM2mM7QxRFmAB3lj0PtiqUmrNLK7mNMsxY4Y9SafPHZMfNEtk5oAyKonUT/AHB/31SjUiP+WY/76qeZBzIukZHWkxgDpiqf9pdf3Y/76o/tL/pmP++6OZDU0XCoNNIGBVUahkfcH/fVL9v/ANj/AMep8yBTRZ6dKUc5qmdQ/wBgf99Uf2hj/ln/AOPf/WpcyDmRcxyKXb07VR/tH/YH/fVKNQJPCD/vqnzIfOj1v4CeEfBnjDxBqVv431Q6XYRWge3kF8lpulLqMbmBB+XPH49q4jxrpthpHjHXbDSbj7VpVtqE8FnP5gk8yFZCI23DhsoAcjg54rnv7ROMeWp+pzTTqJ6eWv4E0OaDmRbYfKaQDNVft5P/ACz/AFpP7Qx/AB/wKlzIOZFsigDBFUzqPJ/d4/4FR/aBH8A/76o5kTzIujrTqojUD/cH/fVL/aP/AEzz/wACP+FHMg5kXKUcVS/tH/pn+p/wo/tH/pl/49/9alzBzIvjpQaoDU+eI+P97/61H9pnP+rH/fVF0HMi+KDzVH+0iekY/wC+qd/aP/TMZ/3qFJFcyLYTIzR14/pVQamR/wAsx/31Tf7R5PyD/vqnzIOZF8CgjFURqYP8A/76/wDrUp1Mkf6v/wAeo5kK6LlJjnNU/wC0if8Aln/49/8AWpP7T4/1f/j3/wBajmQXReoFUf7T/wCmf/j3/wBalGpA4+Qf99f/AFqFJD5kXSKKo/2mP7g/77/+tSjUhn7n/j3/ANanzIXMi90pKp/2gScCP/x7/wCtUguJcf6hvwJ/wqHUhHdmsYyl8KbLB9qTn0qA3Tgf6g/nSG7f/ng3/fX/ANakq1P+Yr2dRbxZYA5paqteMvWI/wDfX/1qaL9j/wAsT/31/wDWqlVhvchxknazLeaWqZvivWEj8f8A61Kl+W6Qlvo3/wBal7SFr3BRe1i3RVYXcn/Pu3/fX/1qBdS/8+zfn/8AWpe3p9y/ZT6RZOQd2a2L7xTfalottpU/km0t9nl7Y8MNowOe/U1gG5l/592/P/61IJ5e1ucfU0vb0/5h+yqfyv7iztpCPWoRPMR/x7N/31/9ammeUf8ALu3/AH1/9al7el3D2NTflf3E+KOear/apP8An3b/AL6/+tR9qk/592/P/wCtT9vTfUXs5/yv7ifb60hGO1Qfa5P+fdv++qUXMn/PBvzo9tT/AJgUJ/ysnXgD60BTuyKrm5k/54N+dKtzL/zwP50e2p/zD9nPpFljBFBGagFzKf8Al3b8/wD61L58n/Ps35//AFqPb0/5g9lUe0X9xOB6UY6nNV/tEg/5d3H4/wD1qPtMmP8AUN+dT7en3D2VT+Vk5z2pagE7gf6hvz/+tR58mP8AUN+dHtqf8w/ZT/lZMelIpwwNQG5kP/LBvzpPOk/54N+dHtqf8wvZVOzLLNuYmkwag8+T/nifzo+0v/zwb/vr/wCtT9tT/mQeyqfyss0A4Oaq/an/AOfdv++v/rUv2mQ/8sGH4/8A1qFXp9xezn2f3FuWbzcEgD6VY0bT5NZ1ey0+Eqs13OkEbSE7QzsFBJAJxzzxWWZ5D/yxP51NZ6hcWN3BcwIY54HWSN+u1gcg4IxwRnmn7en3B0qn8rPUPjP+z94p+A8mmp4mfTn/ALRaZbc6fctMP3W3cWyi4B3jHGeteZ5zXSfEH4x+MPikun/8JTqjasbDzBbl7eKIpv278lFGc7R1/rXILdPk/uj+B/8ArUKtC24uSe1mW6KrC5k/592P40G5k/592H4//Wo9vT7j9lP+Vlimg4qIXEh/5YN+Df8A1qY106f8sT+Jpe2pvqL2c1q4ssjJ70dari5c/wDLE/gf/rUG6df+WJH401Wh3DknvZlmiq63bH/lifz/APrUG5cD/Un8/wD61P2sO4ezk9bMmIxRVY3jH/ll+tJ9sb/nn+tP2kO5Fpdi1RjNVxcyHH7k/maX7S4PMJ/Op9rDuV7OfZlkUtVftbf88T+f/wBal+1tn/Un8/8A61HtYdw5J9mTkGlAINVvtbj/AJYn8Sf8KBeN/wA8v1P+FCqQ7hyyXRlkD1p3XFUjfsp/1X/j3/1qP7Rx/wAssf8AAv8A61VzJ7EN20ZeqSOTy3RgdpBGPzFZo1LJH7r/AMfpG1AMANuP+BilJppounUUJKSPoHSdYsPG95L/AMJ9cW0iwKWg33KxgZJ3bdjc5wteKuoVyQCo5IB9Khm8SyXIXdBFlSSCCR1+gqtJq7nOYU/M1wYagqEpO+j6H0WZ5vHHxgmtV16v1L6tjOa6Dwx491rwfuXSrwWiySpM4EKOSyAhTllJ4BPTjmuL/tfj/VL/AN90+LWUWRS0YIBycP7/AErrquM4tHjYbFexqqUZW8z6x/a0+EXwp+HXhfSr3wDqbalqdzqDR3Tf2oLtViMbOPkCKF+bAzz06V8t5H1rovGXxRXxbZRwDThbBJBJkShuxGPuj1rjDqmOkQ/76rlwjnyWq6HZmM8LGt/s0rxNCkznAzWeNTz/AMsh/wB90o1Ln/V/+PH/AArtujyfaI0QeOv4VKkgwAx79qyf7T4/1Y/76P8AhSjU+f8AVj/vui6LVZXPSLnSvDy+AYb6O4X+3GCbovtWTneQ37vt8oHH4965AE+tZA1fHAjU++7/AOtS/wBskAfuVP8AwOs4rl6nTUxMKjVlaxsA9cmjfngVkDWzk/uQf+BH/CgayQSRB/48f8K0uZKtHuapNArLOstj/UgEerf/AFqBrZ/54j/vr/61Fx+3j3NYDipIzn5eOKxv7cP/ADwz/wAD/wDrUq66wOfI/wDH/wD61K6LWIgups4560Y5rJ/t8/8APv8A+RP/AK1J/wAJBz/x7/8Aj/8A9apepp9Zp9zXHWpI+GB4xWKNf7/Zyf8Agf8A9anL4hOci2J/4H/9as2jWOKprqdFE+3kgHB75qdJjngrx2rlx4kxx9mP/fz/AOtUg8TBOfsx+nmf/WrB07nfDMacep2UT8jB7ZpLrW57O136d5dxcBhuRV8zA9cDp2rlU8ZBACLU/wDfz/61dD4W0lbNvti3Bb7REPkK4xuweoPNckqdtZI9GOY+2apUXa+77Gp4f0iFpIdauJZY76TzGmicqiAtlTwenUGs7xn4tmtbuXTLaGGVJ4Au7JLAsCOCDj0qp4t8UBEvNJMBYsqgTb+nQjgj+tc/pGjRXMMVxJKQd/3MDsRiro0OeXNI83H5iqUHh6Hzfct+HPD6uGmvopIpo5AY8tt6Vs6rriWTQtEEn35+6/Tp6VV1LVf7O2KI/MMgJ5OMVzCr5rY6d+leynyKyPkWxJGd+oJwe/NMwQoz0rqrTwostvFI07rvUNgIO9c7dQmG6mizkI7IPfBqGnuxIjhjDygHhSetF6sUWVDDle59qUcZ4qhqRzMvpipbsK5THSigjgUUuwgoooosIKKKM0lJDCiigUNhsLjNIOGFOoxzmoEdLpt8lpKzMrNlQAAB61EkX72SXcG354H17/nWNbXKwbtwY56YxVm2n+0OQN4AGa25r2TGiNxjVG+v9KtBscD0p4i7kHNUL0lLjuOO1K9tSr2L6S5VkxkvgD/P41ePh6Ysf3qD6A1hQ3IjXDbic9uak/tIBhzLjIzg/wD16fMmNSXURuCeQSD6irK3mAARnAxVxvEFnn5bdx/wFf8AGnwa3bzOVWF89ecUk0UismookYQqT71Yh1aNIfLEbN154q0dVjX/AJZE/itNbVEYEeR/KqugsQQ6xHCm0ws3X+7mnrrsYBzC/wCYqKO5VWUlCcEE9PWr0+txSuCsLIPQEU7oSsVv7ej/AOeL5/3hR/byf88X/wC+hUv9rR/3G/MUf2tH/wA82/MUaFaEY19M8wP/AN9ilHiCMf8ALu//AH0Kf/bEYH+rf8xSf2xH/wA8nP4rS0FoZsF6sMjMRvz7+9WRrEef9Wf++h/hVo6xFwfKb/x2lGsRZ/1R/NaNB6FddZizzE34MKYmooLky+WxX+7xV3+2Isf6k5+q1WS/QXZlKEKcnaCKNA0JW16L/ng/5iq1zqsc5XbEy4+hq82uRA/6ph/3zSHW4z0hb/x2jTuGhlm+A6IfzFS2uorHcRuyEhTkjjmrp1pAP9SfzWkfWlaIp5JGR1yP8KLINCPUdWiurlXjhdF2gYOOvPpTrPXY7aIoYHY5zwRTF1RAAChJ+opw1WMdYz+Yo0QXRKfEcIcnyJMe7CmyeIonRlEDjI7sKUazHsx5bZ+oo/tiMf8ALJvzFPQLoprqqqgHlscd8ilGrKMfum/76q2dZi/55v8A+O0f21F/cb/x2lZBoVf7YQf8sW/76H+FImsIJ1kMR+U/d3Crf9sof4G/SlGsp/zzb8xTshWRVn1yOWbf5TDgDGR/hTP7aTJAiYf8CFXTrEf/ADzb8xTG1ZMZ8tv0paD0IF15B1iY/wDAhQ2vJ/zyb8WFS/2vH/zyb9KBq8Y/gb8xRoTZFeXXElTaImHT+If4UxdXAH+rf8xV4avGMfI35il/tiPH+rb8xRZBZFBdaVc5jYn/AHhTv7fXnETf99Crv9rRE/6tv0o/tiIf8sm/MUadwsimniFAeYWP/Ah/hTv+Eijx/qH/AO+x/hVv+2o/+ebfmKDrMX/PJvzFGgWKR8Qx5OYW/wC+h/hUQ1eMys+xuc8ZFaB1iPP+rb/x2j+14/8Ank36UWQWKI1iIE/I/wCBFTR+IIkUDynP4irI1iPvE5/EUf2xF18pvzFGgyt/wkSbsiOTH1FKPEKZ/wBVJ/30Ksf2tGMYib9KQ6smM+W36UaBYaviSNcfuJP++hTh4pQE/wCjv/30P8Kb/a0f/PNvzFOGrR/3G/MUaBZFNtcjMrv5R+Y55I/woGuLn/VNj/eH+FXP7Xjz9xvzFC6wmceW36UaBZFT+31A/wBS3/fQpU8QIMfumz/vCrR1aP8A55t+lIdVQn7jfp/jRoFkRf8ACSJj/UN/30KT/hJFAP7g8/7Yqb+1Yz/A36UHVUH/ACzf8xRoFkUU1pEJzCW/4EP8KkXXUB5gY/8AAh/hVo6qg/5Zt+Ypn9qR/wDPNvzFAWRD/b6cfuW/76H+FB15c/6k/wDfQqcanH/cb8xS/wBpp/cb8xT0HoQ/2+mP9Q3/AH0KX+30zzA3/fX/ANanHUkzwrfmKX+0F/un8xRoFgXxKigD7O3/AH0KH8SoSf3Dj/gQoGoqP4D+Yo/tNd33G/MUroNCqNbQOW8ljz03Cph4hjx/x7vn/eFTf2mnXY35ig6mg/gb9KNBWREPEcSkZgf/AL6H+FPHieEY/cSf99D/AApRq0f9xvzFPGsJn/VsfxFNWGho8VRBWH2eTJBx8w9Ko2+qxpcROUchWBI4z/OtI6wneJvzWgavF0MTfpQ0n1BaFmPxfaLKhMEpAYHHy8/rXSn4tWax4Sxnz7OlcgdUiz/q2z+FIdTjxnyifwFclXDU6tuZnsYXNa+EVqbWvkdenxegQ/8AHjKR/wBdV/wqOT4q2j3SSmwlwv8ADvTn9K5E6pF/zxz+VNGqRZ/1OPxFYf2fR7na+IMY+q+5HT6p8T7S/nWUWLoVjCbSU5569P6VSh8fWiXMUjWcmEOdoK+lY/8AacYH+qP6U0ajFuP7ofjitVhKSVrnLLN8RKXM2vuN+9+IlpcxhVsZAwYHIKflSaX8QbSzuDIbSU/LtwNntWKNTi/54g/itO/tSIf8sf1FX9WgotXM3mtf2ntG1f0Oxi+L1mnWynP0ZB/SpR8Y7HA/0Gf80/wriP7Vi/55j9KT+0Y2P+r/AJVzf2fRfU9BcR4xLdfcjvofjRZQtuFhc/nH/hU5+N9mR/yDrnP/AAD/AArzaS7jbGIxgewqM3Mf/PMfkKh5dQfUpcS41dvuR6fF8cbND/yD7n/xz/CmzfG6zk/5h91/45/hXmIu4wf9Wv6UovEPWNf0oWW0e4/9Zsdtp9yO8n+Llq7EizugvbOz/CoD8WLUDi1n/EpXFfaYx/yzA/AUz7YqjGz8gKtZfSXUyfEOMfb7kd0PizaA/wDHlOfqU/wpx+LVmw50+4B+qf4V5890Gz8gz9BSfaVHHlj9KPqFLuL/AFgxi7fcj0A/FmzBOLKfn12f4VLpvxdsdPRw1lM+45ydnH04rgoLtEXBjB/L/Cpft8eOIv5f4U/qFJq1wXEOMTvp9yPRV+N9ih406c/R4x/7LQ3xvs3H/HhcA+0if4V5s2opn/VdPYf4UqahGOsOfwH+FZ/2dR7my4lxvl9yPRP+F0WecmxuCPeRP8KRvjVa/wDQPuce8qj/ANlrz1r+J1wYR+IFVZrpMqBGoAHHApf2fRXUn/WPGvqvuR6UfjXad9OuP+/y/wDxNMPxnsyP+QbNn/rqn/xNedW9+kJbMQYHHoMVZXWE6eX+oqll9HuT/rHjPL7kd4nxmssjOm3GPaRP/iKkHxjscj/iX3P/AH2n/wATXFJrsQiAMRz9Vpv9sx4/1bfpVf2dR7jXEWNXb7kdwPjRZL/zDLj/AL+J/wDE0h+NVl/0Dbj8ZF/+JrhW1eMj/VN+YqNdTQA5jOPqKP7Oo9w/1jxnl9yO+Hxos/8AoGz4/wB5P/iaQ/GeyOM6bcH/AIGn/wATXA/2rH0MZP5Uv9rRj/lmfzFL+z6PcX+sWM8vuR3o+Mthn/kG3B/7aJ/8TSn4zWePl02cf8DT/wCJrgV1SPOPL/lUi6rGoH7o/gRR/Z1F9RLiHGeX3I6bWvihDqluqJZyptYNnKensPeoNG+JVtpl0ZXs5ZRtK43KOuPXNYY1qIHmJvzH+FK2tQkY8ls/Va0WCpKPLcwed4lz59L+h2a/Gawz/wAg+fn0kT/Coz8Y7M5xp83t86f/ABNcY2rRY/1R/SoTqkZz+7P6Vn/Z9HudP+seN7r7kd4nxns1Axp0+R6SJ/8AE1ma98UbbWBBsspkMZOd0inP6Vy41SMAZiP6Uo1SH/nkf0qo4GjF6MyqZ9i6keWTVvRHT6b8S7SytUiaxmYrnLBlHemS/EeykZyLKcFiSOV4rnP7YiHSNj+IpRrMYA/dN+YqlgaO9zP+28U48ulvQ3o/iRbRyqxs5mA6jcoz/OrzfFOw2bRYTj/ga1yn9tR/88m/MUDWIh/yzP5iq+pUu4o53iYqya+4ujxpbJnbauyk5HKihvGNs8qMbWQYxwCtVP7Zix/qWP4ij+3IV/5Yt09q0+rU7WOZ5nWbvdfcdaPizYLkjTph7CRBjp7VRj+Jdmt688llKwYYCb1wKwP7eh5/ct/47Tf7bi/54t+lZLBUl1OqWd4ppLT7jcb4lWQldlsZNpY4+deB6dKlX4nWeBiykB9mX/CufGtxf88G/wDHaBrsWf8AUt+a0/qlPuSs5xK7fcb9x8SrW4hMYs5BnHO9f8KZY/Ee1tY2VrOU5OeGWsX+3Iscwn81pjaxCT/qT+a1awtNdTN5viG76fcXLnxnayXEjpayAMxbBK8VmS+II5Lh38pwGOccVMdXiB/1Z/NaUavFx+7b8xXQoxirJnm1K0qjvIrf8JCmf9TJ+Yp3/CSKD/qZP++hUx1OM5/dv/30KY+oxnpG35inoYojPiVSf9S//fQpp8Qr/wA8H/76H+FSDUowR8h4PqKl/taMH/Vt/wB9Cmkg1Kv9vpn/AFD/APfQ/wAKP+EgT/ni/wCYP9Ktf2vGesTf99Ck/tSP+435ijQViuviCP8A54t/47/hTx4hj/54uT9R/hU41aPP+rb81pTqif8APN/zFGgWIB4hTtbyfmP8KX/hIkP/AC7v/wB9CpG1OPA+RvzFH9qRg58tj+IpaCsRjxHFn/j3b/vof4U0+IY2/wCWD/mP8KtNrMeP9U/5ikGsxn/lm3/fQp6DKM+rxz4xE4x9Kkj1qNUVfKckDrkVa/tiPp5bZ+opf7Yjz/q2/MUWXcehANeQdInz/vj/AAqb/hJIh/ywk/76FP8A7Zj6eW35ik/tmMf8s3/MUaICG68QR3Fu8YhkXdxu3A96isdcitY2VoWfcc9QO1Wm1iMgfum/HFN/taP/AJ5t+Yp6D0G/8JLEJMiCTH90OKefFCNjELj/AIGP8KBq8Y/5ZP8AmKP7YjB/1TfmKegyRfFkS4JgZv8AgY/wqZPGUIcH7LJj2df8Krf23GP+WT/mKX+2485MLH8RTTXcm3mW7jxrby2ssf2SbLLgNuU46VRh8QwqrExS+3T/ABqf+3oAmDbvyMfw1H/bMPGInH0IqW/MVkM/4SWErgwzZ45yKSXxHDJEyiCYEggEkdam/tuMf8spP0o/t5B0ib8xRp3CyMO8ulnRQFYEHPI9qp7mA4JH411Q11OP3LfmKVtdiPWBj+I/wqXFMabWzOcsnEVykz/OFOSDznithSt2puMbSv8ACMdsVWmu1OoC4ER2Fg2w46Y6Ut3epcTh0TYuAMDFCSRNw1S+W+kjIVhtBHOO9U1mELZIJyMcc1LNIJMHAGKjI9hRcgv33iWKW0iiVZFI4I4GMCstF824kuc580lsY55OakYLj7in8KrtJ5pa3UbT6gUnLuKxDOzS3RRWxn1OKGsJc8sP1qbAB8gsTIR1xxmq86tC4TeTxnqajRjIpEKYB5+lMpTk980mKa2FoFFFKBzRewbjh1pKKKxQ+oi05utFFMTEooopoQ1v8at6Z/rJf92iin1AtP1NUZ/9af8Adoopy2G9iNvuikP3hRRU9CWNPWnw/wCsb/dooqUUic9RTJOoooqihnr9DTT1/GiimgF9KXvRRSGHaloooEN/iFPXrRRTGJTT1/EUUUgEqZKKKAFaon+4aKKoBnYUfxUUUhDl60q9KKKQC0DrRRQMVelSUUUwEbrTP4aKKAI6fRRSEOHaloooGNHWmHrRRQISn0UUAS0xqKKYyKTrSjqv1oooEh/+NOb7lFFIZDT6KKAH0DtRRQA09BQvWiigAalHSiigCQ9adRRVAR/xUlFFSAn8Rp9FFABTT1NFFIBlFFFWBIvWnDrRRSEhKgPWiikAD71OP3KKKpbDWzEbpR/FRRSEIetDd6KKBoPWhetFFPqg6ID1pv8AEKKKkQ/tTu9FFNAH8VOHWiimjLqL/FTT0oooNRjU09KKKkljx0H0p9FFNl9Q7NTW60UUwGrSSdPxoopCEj+6KkHWiikiA/xoWiirQ2DUHvRRQUA+9SUUUhiDt9KUdKKKAQ1utJRRQhdB3YUev1oooM0N9KKKKlFID0o9KKKBPdDaKKKDRBS/4UUVYdR46mloopBHYU9ab3oooIQN0oXrRRSRfUY3WkHWiikR1Qq9Ke3U0UUFIae/0pp6NRRTQxR0NJRRSAVetPPSiimAh60w96KKQhV6U5utFFACU+iigYH734Uo6miimgFPam0UUwGU7+IUUUAIOtPXrRRUoQo70elFFAPYiqUdKKKBjewpD0ooqhDe3/AqevT8DRRSAevUUx+9FFBPUjbpTof9Z+B/kKKKkoWX/Xfj/QUs3+sH+7RRVdCBlFFFMBG60etFFZsaP//Z') no-repeat center center;
        background-size: cover;
    }

    * {
        /* Prevent unwanted hover color changes */
        -webkit-tap-highlight-color: transparent;
    }

    body, div, span, button, input, label {
        font-family: 'Asimovian', sans-serif;
        /* Maintain colors on hover */
        transition: none;
    }
        
    /* Dark theme for title bar */
    header {
        background: linear-gradient(90deg, #c51c1e 0%, #210b08 100%);
        color: white;
        border: none;
        box-shadow: 0 2px 10px rgba(197, 28, 30, 0.3);
        cursor: move; /* Show drag cursor when hovering over title bar */
        user-select: none; /* Prevent text selection in title bar */
    }

    header h1 {
        font-size: 14px;
        font-weight: bold; /* Use 'bold' instead of numeric value */
        font-family: 'Macondo Swash Caps', cursive;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: move; /* Ensure drag cursor on title text too */
        user-select: none; /* Prevent text selection on title text */
    }

    header h1::before {
        content: '';
    }

    /* Main content area */
    .main {
        background: #030908 url('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAGBBVADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8sutFIOenWrMlsI4UIJLHt2rqSuOxAAaWpLeHzX2nI4zxRcReRMyDPy9zTtYLETHmkooqhBjNWLW2WV8OGxjPAptnALhiCSAP7tTteGH92FGF45oS7lIk+wQn+9/31S/2dCf73/fX/wBao4rwyTKuxQGOCeeKvAZFUuUpJFYadDj+P8//AK1J/Z0Oed+PZv8A61XEHHA9q0rDSRfRSM7vEVIAG3OeM5osi1G5jXGiRwqGKyJk4Gen8qg/suPuX/Our8S6ob2xgjeIKVk3cNnPymuftoftUpjOEGM5z/jSshyjFOyKq6XGc4Y/99D/AAoOlR/3j+f/ANatI6SRn96p/H/69H9lesg/z+NHKhcqM0aVF/eP5/8A1qBpMRH3j+f/ANatE6Vu6SD8v/r0g0cjP7wfl/8AXp8qDlM8aRGerH8//rUv9kxf3j+f/wBar40f/poPy/8Ar0f2OP8AnoPy/wDr0rC5TP8A7KiH8X6//Wo/suPpk/n/APWrQGjZz+8H/fP/ANel/sYf89QP+A//AF6LIOUzxpMXqf8AvqlGlRf3j/31/wDWq/8A2MP+ev8A47/9el/sXn/W/wDjv/16dkHKZ/8AZUXdm/76o/siH+8fzrR/sMkH94f++f8A69SL4aLqD52M/wCz/wDXoUQ5fIyv7Ii9T/31/wDWpDpEYzyf++v/AK1ax8LHP+u/8h//AF6Q+Fj/AM9h/wB+/wD69HKLlMr+yIsdT/31/wDWo/smL+8fzH+Fan/CLN/z3H/fv/69OHhj/pv/AOQ//r0+VDsuxlf2REP4j+Y/wo/siL1P/fX/ANatX/hGP+nj/wAc/wDsqD4Y/wCnj/xz/wCvS5Qt5GT/AGTF/eP5/wD1qBpMWfvH8xWt/wAIzx/x8D/vj/7KkPhnqPtH/jn/ANejlFYyxo8X94/99Cl/seL+8f8AvqtMeGc/8vAz/uD/AOKo/wCEZH/Px/45/wDXo5fIFEzDo0R/iP8A31/9aj+xov7x/wC+v/rVpDwyD/y8f+OD/wCKoPhZSf8Aj4/8c/8AsqOXyHbyM0aNF/eP/fX/ANalGjRc5Y8f7X/1q0D4WH/PwP8Avj/7Kk/4RcdPtA/74/8AsqdvInlM8aNERwzfmP8ACj+x4v7x/wC+v/rVf/4Rhf8An4H/AHwP/iqD4aA/5eB/3wP/AIqly+RVjP8A7Iix94/n/wDWpP7Ii/vn8x/hWj/wjQ/5+B/3x/8AXpB4azx9oH/fA/8AiqOXyCxQGjxf3z+Ypf7Hi/vH8/8A61aH/CMf9PI/74H/AMVQfDGP+Xgf98f/AF6OXyEl5Gd/ZEX94/8AfQ/woOkRf3//AB7/AOtV/wD4RjP/AC8D/v2P/iqD4XwP+Pgf98f/AGVHL5BbyKH9jRY++fz/APrUf2PDn75/P/61Xh4XP/Pcf98f/ZU9PDBA/wCPhef9j/7KhR8hW8jO/siH++c/X/61J/ZEX98/99f/AFq1D4ZJbP2kD/gH/wBem/8ACM5P/Hyuf9z/AOvRy+Q0jO/seE4+c/if/rUv9jwj+M/99D/CtIeF8j/j5X/v3/8AXpv/AAi3J/0kH/tn/wDZUcvkOyM7+x4j/Ef++v8A61KNFi/vH/vr/wCtWh/wjGf+Xgf98f8A2VH/AAjA/wCe4/74/wDr0cvkCRQGixf32/76/wDrUDRYf7zf99f/AFq0B4XBH/Hx/wCQ/wD7Kj/hFsdLj/yH/wDZUcvkFjO/saH+8f8Avr/61J/Y8I/jP/fQ/wAKv/8ACKnn/SR/37/+ypf+EUJ/5eR/3x/9lRyeQvkZ/wDZEJ/jP5j/AAoGkQ/3z/30P8K0R4Sx1uR/37/+ypD4V2n/AI+h/wB+/wD69Pl8gSv0KH9jw/3/ANf/AK1H9jw/3j/31/8AWq8PC2R/x8j/AL9//Xpw8Lf9PI/79/8A16LeQrW6GcNIhJ++f++v/rUHSIf75/P/AOtWmPCX/TyP+/f/ANlSHwsF/wCXkf8AfH/2VLlHbyM0aREf4/1H+FC6RDk/P+o/wrR/4RkdPtI/79//AGVIfCwyT9qHP/TP/wCyo5Q5TOOkRf3z/wB9f/WpRo8R/iP/AH1/9ar3/CLLn/j5B/7Z/wD2VL/wiw6C5/8AHP8A69HL5DsUP7Hh/vH/AL6/+tQdHi/vn8//AK1Xx4Uyf+Pkf9+//r07/hFQv/Lxn/tn/wDXo5fIVjN/siLP3z+f/wBak/smIfxn8/8A61af/CMYI/0gZ/65/wD16b/wi+f+Xgf9+x/8VS5fIXKZ40iL+835/wD1qT+yYv7x/Mf4Vpf8Itk/8fA/79//AF6QeF8H/j5/8h//AF6OXyDlM86REP4z+YpP7Ji/vn8x/hWl/wAItz/x8f8AkP8A+vQfCv8A08/+Q/8A69Plv0GZo0mLu5/MU7+yIuz/AKj/AArRHhTjm6/8h/8A2VOHhME8XQH/AGz/APsqOXyC3kZo0eL+/wDr/wDWpf7HhP8AGfz/APrVpDwoB/y8j/v3/wDZUf8ACKD/AJ+h/wB+/wD7KjlHZdjKOkxAn5j7c0n9kxf3j+f/ANatX/hFgTgXQGP9j/7KnDwuRx9p/wDHP/r0+UVl2MkaVFjhj+f/ANak/sqIfxH8/wD61bX/AAi3rc4/7Z//AGVIfC4/5+f/ACH/APZUuUdl2MX+yov75/Mf4Uf2XF/fP6f4VsHwwB/y8/8AkP8A+vSHw1/08f8Ajn/16fIgsuxkDS4/7x/P/wCtSjSo8fe/X/61av8AwjnPM/8A45/9elHhzI/1/wD45/8AXpcoW8jK/smL+8fz/wDrUn9lRZ+/+ta3/CN/9PH/AI4P8aX/AIRof8/H/jg/xo5Q5UZP9lRf3v1/+tQNKiz94/n/APWrVHhoEf8AHzj/ALZ//ZU4eGV/5+f/ABwf/FU+UXKZX9kxYzuP5/8A1qb/AGTDn7/6/wD1q2P+EYBX/j5x/wAAH+NA8MZ6XGP+2f8A9elyjsY40uE/x5/H/wCtR/ZURP3sfiP8K2R4Vyf+PoD/AIB/9lSnwqACTdD/AL9//ZU+UXKYn9kxf3z+f/1qQ6TF/eP51t/8IupH/H3j/tl/9lTW8LgdLoH/ALZ//ZUcq7D5fIx/7Kizjcfz/wDrUf2TF/eP5itj/hFz/wA/Q/74/wDsqQ+FyRxdAf8AAP8A7Klyhy+RjnSov7x/P/61H9lRZ+8fz/8ArVr/APCMHj/SR/3x/wDZU4eGiD/x8j/vj/7KnyoOXyMf+yoh/Efz/wDrUg0uL+8fz/8ArVtf8I2f+fkf98f/AGVH/COc/wDHwP8Avj/69PlQ+XyMYaTF/eP5/wD1qd/ZEX94/n/9atf/AIRwnrcD/vj/AOvSjwzj/l5H/fH/ANlS5ULl8jH/ALHi7sfz/wDrUv8AZEX98/mP8K1W8Lgn/j5A/wCAf/ZUn/CLD/n5/wDHP/sqXKhcvkZX9kRf3j+Y/wAKP7Ih/vH8xWp/wi4H/LwD/wAA/wDsqQ+GM/8ALx/45/8AXp8o7Gb/AGRD/eP/AH0KP7Hh/vH/AL6/+tWifC4/5+R/3wP/AIqk/wCEWB/5eR/3wP8A4qly+QcvkZ39jwj+M/8AfQoGkQn+M/8AfQrRHhUEc3I/74H/AMVR/wAIqCP+PkD/AIAP/iqOXyDl8jP/ALHh/vn/AL6FIdHiH8Z/P/61aR8JD/n6H/fsf/FUn/CJf9PQ/wC/Y/8AiqXL5Ct5GaNHh/vn/vr/AOtS/wBkQ/3z+f8A9atH/hFB/wA/QH/bP/7Kj/hEx/z8j/vj/wCyp8vkFvIzv7HiP8Zx9R/hSf2PF/fP5/8A1q0x4W7fah/37/8AsqP+EXx/y8r/AN+//sqOXyC3kZv9jxDq5/76/wDrUv8AY8WOHI/4F/8AWq+fC3/Tyv8A3x/9lTf+EXx1uB/3x/8AZU+XyHbyKf8AY8R/jP5j/CkGjRZ+8fzH+FXj4aXHE/8A47/9ek/4Rsf8/H/jn/2VLl8hW8iidGhH8bfn/wDWpP7IiH8R/Mf4VoDwyDnNx/44P/iqcPDK/wDPx/45/wDXo5fILeRm/wBkRH+M/mKUaNF/fJ/H/wCtWh/wjQ/5+P8Axz/69OHhsf8APx/45/8AXo5fIdjNOjxf3z/31/8AWo/seL1P/fQrT/4Rof8APx/45/8AXpf+EZH/AD8D/vj/AOvRy+QWRl/2PF/e5/3h/hR/Y0f94/mP8K0/+EZx/wAt/wDxz/69KPDX/Tf/AMc/+vRy+QWRlf2RF/eP50v9kRep/wC+v/rVq/8ACMg/8vH/AI5/9lR/wjXfz/8Axz/69HL5BYyxpERH3j+Y/wAKP7Ih/vH8/wD61an/AAjX/Tb/AMc/+vSHw1n/AJb/APjn/wBejlCxlnSIv7x/P/61INIi/vH/AL6/+tWoPDX/AE8D/vj/AOypf+Ea/wCngf8AfH/16OVBymX/AGPD/fb8/wD61N/smHGd5/P/AOtWwvhnI4uP/HP/AK9KPDWB/wAfH/jn/wBejlQcqMb+yYgfvH8//rUh0qIDO4/n/wDWrZPhon/l4H/fH/16B4bwP9eP++P/AK9HKLlMcaXF/eb8/wD61J/ZcP8AeP5//WrdXw6MDNxn/gA/xpJPDCSYzc4/4AP8afKPl8jE/syH+8fXr/8AWo/suI9z+f8A9attfDQCgG5Bx/0z/wDsqT/hHP8Ap4H/AHx/9elyhYxv7Ki/vH8//rUn9kxf3j+f/wBatoeHCf8Al4H/AHx/9lTv+EbB/wCXn/xwf40cqFymJ/ZMX94/n/8AWo/sqL1P5itv/hGF/wCfn/xz/wCvSHw0o/5ef/If/wBejlDlMUaRET94/n/9al/siHPLN+Y/wrY/4Rtf+fr/AMc/+ypB4dUf8vI/75H/AMVT5UHKZI0iHjLP+Y/wpDpEI7t+Y/wrXPh8ADFyM/7v/wBelj8PCQkfaBx/s/8A16XKh8phtpUQ/if8x/hSDS48Dlvz/wDrVvnwsDz9o/8AIf8A9eob7RBZ2qsJt53AbdmOKOQOUwPsH+kBMNs/vfhU402MfxN+lb1rfvPDFYhVCsmwvnJH4VW1CwOnSxoZA+9d2QMe3SoUbaMbhpdGV/ZseOrEfX/61B06L1P/AH1Vh8lGx6VBp+kPqHmkEqIyASFJ6/8A6qfKtkZ9SF7BM4XP/fQqq8ZQnjgGtyLw1k5afaAf7lQXNiEke3352nrik4sOUyRRUk0PkuVznHemVmRYKKKKdwCiiii4EttIInJYEj2q1ckeQjjoen5VQBqxLOjwIgPzDGR+Fap2Vir2GxTeW+/bu4ps8vmzM/TPao8ndzVy1VWhGVBPPap3Gin19qbznFWmUfbI1wACRxV0QxDrGv5UrMVhVG0ggc1s6XoTQuZZZIpVkUkKBkjv3FYAbyOZGzk9etadhr8ULjzJG2qMBQpPp2raNuoxuq6YIL15VxjdkKowB0qGFvPnWJB8xJ5P+fatAajDqt+I48sZCANy47d+tWbfSzZXRu3VNiB2KqcnpQ7dDWEG9ehFb6RLgMzLgfNhcnGOabq2prqjRuiumwEfMfp0xUWo6iLyWNrcyRKBs5O3qeOlV5wtggE3zFuRtGfSpG3Z2RWuZGgj3MN3OPSqck3nYwuD9c1csdLk1m7lSDaMAyYY4yB2HvzXaWmmxxWcKPFGZFQBsqDzXLUrKLsenhMvqYq72Xc5K18PzXVtHMJI1VxnBBzUx8OSqP8AWx/rXV/ZlRQqAKoHAUYxTHiAUisVWZ7ayqko67nLf2DJniRP1oOhS5x5kf610XkEU1osGtlUfc55ZdBdDnjoco/5aJ+tJ/Yr/wB9PyNb5T2rU8O+DdV8WyTppVobt4FV5AHVdik4ByxAOa057dTD6jG9kjjP7Hf/AJ6L+Rpf7IYf8tF/I10GqaXc6NqNzY3kRgu7dzFLESCUYdRkcfzqqV9qpSvqmZPCRWjMn+yX/wCei/kaT+yn/wCei/ka1tuaXyzTuR9VgY7aXIOki/rXcD4PXqeAh4oOo2htzCJvICvv+/sx0xnNc8I8kd69J8I+JrnxRY6Z4HuY7a30yYiB7kMUkChi+dzNtzkenPSuTEVKkEpU+m/oezluCwtWUoV92vd9TyUaZJ/fX9aedKlH/LRf1r234jfs+ax4R02TX9K07UbzwrBZx3M2sTGNoNzyiMKrrgN8zIMDJ5NeVmP6VvSrqrHmizlr5csPN05rVGIdLl/vr+Zpp0yT++v61tiFmRmOBiomiNbqRyPCRSvYxjpcmf8AWL+tIbCQE/OP1rVZTnmo2QHPrTTOeVCKM37E/wDfH5GkNi5/jH5GtAoR2IppBHHeqMvZIzzZuD94fkaT7K3Tev61ecHNMZCD0osR7NFP7O/98fkaQ27f3h+Rq2U9RimleelCRLgit5DD+IfkaPJY/wAYqcpz60EFetNJE8liAwt/fBpfIb++v5GpRSnJ7U7InlIDC395fyNAib+8KmwaCDntTsOxF5Lf3h+VAhb+8PyqQU7PSiyBkJhfOdy/lSeS3qtTk5ppJJ68UrILIgNux7r+VHkn1FTknAPaosnFOyCwnkN1yKUQn1/Snh+eeleu/Ar9mDx1+0bHrDeCrWyujpMkCXgvLxbfYJhIUYbhyv7pgccjI4oskrsTsjx8Qnsf0pfJJ6N/Op5ojBM8bfeRipweMg4696bS5ULcj8k+o/Kjyjj7w/I1ICPWnEA07IZF5bDuPypDGxH3h+RqU4xSDA470+VDRGYSe4/Kk8o5+8KmPGKAMkDqTxTsFkReUR/EKPKIP3gPzrQvNIu9OjR7iExq/CncDn8qp9aTihbDPIOPvCk8s+tSc4ooshjAh9aURnHX9KdmkyM4zSYxuwnvSFPcVJSZosAzyz7UoT3pwyT04pM0WANp/GmmMnvUi8g9qNposKxF5Tf3hTTCxP3h+VTkYoA4osJxsV/Ib+8KXym9anOc00g4p2QJIjERPO4UvlH1FOTI64pw60cqDlRH5LZ6igRkHlhTySTwaQ55zRyodhpi9x+VJsOOtSnpTB0qWgsN2e4pNuO9SHoaTIIpBZDMU7yz2IpcCnKcCmgsM8pvUflTdjeoqbPNIfmHFFhWI/LJ70vlmnfd4JoL496LAJ5Z9aBGc9afuoBzTsA3afWjafWnE4xSZwM0WKsJjFAFKBu5pQQDiixI3HtTwdpB4oppPaiwyTzVP8NIZFP8NNRC7hR1PAr1L42fs0+Nv2f7bRZvGFvY2w1d50tBaXizlvJEZdjjoP3i479eKVlswvZ2PL/MA/hoMyj+Gox0oIzVcqGmyT7Qv939aPtA/un/AL6/+tURHFN55osguyfzx/dP5/8A1qQygjp+tQ/zpcZosguyXzR6f+PU4Sg9B+tQg4py0WQx5JOO1NIPtTunekPNKyEIBjpzRjmloosA0jJowadSA8mlYBmOMUcilJ5op2ATNBOec0GhT69KdkAcn0ox9KPpTumMnFHKgEEW7oRR9nJ/iH5U9WGOKcORT5UIh8hsfeH5UGE4zuFTUYosgsQ+TnuPyo+zn+8PyqYDFFCihWIDbt/eo+zt/eX8qnop8qAh+zn+8v5UnkN6j8qsY/OkPFPlQiDyG/vCjyG9R+VWM4pOvNLlQEHkNj7w/KkMDf3h+VWBxSHGaXKhohELY+8PyNKIW/vD8jUvAozSsgRGYWz95fyoELf3h+tS559qAefanZBa5D5Ddd9OWMjHNSnp1ox0o5UCViPyz60eWfWpe3FJjgetLlQrkfkkgc0nkHnn+dTDgAUhJH5U+VFX6kPkn1pRCT3qQZIznFLjpzk96dkNakflf7VJ5PvUo70lLlQ+VbkXle4pfKPrUowSBQVxz2p8qCyRF5ZHegRE96l/lQcY6c0cqEkQmHP8Q/Kk8hiOCPyqYHNHbNHKgSIfIPHIo8k+oqXcPelBzRyofKiOB/skwkbLL0IA71sC6Bs45sHDHhe5rKKhsZAP1pLZ/s8mZWYwc4XO4D8KTVjOUbFqWNizXYA2KN209enpVmx1G2aFoSrb3BX7vr071QZjua4DN9lLcKD2/wB2llQzRG6iIRAB8uMHIrFq5KfKR39k9htViHLLnK5xW78N4YZRqnnRrJt8rG4f71ZFrdwnd9qJck4XcN2KhVb3QH+Scp5vJ8lyM49fzpRdmrkSjfVHS3c2AUA6ZHc965m7GdSnP+0f5Vf1DVbe4tIkhfM2/c7AYzxzz9aymbcSScseTmtJu5KdtBlxCssbKAAx6Ej3qjLZPGhYsuBzx/8AqrQB6Ckcja2eRjmsXFMlox6Kmu2RmUxgY+mKhrJkMKKVVLnAqT7O6oWI49aLBYiooorW4hKuwkrZsRwQDVOpg7i2Kj7nNIBlu5e6jLHJ3AZrRHfNU7QRALIxw4ORlsVd8+LH31/OlEpK4jRrL94Zx0zSw2SyOVEYPelV1kzsYE+x6Vq3KW1rZLJDgXBxn5s1em5pGN9WJptvb2VzHLKixhSSH5ODg46U3VdQa6u3S3nbyGA2rnA6DNVBcyXPynL9wAPSkk8uGDe0mycHgZ5H4YPrQa89lyolhEFsAZ2Xk7lKg0/TdI1LxQzmBPPEOM5ZVwD9evSjTdF1PxFd/wCiWd1fRRsA5hiZgoPPOBweDX0X4e+D9pbzvBosgjM7/N5rNIFCjI5A98d68nGY2GHXLfVn1mRcPV81m58vuR3Z5hY+HINMRPLtlin2APg5IPGR1IqZrJ2DbEOPWuu8Q+H5NE1m5sZnWV4G2F04DcA9x71kNCqAjrXjRxDl7x+kSyyNBezirJGELR3AwpqB4AGII6VutCBgbcVVnsh1UZYnPWuqNW7POng2loY/kD+7+tNNpk5H6HNahsnOBtH50q2jZ5UY9yK2VY45YVvoYzQcEd61/C3irUvB09xNp/kh50Eb+bHvGA2eOnOagksnBOBx7c1A0BBPyt/3zW6qJqxwyw8oO60INXuZ9Z1W7v5wnn3MrSuEG0bicnArPaBlGWGBWo1ucfdOfpUT2+Ryv4E1vGp0OGphW9TO20FDV4QgE8D880pgRhyAPpWntDm+rsppA3sBU0cA4BGQexFTrEoUDt9amjiG7p0qXO+5tToNH2t4a1ey+Mv7J2kfBvwXcw618RHsLR20zDW6xxxXQnnJmlCx5VcAgNz2zXyH8Rfh3rXww8Y6j4Y8QQxW+saeyLcRQTpMqFo1cDepIPDrn8RW58LPiPffCnxZH4g01p0u47W4tUa2dUdRKmwsGZWAI+ldVd+BPEvxzn1rx7FGlvaTPcTXM93ceYd8MAd14BdmIXrjGTXIqsaL12O+OCnWbktfI4XwZeeG9O067GtWwuLl5Mxk2/mbV2jvnjmuMlQeYSowOfwrTNuzqOdpODgnkVDNZso7dq2ptKTknuTXhN01TcdjKaHLZNQeX7YrUktjkZXj61UlgAY8Y5rujM8KpQaKZUjqOaa0eTnPNWjFz0yaaVGcVspHG6bRWWIkcEAe5qLYQxzVzYPSoioJ461aMHBldlz17U0pxxVjZzSMnPQYpmTg9yts496aVwOlWQDzUZjwKCHEgZNwGMU3GPrU5jJJ700oy4yMULQzcWRcU0VKF5z1prR556U7k2I8fN7UuKUA49qAfWqJFApCKWgjikJGvpnhWfVdKnv4poUihLBkkJ3cDJxx6ViEBhkdKu22qXlpbPbw3UsUD53xI+FOevFVdtUMiC9ea7n4bfG3x18H0v18G+J7/wAOrfmN7oWUgXzjHu2bsjnG9/zNcSRjtSHNITVySaZ7meSaRt0jsWZj3J6009KZRmhhYeFB+tLtpit14pd+f/1UIYtJu59qQjilUbiFHWquA4EGgcNkeveh42iOGGKTt7UAXL/VbnUVRZ3DBOQAuMdKqDrSjoKQ9etQITpRRmigYYzit638I+f4ck1f7Twqs3leX6HGM/gawSMinLK6qVDsFIxtDHFUmluA2k2knOKdjB9aUdKhjSG5BFOAxRt46UoHamh2Ep5TABHNIABUsTAA59Mn6UMcY3ZAQQOlITkV0Nj4ej1fShLBIVucjIJ+UHPQ/hio9R8K+Q9vDBPumfhhJwM8dhyBz3rlWIhflbPUlluIUFUS0ZgE89fcUvWu5l0my8L6BIty5kuLlSFYR5+fb0GeQOa4g98cVdKsqjdkYYvBvC8qk9Xqxp+WkPOM0rcgc0gzXRc88Bj1oJxTWPB5puadwHHkUmMDrzQOlBosAuaQ9KaARzTs5BqbAIFzk0BuKUcDtSNyRRYBc/jQeKVO9OIzRYCKlHFKV5oPSgBQc9/wpOmcULyeOtaVrpIntBMZQuc8Y6fWk3bc1p03VdoozQeP8aWjGe1JgUzHqKDxSjGKQU7rQMQdKTPNFFAkAJUgg4INdd44+LnjH4mQWUHivxJqPiCOxaSS2GoTGXymkChyueRkIvHsK5EHmjrTDQBRRSZFVcLC00jk06gnigENIxSg0h60A4I9qBisCaAdpNKDkUhxmgSHKc5p1MXAp1SMWiiikAU0jvTqKAGAA/WjFOpaAGECjAxTsCkJ5xVgNBCnmnGmgYozjigBykEGnKx/pTW5oDYFAEh4GabuNJml3ZGBmgB1FIDxS00JigZpccCkBxQWp3JFHApDyMZpQc9aOvShgJtyOKQcU7HPtS5pXAZj8qMAmlPNGM0DE2jPWjgcUpBFKRSENo7cUpApAc+1BQUc+tFKBg00DAdAKd1pD1FIMDvSJbQp4+tA6UhOTSUE3YpOenSgdqSinctMCM9qXGeKSlB54o6lCDIPNKaRsmlHFNMbEopRz04ox0ouISl28Zp4GRRjHFAbEWRS04jHHWkAplXEpGVWGGwR70/BGaYeTQG4xZTDIFlP+i/3DyPXp9amHaVQPsePmUHj34qNlV+qg/WmpI8WI2IW1zyCOP8AGsmjKUbakk9v5zB7dQYwOe3P0NPtZ4bt2+3yfKv3M5GM9f5UrttcC0BMY+/s5/n7VFdW8RCfZgX652nOKxaM0+VjLywltG3vEywOSEYnIYdarj19a6LQ92uySwX7vNFCgZFzjB6dR7etU9Y0G50+SeQWrpZhyEcnI29qzUrOzNZ0G4+0itDKJAGewpGO6GTvlTTo1DEbuneiZVjVwgwu09DntWhyGQ5yRSUMTvpURnPAJPWsNyCeBPLYNIpVR3NSzzxvGQrAnjgUuwPGFPb0qnMoSQgZwDxWi0VhsbRRRQIKtKP9Cb6H+dVatKP9CahjRSwTgDrTxG2O+PpTrfPnJ25rQQ5Bzz6VMUNIu+F9OS7W6LMV27cED60l6Au9AchWxmtHw0oH2v8A4Af51QfmaQ9fmPP40R3sdrjFU423KcNwbWRZVAZhkAGuj+HfhqH4jfErw/oV5cvYwapexWslxCoZogxxuAJwce9YEgEh24JPUcV0/wAImFv8UtAMheMJeI/C5I49DWdebp03JdC8HQ+sYmnR/maR+lXwL/Yi8JeF/DOs2cHi6/vL3UZoXimmtokNvsVgRtDHdkuec9hxWL8Yfga3wb17SEOqyait3FK6SMixNHt2qRxnrury2z1tJLu2OZgqSRyE5CthWBOMHrgeuK+3Zf29PBckarL4U1uTbgZ22xH6y18L7Sli+Z1Wos/oB4HOOHZ0oYCDq0mtV2Pz68T+Hra/1m/uriZ97yt91hggAY7Vx974bKXL+Wk4t93DYB4+pr9cvhf8V/Dnx90zWTpXh65sBZ7YS9/FEQzOhIxsZunGc+tfCnx0/Z+u/g9fadY6hrFvqE19bzXAa3gMSx7CB/ExznIPaidKVGCqQlzRPQy7OKGZYiWCxlH2VVdG9z5YlTEjBclQSBkdq9O8AfAn/hOvBr+IpNcSwiS4mtzbCyMrkxqrE7t6jncOO3vXEaxoR0q5VGuA5cFuAOOcVf8ADmtaxp8kVhY63d2VtNLhooLlkTLYDEqDjJA59hV+291NMKuX1faciVjkAuOMfhU9pafabyCD7vmSKhOM4yQM4/GvT9R8CxaGI5RHHIHfaMx7cD17jt7fSoU0coylVQYORtVeCOhrKWM00PWpcPylrOSMP4hfDBfBVjZzi/N61zM8ezyQu0KM56mvPngAzlcDPWvdtXtLpbS28+/luDIC2HbOzgev1rktS8ILe/OZm3Z3DGD2Haijj2vdmGL4d5lz0d+x5dJagliFz6f5xVdrb/YGfp/9auov9Be2maLLTSB9vyrxgcZ4rMaxkQEuhQdOeD/KvYp4hS1TPiMTls6TakjFNv14HvSGLJyCOPetRrUgcA5pn2QqOg/KutVkePLBvojPWE8cinCHHPFaIteB0z9KkW0I6EY754p+2Q4YJt2KUVtuPYmvW/h98ddX+H/gO88J2Wl6Zc6fdm4Mstyshkbzl2sDtYDgdBj8685t7EyzIuQcnHNbcXhi5mfC+UeeAHJ/pXBXqxkkpHvYLL6u8I3PSPBGhaVc/CvU5pdNsJrqGC8KTSwRmUYj+Q5IzkHkV4lPZ5XiNu3OK+tfgZ4f8J6t8Odc8F6x4aWbxvq872mm65LArRWyyxokR3lt2VYOxCqTgjn08r+L/wACNW+EPik6Fqt7aXcxt0uRNZFzEyMWA5ZQc/Ke1c9OTpXnzXTNKiWKqLDSp8skvvt1PEXsw43FWAHtVGa1yAFU56/54ro54AoIyccgc1Rlg7gEAV60K7Z8/icAo9DBa3Ck7kOeveoHhP3vWtqS1DNnPP1qlLAQxBxjNd0K12fOV8Ly9DOZWXjjH0qHaOK0Gi47Z+tR/Z/c/wCfwrrjUPKnQZSwfrSOjEg4q2Y8EimlOD1rVTOd0mUyvqKYy9atMgOOM0xgApFWpGLp23KpTH+NMZc9asEY45pjL14qkYONiApn6UhXGe4zjNaGjyW9tq9pNeIXtY5VaVVUPlR1GDwePWtfxzqujazqNvLolmbG3WAJJF5Cx5fcTnAJB4IFO5m4XVzlj0qIrg1O0ZAPPFPsvKXULb7R/wAe4lXzf93PzfpTuYtWKvbPaitfXzp5uEGnbfJwc4BHOSe/NZJGKq5m1YSiiiglhTWICk9acelMoBHceL/hmPC3hHTtcGpfaftvk7YDAF2h0Zid249NuOneuEAwfWrl1rN/fW6W9xfXM8CYKxSysyrgYGATgYBIH1qoOKbsMXA9aMZ9zSMQgG5gufU04f8A16VwEUHbzS52kEdqWimAPKZDknJFFRsCT0pVFDAf2oAGKTFKBmkNC7c96CoIpelB9qB2EHFAOeKCp9TTgOR7UrhyiAYHWnelBUD2pQuSOKNDSw4AUhFShMjj9KQxkDJ/Wpckty40nLYh/wA81oaHok+v6hHZ27xxyyZwZDheOT+n8q1L3TdOi8KwXUYxevt5355yc8fh6UzwbDIfElg0d4ti0cocSk88dQPcjPpXPOtzUpSjo0etSwPJiKdOfvKVtjq77RLXwBaLBNeJJO6+bsYDJOMYAHOD68VwN/qEl9cJNIFWReQ0ahTnNdh8TLDUZ7i11O4lkubaVmiilMJROPmwD0PU5x6Vwr8fSuTB0uaPPJ3bPTzrETpVfqsFyxjsiS+vrjUZvMuJXlfGNzHPFVcVIetMbrXppKKsj5OcnN3k7saeBSfjQTziirMrDGUdqb3qQjim0CGjilAyTS0UXsAm33pSuOabzmnqMLzQA0DPejaKeKXFO2ghoFOoxSHOOOtIYhFNPtTsEgcVr6F4YvdduEEcLi33YeYr8qjPPPepnJU480nodFChUxFRQpq7Zirz9KsIzCLbk7SclQeK7XWrfTfDGjNpznzZ5lLqzRDLnoCcdMY9TXDo+evBrClW9sm7HZjcG8DKMHJOXVLoKRTDUhGaYwOa6TymNpQOBR0FLuFArjeppeKQ8tmnAYp3HcbjFFFKOtIYgGDzQBinYFNbjFACAYNB6UY4xRimA2inAUh60/MBKWgDNKeMUIDQ0y0tZ4ZWuJdjA4UbwM8VRAyc00YNPGCKpgLRRRUAFFFB7UhXuIcAcsB35IFOII/pX0t+xx+0B8Mfgla+LYPiR4Hk8ZR6m9m9isenWl15Bj83zDmcjbnemNuQcZPQV88eIbq0vde1K4sEkisZrqWSBZQA6xs7FQ2OMhcDA44pJ6gjPpMDOaWimMKZT6KYDcGl4PalXqc0pXIFAEdOHSjb7UtIBM04GmHrSVd7CsS0UzfShxQKw6lzTdwoDDHJA57mqEKeaKBzg+vP1opAKOacoGKRetKCBRsApHHrTCMU7ORxxSbQKRVhMUUpGansLRr+9gtlYI0rhAxGQMn0pglYrilBzWn4h0GXw9dRwSSLIzruBVSOM46H3rL7GiwBjNJSg46Umc0WMmgPSl5+tJTSccCi4KWg8jn1pKVegpcc0hrXUQdaCKCMUDmg0QAZNDDaOKUfTFB9aAQ0Giilximih6fdp1NQcUnNC3EPppHWlHSg9KoBhyDTeD0pzqR1BH1ptA07DRxn1oKh1welOxRQDdyNbh7M7VAKnrnJ9qsOFsQpgzJu+8Dz6elMwCvqMVJoZwbnHGQv9awno0YzQzStWk0qeeREV2kXbhs8c57V193df2xpMMEhVd6ozeWe+M964J873Bz1Na+jXy+aoCDIU5I78Vzyim7m9HESjF029GUtRhFrdyQLnapGM4z0qlM2In/3T/KtDV28zUJWA2g44/AVn3HET/7pq1sck7X0MsnBNWLPmQ/Sq7Dr6Zqa3lET5IJrJbmOxawd7dcCqk4/et9atHUQBjY351UmfzJC2MZrTRh0GUUUUhABmrSf8ebf571VHWrcYzZPz0/xoGiG2jJkVv4Qea0MZAHrVa1XKHHrWjZxqwO4AkU4lI0vDA/4+uM/c6/8CqhNxNJ/vGr/AIbYA3OfVP61TMbT3MqxjcQx7+9KO7O3/l3FC2QzdofQH+Vbngsi3+J+kyHtcRH+VZ2jwZ1ZIpB2bI/CrkR+zePLcqSu10II7fKKxxMealJHoZbJU8XSn2kj6JvtaksIY5IlUsSAQwPQ/THfFdR8LL7wn4lTWR4v8Uv4dnh8k2SRlEWUHdvyWVs4IXuOteK2+uXSwvGbiVo3GCrOSKru5YDB59K+EWESupI/o3E51UrNOlJrY9ksfFM1lfagug6rc/Z4pWRLi3uHjWUAnax2EZyK/QLwh8adJ/aP8K69ptvoUtlPaWiW7z34jbLSowyuMkAFc+/pX5g+DbtIIrqJ5VDsysBn/ZI/wr6A+B/xFvfh/wCJtPWHURp+m311bjUCUVleINgknaSMBm5FRTm6M/ZS+Fl5nlcM3wccbTX76Gt1/WuiPVfGv7J2ueJdcaWyvNGSCKKOLEu8sSBliQI+5z+leYan4Fm+E/iybw1qs9tPeTRxyh7RT5aiTIAJZQR6mvuDSvj38JbPzC3iG282VtzExynPPb5f5VkeIfHH7PnibWf7T1htKvtSVVQXE1pKXwvQE7ecVrLD0mtJL7z4ihxHmtGdqtCUkl/KeR+A/wBi3xNoOq297qc+jX8Ee4tD5jvvyuASHTHvXomt/szyX+g31vDouiJeSwMkUu1F2ORw2QmR+FU/iz+05pt1DaxeAPFS/aFuQtwnknOzb2EieuOlYng39oPxFba5aP4i1rzNJQn7Vi2UsV2npsXI5xzSvhIzVMtS4ixdH63e1tbWaenkeY+P/hXfeARp1lqcdq91Ijybrc71ABC4yQPbtXn+r+ANS14JJZNbQxKChWSQoSc+ymvsfV7nwb8c7O4vNLuP7X1HTYCgWPzIyhcMVBUgZyVrymw+Dvjea2UxeHL1VPJ3lEPbsWFceIwklP8AdK6PqMs4itQ5cbLkqLe+h85QfCDXjfx2wezEs24oftLYOB67auJ+zD4hvrgvLbaWQzZLvPk9v9jJr7F+G/wx0fQo7i8+ImkpbyxyIbR7pywHHP3GI6461V+J3xa+GHhnWoLDT9Ss7crCGdIYpCMknbyFI6DpWqw8qdPnk7Pt1OafEtTF4r6tQpcy/mtdH526v4RhtpSRBEjPOcqEJ2jngdBXO6loRikxDFvAG3he+fTHoPWvrrxz8KdP8YaZpur+CPDs+p2txO/mz2UbspAB4IY/3gRwBXmviT4KeKbbSZXPhq806NZFzLOixgDJwCck9xURrVU12PoYRwOKpvmkoy7dbnz1HpMzy7AhViM/MMVtaVoDRli4VgccdcfXNdhb+BJ7C8njuVImVMFMZIyc9+M4HatDQPDznxdpVncQ5tZ72CJ8glXVnXI/LNbzxEm+VHRhcsoUIOvV6GT4S8Ft4h8QW+n2aWyXTxySIZhgMVXOM4PPB/8ArVtHwjd6fq6WF3bx+ZDOscqxsWA5GcEcV99eFf2fPhhoWl6H4guNDttH1N3URyNdSxhZzuUKoLHk8gLXP6hf/s36brF5Brs2kxa1DK0d0CLnd5oOGyQME8CtHhZz+KaR8tHi2kpyWHw8ml2XU+VrhZdBhl1DTgbW+tQZ4biMfNG4+6y8HnjPSpvCtvq3x88a2Fpr1wdW1m8jMUd3fnGI0BcBtoHGN3bvX1G+s/svXULxtf6WAwKkGS6XII5FJ4ctPgZPrMcfw0nsF8etFMNHMNxcOfP8pugkOz7obrxihYJpW9omvI5q3EqkpVVhZRlZpSa0Xr5Hyr8Yv2TPEvg/VZbq1ttM/scW3nmWByqoVUlxggsSdueOPmFfO914Zu1ieVjCqbS5BJzjrjp6Zr9a/DPw48S+IvB3iJviVo1jfXpjkWxNwI5XWIxHdxGNq/N0xz+VfnBfeHJrJkiuImAKA/Mpwc/X/Cicp4dJrZnVkdWjnkalKrbnh1WzueL+SDk1G8I6lR+Vep6j4Vs70Rjb5QUkkwgLnisHV/CVtZWE8sLSyTKBtUkHuO2K6qeOhIWK4drw5pJJpHBmA5OQMfSqklm6EkkYzxXTroF6wBFucHuSB/Os+5tWyV2gEHBFerSrpuyZ8fictnTXNKJzz22WJDYz7VpeE/C03i7xVoug288cFxqt7DYxTTAmONpHCBmC5JAJycdu1Ry25WVhnocVPpN/d6HqdpqWn3UtnqFnMtxb3UDbZIZVOVdT2IPOa6/avoeLPDI6T4y/A7V/gpqum6fq+o6dqM99bNdI2mtIyRqJCmGLqvJKk8DpXnLQMBXbeLfGXiDx/eQXfiPWLzXLuCPyo5r6XzHRMltoPpuJP41zstoeSOB6VrCpZas4pYSVtTHaIhuTUJTrWnNb4XJzkVVeLGMda6ozucFShy9CkUNRkc9s1baPn+tQMvXjFdEZXOGcLEL9D7dqiYZJPQVYZcd6Ywwa0ORxuVyCCaQYDrkfLnmpXQ5yBxURG48mhGDWo64EZZdmOnOKgzipGXODTWj+XPUmnch6jc0U4oQOlNxTE1YTAoxilwT05pM0CPev2Zf2jNG+BNh4ittV8O3OujVZreVTBJCqxiOOZeRIp5JlBGCOnc4rwRF2qq5zgAZpSM0mG96PMSQ6igLkA80oWgY0jNAU9R096eFzTguPp6UmykhgX1p1KFGe2KvaNot74h1W00zTLWW+1C6kEMFrAu6SVz0VQOSTTuupVijtpOhNdB4x8A+I/h5qMVh4m0O/0G9mj8+O31CBoXePcV3gMMlchhn1BrC2c1F77FWGAFjTghHengbe2KftB+tMpRuMUbjkipFXkU5YiMnGKfGnPTilc2jTE2ZGa9E8M2EGseGkjmtYYF+eJisfLAAfPk9/84rhIhtZWTqDkHrXrfjvwr4x8L+CbPW73Sxp+n32yF3eZGlRnTcuUzuTIV+oB/SvLxc3eME7Nn1mTxp0lUq1FdJbHlfibSV0rVpbRbg3KxBcSMADyoOPT9a0vh9pFrqXie3iuLlbfCtJGGXd5jgcL7Z/pWHjJz/OvYv2UvDfgLxL8WYrf4iaxc6DokNnJcw3sFwsCC4Vk2rI5RsKVL+mSFGRmt6qaoOK3seZh6kI4yNVx91O9vI9Q+I3xqi0X9lQ/Dw+HnuZZWEceqyOvlW+668/KqVzv2x7cjoHPWvkBvm5r6H/AGs/EPhWw8cX3hTwRcJq3hrT3h8rUvNE/wBobyg0mJF4YB3YdByDXz4VB5AxzmsMApxo2mjbPp4evifa4a9nrZ9GQkfnTTxT5BgexqNjya9Q+XsIwyKYVIqQHpRj1NNMkiIOO9IOD7VLmkIyKdxWGZFNKknPanbecZpdnOaZIwJgin0Yx3o20kOw0nJpBnIp+2lVQOvamAEEAUdCO9OJDfhTCc0XC1hdxrvvCOq6xZ+Gp4YYUeAq0luzjcQcEMFHuVzjHvXn4yx4Gfwr0LwxY61beH7wPZukaxsYS+FY5ByADyfUVwYuaUbPqfRZLCo6zlFPRbo4XVrm8vL93vWdp1O07xyMdqvaH4buNZLOoKRIQC5U4bnkA+tdBoHg251BpLrUx5cbAuTIxDk4ySfb60/VfE1rpNu9jpsUZ2EoWicNGR0z0BJxz1+tZe1bXs6SOuGAhFvE42Vl2e7MjxTpOn6ZKiWcx83pJAxLMvuT+mK549aklkaZy7sXc9WY5JqMnI4rupRlGKUtWfOYqcKtVypqy6IaxoAyKUYIBNOIGOK2OOxGaA/NOI/Ck20XGkG4UlGMcU7GBQLUAKKaBmjJAp3BiHgGjsDS00g5NIY4UmOvegdDQBimAgGe+Kdt204DGaRhwaQXEA3dKcBgU1O9PoAKKAM0UCYUUUmD+FMELQBk0Uo4GaQCbTQFNOBBpDQMSmgU4DOadjNMBB1pa7fTfgn451n4eXPjux8NXt14RtTIJ9Wj2+TH5ZAkzzuwpI5x371xA7+1CsIKTbmlozSAaVxTcetSHmkP5UAR0U4HI6UMMYNMY2u5+EvjrTvAOsX13qWnSalDPbeSkUSoSr71Ib5+BwCPXpXDYpe/NNOwmjS8Q6hFquu6jewI0UFzcyTJGyhSqsxIBA4GKojpTQMYp1PzJHfw02iinuNBSjrSUUiiRF3sBnFOVmgkDKxV15DA4IPtUQO05HBpc55JyfencViW5uZrtg080kzAYDSuWIH41AePWlLc0nFO9xNCc0oIxTSevFeveE/h/e6l8GtV8RR21ube2juiZmxv+XGccds8c1UY3EeS8/Sm4pXyCaQ8nioasS0FA6UEUUgT6Afm70qrjNAIyaCR3oHZrUC+PU0qsGPTj3pCMUhznnrQHNYfRSDpS0/UsM0pzmgUtMpAOnNJ3pD1opiPS9e+LltrHwosPCI06eO5tY4EN40qlW2OWPGMgHI4/OvMetPxSEYFA73G0U4AU2gQvY4p2in/AI+OOyj+dN/hNGjnHnf8B/mayn0InsU5B+8k78multLZFtomCKCUXJAwelc5Mv7x/cmugsbyKaGKFWzIqKCuDxgc1ktzBGTqY/0uQ/T+Qqhcf6mT/dNaGp8Xjj6fyFUJxiGQ/wCyalikZVSQuFJJ5qOpLfYHJk4XHcVktzItPHti8xunHFVGwWOO9Wp7iNoSinnjAx6VTLVpohsSiiikIBxVyP8A48m/H+dU6uRn/Q2oGh1p/qm/3jV23m8s4zjPaqdqP3Z+tWAMD3qluaI1vDgJ+04GfufyNUg0ou5fJzu3nOOvWtvwXaC6+2Z7bOn41CdPWCeU5JJY53Y9azi7ysd0qclSjIk0CHdfRSSDM3zZOfai5jePxrE+MLvT/wBBFW9HjCahEOT16/Q0X4A8TRt7p/6DU1vhaOrCR96L8zohOcAcdqnjmwxOBms4SZFSCTHPT6V4Tpn6bDEWN3TNXk0+RniCs7KB8wyBg5rsLbxfaQGKUTkSJg5EBODx/hXmqzFeQakW5I53c/WuKrhI1Nz6LBZ3VwkXGL07HrJ+Jm4lmvXzj/ngwHXPtUMvxQuhM7pcFgW/iQj0968wF0f7xzTjdYH3iK5v7Pgen/rJVfY9IHxN1KCSSe2uFgldt5IjBOeOm76Cuz/4WjrF5Fsk1FGLr8wWOMdQM9BnvXhEd4CcbgPwq/p2qmxu451VZNmTsPAPHqB71z1cCre6duEz2871dmfQ/wAPfjXr3wvmvrjRr+K1e7EazGWETAhCSMA9PvGvXPDH7c3ieCz1ZtV1W2u5GtiLVV04gRvgnd8vXjHBNfF8/i+4uo2j8uKNXxyhbPUdOf6VAb+6I2maTH1NTSo4iCspWHmE8nxsnOdFSb6n1D4u/bK1rxrbwRXV1YwpE2/MOnuGYkY5yxHrxXmHif4kxeJNQF7c3ayTCNYyywmMADoMc+teQC5ZT8pIUDHFSJflV5YH3INbTwUpvmbucmEzPD4CPLQgo2PevB37TPi3wRpC6R4e1lYLFPMeO2a3jkwzEsSCy56n6V9o2n7TfwP8SaNYx+KNWjlmWON5YJrC5KrKFG77qYODn19q/LS01F7aUyQzASAYyFz/ADq+PEupFRmbJ46oKFTq0X7quvM83GUcDmvvzbpzve8ep+klz4r/AGVfE+uJ9nktDqF0VhRIoL6LzCBhVwFC+gFaNvB8C9M1OODT9M059SD5hF3DO53rgjBkGARivzo8DWut+OvFtholhPGL+5LmHzZPLXKIX+9jg4U498V9b+I9J/4V78A01DxTPO+s2QOy8tpDM29pwEAboeCAfb8KU5zb+FXPP/s2jSsliZyXZs4f47/F7xTq817bDxDfJpaXivBZRz7UjwX24wM8fXtXz/qXiu5Fy8l1cySzSfM0kjM7N6knBJrE8R+OdV168bzr+WZd4bkBcsM5P6n863tF+F+v63o9lqGbWSK5QyRtJP8ANtY8ZGMdjXM6E0uarI+vwuOoUIexwdOz72Ni1mkuLeF/OfLoGx9R/ntWj4U+Itx8PvFOma9pVzImq6dN5sRMW4AlSpJB6jDGuFn1gGLy41khkQbQQ3C4IHT8KzvOfjLMT7mopYeSlzXPUxeZ06tH2TSaa1ufcPwY/br1O68Q3Ft8RdbT+wngCiSPTQTvLAEHy1zjbu9+nSvYNf8Ahh8NPjP8PPE0Hww0iwn8QQRwRJcTxyQiPLq3yvIODsVhkD69a/MRbpgBg8/WvX/Bn7UXi7wBa6hb6Dq8elR30qyystusj5AwMMynjnuO1eiqso+7NXX4n59WyWEpe3y+fs6iastouz6np/iT9k/x14asnvdRtNNjtlcIXW783ljwNqrnnFeR6/4RvrHWLrSRbrLcW0piYQ/dJGDxkD1r2L4YftPeIdY8S+R8QvET3/h7yXLRzWyMPOGPLI8pN397869L8e2XhDW/hd4g8Z+H9OtvtFzGzRah5DrIX8xUZgG6HqK8+dKnJc1J2sfY4bMsfg5xo5lHm5rJOKstT4m1LT5NBu3hv1+zyYWQITuwrEgcj6ViaB8JvGHjKG4utG06O5tUkKNK11HF82N2MMQc4Ir0/WNNh1S+ae6t455SoTdJ6A8DA+tOs9Y1Hw7C8emXTWMLNvZINoUtjGcHv0rCninT23PdxuVrGWu7JbHg3ibw7e+FNUuNN1aFbfUYH2TRhw4BwD94cHgjpWfb2jXYYwgPtGTjtX0brfhtNc0W61y4C3F5s82aR0U724HPA54/SsXwn4Ml1/W7PTNPSCC7un2IzYRQcE8kewr0I5i+XbU+XlwzHmc5zSijzyy8ERTwwH7U0bPGpIYA4Jxn61k+I/DD6TeLAkyyoYvNLuQoAHX2/WvrDQ/gpqmieItNvb66sJIraXc6JJuJwMcFveus+Ing231nwre+dEs4iiaRBCF4YAdwPaso42tCfNLYVbL8vrQVGi1fufn9PbkZGMHr0rOmhYFsAV6p4+8HNpyS6iHXaGRBCzjPOcnuew6+tefT2pK89T2r6PD4pVYpo+EzPKp4Oo4SMKSFgw4zkVC0RINadxBtYgYxVR0xnvXrQqXPkKtCzKDxkdajI5+lWpVG7nrULJ1rqjI8qpTZXYcmo2TPbpVhk9OtMIzWpyONisVyPWkxipmXBphXPvTMuUZSYAqQqBSAYNK5Nj2b9lWT4Rw+NNUf4yRxyeHvsC/ZY5FuyWuPOjJA+zfMP3Yk68c+uK8r8Zx6Z/wl+uf2IUbRvt9z9hMe7abfzW8rG75sbNv3ufXnNZjA5JFMIOafUlxGBaB096liTc6g9M1JcRLE4C9MZ607i5SuOlOA9aUfXNOx+XbmkUojRwSKWlUZG7rnnIqUIMCkUkRAc1t+CvFV54D8X6N4j0+OGa+0q6jvII7kMY2dDlQwBBIyOxH1rIVTuPy8U4Rk0tylE9A+N/xz1/4/eJ7LXfEVvp9te2tmLJF06N0QoHd8kO7HOZG7/hXnoQkgYzTxEVI9KkVAuMjNJWSsaRgMWHIBI5qQRruHTNSBCOKkVOBxUuVjoVPyIlQgc1IqE844qURGpVi4xWTmdcKJGiY6jmvZLL4tX3jrQrfQvEgt9YkjmDRefAFCoqEKMrjkAkDge5J5ryVYvauo+G3g6/8AG/jzw/4f0mWOHUtTvI7WCWb7iMx+8xAJwACTj9a8/FUlVjfqtj3cuqvC1E3rF7ozta8DXltrVjYabBLqM9+yx2ltAvmTTSE7dqqoJJJ6Yr6PH7J918EfhVF8RvFl/L5Vzb2iz6ammHzLEzn7jlpMlwwVThQBuzntX0jovhDw7+xt8KtQ8YeIZrDxF40t4Fa1i81bY3Tb4wiQiTLfIzFiyAHHBGBXwt8c/wBojxX8aPEF9cX2oX1hos02YNAhv5WsYUG0IFjJxkBQec/MSRjNZU/a1qShNk16tKhjnWw0fdXfY898dajYaz4jubrTlYWbldgePyzwBnjtznvXNyj+VWXGGqvL978K9ajFQionh4yo605VH17FZxkACmFcdamYHJPamMNwre55DRCRRUjAAUwg1RDG0UnINLUsVwx19KMUU7AOfpVAxuKTPNPHTnrQVPagEho5o70/YT2p4jwPemilEhxk1Lb2klzJsjjeRj/CgJNWtL02XU72K3iXLyEAV6naeGtH8GxxXl1L5c8bGMTM7EFiP7oHcD9etcGIxcaPupXkfR5ZktTHr2s3y01u2Y/gzw5pnh91uPEXkwyylHtWlZgUZeSD2B5XrS+MviLa3llPZaekyys215nUKNueSCOTniuY8X+JD4kvEZA8dsigLE4wA3c9+tc+ck8kt9a5aeFdVqrW37HpYvN1g4PB4BLk25urN7VvGV5q2mLZSRRxRgqS6ZBbaD1/z2rn8U7bSjpXqQhGHwnydfE1cQ71ZXYzaKYw5qVupqzp5t97G4wVA43Zx+laSlZXOaEeeXLcpwRSXMixxxtIzHACjNdLP4Imh0L7Xvc3ajc1vgbVXPXOeuMGq3hRpo9eU2kAuC2V2H5RtPqTyMUeJdbvLq5NtIjWwhLK0QY/Mff14rglOc6ihE92hh8NSwsqtdNyei7GAQaQ9Kk25GetBWu9Hz9rMjAoAPpTttAFVcljcH3oA5p49KRhxQIZtpMGnnFFADKUCncZoOM8UAFIRk+1FBNFwDGMYp2OKQY704mgQhFJThycYo2igENFFOKkdQR3pMcGgYmM0YwKcBigjIoAb1pcUgABFOoAOlGcUUGgD1PR/wBpTxpoPwavvhfZzWUfhK+E3nxNZq07GVw7nzOoOVUcdhXlg6+uaQDFAOTQtBC0UpGKSgAooooJCikzzS1VxjSMUhAzmnGkxzSuO4UoOaCOKZ0OKaDceDxSg5puRRnBphYdn0ozgc02gHFAx1I1GcUEcUAJRSgcnNJ0poDtvDnwe8VeKH019M0tNSS/IWCOK5QNISpIGCQQeO9ffnwV/Zf1a3/ZI8T6bqvhHztff7eIwLpCxDbAmCJdvHzH+dfBXgf43eLPA95pg0/U4bSCxJMJayhkMZ2EA5ZTnr1PrX3v8Hf2o9UuP2V/FN9deKbQ+IVjv2jWSzt1dcKNuEChTkA+taW0XLuZu58c/GL9m3xT4A1awsz4dawllt2lkia8jY58wqDkuccY4zXi00D207wyY8yNijAEHBBwa9n+Lv7S3i3x7rVnePrsF20Vv5ZeOwgjA/eE7cBMd+teLSymeZ5HADOSzYGASTk/rUvReY9WLjOKQjApV6Umc/SoE9BnI9qUZ/CloAxQRfqKTkdQKAOM96acZozzknimkUtUOHWlHrSJx/OnBWk4UE/SmiloJnjg0bjkVMxUJtx830qE9RT2DcXNFIQcZ7UmTQWOopAelLQA3FJTsc+1Jip6j6CnkHHFJpA/1/8AwHr+NL1FSaLFvE5/3f61nMzkihMMyN9TW7YW8UUEcipiRkGSW+n5VjSriV/94/zrat5BHZwbiFGwDms0YIzNT5vJD9P5CqE5zA4/2TV7UHD3TkEEccj6VQnH7uT02n+VQxMye4rSNvbxqM/L9TWeo5/KtGdY5lUbxx6GlFGadiCcQCM7CCw9DVUj5qsSQxohIbJ9M5piRhgD3pW1AiooopiDvVyL/jyb8f51Tq5F/wAeTf57ik9ykPtP9Uf96rNV7QYi/GrFXHoWd98LGKvqWOpWL/2asu8H+mT9QfMb+ZrS+Fp/eaiOvyxf+zVm3hxe3P8A10b+Zrlpv960fRVf9yp/Mfpg/wBPiz2z/Ko9QP8AxUMZ9Nn8qfYN/pkR57/yqvfP/wATxT/ufyrSproc2Hdkn5muJMAHcaXzRxyfzqqbhRxmkaUjpj864/Zn1arWW5dEmc4OaU3Pl8ngfSs77Xx0/WmvPvXBGPpVex7kPFWWhpi/T+9/46acLoOMg5H0xWNkY4NSxz7FABP4Gm6KJWLk9zYSfBBxmp1uSR0/SsZJcdc/nT/tJB6Z+prF0LndTxnKbcV1846dasnUHI/hP4f/AF65z7W2ScfmaUXJbjqfas3h+p0rMHayNg3GSOcZ96ge4G8c/hUVlo+p6nGZLTTb27iDbS9vbSSKDjplQRmoNVs7zRZ/s9/a3FjPtD+VdQvE+D0O1gDg9j3pJRWl9SHXm1ezsa+m3kMN1GZAJULLvjU/MygjI/Hp+NfQXxx8Q/CyHSNOfwBotxps5nb7QZoJFHl7flXc7vk5HbGa9Q8Kt4Mn+DXgnTZm8NQ6lLoti8xuJbVJlJQMzMW53d+TnmvibU9Ylu/NhL7ofM3dM5IzznFeam8TO1tj6CDjhKSrSl7z2/4J9efBH4rfDPwd8NNOvtUGjx+LoprhXkksd14MudjBwhP3WI69j9K8L+MXxAbxV8RPFF3p2ozXGjXl80kSpKwjdPlIO04HYdu1eVfaXCgBmC+gJFM+1tu9ffdXTHBxi+a55s8xb33Og0+5g84mYqqgcE59faulh+MWvaHbRWFjNbCztgI4d1sGO0cjk9a87F0cZ6fjUbT5Y8/hVvCRl8QRzSVNWpu3mdubjzZWY4y53HHTJ54/OsfXbiWG6j2SOgKdA2BmsSTUJplUO5YL0yf/AK1RvMznJOTSjhlB3Y6uZOtHlj9500OrxSbV3HcQB071bST3rk4ZWUrtPoa6zw5oWpa4sj28aNFGyqzs4UAkZHHU8AniuWvCME3c9jL8RVrSULXZ0ei+I/s95HuaURHO7HzEnHHfHUV7t8CPEGteL/HnhTwtf3D3Phy7u8SafMAYGQK0jAqB6jNeI6f8P7+YFjPCsnOFCu2eOOQvQ+te46DeaH4O8HWE+kTCx8ZW8MO28t0cSJLgLIdxGMbSw6DivBnKnCSkj9CccViMNKjOOrWjfRn078RfhXo2iajpf9h6TaWbNE4aOGNQJCWG3IPU9ec12eu/s2WN7oN5Fa22ny3z27LEJYNi79vGW5xz35rxb4BfEvUryXULjX77UtflR4iplIlKLhsgZwFz7eleofHv9p2w8FaNJpmj3F9ZeILu2eS1uFtwUjP3VJLcdT0wegrrpfV5RdSSPzbG0s5oYingqU25Lr0Mzw5+y/rNn4Zj0y/07RZT8wkUsrhwWJGSU5/+tWt4c/Zph8JeJdJ1ttI0i3/s+7juTJCFDKFPOOPT+VfLh/ax+JwBz4vu2P8A17W4/wDadNu/2q/HepaZd2Oo67f3MNxE8LiMW6ZDKV6+V71zrEYWL0i7o9aeQcQ1k4VKsbS0evc+wfGH7YPwu8M6rPp032rUp4cbns9P82M5AI2ucA9etcnqnx3+DnxV046hqq32lafo5ZXtbq18tbsyoRtKpkvjaTjjBxXwFBcywxhN5wOMYwB+ldBo0q6nHDp8qhIncszKMk8H1/pQ8fJv4VY9WnwLhaNNSjVkprrc9x+OXwIfTdAPim2t9MTwzqN3GdJt1ILCKRS0W5WTg7c8ZJ+Y+lfG3ifwjc2d9MIVSZjM4KoyrsAbAGDj9K/Qz9kPxnrni7Vr/QvEF+2s6Nptgn9n2t1HGy2+yTYNuFyflOMkk4r54+LulWljrviS3t7WJEfWboALGBtHnPwOOBgCnOoqCjXo7PoLAKpjqlTKcwV5U9VJduh8lX9i9tI8cqFJl+8pIyD/AJ96zJ7Ziv3DXovi7wvetqN5eQQBrTHmF1deAFGTjIPY1xkkQfPOe9fQ4fEe0immfH5lljw9SUGrLoYEsTAgEY+tV3TIPOMVtzWsZJJH61nSQ7VY169Opc+Mr0HF2M/aakjsJ5oGmRMxrnLZp5h46mp4rmaG2eFCoRs5yOa6+ZHkun3MsqDmmlPWrLR4HSmlOnFWpIwdMrmMEdelJsPccVOy0eWew4p6EOBDsHofzpGTr1z9alZOT2prRkdDmmiOQgKN/k0eXkdP1qbY3pRsbPTigXKQgbTjn8q9m/ZQ8b/Dr4ffE6fVPifoieIfDbaZPBHZy6dHfKLlmj2OY34GAr/N159zXj4TJpwiOenFBXJdHZ/GvW/Dvin4s+KtX8I2qWHhi8v3m060jtFtVhhONqCJeEHB4FcWIyalWLkZ4qQRAdKlmkaeiREFwMU4IOKk2H0zThESOhrPnNlTZDs5xinrGCP/AK9WI4M5qVbXb2H51lKodMKLZB5Dn+GpRB04H51cW36/LUghGQe9YuoejTw19SqkLZxipVtzmrcduGPp+NbeleF7vUbhIxC8UbAnzXT5RgVzTrxgrtnrUMDOu1GEbtmBHDg+hr3H9mL4K+JPH3jnw/r1jp5/4R7T9VjFzqEkyxqGQBzGgzuZ8FeFHRh0rzZ9Cg0HXbBdUje4sDNG04g+Vni3DzAp7HbnHvX2R4n/AGqvhn8G/hdB4P8AhH4clvbDVYLi5NxcTyRtazvmPe/mBndxgEYI+6ozWMq3PH3WXWw9TCTVOUdTw79s/wCHN14O+IsF490LmzuYEhiQ3HmPBKifvEKl2Zc7lPIUcnHSvm6cYf2xWxeMbiZ55WaSZ+XlflnPcsTySazJ0y5roo+4rM4MSlJNpWKEg5HNQOMk1akj557VCRz7mvQjI8ComV8cYPrTXGPrUrqaYetbI4nGxEVPtTe+D0qUgGmlcnjpTuYtELLk8Um05qTBHUc0fSi4uUjwc96UDOPWpFQnmneXnnincOUi2jrUijmnLGAakCY7UkNRGBcjikK4HNTAAL2oZAVJ6mqNVE9j+Dfi3TI9Kj0KPTRFegvPLduVYysWAAHGV+XAx359a5b4paDrOk3S3V55z6TdTSGzkbdsIyDwMYHGOlcXpk17ZXsctjLJBc5wjxEg57Dj8K+tPjn8bPhB40+AOg6LpPhvVh4kWC28nUpbdYY1nREWdywdvMB/ejG3q2eDjHiOg6OJ9qtUz7J5pHEZYsHJNSj22+Z8f4AUCmEdTVto0LfKeM0jW0jybI0aRyeFXknnGMfjXqc66nyMqUm7FTd0roNM8E6pqVhHdpAEhkG5HZlwwzjjnjnPUV674H/Zg1R4hf8AiiEW0Lxbo7SKRvOSTdgrKgXK4wQR159q4zUfHdraWn2HTLNo7QBo1LybSnPbAz69a82WMdSfs6GrR9Lh8mp0aXt8fLli9l1Oc03wHc6hHK8syWyowRScMC2MkcHt/WpfEHhrTrW8sbKCdbeeRgrEksCDjDHnI7+gqPSfE0uiW0sUMUcyStvPmk5zjHUYrnXYmXzCSXzkEnp3rbkrzl7zsck54GlSjGELt73O82WngPSXR2hm1N1LJ23gkDHTgDB7jmuH1C+k1a/eeXYkkp+bYu0dBRqWpXOrXAmu5mnlChd7jnA+lU/wrShQ9neUn7zOfH49YhKlTVoLZf5l+VI7eDb1D9uuaonpxSY469OKUDIrsirHi1Jc70Q3bRtoIPagdKowG0UpFJVakDaTPOKXnpSjBOO9MBoFLTsCkC475oGJjNAXHvS49KdjFJjsEaAyoG+5uAJJxxkVp6tBYwiL7E6sTu34ctjB461mY70d+tNPQLag3b1pB1FDE03LZ6cUkPlJHcucmm0KDnmnYFMLDaKUKacUBPSkwsNzSU7GO1Lii40iM55pTS460Y9qZFhhxmk6dKfilCljgDJJxjGeaBCA88/lSZOa0NU8O6toPlf2lpd7pwmLCI3du8W8gAsBuAzjIz6ZHrVHaAOvNACEn0ozSjA9KaRQKwhPNKOlG00tAWEPWgc0uBQBigGGKTaKWigkQgDmgAHB4paQjFMoQ8Yop2wsAcZHWm1QwpQ3Q0lH1oAUtSUgPPtQTx2oAQjHua9J8J/ErUdD+HOp+H4o4WtLtLhXZ9wcbwAcduPp3rzcYNL5jqCAzAHggHrVKVhNXGinZxzTQfzp1SK4qtx6UoIA5ptGcUwvd2HD5s4pSKYDinbulITWgbR+tIQO9OzSYBz60GSAECnRzeWxK8E8Go/4jjtRTRonZWZLuBbOc5oIzTAcYHenZ9aZSaHE/KAKYBTuvTrSYxkHrTKEAp2c0gxijHNAC0UUUAIelS6GfluBn+7/AFqI9Kk0IZM/X+H+tY1CJXK0v+tk4/iPP41ozrmwhB7Bf5VnScO+f7x/nV+5JWwi5wcL/I1ijLltqUZI8DIHSqs3+rf3U/yq0Jh5LIc5OeaqS5MLf7p/lQZGXFw3TtTn4ApI/vimnrWaIAmpIn4AxgVHT/MGzaRk+tWtBjKKKKQgq3Ef9Db/AD3qpV63A+y88j/69DGh1pkQ/iTU68nFRx428DAp6nBpo0R23w5vYrKe9MxIVljAwPc/41WvF3Xk5XkF2I/Op/DMEaG42oBwv9armRHndQcsCeKxhFKbkexKpJ0IweyJ9IjH9oRBwNvzZz9Kp6wFXWQVwBhDj8K0NMH+nxH6/wAqz9dUrq68/wAKfyNOXxWHS0pX8xwfOKVpCfSoAcUbs4rRRO9VHbQkBz9Ka784NTWlhcXn+oheTBwdqkgfXA4rrbjwHb2LWvnanEZXJLDKBBgA8En+Y79K56leFPRvU9PDZfiMTHmirJdzM07wLrOraLNqttDC1lDE8ruZ1BCqMt8uc5wD9ccVght20g8YzXVX/je90Ka80qwu4/7LfIaIRo6neo3jIH4cVzd1d291IiW6BccYVcelZ0ZVJNue3Q6MZSw0OWNCXvLR+b8hgcg+tOWTIOeDW9o3ga81KCSaYPbLtzGrAbnJUkDnGBkDn371zs8EtnO8M8bRTJwyMMEGtI1ac20mclTC4ijGM5xaTJQfMkVBjLEKAeOSeK9I8a/AHxr8L76xHiGytbWK7keKCaG8jnR2TaW+6cgYdTkgdeOhrl/Dngu61S7kS5E9m0JBKPHjd+J6dPQ16H8bPjxqfxRstLs9RsI7Z9Lnlw0NwzBiyqrZDjI+6Ohxya8+rVnOpGFLbqe1h8D7Kj9YxOi6eZ7tBqvgv4G/DnV00mWK6uP+PhrRdTWR5pztTIG7OOnAHQGuP+FsHw3+O41HUfiBeRaNqtm8drbqL5bdXtyu7d+8LFiG3jrwCBxXyrI4aUuEC89AB/hSC4YL8vA+n/1q545ZL3pOWrOirnUXaEY2iuh7V8afibovi2306HSpLmSa1l8qXzrZY1KRp5SMpXjkKDgADn8/HvPBY4J5qk05IGaYZTn1NenRwqpRsjw8TmMq71L5k4o8ys/zPYUebzjFdHszzvrF9y602emPzoEg9RVHzKVZNtNUyPbl9WHrW5pJs/sa+cIDIWb75GcZ4rl1l+bmpEl3MKyqUOeNjvwuNVGfM1c9R0JNAljYXbWC7dv3yo78+/Su807XfCukwtHY3lhao5BcRNjdgYBOfqa+exdAA7VI98//AFqfHdsv8QAHrmvGrZa6j1kz7jB8TLDpctNX79T1K3+JepQ3DstxEqZ4JiTHX3FauleNLzULwPc3XmRMCSuFVckew9a8hW9BAywJPXitvRNSWae1tlDGRnCg4GOtctbL4xg7I9jA8RVZ1lzyPpX4eeMbjTtThhgu0hguriFJssNm3dgknHGAx5zX1N4w8AfCz4iTWtzrfjO1hntkaNDa6nbx4UnJBznPNfDXh2aO2hmEzCPKKB8ue5z0qpf+MtJ0loRdPIplGVKQFhxXhU7wk4KPMfZZlhIYtQxTr+yfVn2knwH+BSD954/X8dZt/wCi1z3jL4U/AzRfDupXWn+N0u9Rht5JLe2XVY3MkgXKrhVycnHANfJC/EXQMZ+0Tj6WzVXvPiRoTQyos14zFCFxAcbscdT610csntRPJjhqdNqcsybt0Pbbfwh4J1KC3a11HNxMABEL35t/Hy4Pf2rN1P4X61BqrjStLvJrFSDHIXQs3HPO4d89q8d8J+PrC2uBdXF6bKa3lR4fMQsSwGd2Ap6EDrXplv8AtHSbx/xUSMSev2Zf/jdcUqFSL+Fn0SxtKpFOlWT9We5+BPG037O/hqDW30lb7VbiIWslrJKYz3kJLKG6YAx9ea6L4vfs73niHwxo+u+DbPVvEGoa1KNRuEJjKRpMrSnk7cfM+AK+a9X+KK+LkW01LUGu4o2+VHg2qp6E8KO3rXufgrxL+0Y2haTH4Yvpk8Oraxrp5mt7ML5AVQmNy7iNvTPOAK6aPLOPsq0XbofJ5jhcRhK8cfg6sVN73ejXQ+fPin4I1/wFbahpniDSrjSdQa080QTAFijZUMNpI5IPftXiUmi3qRPIbScIoyzbDwAOc1+ofji0+EHxk123g8Wa5dzeMZUj0v7LAZImjlR2+QKI9oJdmBJ4Pbivmr48fBOL4aa/DplvNLLZ3Vl5weTbJIpJZGBOwL24x2IreP8Asd+TVGEMZHPpwo4lONW3bR+nkfHrxjb0461SmiBD/Lk444rsvGvh8aLqywxl3UxK5MhBIOSMcD2rmzAc88mveo1lOKaPk8dgJUajpyWxlQ28LIwk/wBZzgZIqs8EkeN4KnpzWjNbMjEqOc5zUEqu65fnHNehCbPmalDo1sZ5iBPSkW33tx2qw0fehEfd8p6+lb85wugU/L5PFBj9MVfWzZv4W/CkeyZB90j6in7Tpcl4Z2vYo+VnPHNMMfFXTbNimtbMWPynirVQwdB9ikYz0xSeXVpoGHUYoeDbjGTTU0T7BroVljwecVJs/Kn7CDyDS4IHTinzCVN9ho7VJHE0oO0En2pAox71rWFuETLKNx71jOpZHXRw7nKxmRxGQhVGT0xTzA0WFdSpPPNbkNnCJQViUN606709JpVds4AxhRxXI6+p60cA+W6epjRxg4wBmrixH+6Kn+xJG3y5/Gpktz2FZOrfU6KeGcVqRJAWPQYqwtoeuB9cVbW1I+4M/ga9E+DvwpT4n3esRz6sukwadBHNI32cyvIHYr8vKj5SBn6jiuadZRV2enSw7k1FI4bw/wCHzrN6sKzxxoxxnBY547D616VBa2kVylvbXcc8oBHlxyAldo54HTGP0r0D422vh4X8EWk290msWlhbpFcWxjSBiCoAlG3J+TnIx1r0z9mH9mKx8FabrHxC+JFkl49rbtqGn22nXomV43hcTCRBgFvmXHOMk+leRKX1u75rWPr6WKWRU4ydJycv60PB7CCyj1rSH1aAXOnxXkM08Ese9ZIxIpYFSDuGOtUf2j/GPhTxVqGkW2geHYdIuLWJiZbW0S2jmjkdmUbFJzjGQf8AaPTFe5fGbXbPUtQN3o0dymgW0SCztrsKDbhlQADG7IJHXNfOPjZm1XUFvZrdI9kAjDHJYgMTjJ9M9vyrnw9R06vK3oj18ywyzDCxxPLaT6dv+CeWzxso+YEVnyqefSuj1SDMYI67sc1hTxkEjqa+npT5tT8sxtB03YoSLkcd6rMm3PFXZEPFQugYnNehFnzlSncpMpOKaU9RU7RjHFN2GuhM8+ULFbae4ppUgnAqwy1GYzk44rS5i4EWyjaKkK/Sk2UcyM+Qbj8aO1O20/YMdCKd0HJcjH3hUgU+lPEQz0/WnqvNTc0jAYFwealWPaMEU9EB6V33wk+DPir42a/Po/hSwivby2hFxObi4SCOKMuEDMze7AYGTUzmkrnTCnc5Dw9YX95r2m22kWzX2sTXMUdnaRxiR5pi42IE53ZbAxg5zX07+2n4t1j4hXnhDSNX+Hcngm9hPmRNbTR3Fu8k8cXmRII1CqQ6uSoO71HSvqzw94R+Hv7HXwx09rnSr3W9Rmvo7iWSO3t7q7+1+TndEzAFI1KHG0jG7PUmvib4uftKeNfiB4vuroaxfWGi2mpveado7eWBbbXPl7yigu4HGSSeTXiVazxEvc6HuYfDOn79SOjPVv2ef2fvAfwfs7b4ifE+a9kv9JmNxb2cjwR2UUij93vy5LvvxtyQuducisT4T/ED4VePfj/4617xD4X0vRbLV3mv7CfVbpfJhJkXdGYnxHvcfPlT8pDYyK8A+J3xO1X4h+I7/UrhpLC1umTGmw3UrwRBRwAGPPzZY57kmuGduDzSpUari/ay1f4E4hUY1uairJHq3xl+OGq+Ldf1PTbR7a20y01Sd7S506Rw0kSsyR/PuwVK4IwB1zXkDZLEnnPrTth3cikcYr0qFKFJWijhxVerX/iSbIm5PFROvBP6VMy5NMZBnk12JnkyWhXIwKTn0qwIRI4Cn5j0FI0ZRtpHNUY2ZCASTkcUYwTUjJ7U0xnsOKaJaZFtNJtIqUrge9Ie9GpPL0IypJzSEEVJjNBT86aJ5SLHtS4p200EcGi4uUaFzS7QKUAhDkUm31p3FYQDHQUoHHWlHFKFzQPlGhcH2padtGMdKTb70DsMxk9KMZp23Pc0uMAUIdhoXnmlVfSrI066+zfaPs0xt8Z87yzs6469OvFQAbTVDsJtpQMMKcVK9aaQTyKWwrEssYKlh19Kg2079aWhisNpKXafSgqQKVwsMIojkMUyOADtYN83TginZpCCTTZNju/in8YtV+LLaedStLS0SxMhiW03/wAaoDksxz/qx6dTmuEAzQFxkkUfhSvYmwbaNtLRnBoGNIxSUpOaQ8U0xWA9KKD9ak+zShA5icRno+0hT+OMUyWiOgnH0pSKQjNArCbuaCetIVOfajGKBj1mZEKDoRjGKZ1opKYCgZoI496KKAGY9sUYp4HtQVxzTC4gGKCM0uOlFMBNvOaDwKWkIzSuAmSc0o5puKns1ja7iWYgRF1DknGFJ5NUTbqRilBwa0dbt7GGeIWMiyRlMsVctg5PrWb60WHuKOnvRupAcUUhaIBjPrTsU0GnDpQTuFH60ZoyKSM72FDZFOUZGaZ0pc+9UjSMr7jguCaTJGaU9TRjNMsM0ZpNnvzSHg0IocelXPDaBluuP7n/ALNVHPB/GtLwuM/a8c8J/wCzVhVeg4K8rFR1USPx/EakvhiyT/gNNlB81/8AeNPvx/oKZ/2azWxM1YyqZMP3Mn+6f5U+mzf6iT/dNI49TIRtpzSGiilbUzCiiigAooooAO4q9D/x6H/PeqPcVdh/48yf89aVxolg/wBWcepqULUdscxZ9zUo6j8KtbJmi3O38O4DzD/d/rWZCP8ASpvqf51qeHeZpcf7P8zWZD/x9TemT/OsV8R6sv4UDQ0//j+h+p/kaoeIPl1lR/sJ/KtDT+L6H6n+VZviNsa4v+4n9aH8aKi7UvmQk4OCQPqcV0Ph3wTe+IoZpIyIVjKY3o2JAe6sOOOPzFJ4Q8SaboEl019bPcGQIEKxI+3B5+9jGeOlTeJfHrXslp/Y0l1pyRBt4QiMMTjHCn2rGrKtKXJTVvM+lwkMFTpKviJ3f8q3OvXxXoHhVPs0N48p24ZIATh0XAJ4AyT356V5rqvibUtYCC+u5LlUO4LKcgHjp+VZc0zTSNI5LOxLFj1JNMJyKqhg40nzS1Zjj85q4pKnH3YLZIe0m45xgVueFNMvp7+3vbTZtik2newB6c4B68GsDtV3TtdvdIP+iTeUc7sbQwzx6iumtCUoNRPLwleFOsqlW9lr8zptW+IVwRHHps01kEyGIVQW6Y+mMV1HhO88J6hc2Ooa5KiXkZjkmeRpD5jDg7lAIPQHAxXkQyzE989vrXYwR+H28IKWuFi1ZYWO0ytywY4yMY6Y44ry62EjGCUdG+qPqsBm1XEV51KlmkrpPy7HV/E34hwy61C3hnUWjtTCDIbZdg8zcfVQfu4rzee/lvLmW4ndpZ5DueRzlmPqaotMW5PX3pvmnseld1DDwoxsv+CeFjszrYuo5Tdl26ItmY4Ippmx71XMjY69aQvx1rpsjyXVbJzMD3pplGOTUIf1NNZuRg8VRLqE3mDPU4rsdQ+GeqaZ4Nh8TTXNkbCaOGWONHYyMJCAoxtABHfmuHyw71pzeKdYuNMTTp9TvJtPQBVtZJmMSgdAF6ADtSsCqdyqZD26Uhciq5cjvQHbPJosTz3LQkwQc09ZAM81UUn1p+/GOaC1MtCbnnAFOEy5wDVZZPl5NKXxUuNzZVWXY5xjg/lVzT9SfT7yG5i2tJEwZQ4yM/596x0k2jjrT1kyOW5rKVJNWZ2UsVKDTjujuo/iNqW1lC24yMHCN7e9Y+qa3Nqvlm42nZnbhcYzj/CsESKD1FO83PQ9K5I4OlB80UevUzjFV4clSba7F9Zhgc/pTxKCf6VSinULyeakEgb5hzxVun5GEcRJ9S8k2OOfwqzbzKJUJB2hgT+dZkb89s1ZjkGRk5FZSgdlHENSTvsd5H4qtf3hxNvdWAGwdx9fevb/AA1+1B4jGn2emWviO8tI7aBII44Yo4kVEQKoHy9gOpr5cgfdIOeK1dNuTZzrJlnAzlc4z/OvExGDUk7N3PusBmynOKrwUoruj6k+FnjCa5+LGh6jc3jXNxJqaySzOwLMWbljgY6nPpX2B8RvhB4Y8Z+HtZ8Q3B1HW/ESWsiWyzXpYxuoJWNI4+Mbm7g9a/NPwf46i0fWLC7ngkaO3nSdlR13PtIJHIwK9rtf2l7YFJLPRr+Mp3F/HHxv3fwp79favGUZ0bxkrpn0OZU1mVelicHPlcFbTsuhHrfgS3TUTbanpNqmoqqo6XkA80dwMHnv6V594x+F1idWGxfssvlZNvbxiJM4bB4/Cvs/9nH4p+GvitHqvh3VPDcOn+J76Jxba1eNFcbv3eEBLYbcDnCqDnHUVzXxk/ZX1zw3e6rrEGq2N7pdnYfapJCHjkwo2kBQCOSCRzRGlVpx9pTlfy7FrOcHXxMsDmVPkl0b6/10Pg5/h3rLW8kksKRbELssjjJAGTjGc8A1yfkbxxnPvX0jq+hvaaRPeNLstSfK+YkByQeOg9xXj3jLSIdP1CBLa3jt4jCG2xZIzk9c5ya7sJjZTfLLc483yCjQpqth3dHGPaHJwVx6VoaJ4Uvtbt2nt4ozFHJsYu+3kAE/Uc09oc+tb3hzxU3hyye3W0W43yNLuMm3qAMdPavRrVqiheG58thMDQlWSr6IxHsU8yNLSQXTHkiKNs/qOevp2qjdxmT5GUrsJBBGDn8q9zsdFsoPLlis7eF3UN8iKDngnmvOPFHgufRo5ryS6inDy/cRCD8xJ61w0MwU58stD6HH8N1aNBVafvLf0OIaAAcCmeVkcitNrZvTj0xTGt2BGM4r11VR8PPByjujMaDcajMHoM1pG3IzgVF5J9K1VU45YcoGPr2pDGSOKvmE+lRtASeKv2hh9X1KltbGeUp93gmtWeRLeMIFdZQowwHFanhfSoHDTzMPMG5dhbtxziofEwtpLqJbfB2IVbb2OTxXM6qnPlPZWBlQw3tdLsyPOkLqxbLKcjOK0be7a4G1zls44FZ4QetbGk2UTwh2BL56hvp2pVJRSMMLSqyna+hIlsznpmp7a1DTIG6E8irUcYVuPzqdYx6V50qnY+op4RaEr2MEIDLtHqS1eofAL4W6V8Rr/Xlu7y6sbmyhhaGWzdFAR2YOX3D5gNo6EdTmqnwQazsvGsF3fRo8EFvMcSQiVQxTaCVIP978K9X8Aadol74+11bTSYRPr1y1ikpJWCKIn51EYAADYOfy9a86rW0cO569HCvm5lolqeQm4RZXAk8xFYqGbGWUHAPHqPSvT/Eg8RaX4W0eS7vrhtLjPkW8KXTssRKg4wOACB+lbfj/AOAUfgHV9PlKW97Y3NvJI4to3EcBVgFU5zkEEdTzg1xXjprdI7FIr1Wcbg0HnFto+XaducDj15rzW3CVmfc06tHH0oVKdmk+qOevtcu7izktHupjbvgmIyHacdOPwrndVuLWOBUumjUPyofv0zj9KmvGbdweDXMa9BcXV5AFG5Qh/i9+a3oxvJXZhjq/sqT5VqcxqSttUucjceAfasWdRuOOciuiv7KYyOmwlg2cfhWTNbPGzK6lG9DX0lGSWh+UY2jKbbasY8gBJ46HFQsuc8VoT2m3cxbjPTPNVniK84NenGZ8tUotbopvHwDjioSuDV/ysnkcVC8BycD6VupWPOnSKLDFNxjOatPEc8ioth5rVSOOUGmRBfbrSYwfWptlJ5YznFMjkZDg88U5c45p5XFAHTjIp3BQYAfMKlVeRxxSpCGIwDj2q1FbFnGQx+lQ5JHTToSlsMihLgkflX1L+zH+z78UIv7M8c6LqqeF9Iv7fzo5YdVENzf26yZ2+Wqt8jPFjD47HpXy9KjQklcgda+t7v4+eMfDH7LvhnwZcfD3UtMtrSyFg/iW5kdYWjlkd0CKqjBdCVyW68jtXDXrNxtDqd9HDyjUjzLTqcb8ZPiZrr+J7u217c2vWqqrjzY5Y0ZvnK7ozg43f0PSvD729e/u57iXHmzOZGAHGTz3qxcT/a5Sxyc8fMcnt371RZM5Arnw9NU1c+hxuInWSjf3VsUZVJxVWSLDH+tan2Zsdqje0PUqDXepnz0qTk9jLMZJ96ayHGCK0zbmMgldoI4JGM1DNAGYt0NUqiMKlBpGcVppXJq0Yz/+uo2Qk10po86VNoroTE25eoz1FNdi7kk8mrIXIqNosA8Vqmc7iQkUhFS7R6UbAaq4rMg2Z9hQYgQetTbAOlBHBo5iHC5AEC9Ka45qbbmgoDVGVmVyGPGKQK3pU5TjOD+VJipE0RYpOAelPdN5zjNAQgYqwsMHPalx09aeE5OaXYBSQrEagke9LtPpUm09etAQt7Ci4+Ui2cckZpdueeDT1Tn5hxUhjAHAOaVx8pqJ4ouk8OHRQkf2YqULYO7G/d6+vt0rHAx3/SnBfQU4A+lUFrEeC4prIV9qmIz60hXOKAsyLa1JgmpOckYprKRnigm1hmDQckYqTZxTTGBQDRGVxSYNSbeM96TFBNhoX1qzpumvqVwYkdUIUvlgenHp9agK9DT4ppLd90UjRsRjKHBxTXmZtC3to1jdSQMwdozgsBgHiq+A1Syu8zmR2LuerMck1HyaHboVYbtApKXGetG2kRYQDBFemXfxlN78IV8DNp0iBBCBeeeCp2Sh+U28A/X3Nea7aNoouAdSecijbQBg0tO4MbjmkI9qcRmkYZx7UImw0jikC5JzTqKYhp4oGaUrmgDFAmLScUpOKZgUAhxHFN6UoA9KSncYtIRkUtFNCACk78UvWkximGooOO9OFM60oPagLBQ3enGmn2pDEVQORSg4oHvRnr607mbQuBmjH1pRijFJCWodTXVeAPh5qPxFv72y02W2hmtbf7SxuWIDLvVcDAPOWFcpgAe9aOjeINS8Pyyy6XqF1pskyeXI9rM0bOmc4JGOMgHHtVodrC61o8mgaxe6bPIks1pM0DyRZ2FlOCRnnH4VTAxUl1ezX9xLc3Erz3ErF3lkOWZj1JJ5J96iU5ob7Fod0B9KjPJJqQnjFMIA6AUkx7CHitrwvbBPtJBznZ1/4FWKw44610vhKPzFuu+An/s1c9fSNzqw8eaZhTZM0mf7x/nUt/zYx/h/WmzR/v5Bnjc386lvkAsE/D+tRHVI5qmjaMb0pkvEMn+6f5U8DpTJuYZf9007HGY6jpRR6UVJmwpDS0hGaBADmlpo4NOoGwHUVetxmyaqPcVegI+xN+P86O4IktvufiasKOR9R/Oq1t/qif8AaNWEbBH4U1sjRHo3gqxS9nn3lhgJjbx13VzyxmO/uFI6Mwz+Jrr/AIfjFxdfRP61z98mLy4/66N/M1ywd6jR9FWpqOGpyDTv+P6EdfmP8qy/EQY64igEsUTgDJrW0wYvofqf5Gquo3a6d4rtbplLLCYpNq9SAcnH4VcnaWhhTipU0pOyuYsoZG+dSjdcMMfzpoYc1reLNdj8Q6qLuOKSJRGse2VgzEjqcisYNXZBuUbtE1VGE3GErpdRwJ7UZxzTQeSa0tB0WXxDqSWUMiROyswdwSPlGccVTkoq72M4RlVkoRWrM4nIpAcVoa/o0nh/UpLKWWOd41Ql4s4O4Z7/AFrNJojJSV0KpB0pOE1ZjlPJp2TUaYGeaUtg0+hkpW2FJAzQHPpTC2c96buz0pEtsm3+2KQtjtTATgUlFg5mP3+xpC2egptJz7UWFckBz7Uu7GcVGMg0UWDmY7n1pc4pmR7UuamwkxwbaSck07dkCoqUMR9KLFcxJuyeadvAqDOacpODmnYpSJllwMck08PnPrVde1OzgikUpWLKtjB7U5ZMkDFVw/r1p4boelBvGZbD4PapEcgfWqisRjrmplNZtHVGZaQk1PEcHPtVOI8VaikGQMVhJHdSlctwuVIxx+Ga0rWWPB8xx7dqy4mGT6VctVMjhRk5rkqRR7uFm00jTWKFliEcsZI+8C/Na1tdLbkDcD/sg8/yr334GfsZeLfF0XgrxpdwaPceC76aG7uvNvf3gthIQ6vHtyT8pG0Z6jkdvXfiZ+xAuueJZJ/CGq+HtL0wQoi2zQTQkuMlmOAw7gfh0rx68VLY+nwea0aE+W+vWx4L8PPEsvhrxZoerRqsj2F3FdKr8AlR344/Kvv34aeN7D49/DK/sNQuNPttc1OK4spoDLuKRlzsOGO8jB/H8K+atD/YM8c34lePxB4cIVtpJuLg549PKrgvE3gHUPhB49k0nULqC41HTJoneWxZgrfdkADEA9CB0614f73De9Je6z6rGUcu4map4apavBXWnY+u/HPwtXw1aXFkZbS8mjtR9ngtbbykjGHCoFYsCfc18W/EHwS2j3Sf21piW13NGdjXEYZigYehxjnFfU+nfGOTx7cfbn0yW2Fw6xh2nD7Qp68KPX9K8n/acQXXijRVA/5cH6D1krnrOKfPT0N8iji6E44PGq7lvc+RdZ0WX7VIYoCR8owi4xwP6mu28EfBW4121sNSivFnLgSG2W2L7Tn7rc+3pV7UvDEUbx3Ls7ksw2DpyOK9W+BHxzufg7Nd2sXh6DV4L6aNpGluWhMYUbeNqNnrnkfzrWOJdRKN7eZ7OLylYWM8RRhzz6ROu8AadpXw98E+ILPxHodvealqat9jvZIEBtyY9o/1mCBuw3y5HWvCrvwfJqZEVyYJ48glRJwTx3Fe1/tB/EvSPinrel3+mxT2v2OB4ZEuIsZJYEFTk5/SvKtMvHi81pVMm44BOPQ9PTtXJWmk1GL26nblOHqSpTxFaLjKpvFu6VtEWrL4AaZqiwmHT1cOFO5HmOeBnpXluqfB/V9Ke5+1gQGMvhFhdmJGQByAPTv3r7Q8H/F7RZ7ew0yKzngZmitk81owNxGM8H9cd62PG3wv07x3pbWsATTZ2lV5Lq0t4y7qMgqSex4ranWqR1jK583i6lL2vJi6PLHpb8z827mwe2dkmiMbqcMrDkVWe1JUkKwGK+pvix+zppvw90xLtxPeS3ImKSPNgIVUHlVUDkn1PSvnCW22xsMgjHqMV7FHFqej3PnsRl8HH2lJ80XsYZt/ZqZ5BzjafyrU+znpxn0qxHpszxGZYyYx1ftXZ7Zb3PKWCk3axFotkWaRsEAjafXt7VcvdEt5opCIx5uCQxJ602zt5YZg6AHjoScVaE84bDrHj0Ga45zfNzJn0FChTVH2c46mDa6X9nlJkCYx0HP8xV620xI3Dxbjvzx2yMZxxWppmmy6ozhdqBMds5zXX6R4chhtFjJkExZiWUDnOOxHt61jUxVt2elgskdWKlGOhxH2R41BIIycc1ctLUuyZViCQOB/Kuv1DwcUWKXzSVbOA/tivW/hD+zb4q8SXWiahLp8lv4ammjeW5aZE3wbvmZVyWPAI6Vz+1dRWgejPBUcAnVxUrRX4vsZv7PWlX2n+J5rrTdPublDbGGSQDAQsyEckYzx/Ouo8J2Wr/FD4l30WkW8unanBf8AnXV1bMJHs1EpUyAY5I9Oa+jda8P+EfhJohTSbS9gWaQkokrSklQeu/PQGpviX4sg8A+Ab268KpDa6/cRI6TwWsbOwym4vgcnDZ5pxo6++9j5etnKrSawtO3Por/qeR/HG8X4carHo83irUdfup7SK58zU5EYxHc6/JtQBQQuSD3H4180azey6i4kkYySqNgY9SOw6V1/i+x8X+P7K78WanLd6z9iCwSXUkfKRbuAMDoGb9a9e/Zb/ZT1H4gS2PirXSbHRbK9B+wXFu4kulQBsgnGEJIwcHODWDpSr1fdR9RSx2EyHLP9pqJyXbq+x8/6H8HfFvjzwT4g8V6HBINL8Pwma7dxInmJtLN5R2lXKhSSMgjI9a890vSNW1O4e4aQm3jBXdL0P0Ar9utVsrK80O7067t47nT7iB4JreRMpJGykFSPQg4/Gvzw/ak+GunfD3X9KtPDGiLYaVPatO62MDmGMhyMFjnB2gE5I69K68TS+r07w1Z8dkeeLPMe6WKXKntbb5nyFqTPZ6pdR3A4UhRsGc4rEvn8+Z5Nu0MRgd+lejeI9ATUoY/KaOGYNlnYfe6DmuEnsnEuxEZyM8hTzya0w1eM4p9T2c3y6vhZuG8XsGlQxTQNE6q3zHgjJxWTfWBtHCsQcjIPT2rQjMkMqsByD0I96maRrkF2UAjjjpXdGpKMrrY+Znh1Uha1mc8YVc85H0NRyWwUjBOD6mt64g8xABhcHkgVUkjGCgBLcDOK7Y1rnj1cHbRmJJbc9SarPD8x7V0BtgDnaM+9U7mxCqWBYn04rpjVWx5dTBy3Rj+T9aDFx0q6IWb+E/kaeLNmUHO0/StPaeZyxw0n0M7yPT+dPSAlh2/GtH+zmHJBx/umlFptYdT7VDq+Z0LCSXQghs2duF3cdM5rTtLHylD7QG7/AOTT9PjEdwvyE547VsJAHGMZ+lclSvbY+gwWATXO9zLWye+nhghCtJM6xqGOAWY4GT6c1798a/hp8T/hp8KLOw8Xa6mqWd5q0UEVnHftc+V9nt5CACQML8+MdinSvKNA8Faj4kv4bXS7Ke5upWVY0jRjkkjGCB15/SvoH9rjw38Q/Dn/AAj9n4o8XReJdDmmlmsUZAJIZlVVfefLG4YbAP14B68sqmzOirSbqKnFrU+U/LOcH73em/Zucjke9bM+lqkxIYNuy7FTn5j26U+20h7jbsXOTjqfatvbxte4vqNRytymILV3ONhq1a6SzjLFAB1U9TXXW3gu6z5sMbzqp+ZBEScEgdgfWtfxF8PL3RPCena0zNGbmVIzZPCVlQMzKDj3Keg6iueWMjsmdccqcNZr5HBavEtzFGgXDKcjnoKwXgKsRjB6810bRM+5jknvmqN5amTLAgYGMYrppVLaHmYzCqXvJanPz2+VyMbs9jVMpWs6cdM1Tmj5HGBXpwmfK1aJRZcAUxuasuvbFQleTz+tdKkefKmyuePb3NKPXtWno2of2VqMdyyGQIGG1SOSRj0NRateLqV/LchPLEmPlOOOB9Kak72IdP3b9SkADigqKdswOKUJ7VfMZcruRYIppTAzmpygz0pNvWnzByFcLz7U8RAjOcVJtpdv1o5g9mVpE2EDJOe9Nq2F20hXd9KOcl0iuibyecYpTFg4P581OIwDilMfHQU+cnk0K6qAMClKmpSn4UYNO63Dl6EJHrSqMmpcZPNAX86dxcnUjxjPejbk9DUoFBXdg44p8w+QjP0pCOKmChTk8AV7D4Z/Zu1y90q6v/EUN54YhRVeJrq3XDrgkscsNoGB19fauariKdBXmzvwuAq4uXLSWv4Hi2wntRtIJz+FdF448OweFvFV/pVrfJqVvbuojuUK4kDIrD7pIyM9j2rBYEkVvCaqRUl1OStQdKcoPdERXIFM21PjI57UxlwfatDlcehC4+bgce1IBx6VNjFMdeeaEZtEbcdeabUu3IqIKc4pkWDvTSKcRzRigloZj1o2j1NOxmgjNAuUaOaM47UuDmjOKCbDd2aWlo7cdaBCUGgjgmkxkCgAjRpZFRFLMxwFAyST0xUs9nNagedDJCT0EiFc/nS2l19iu4LgKHMLiTDdDgg9qu+IPEEmuyQl4Uh8lSAEyepzzmobmpJJaHVGFF0ZSlL3uiMqg9KAc0hFanENzzQMVtHwrcHw3/bSzxNBuwYud4+bb9P1rEKkLzUQmpXsbVaNSjZzVrig5pR1xSAYpaswQUUUUDGkEY5zzSnmlopiGjgUucnil7Y4qS2ZYrmJ3GY1cFhjPGeaY7kfagVreIbyxvZoWsY/KRVO8eUE5z/hWSOtDELjIoK4paKLCuID2pcH1ooPSgQE4pvU+9O74oA5PFFykhAcU9Tzk00dKKYIfkHNIRg+tIEx3p2cUDEI49K7/wCGWmW19FqZuZniCLCV29yS3X8q4Aj2r0P4Xr/o+q/7sI/V64Ma2qV0e5lEIzxKT1OJu2C3c4HQSMASPc1e1S1RNGjkG4udh68c1l3Llr+5AHHmMc/jXW+I9DjtvBtpercbndYt0fynG4e3PFEZWjE450faTqNdDhMdKimOIZf9009j/KopMCOX/dP8q2ex4j0MmijvRUmQUUUUAJS0UUAA61chGLNv896p1eix9kPvn+dT1Y0SWykQE9smpo/n9qits+Vj3NSp8pFUtkaR3PWPAsRiuLnLBs7P61zuog/brkdf3rfzrpvCB23Fx+H8zXMagc3tyexkb+Zrhpv96z6vEq2Epj9N/wCP+H6n+RrK8Uj/AInB/wBxK0tMP+nw+mT/ACNZvik7tYb/AHE/ka6V/ER5v/Lj5mSefemk80Z+tITXcjkuKGwantb6aymEtvM8EgGN8bFTj0yKrHntS9RQ9VZjVRxd0S3F1JdSGSaR5ZDjLuxJP4mocikPANB60kktBSnKTux1HOcY49aaD6mnZoJ06CFcjGaFXBpwG4gDrVu/0i+0kJ9ts7i0LlgvnxlNxGM4yOcZH50BvqU6M0U3jNBKY7vRSmJkUMVIX1pu6gYtFM359qN3rQQPopoJozQVsOJxRuHrTO/PIpOnSgEr7Emc0UzocZp248Gi47NbjgaXdyKjz+FaOhaDdeIbw2tqYhIE3kyyBFAyBnJ+orOUlFXZ0UqM6slCK3KmfzqVTnnt9K+gIdD8CeC9KtR4jtLGWSREWOUQtKXdUXzfu47nP41z/g7Wfhza2ci6tDbGbzCRutHfgkYxx6dj61439pNpuMG0j7dcNKnJQrYiMW+j6ep5NEpJxggfQ17xov7EPxj1/RNN1ex8MQTWGoW0V3bSjU7dd8UiB1OC+QcMODyO/NM1DxL8JxayiCyt2nZSqFdPcAMehPI6Z/8ArGpLD9tv4yeFrK20bQPGrWegadEtpp9s+k2LiOCMbY13NCWPygctz61cMTWxC9yHL6nBjsvpZe1asp37E95+w78ZdNtZbibwvAI4lLsV1O3PAGTxv54HavKvE/g7U/BeowWWqxJFcSwrcKI5BINjEgcjvlSMdq9Yk/bv+N15C8V14yt7iN1Ksj6JY8gjGDiEHpU934o8C+PbIahrk8M2oW0Kwg3CSwsVALBVCHBG4sK561evQadSOnkejleBo41SjzqMltc87+Gvww8S/FrXpNF8Kad/auqR273TQefHDiNWUFtzkDqy8Zyc8V6Bd/s2ePfhZLDrPj3wtcaP4bSQQS3b3MMimRwRGg8t2bk+3brVXwF8YdM+EeoX+t+CrltC16aze1jnNu03B2ttxLvXllXn2rI+If7TnxN+LGgjRvFXiltU0ozRztaizt4l8xPunKRg8ZPGcc0lUqV72jZHTUprA1otTUl5Hpa/tLeIPCngn/hCdH8VXmn6DDEYks4lX5Udt5CybN/VjznvUOlftSeLoYTGfHGqYB4LtuPQDqVOelfOxlM7bmYscDJxjtj2r2j4OeEvhhqngfxFf+NvEaadr0RkTTLH7YYjLiAlSQI2BBk2rksB19c1zSwKa3Z68c3hTleNKNr9vzOyi/aj8XqWMfj3WF3dfLlK5/Jaxr/x7f8AizUH1HUNVudTu5yA9xdSFnfHAyTzwABXh1vMVKhsg4GeK6DStfls5YlE+IlYEjZnjIz715WIwkuWybPsspzmhRq87pqLatdLU9j0bWbiz1K0lS4kjCTxuT5hC8MDzX1hovgkfGVpNT0vTLPxDHaH7MbobGEZ+8YwWIz1B4GOa+ItM8T2V3LIweRggzzER1NekeBf2g/Fnw4sJrTw3rk2m2s0nmyRLAjhnwBn50OOAvAPYV5Maai+WotD381hUx1NVsvmudd9j670P4CQaXrdjceJPC+nR6LFLvuTNDC6BcHqASSM47VT+Kvwc+H+sa5bS+H9J021tBbDd/ZyGJTJvJyQuBnGOory7w3+0rr+vaXND4p1fUNVjlWJkEEEIWNstuztC5yNvc9KuL8WLTai2s10GZgiia3AGTj0PvWvPSjFwitPM+NpZfm6xKxFeo7ror2Mj/hn7Wroz4TT0t1dihadssuRjgDjjP4ivMdY0OW11WO1tYCpkIRIkySzZI4yB3r36z8e6g80UbPEUZgpJwMA8Guin8M6Lqt5HcyafbvcQsGWQDaVbgj+VcjjB/CfWUs3xOEu8QrrofK2oaLqfh65ha8t5LO4zvj3kZ+U9Rj3Fe8fA74rx/YtVTxRqubgyRm3aRP+We0ggbRjOcE/Wtfx38NIvGdoZYWkF9ZxOYYY9oErNzhi2Mcj1rgvhp8HPEHjPVLy2s7b7ObdAZHucooJPA4ycnBqI88JWjrcWJxmDzPBylXlytde3/Dm78ZvG+neLbmwg06QT29uj7pCpALMRxg+w/WvAdf8MxNfB44o8SkBV2Dr7cV6frHh250jVLqxuFCXFtK0Mi84DKcHHT0rS8M+BtX1N4b+302W4skkwZ/l2Z9MnuKbU5tt3LweJw2BoqKknHpc8f8AFPwku7bw1HcyJbW5Eyg4XL4IPoO3HeuUk8NNpunx28MZumMmXIXHXB/pX19/whaa4y2WrWiy2rMDsMhHzDp905rRsP2Q11XxK5fNhoL2wMZhnDyednBXnJx3rqpxqtWiclXN8vpyc8RZN9j41l0SFg4S3RpD0DADvViHSo9NDE28aM/Xad2P0xXu/wAR/gfHoFlfpo0d1eX8EwRF35bAbDYGAOleN3unXdlI8N6jwTRY3pMQCn19KyvUvY+jw1XB4iHtYbGRIqpIXjRFY/eOAM4/Kvfvg/8AAN/EOmW2v+IWsU0qS2aQRJOwkIKqUdscDnPf+VaujfsoXujaBdar4mEaywRtPGbS7LJtCbgGUqDzgjg9683m+Lmoal4MvvDVnYyQWN3AsQEVyw8gAg/KMDrzx71py+zd6iPMq455hB0sunaz1a7eR3PxJ1v4daXrug6ILOC9i0+aWO8EKSK0f3MB2HLfr0r0jwh+0d4T0F9H8N28Xk6PDGtul/vxHEozjcGAPpzz1HWvjvUDcWt4PtRcOVzl2yfzprawIl5lwc+uaUK04vmii62R4fEUVSxE22vPr3PtzxT8Zfhf4jxb3erRakLeN5jBbmQFu20MFwcjPGa9D03xP8L9Eu7bUp9RmAms18qzuEkmRUbGGClThsADOf61+dUdxPGs5Nw4WdBHKNow4HQGteDxbLFLHKszGVI1jEnlJnAAwOR7VvHGyi2+U+fr8G06kVGnVasffuj+PtA1/wCJdm2mu50OIq+3yHQySBGGAhUcZZTnP+NeneLPGtnbaSUQXOns8UjJPIAgGyMt6+w7dq/MOH4lazCpEGqXkC/9MZPL/wDQAK2fFHx38ReK/Ctnomp35nt7R96T4Pnt8rL80mctwx962p5g4xatqeLi+BqtarTcal4rR3f4ntvxH/ah0bxHqkUXha/ljIUsxMMkfzAjbgHg4x34r0L4XfEGw+NngPUfCHiy9S41K8MkCw2xNvLcW2Bzuyo3YDZ2847V8HaVq+nafetNOs8gKbAIipxnHY13nw68bnQvF1jrmkSTWNzYuSs0iI+AykMNvIIK5GPfrXLTxUo1L1NmfR4zhSgsF7PC6VIap+ZL8U/glrXw88ZjTH0ycWV/O/8AZ21xKZYweAWAxuAIyP6V5xqegx2et3UV1AsdxC3lMjgAqR2+tfo3pOp6D8ePhlZX80kL+JbYPCZI41jkglPDFU+YhWUZ9SPQ1m6l+yxB4Xgv9Q0WCLxBqN7OHkN7FGpQYPK5UjGeSOtdbwbcnOi9NzzMPxfGlSWFzKP7yOmq3t1ufm1Z+ENNE0jzRNdAsSBLIcde23B/Wm6Z4TtLZpfMVHVnO0SchVzxjjPT37V+h9r8CfDvhywnnbQ7C4uJXM8zi3EgBPJABGABnHHFfMviz4Ea5F40e002C3mtb+aWaBw/lJCgYna+emB6ZzxWM3Vpbs9bA47LMfJ+6o26nyzJbmF3jYZZGKnj0JFMECu+CgHuBXuOsfATxRrviaPRLLSJ59SSNpP9Hi3JIvyndv4BHOM/hXB6h8PbrS5jbSMFuo5jFNG6kGMrkEH6EV0QxOictDlq5ep1JQotS66eZw91aokeVU7s+tUmtXJ+435V2+q+DLmBIzE63BJPCjGPzrMXw7fCZ41gZ2TG4Lg4z0/OuqOJVtzy6uU1VKzizlns342o9RNZSyMcYGf7xrtLfw/O0+26ikiTbkE8c/rVHUdPS0v9iHKADBJzzWixK2uZvKJKPPYz50863SPGcYzn6VWW03MFwAB/dNdZpXhebU4Q0TxmRs7YmyG4IzzjFbKeBtTisJGNqN6JklXVifoBz3qHiY7JnYspqW55R0OChs1RwwzuFew/Af4C6n8ZdUuXs7+wsbfTZIGnW+V285WLcKFHP+rYHp1rf+Dv7M+tfEjVJ31rT9V0Pw9bRM8uoGDyWLjG1V81cHPOT2A7E10PjOGx+E93pWn/AA38VXtmPIn+139rdpNLI/mLhJdq7flAYAED7x+tTOfK7yOWK+sc1DC6y8j3T4hfFnwD+zl4G1Dwx4Zu7BvEenxTfY9GVZZkS4LiUJLhvlAZgw3Hp3r4c8V+Nde+Kmr3Wt615ct40rALbQiKGIHHyoo4A/Ek9zSanYatrWsX2oavey6jf3UryT3MvzNMxPDEkDn+VaK20dhYl2UIowWOO54zwPpXNVxKatHU9bKeHp0n7bE6d7nL2ujS3WowWYTZLNIqAOcDJ9SelfQfw6/Z91bxzb6VpFrZ20PnyuIrqRgoDqCzB2XJzgkDI9KT4Z/speNviPNp99No8mlaDdqkyand+WylDgowTcGYMOmMV9+fCDQPD3gXw5pvhTTmtjqWn2iG4EasGZgNpk+bJ5IxzzjAqKdKVeS5nZL8Ty86zmhldOUMFac/LW3qeVfC/wDZr0n4V31jLLbyXHiWO1zJMblpEG7KtsUADHHGRn86f8YvCH2eYaxJASsVsWkAbMr+WGIAyPr3719BalrOm6Te2gu38uW8JijdYS+cDOGYDgc9TxXl/wC0X4I1eXQ7jxHZfYJrDT7GV7mK6JVlUKxLKRweD09u9bYrDKFN+z1aPg8rzeriMbCeKla+l3+R+WXjvR7K1uze6RaTWGlShNltcz+dKjHJbLY5GelcgyfL06jpXqviLThqVt9nGEUMCCFzjH+TXnus6RJplzsYlk2ghiMdanC4jmSjLc/Vc2yr2KVWkrxdjmrq0B3FEAxWdJFuHIrekjWQsMAiqs1qmeEAr3qdW25+dYjCXbaMOSMg57UkBVHPmAEe4zV6W13FgAOvpUHkEZyAfauyNS54s6Di9EUbiP7RMzpjaeBxio/szjnitHyNo6D86QxE5rVTOV4e7u0ZpiYEdOaURkjkVo/ZSxBK5pssIL5QKPyqlURLwzKPl5zR5JPStGGx8wAlsE9QK0LKzjg3NIBKDjGRn/GplWUTangZy3OeEDN0BP4VLDafP+8U7a2W05UIMa4yPWrEmi3MVil40J+zs2zdkHB9x26GsPrSWlztjlc3dpXscy8DLxgdaBAxGSowK3PsyMoYopP0pjWgJOEAHsK1Va5xzwTiY3lgY4pUi3uFAGTxWi1nu42jA70gtChDDA+lbKorHH9WlfYzri28kYIGT6VGEGK1HjDt8y5I71WmhUEBV/Kmp9CZ4e2pU280mD0qwYvY0nlYPfFWpGPs2QhMnBpwi5AUZp6oAehp6DacrkEd+tDnoVGk2RG3klIRULM4KhRyT9BXrfxF/aA1vxh4V0zQlifSYBZi2v0VzIt4Nse1zuG5TlCSAe57V7BpeqfDr4cfCfwp4hGl6Vd+JHs7WSRLERfbBIykO5JJIII5BGea+a/iH4tHjjxEdTFobPMSReUZN5wueScD19K8iFRYqr70NI9We7ODwdF8tTWXRHKsmCNoA46DtUTD9KsFOM1EyYNe3FrY+ZnHUioyKfsHfvTdntWtzFx6kW001hg1LwM5oCgjoKdzFwuQdz6e9NK88d+alK4J9Otbmu+D7vQLKC6uJYJI5WCqI2JPK7u46YpuSW4lSlJNpbHOFOeRQY88jpUpXmgiqMrELrgdabtz6VMRzTWQdRmgViPvjvTW608ggUjAYHrQQ0MoBxQRW3oWjWWp2shnuxBMrY2llAC8c8/jWc5qG5tQw88RPkiYmeKQccUDJYAAkk4GO/pWnqnhvUtFiSa9tGt43IUMxHX069eDV88dE2ZqjNptK6W5mHpUZ609jSfSrMLCA4pR05FSRQPMwVEZ2yBhQT14rt9J+FVzdRu2oXBsWBBCoA+V7k8jH+c1hUrQpfEzvwuX4jF39jG9vuOP/tS6GnCxFxKtqDnyVbCk+4qljnip7qH7PcyxbtwRyobsQCRUXFXFRtePU4q0puXLN7aCbabgk808HNGOc1oYDaQ9DSnrXZR/C/UJPh43jAXdp9gG79x85m4k8vGAuBzz16U0rjOO6DGaTHXNKBS0hMaevFPx3zTc84pTnHWgLhim04sCPemNyrY644oGhwz9RQDmuz8beJPDur6VaW2i6ebOeOXdK5tUhLLtxjKkk844NcXimimrDs/jSAZrpPh1o+j674vsLHXr5NN0mYS+ddPOsATEbMvzsCB8wUY75x3qX4l6NougeMbyy8PXiX+kRrGYbhLhbgNlAW+deCck8dulDFY5gHgUmcUUU0AZz2rvfhF8KZ/izqupWVvefZGs7dbjIi8zflwuOoxXBY96khnktyTFI8bdzGxUn8qpeYjR8S6K3h3xHqmku5lawupbUuV2lijFScds46VmfeFLJIZGLsxZjyWY5JPqaQDOeaGMM5Neh/C45t9V/wB2H+b154Rya9D+FY3xarjniD+b15+N/hHv5Lrikjhrhc3E/wD10b/0I1va/YC38KWsvmAkiLK7cYJz3rDu8C8uBnpI38zWzrllJD4ctpS3yMsbY3evSps2o2OSc1CVRNXucc2eM80yX/Vyf7p/lUxxmo5h+5f/AHTXQeA9TI7f59KKO/8An0oqTIKKKKAG5q4umTMoPy4PqaSzgSRmLDcPTNbhtHijjLAAMOMVSVxpXMObTpbeIyNjaPSpYeLI/j/MV1uu6RbxeD4LtVInOze27IPJ7flXIxn/AEFvxrPmTeh0VaMqLSl1JLU5iP1NTjr+VV7IZiP1NWfLZTgj/OaroiInrHhU7ZLk/wC7/M1z2o2skUskjYKM5xj6mtvw1dQq9wGfaTt7e5qlrg/0dTjOX/xrhheNVn1lVKeDi77GZpn/AB/Q+mf6VmeJ/wDkKsf9hP5Vp6b/AMf0X1/pWb4n/wCQq/8Aup/Kun/l4jyn/A+ZkZ5opwA7800gg/yrvRwCYNLQOlFFh3CkxxSnjJoqR7jT1oBwaUDmlOMHpQIEco6sOqkEfga3vFPjS98XCD7ZDBEYSxUwhh97HByTxxXP0UDvbQXdSUY46112h6V4cufClzPf3iQ6uDN5URm2kgICnHufzqoq5OxyrTl0CkAAY/So6M4x60Urj2GsaSgmgHJ4NInccDmlpMgU3NBXkLnkd667R4fDR0yD7ZLF9p25k3NJnOT6DHpXIU4cAcmsatP2isnY7sHilhZOXIpep12tf8I5Hp0osPJkuW2hQN+RyMkZ46Vj6PoE+tJK8DRKIiARI+0kn049qywcHjirljrN5piuttN5auQWwoOSPcis1SlTjaLu/M6Z4qjiKynVjaPZHf6RfeFdN0u3ttRitTfxJtmDW+87snOSBz+dcfquqJB4lurzR3FtBvzCYV2ADA7YrGnuHubiSaQ7pJGLMcYyTSB8ms6WGUW5Sd79DoxOaurCNOEUuXZrc0tS1rUtflhW8u5LkqdqBzwM4z/KpNW8P3mgCL7UqASZClHDdOvSsxX2sGHUc9PfNWb/AFa71QJ9qnaby87cgALnGeAK3VNxkuVaHL9YjUhKVdtzezv+ZEsmcetSxtmqynmpVbpg9eMVtZLU5ISbehZBwOfyJresbJ7IyLeYtQwBw7AZ/nWp4DsbU2t1Le28LkMMfaFGQACTjI/lVLxxq8N3fpbwbWSHDCWJgVYMoJ6fQfr0ryZ1nVqezitO59rQwscHhVi6stXsijqMlujobdw/B3ENkdeKqo49apeZ0POKmikznsK640+VHiVMT7WfNa3kXY32lTyKtJOwHBIFZiyEAZNTxyeh4rOUDopVTSSQg9eatRTnPU4+lZKSHHtVmKQgZB61xzgexSxBvW188R+R5Fz1wcVpW2rzJKrCeUYOfv1zMMmCMGrsU5z97OPevOqUk90fSYXHThZJnpvhrXrqSKZ/tczH5B85z610tv4gvS6BrlxjkNxnP5V5t4W1SC2FwJ5I4g2wAscZ6/4ivUvBPge98dSj7LJ9msyGBvjGXi3DGVGOrc9Pzr5jE0XGex+sZZjqUsKpTkrlr/hO9bTI/tWc899jf0rc0L4ta5pto1tHfBEdizPsUNkjHUDiu18Yj4b+BNLntL/TdLOtvZSTWtu1oxkmYIVUkgELl17kYr5o07xBLHuS6lwVQbTs5Ld+lYKhNq6HHMMFiZezqQsfXl78YtHsrJDHfedOqqjGJmZ2+Xlu3eul/Zz+K9ho2pX8r2zXQnCKxVijLg8cE4OS3X9MGvjrStYS4WRnm5DAKNjD+hrsfC+vtpjLJbzSJJv3K0YYEfjilGUqU1Jo5sTkWDx2FnSpy+I/ULT/AITeErnVDrn9hW0V5dq7XIBJWcsMESKSVb16dcHmtq78J6C+mJYf2RYpYx4McCW6qiY9ABxXw98Mv2jL7wzZajHrGqaxfC4MQtyJyTbhc7sbjxnj24ruY/2kIfFlnd2P9oatHiMB/MdFByRgZXnJOele2sVSnHRan4niuEs1oVWnJuKOj8a+LfBNlqn2e10y6t7m2nwZ4sCJgrAHgscg/T+dd3B+0D4Ak8Z6f4XkST+1rqWOFc2o8tHcZUM3bP0718U/FD4zaXrcz6dpmm3Fs0E7h7uZlAOMqQFGcjPPJ7V55f8AiGdddXWba+jhvonSSKZAA8bIAEYZ7jGa8+niZUpvsz7T/VD61hlKbakl1Z+iXxA+HmgeF9L1nU5bq4lhjtp7yKEuiqpRdxUseWySfpivL/Cp+CreAR481Sz0/WL6CHOoQzv9pmVsqpTymPPAUqMdDnvXkvxtl1vxD+zr4M1XxJ4iuta1ObVEuFFwIh5aSwyjaNicjAHOcduOK+d5IFKjCrnHB2jNdFWtCnLmjHcyybh/E43DSjUxDXLKzt2R9E/H/wDapvvFeqtY+C9SlsfDZthC8ZtEV3Y7gw+YEhcYHGK+ctM8U2elyXELOGldNmwIcAj8OKxNa1230xAsju0jZwoXPp3PFcDfanNPcPL5rZYkgg4qYUZ4p80z6l4jCZBTVDDLXr3+Z6H4p1lNQtvM83cdu0tjb3B/rXHi5KsrBs4rLttRdsrPPIUxwGbIzQ+pJFlVJbpg7f8A69d1PC+zVtzx8XnH1mSqJ2OoHiy/CEfaZAD6AVNa+Mmj4kDyn+8QP8a4yXVugxj/AID/APXqIXwDVr9Ui90cSzmqn7szuV8YyopACk54Ow5/nSDxVNNwWAz6RmuLXUXAIHIPvTDdf72fZqn6jDsbLPay1cztYtbjkuoVlmUAuAcriuo8P61FdastvCSU2l3IGOnb8zXkNvd7JUY5wGBOTW/p+oBkMkfXJGeR/KsK2Cjy6Ho4PPJyl7zPpbwx8Z9c+G8jJ4fe2t/NCtK08Ak3EZCkZx0BP516V8G/2zbrwjr+t3PiT+0vEQ1Nk2wwygR2zgsTtRzgZyOB6V8XR67ewhoobhkjJ3ELjr069a07GeaO2jmViJCxOce9ccYVqCTUtjqxVDLs25lUpay3fU/UX4F/GbRvijpuqWHiC8toru5kMdvE0Qt5Nhx8oIJDEEgDHJx3rZ+IGq+AtAsrnREaF/EVuIwMwM8yMQCCX24GVPryK/Nrw14r1nQtLiurO5+zyRyN5ciIBIp3A5B+v8q7TSPHuva/fXd9qGq3N3fXciGa4lkG47VAXOAOn4dKuWLfs+WauzxHwap4tVcNVcab1t5/5H2d4G8VafpmuPJJby3ZmgMKiNlwnzBsnOOOOteH/tT/AALj8KrH4p0LTray0iSXyp4rd3ZvMckhiCMAduD1I45rzj4X/GC/0fxGj6zqD3WnkNG3nkMYySBu4GeO9favgXxd4Z8YeFmj8RXFrqNvHOlzafaV3KAFyhUAcEc89eaVKUK8fZyduxx5hQxXDuKjjaSck7J+Z8I+C/hTq3jmWdInjtGiClRdo6+Zk4+U47f1pmqfC3WtItrln0e8IWbyTIsBwxBIyOMkcHnFfonpug+GvFupXlrCjtZ2hiZJIpWxMWySDnqMpjHTrTPiJ8J9I1mOG+trCBJ7W3eJVCZLLnI7dck1UsDaDlF3sbU+PWsRGE6dk+/Q/NO08ISXUs6XSG0MIGY5kwxz9eldXpfws1DR7X+17zTpIdPIVI5pQmGZvukAnPNfQT/DTTdd1m4xo8d9d7M7Y0YsVHy9AfoK9n0j4DJr3hGystcZbWNVjZbRIgzRBDlAWJ7Djj3rmw9CddtI9nMOMKOFUXZa7nwzZ/Cu6/t2S9mMVlDMWKLIBkZ7AL+NdD8KPB1n4m8aXeneJkmg0G0t5p7i40qRjKQm0rg46NntyM11H7U+i6nYeMNH8IW+nShri4DWjrjF2ztsQIPYkgg9/wA69V+Bnwl0j4M+Fbm5+Ikej2muSySSW7S3Su5txGu6MZIBwc5UZ6j2FdFHDSjUvLoZ5nxBTq5d+6l71RaKO/qWf2q/Hes2vw/0aXwy13ZWFzdm2u5pIsSNG0R2qSeRk/0r468Q/D/V9Ehtri7tRGLp9qBXUsW69B65H519QWX7Y3hnxlJeW2s6Ouh6bCqPbee32mSRs4xtVMIQADnkc1l+F/jX8Pbj+0LjxHaQz3Iv5JLLdYvcbIRjyyCFwrcdOtGK5cRU0noebkVXF5Jh2nhm5X+ep8/aR8Mta0y92eIPC97GLlkitI7m2OZZMnKqOpPTivrD4AfsvaRp1udf8VeHtPktL+22f2Jqll5kltIjn5sMWB3KM8AdBXlGtftD6heeOrK68q0ay0vUftFskkRR5IwcBXYnOSpPTpxwcV6742/aE8N+LNB0rUmku7NIhJL9jYuku8AY+62COeGJAyR0qKPsabct2jozvEZ1jqVOg4ckZ7tfkcZ+0H+1jpF3oFz4M8BW97pptbkW0moxotvEkUTYKQgZJU4x0HGa5X4UfFt7mW7v5lEGqHEMk8UpQupyxJZic8/yFeFeO/FGg+IfF2oX2l2n9jWrqpaK4YBpH/ifAzgnI79ee9YVtqVvMkjRzI8aYz1A/lXHVr1ZVOddD6TLeH8up4FUGvelq297n174j+OZkvzbwNc3b2ri3nkW4QhS56rzkgDGT717b8IviaNRSLw/rUgvrK7V44XlAdccnYeDlSPX+tfmwut2xQESKUP+ycfyrpPCfxK1Xw3pup2GlXMcdvfRmJy0W5kBUqSjHleD2+tbUsVOM+aSPNzLhPDYjD+yw7XN0Z9A/tjfA8+HdfvPG1ldpJZ6rexW6abDbEGJvKO5i4OMEpnGBjPU18pX2mWuoozSxRynGAzDOBz0/GvrD9mf4yXup6nH4R8R3F3rkV3lbN7k+cYtqNvVi/bGfWs39qH4JjQLpvEWj2VhpmjTPBZQWVvhGeQq2X2gbQD069jWtSCn++ohlWYVMtlHJ801092XddEfEMfhPUZYwwgwD/z0kUGsu5tDBcyQSKPMjYqwHPIr13W/D+o+HVtmvIVhFwWEe1wx+U85x061xep+HzLM80KF5JZMsv1rSji3zWnod2NyOEqXPh3zdziprXnCJ+dVXs3JJ2j8xXUXmkS2lxLDIuHjA3Y5AJGev41RFg8g4Use4FerHELufHzyqo3rEwxaADlRn/eprWbE8AAf71a7Wq/5NNS1V2woJP4mt1XXc4J5c+xnLbEY4H+fwpFs0LYwuT6VvrosxXcIzjHUqf8ACrVj4ZuZ9koWLy2OQTJioliIrqbU8rnNqKiYaWLoinAA6Dt/StAeG7tnRW8pVJxy/Tp7V2ekeHCZcTpCQBlSp3YOR2x6V6t8Kfgh4m+Ket2EOl6dcvpkl19nudTSEmC34DNvPODj27iuB4qc5ctPU+ieU4fCUHiMbLlSPMvAfw7XWb6Kygg/tnULggwWdtGXlOBkgL34z+VeveOP2fLrwx4N0+616JYra6ZPLsvnEqkoWAbGNpBP619dfDj9kqz+GGr2WptNca3qVhNJLbXO5bcR7lZNrJyGwG68Z9OBXn/x9+HniPxFd6nqyNczaajSXghlk3LbhEwQvGBux654rmrQqKPPK/McGDzvC4jExwuGaVK2ra1fkfnv4s8KjRNRmaBUWxlnZYEEu9lXsDxnoK557f5iACcda9a8UeF73WpYltYkeNHJLO4Xr0xn61yGseErvRmjS42eZIpcCPLY5xgnFdWGxalFKT1NM0yiVOpKVGPunGtbjnj8aheLHPatmbT5yxRYnYnoMGq8mmzwS+S8ZSTjg16qrLufKSwdT+Ux3jGeOvfvTBbs/pxXUx+EpkIknWMg/wAIfnP5U5NAkjkO2KIR49QT/Kn9aiupSyqtLeOhyDwZPf8AOmi2LEBSc/T/AOtXWr4e+Y/PGuT2XNex/BH9l7XvGXiPTNR1zRLk+DiZPtFxDdRxSsfKJQKgbzDlinAHOeOtV9bilc455dKm/fVkcZ8Kf2Y/EHxGsDqt1L/YOiyQ+baX09q1wt0d23ChWBAyGyT3HSrOm/sn+Lte8eax4a0u60q/OlpBLNqJna3hZZQGXbvXduAzkEdjgmvbPjL8adE+HPgnw94V+FmrS2stpNKl6JLZnmhjxuC75kznzHPIyeK+bdN+NHjfw5rF5qGneJ9Ss7+7VEuJ45BvmVRhA2Qc4HTiuenWrVW2np0HVw1Kklo7np3xa8MeBvh74R1jwncxWS+MrG1t443hhdn87dGxbzQAvzKzZyOmK+bJo+u31rd8R+JtS8X6zdatrF9NqOpXb757qcgvIcAAnAx0AHQdKyXi9RXbhoeyTu9WcWLkqzVolDbTDHknnirbxE5wOKi2EivQUjxZUyB4xxxTCoNWShx04qNoyCR1Fac1jCVPsVmTceOKbtNXI7RpQduOPWo5bdon2tjNWpowdKS1sQbM1YuNRurtAk9xLMoOQruWAOMd/ao2Uk9eKTbzVXVyeWS2IcHBrR8P+G77xVqqadpsSy3bo7qjyBAQoyTk8dB+NUyoyeOParuj63f+HL9b7TZzbXSqyCVVDEKwwwwQR0qnJ20IjBcy5itreiXmgajJY30YiuYsb0DBgMjI5HFUGUjtxWlqmo3eu38l9eSeddTEF5NoG4gAdBx0HaqrRHAyOKcZXWpM6d37pVKllIxSCI9+T7VYMbY6HFOihZpAF+91x7U3JLVmcaTk+VIt6H4T1TxDLssbRpADzI3yov1Y8V2kPwohtdJYXjM17JGfuvhI2PTtzir3hR9a8LeFdWuHt41jQeZFDcgh9wHJAHbGDz6Vw194ovdT1tb+6mMZ3KSkZO1VHYDNeLOpWxE2qbskfbUaOAy2lB4iDc5rr0Myz8M6lPq72VtGJriFyPkYYyD1yeK6n4jXuqvNDFf2kdvC53IEkEgYjGSTk46n061o6b8QrHS5JpPKMxmUbvLQKxIbvngj/CuF1nUrnXtUkupXZmkfKqzZ2gngD07Crpe2qVU6iskcmKWCwmFlDDVOaUnqjOYY57Vo6B4fu/EE8kdois0a7iXOF6jAzjAP1rY8PeBrzXoHn3LDboQGYckcZzj05610suvaf4LtIo7E/aJJ0KvLA6MTtHG7g85PFdVXFfYpas4sHlCcViMY+Wn+foHh+10bwZbyyajJbHUFbYGBYnbhDjaQcc8Zx19cVyXifxjca3K8aKILUNlVjJVivGN3ODwBWNqGo3Wq3DTXk73ExJO9zk81Vxxgc1NLDXl7SrqzHGZu3T+rYVcsF979RpAJ9u1AIWg8D3pCfavTWiPlndu4A4oLDOM0lJimRYWtBPEGpJpbaat9ONPIKm18w+XjdnGOnXms0kjvTlJPanewDsUUUUhXE28570ueKD0pp9qBDs009PeiigaAfpTsim0UDsL34FOzkc9aYG79acOaAQUUZ4zScCmMWlxTdpbOKk2jvmnsOwylHy+9JTwM0xBjPWvSfhJGGi1b6QfzevN8cH0r0r4RjEGrfSD/ANnrzsc/3J9Dka/2tHAXy7b66H/TV/8A0I10viNyfCdquANqxVzV+f8AiY3g/wCmj/8AoRrt/F1tAngO0kSPEhjgYtznkDP86xnNxUF3HToRq+3k/spnmQUuwUdTxTbhDEjq2M7T/KnxkJKrNwAaS+kWUuVPGwj+dd58kZ1pp0t4GMe3C4zuOKglhMWM4554ro/Ctg9zbXLDGAyg5OP4TWW8aTBQwzgdqzTuVKnyxUn1M2ipZLZ48kgbfY02JAzgEcGmY2LGnuqF97BR7nFdEsktyqLtLhAB8q+wrmLWBJCdzFenQgfzrdsNXawZjGYzuAByw7VordSomjr19OdANo20RJjA285B/wDrmuYQf6E/4/zqfU9cmu2miYR7HPVRz1B4qCM5sGPsf51k7X0KnUc2rvYfYf6k/U1bLl2B+n86q2XEB+tWByR+FUthroeg6Pw8vv8A4mn6uxNqo4I3j+RqPSTmSX8P50mqyFoAMdHH8jXHb95c+ig7YSxS00f6dF/vf0NZvijjVm90T+VaOnHF7F2+b+hrO8UHGrH/AHE/rW3/AC8Rx/8ALj5mTSUUV3o4AoweKKcPWgaGkdqfBEJ50QnCscEjqKYeeeppBkdKLFFi9t1tHVVffkZJ/GqxPJoIwDRQxMQmkNKabUghQaXeexxTaKAsBOadsbBOOKbT9+FK9jTQrDKAMUuM0lIaCiiigELilBptOA4oE0HNJkg0rHApCOM0DQh5pR1oxxWlB4ev7jT2vo4d1soZi+4dF68deKmUktWzanTnVfuIzx0J70ueab3pR1qt9TLbQeDiuh8FRaVcaqV1aWOGFUDI8shVdwYcHAOeM+lc5kUDnmoqQ548t7HThq31eqqrV7dDs/FfjEXF2U0yV442Ro53XGJOSOuORjH51yiuPSq3Ip2/GMVnSoxpKyOvFY6pjKnPN/Lp8i2GyPSng1WSQYGTzUobj3rVo54zLSNkjHPvUyP61TRuR6VMrZJweazcbnXCZbSSrUb5ANZytg81MknTmueUDvp1bGkkmM85q1HKKy45QeQTU0chPc1ySp3PWpYhI2ILlo2DK2GHTpXrHw5/aE1L4feHzpcOkWOoqZ3na5uZJVkYsR8p2nGBj0rxiObAFTJKDzXDUw8Z6SR7VHGyj8LOy1vxtdeIdTu7+5kk33Mzy+UJC6x7jnapbnAzxWel8Xk7rnJzmsSOX5ic1MspUcfyrn9hFKyPQhjZdWbiag8YxFK4z2ViK6DTPFb2hjVxIFC4J3ZOcDtxXErPnHOT7U8XLYxnFc1TDxluj2MNmlWi+aLPQz42DqwSS5VsZG0dP1p9n4vuE3ul5dKWGDyV3D0OPrXnYuWXdhjz1p63ZAGGOfrXN9Sitj3IcQVL/vEmdnqetq5UvJjeCdznk9Pap7G9GrIltAfMmkIRUGMlicAAcc/5HNcHJdtKVDMx2g8k+uKEvXiwEX5x0bPT3GOc0lgl1Y6nEU2pKKVmj7q+NHwZ8V/Cn4F+E7XVvEs2qWiTJFcaZtLxW8m12TY5AIAHGCBXznGd65z7cV618JP2vvtEsum/EjWJr/QUt1FrDeRtfMswOMklC5yCeSTz0rz745+OvBdvrjaj4JubW6tLlECWUKSKYmA+aRtwAUE4wo9zjms8Rh+aa5EcXD2cSwtOdHGd27o8d8ZI8Bbzo3BklJRS4OBzk4965MsDz3qa5unupXldizudxLHJqlJJgmvbw9F04JM+PzLGrEV5VVsPabBwc0xpePaq+/OcHNQyuQ4rsUDxHXsrllpc/WgXP1zVXzuelNaULyc89q1VM53iGupc+0EtnA/PFAuD6frVLzgcdRQJOelUqaJ+sve5oLOeuPwJqVL4qAA5UegbisvzPanrL7Gk6SZpDFOPU2rbUismfmYAf3j1ra07XApSOT5ByQWfpXIJNVmKcFh0xXJUw6krHtYXMJ03eMjvl16IKFDIy9cb81qWniBViTEUb8dWavOUuhnqM/StK31JY4kU7iR6D3rzZ4ONtEfU4bOqkJXbPSNI8RLBuYvFEd2QM4A9O1fQPwe+JcGnQXVrLJNPapDGwKqQBI2dw+Y+gHbtxxXx62pqOm/36V0ukeIbx7eIiZkULgZPOB0Ga8mtg3D3on1FHMaOZQ9hV1Pu/SPin4gm16xTwuZLeVmHmCR0AlUMDtIIxjG70PSvq3TvGthqiyiFmeeJQ726gGRQc7SRnvg4NfmX4e+MP9gaXps9jqJh1BLeNZGS3MjBtmG6rjg9etexfA39omXw94i1LVdaa81iPUYIonZAsbDYzFeCB03Hjj8anCYiVJ+zm9D5HP8AhaWKg8RhI35V82e++EvjlpaeMr+S+8M6hpEsdmQzz+XvUhmOwgHIJ2133w5+OWl+NodRN5avo81ncGEQu/ml0LMqtkAYJ2N8vOPfNeUftCePvAXhTSfNWK01HXLnY8dtYuoldWzl2ZTwAB3554rwbQPibFeWWo3Wn6XHo10pYsBM0hc4LAkgDjOetdMsXLCz5dGjxMHw3DOMP7VRlGW135H2v4y+LHw30i70+fxHc2UV1bhrixmv7blWBCnymZeHzgYGD0r87/2ivjzJ8WPEDatqNqNPNtCbe0t4T5qbBIWBywBDncM444HXFZXiTxTqviiSK51a5E80alVwgUKCckD8eeea8q8UanY342R3UZZSDw2Dwff61yVMbPFtQSsup9zlPC2GyJPEznzVLaX6ehHD4iRhIUkljPG0FcfyotPEEwZJPNPysGKgdce9c5OPKi3IxIJHzA5/lVZLh9332I/3q6IYeNjor5jU5km9Tub/AMcS3F/NceTncRwXx0A9BUOueKmuliT7SBEsePKEh65zzjqf54ripbwJGcFd3vVR75mGDtH/AAGtY4WN7o5qmcVOVwnK5syX+92beMk560LqToCBOyZ9GrnzdEk9D+FKLhiOP5//AFq6lQXY8R5i07pnRQ6qygKLlgPrWvpWutC5DXHytjJPOP0rh1vGB7/nVuDUDgDjn3qJ4dSVrHZhc1lTmpNntOg6yskv+jzo5C7iUOSOnt9a+1P2WPilpeqwReB9TsdPt7S1tVeznmbe88xdjIPnGM/NkYOfbivzr8M6+bSSYSOoUooGz526noMf1Few+GNWggttL1JIQzwmO5i84c7lIZScfQd68mMpYSprsfTY3B0OJcG4rSotn1R9HfGL4LXGq3eo6TbaVcX8iym4tZLZAON55zwMAMRg5zj6V4f41+CmoeEfBttNJpepR+InvtphRHkHkEMB8qgjPyjvXaeDf2mfFM3j6fW9Xu4bj7VbPaJaGMrbRLncuEBznOeSTnNdndftGaTp/iVNb1qzTVl+ztCLSzCxMuW6lXPOAzDJrVqhVk2meRQhnuWwjTlDmUVfR7vsfKkvhnVNMlkW/s7uxlD7XS5RonVgBwQeelUY4Wj8xCkjRhmO48qRmvcP2ldW8G+MYdD8beGZ7W21HWmY3+mJcRtcxsqLh5kRflYFQvLEdMck14rbXxS2ZH5yCBx61w1o+ylaLPvcpxX9pYVVqkeWWt1bqtzOFlpcbcWNt+EIP9KlXTbHUMRNbARjosZ8sH8q2rn4f6vp9u091biKJBlm3qQP1r2D9n39ne98eXdlr0kmnz6RBLIk9jeI5aT5BtOAMEZdSD04pU/aVHaJyY/FYLA0nWr2seQ74LO2WFAsKqAipkZ+n/66PFPg7W/Bc0EOt6Ne6M86b4UvLYxGRcjJXIGRyP8A61fZnw2+E3wq8Y+MtT0/WNGhD6I6yOlndSCNnDYKtGuCRlemMHjsefbPHfh34R/tM20djqEn9rHQLhkAhee1aF2XDKSNpIIC8cjgelenRwPtKblKevY+Bx/GiweLhSp4duFvedu+1j8yfhxo8ni/4gaXoTSRRRXZY+Y3yYCqXbn6Ka/UP4TeCbX4eeBrrStJ0FNCt53eYf6Ybh5HZQC5LDjgAYycYHTpXkur/s3fBvwlNcapaeHVJ8O7NQufKuJ5ZVCfvB8rPhuEPHeuF+NX7cja3pllafDl9Q0aXzWN3dajYw/PHtIVUDM2DnnJHbiuyjCGETlNnzOc4vE8WVaVDBU5cq3vsn5nqfib9oey8L3M+n+da3FzATE2+QkhhwQcKM81V+HvxXaDfDr6Le6fLHtZkiztJz1X+IHP8q+PLr4hW180l5d2E91fTkyTStcBA7nlmwq45Paqtr8Y/Een3INlcxW6KcqhgWTA7fe615Dxk3UTWx9hHgqnHCuCjaTXfr5H0P8AtQfBWx0VoPEfhrRo7HTAkj6i0D4VWLKEIToo5IwPy718u6zo1tfwODAkkoRhG7dVPqD2r6E+B/7SaahJrel/FDVo9Q025CvbveWoYDKuHiwi4A+4Rn0NZ37SnwJ1n4e+J7KTwnoscnhq5gjzd3d6p2zksWXBO7GApzyOa6a2H9qvrFDbqiMox1TL6qyfM1732W9n8/I+SbrT5rFtlz5iyDqrN9KpywwSSKTbJIzcbjXq+v2D6hqmnWEllFBIhPzMwcNn2+orN8SaD/Y2oQQTwwfNFvGyNfXFc0a0luj7Cpg6UtFJHBeQG2hlyPr0oubIIqFRncSOucVt2VtbXurtbssEcfzEbzgHH5V1Phjwe+ta42madGtxIYd5WEq20DGTz2GRQ6rvdGX1eFnzNWOm/Z8+AXhj4kaJ4g1rxD4jutF/sR0neGGONkeEIXZiG5b7rjC88d67X9oH9pTwdLqIg+G+q6pFE1mYnFraGOxyShX93KAVIUEZUcYGADUnhr4A6RpWmaleeLNSuLO0S2kLPaSC2MamNgxaT5uOh4/I18iywlRFli/yA5PP9BXfSmp07M+HrYKM8dKspuUVsumv5lC4je4iIlk8x8AZkYtnj1Nc/e6VIZ2ICuvHOa6eRME+tQNEH7fpXXCo4bGeIwkaz95HKNpkwbOzJHoagaE7iGHI61132ZS44B+tUR4eaa4dy+0MxPCD1rpjibbnkzyuT0pq5zJiB4xkU0wqP4RWxLYskzqgZ1ViA2AM1HJppjXeUO3pn3/Cu2NdPZnkVcDOO6MaS2YsNq8VEYGGflwPrWybXOMZxUbWwIPy/hW6rnBLBPczIMxFs45x3pZUWVtxAq61t0woNKLUcfJT9or3M/qsrWKCw4BwBik8kkngfpV7yck4Wm+V160/akSwttzOeBtxyAB9aaYsYwK03tg/Xrmp9N0iXVNQtbK2UPcXEiRRqzBQWYgAZPA57npV+1SV2zm+qSlKyRqeC/hP4q8ciOTSNDvrqyd9rXiRYhGCA37w/LkV6Z8RvhJ4U+GejWUd7dRSteebHDeXUL+YxVhlj5ZwNoI7c+hrs/hXY/Fj4d6TJo8FvpX9ix+fcpBeTRybJiuRsKHdy6qSCSDmvm7VL671y8ub/UJ5Lu6uZGlkklYsSzHLEZ/zxXkurPE1bRloux78MP8AUaXvU9Zdz6M+I37Nfw60Pw/8PvCNj430jSfiddiE6nNe3VzPbXf2hVdANqMsIXK7Mqu9X55xXeW/wk+D37OWlX0HiHxFbaj4vudEniubS5ukDygo2TbRFD5LuVKLubP1r4svNWvbm/F5Ldzy3aFds7ylpAUACfMeflCrj0wMdKXXfEmq+J703msajd6rd42m4vZmmkIyTjc2T1JP412ujUnHlc3Y+djajU9pFarY0vEPju71WGVIFW2hlQo8LxgkKVAPzd84PYVxckWcZ4+tXXwfeoJI8GvQoUoUVaKOfG4mtjJc9Z3KbQnnFbPgfWk8L+MdG1aQPtsbuK4OxQW+Vg3APB+lZxTANRtEGPXFdrSkmmePy8klJHvPx2/aVh+KNxokthoz2ktpaPDdT3Sx7p3Lgg5UZIAyBn1PFfP8mWPPPAHSpdrKTk8UECuelQhR0ib4jF1cRFRm9F0K5XIpvtUxU+lJ5a102POauQsvGabipmHFM2E0zOxEVwBjk0bT6U/H6UnfmhMnlIyuKAMEVJg0wDnpVCHDpRRgk4HXpilwR1HWggQjNNIxTqRqBsSiiigEGM0u3FIvPNOoBDDz719D/CP9jbXfi78D9e+Jthr9hZado323zrCW3lknc20BmIUrx8wGOenvg188sBkVr6f4r1vSdPewstYv7SxkLF7WC5dImLDaxKg4ORwfUUn5A12MojBxSbaeVPUD8qaAaq5SXcEzUg6CmqMUuKQ02hdoxShcdRTlXFKQDVXGNPTFei/CltkOqD1EH/tSvOyMCvQvhWAYtT+kP/s9edjtaJ7+SaYtM4HUG/4mN56+a/8A6Ea73xax/wCFfWY/6ZW/8hXn163+n3foZG/ma7nxRdxP4HtYhIpfy4MpuGRwKwmr+zZphpxSxKb6M84PJqGf/Vv/ALpqZuuahnOIn/3TXovZnxz7nReAkzZXZ/6aL/6Caxb+1aCMSRqxY9e/6VJ4c1yXS4po40jYO6kmTPHB9xVtJY7g4aRQoH94CsYRaOuc4Spxj1RzM88rbkfjpkYxTIT+9Wtu5022kmdvMYEns4xWRPGlveMqtlFPBJ68VZwMgozRRTYhvOa0I/8AkHn6H+YqgelX0/5B5Hsf5iotqA+z/wBQf941YjGXHvUFp/qPxqxH95fqKtbGx6DpQw8n4f1qHU+Ux/t1NpRy8v8AnvTNUhKxbuxfj9a5HpM96KbwyKWnD/TIvqf5Gs3xQMasf9xP5VpaccX8OfX+hrN8T86q3/XNP5GtV/ERz/8ALj5mRQpz1pAaMd+9egcA72ozTVB5zT8UDQlIBgCn00igBMZBphNSEZ96Q8VI0Rmkp5XOT0pmKQIKKMc0EYoGFFFFOwHQeCNL0nVtYaHWbr7JaCIsH80R5fIwMkH1NVfFNjYadrtzb6XMbiwTb5UhcPuygJ+bAyQSRWTR2p+QgooxRSsMKcPu009qM9sUCHFTjJBxTexqRrhnQKcYFR0DBTz6VqQ+JNQt9NawScCzZWUx7V6E5Iz1rL7UVDipfEa06s6Tbg7X0FzzmlBzmm0VRg3cfmgU0HFL1oGmLigHnmilA5oGKKlRgByeTUQGBRSt1NEyyrnODUynAPrVNGI71IJOcVJtGVi2rYNSK3piqiNxmpFNS4nTGZcWQ4Azjmpo5u2Qfwqip2ipFk96ylE66dRqxpRTfSpvPKjOeKy0l5HORU8cgIB4/GueUDvhXaNpo2SLeGLZ7AU6MkKM9azIbpg43EbfTNOmmVmGDx9a5/Z6npxxMbXRqbyMUw3ag/eH4msszbVZs7gozjNeq/Eb4Aav8N/AWkeKr3V9Pu4NSNuI7S2WTzU82IygsSMcBcHHcispwUWkzaOIlNNxWiPPRdDt0/OlNz6VmLNjqxzQZiRwzZpqkCxfmaPn5P8AD+IqSN9x7AewrLEvAySamhlAYc/hVeyEsU7nqnwb07w7q3iiaDxJFbzWQtXeNLmUxp5gZB1BGTtLYGfwNJ8W/h0/hoQa5p5jk0G9ZjFHb5YWwJOxWJz1AGD3r2L9mX4B+H/FugW3i68uX1WeMXEEulyRgwwSB1EbHad5yhLc47nnFafiTXI7j7TokEFpBYW0myNImLgBGO0KD+nHevnsTiVhqtz7HLcvnmdJpb9z48lnHQcVVllLZziut8f+DH8OXM91blBppm8qFPMLSgc4LZH+ya4d3Br38PONaCnHY+Ox9GpgqrpVVqh8khXGCRULyk9TmmsenaombGea74wPCnWHtIeqke9N3k81Cz4wAc5plaqJxOq+5Y8/3FKZyR978Kqbs96PM5qlEz9qy1vz3NOExHGaqrJilDmlyFRqlxJSe5qylznAGc9Oazg4wKekmBxWcoHZTrtGvHchc9RViK4J9Tj2rGSYlhkmp45QK55Uz0aeJfc2luCcZB/Kr0GqeQqgBwQO2BXOxz4P/wBerKSZxzjNcdSlzKzPYwuNlTd4M9A0nxGjLDGRKGwF6Zr1j4Z6nps/iCytdYuzpulvJ5dzelT+5jxksPlPYHseccEV88WVwIpo3YkqrBiFHbI7mvSNC1iC+tWdYvLDOUwxDenoPevm8VhvZyU0tD9WyfNPrlKeHlO0mrL/ADPtX43fszeH9L8KT+OvB+sgaPFpsNw1nKfOE4woDpJkbQVIbBB5HGM4r5mW7ktywjZlHQhWxmvYf2dv2kbnwncHSPGepT33hu3sooNPt1tvNaN1cBV+UDjacZOcYHIxUP7XPws1T4bx2HibThpw0rUrm5F2I0CPDOzPLGigt93ylwMDqp45rPEYeOJSqUVbuedluYV8kqPA5g20/hZ87eJvHCT2sttaPIshx++QYAwwyK4G8unnYvIdzMckmo5W5qvIeRj8q66GHjSVkebmGZVMXNymSQ/PKgIwCe1XF2wsMcfjWYk3lSBu45pJ7lpuemB2rpdNtnm08VGEHfVjLm9Bd+vU+lUZJ845IqK7nO9sdM1BM5WIMP1r0YUrJHg1sXzNlpZsN96pBPkdf0rKW6IPQGnrdEDjbj6Vt7I4PraNNZFfOAD0p6y/OOBge1YqSED7xBPvirNtMRuByefrSdEdPGc250VnqJjwo498e30r0HTvF9zBpttCvlpGkSIvHOMAd68oS5CEdRzXSWWrlbSMHcMLj5cCvJxWG57aH2GU5o6Em4yPQZ/FlrDGjb3JJwVAGRx/KoZ/E9jKMsx9eYs153NrOMAPL19RUTasz8b5cfUf4VwrA2PqP9ZZXtc+gfhRqHh2fxZ4fTW3s49NN5G929zGdvlY3ENwSR/jXvv7SPwGn122sfG3gKwsbvwuLONmewlQeYN/ytGgxuGOODmvijw/rxW3BeTo4wXUE4CgDnivo74WftJanaeGf+ERvru7v7PyiLfz5IUtoY1QkJgru+93J9Olc0qfIpRlH5kYrFYirVo4zB1LNaOPRrr8zt7Hw3e6vFcW+q2TWMEkZQrcMCTkYHAOeDXXeJP2t9P8CeF9H0vStBgyYDDcSWN2I/soUhAVUKTnjO08cjnrXnfx88W+KfCV1pVta24sba6tmleaGHzgWD4wH5A4xxx1r5p8Xa5JBJJC2ZTPACzNjvnrkVzUXNScKfU2r4XD42lHFYzWK2V+p0XjvxzfSeIblrXUri6W4UNLcNO2+QnsxXAPbrml8NfEG50azWKG4ntznJ8u5dB/OvLvtwx9xunao2v1BPyN/OvQjhpWSucsszoubagrdrdD2m0+NWs6ZLq0Ftrl3bWuowCG7i84yLOuGGGznoG9c1xl74oiVP3LuWz/AHa4oX52jHmfQkU5bkuuTuqvqrdrtsIZrGgpexiot7tHUw+K3EiGQtIo6jABq5beKrVpHZoWAxwAQ319K4h7kBurCo/thP8AET9VpvBxl0NaXEFaNk5HpdnrkN5IYkV13qwydvAxz61674j/AGn/ABd4hufC11rM1pqI0RgIY1h2CXhQxc85YquMjHU8V8sx6o9uwdXCt0+5Vz/hKJ3UKZI2x6pWfsKtLSD0OqWPwWNkqmKgnKOz7XPq7X/jhpnjbxz4f1bUdFWwsNMVxIlu6yvIScg8qo4IAwff8ejn+J/w98VeKVudX8ONfaZHZLEn2i2HmJJvJPyh8YI7/pXyDpfiYr5huWSbgBVCbcevIFbmn+OItOEjJZpKG6jzMflx71jJ1o30udUcNltaMVzuKWm59Qfsx674D8N/FDxBqetWdpZ2M0TCxWe3MojzJkBQQdvyj1/GvefA/g7wvffGLxZr+kRlo9aSJoV8pUii2RqG2D/aIDZx3NfBVxeNdJFJFEIJAQ/HOO/pX0b+zb8UpVnl024lA1KyiHkyvjEiYAOc4GR6DtU0sRe0Jo8TPMgdNTxmFqNtpK19DJ/ak+Eni/SvHCCGB77Tdbu/I05bSQkF2CjymXOFPJ9jz6GvJL39lz4n2uqmxk8H3qTrHv3eZD5ZUHHDb8H8/wAK+19K8ba34y1yyu79oLu10693JHBaoCpGejMeuD2OK7z4qeJdQuvBN/q/h/QV1DV7GNmhtb2RVEh4LAbWyTgHAr0YRpSTcWfHRzjH4ZU6FSC7N/kflp4y+FnibwX4hh0XVdKli1WaBblLWBluHMbEgH92Tj7p4rmDbSRTPAyMkqMUZGHKsDgj8DX0t4V+OFjq/jq/8QeKNKispPsH2VDZRvKCQ4wMMSRxnoewqtqmr/BEahe6zJZ6neapcSyXPlETLGZHJPK8ALk+prldSN7Jn3NOhieROdNu/VbHzelq5mGY2AzzxXpngvw34b8Q+En+2xra6hFK8ZljnKM4ByDtY4744FeqeB734G3mhxHxFBFHqJZt67rtSBngfJx0xzTvHPwX8O+JPG+l+H/AVpDpck8btO17czshYcg4cEgYzyODnHGOc5++kovUmlV9hXaqRaS3b2PGdN+F+mX2jyXk2pXEUpDkIvlkcdPr0qS1+CA1fw1G9vqLSSMPN2LCuQQCSvX0/Gup8S/ALxT4c8aHw1HHBq18IUnDWUo2bGPXL4PHOa90+CvwZ1Pwf4Y1H/hIFjsru6lLRQrKkjiPysHpkDk+vbmublxCdlLY9WtisvVJVLJ36HxPqngb+zrpYYd0q+WrF51wcnqMD/8AXUc3hNTbOEtwZdvytu7196fDH9lLwr4j1fXY/ExnnSO3jXTi1y0LSPhgxwrfMQQp/HpXkkH7HXxRkijP/CMzKxXkPPCp6em+vQX1jkUt7niRxmSzrTo1HyW76LXsfKMfg69ZQGURkH+IcfmKhtPDVxfLM0YQrCPnLZAH6c9K+ytA/Yf+JGq3ciX1jFo0CJuE8zpKGPpiNi3v0/nXgupaULa7ubdXFzHHK8JlCsFcqcHAIzVPEV6avOJpRwWVY6XJhKybW55ZBoM14D5Cq5AzxkVd07wc0jMb23kUDG0JIBn/ADxXeRaVAg+SFEzwSq44rs/BvwY8Q/EG0nm0C1iuTbkedHJdLEUz904bseeenyms3jpy0gj0HkWEwsPa4mSt5nh2k/DPxFr+rHTdL05tQuzFJcCKGRP9WoyxyxA4HbrXT/Bj4Xa1r3xS8PWk+n3Ntbw3qT3UzKMRIh3sSecdAOh5Ir7E8OaD4W/Z/wDBGmeKNb8Opda+qJaXMltiWYPLncBvO3GMZx+teEWvxlTwtpHii80TSbbTPEN5cSPbahFZw7o4nm3bG4xwvGACOfat/rU5R5X1PlXlqqVJVMNF8sdmS/tM61r3w71TSoNA1aa1guYJXlUrG5ZvMwDkqcDGOK+YxYSGNcbcY6A13fjXx/r3j+aCXXtRbUZIN3lGSNE2bsZHyqOu0VyUlqSeGGR6114ZRpRS6nn4qFWrLmldnM3EP71im4jJ69ah8lvQ10EmkFFLEApnHAOKjfT1A4UZ9816sa6PmqmBk220Yrwk54qJoB6Vsta/L90Y+lU5rVySVHHoK6IVb9Tz6mEcOhlvCCTwKh8vb1rQkhZBkj2quykj2rrjM8mpSsyqyg4qNo8E8cdqsSIExWx4e8C+IvF8cr6FoWo6ysMiRSfYLV5tjvnYp2jgttbA74NdHMjilA5wjNIVxnmrEsDQyPHIhjkQlWVuCpBwQR7YphTj2pmHKyLAxTWXI461YSMyyog43sFz2BJ6mu5+Jfwd1L4X2emXF/qNjfLfyTRoLPf8hjCEk7lH/PQdKV1ewezbV0eeGPHXrTWTmrBXceeaY4A46VRlysg24ppHSpsGmMuTzQRYarbXD/3TmnXFx9pZTjBAI5+tJsxwRSFD6UX6ENdiPB70HPpT8EAUmDT0FYZjnFGDTwu456UbcUXBIaowMYpc0uD6GpAOKAsRbc/SnIu7rUi4IycZoHFFxpCAYpCOKXNIe+DmhDsJT1XFIq8Dmn4p3KEzgUZ4oINAyaYcoh6etei/CsZj1H6Qf+1K87AyDzxXefDK8S2F+GUtkQ42/V64MbrS0PcyZqOKVzg73i+ue/71v5mo55cxAYG4dDT745v7sjp5rY/M1ZnQGzjOBkgc4rWmvdR4OJlarK3cx2qK4/1Lf7pqecYlI6VBcf6h/wDdP8q0ZwmXRn2FFFQl3MhKKWiiwCA5paaBS45oGHc1eT/jwP4/zFUT1NX4/wDjwJ+v86T3EPtP9T+JqwhwQf8APWq1p/qvxNWVIyPWqWyNUehaV9+T/Pen6sMWwP8Atj+tQ2cyW7MXONxwMDPepNWcPZoy/dLgj6c1yy+M+ipyX1axm6fzqEP+9/Q1neJxjVG/65p/I1uaVbB7qAjlySc/gax/FkTQ6uVbr5Sfypp/vEjBxaw7fmYVKDimg5FLXpI8wdTh0pimnA4pgOozimhvejNIaFyBSE5o6mgDNCGNx19qCMjFKR05pM80xiBcD3pCo4pwPOKXFBKG7dtNbpUmBTTQUNxSheetIAQafjIoJQlNIxinYx+NB5oGMA/AUdO9OHHFLU2uMZRTiOKRRQAuOKQ8Gg4PekIxSEhRzQBQOKWgGGKMc0tIe+KAsLQOtJn8KM8UDH5qa1t/tDsMkbRngVXBwaXPOaaGiSVPJkdDztOM0q/Kc9aj6ml3VLKRMJQB1pwkBAqv1oBx+FItTaLqSZAAqaOTY6segIzVJG3DPFKsm3txSaN4ztY1by9ScKFUjBOcrioUkGBVRZS2eMfjTvMPvU8qNlVZeWbBHPP0p/nj1/SqgPFLvqeRG6qPuW/MHOQSCMYIre1b4g+JNe0xdO1PXNQv7BWR1trq4aSNSikIQp6bQSBjtXK+YexpQ5HGazdNNlxryjpctecPQ0hmAz15qv5nFNMvNPkH7YsrNzjcQKtWFvPqF5BbWsT3N1O6xxQxKWeRieAoHJJzWZvOcV7B+z/4+8K+ApNZ1HxBbLLfRGCTTpVtPOlRhvD7G42ZDL35rnr3p03JK7O7Cy9tUUJOyZ6n4X+A2jaBocOqX2u39lelfMbzZEtURl2/K2efbr3rP06ePVbi3FlIs7XMoSPyGD7yx6DHXOa83+MHx21D4jNc2MCRJoC3Xm2ztCyzuqjADkkjuTiud+E/xZm+F3jLT9YW2W/htpC5tpJCi5I27gR0IHSvnK2Aq4iHtJ79j77AcQ0Msm6VNXi+vmP+Ifi19bna3jiWK2ilLDPLsRlRn6ZPA9a4nzMDk5r379r+48Ba34h0jV/BF5o1zcXqXEmqNpcxcvIShR5BgAMQz/d67Tnnk/OzMRxn9a9rBU4wpJJWPjM2xtXFYiVWbuTs27nimM3ODzTATj0pGNeqlY+clMRjj+VML4FNdzxzTCSf4s1djnctbjy2KTf3qMHHajdn6UyeYlD5xTw5qAMRTg340DU+xOH5p69OahDZORzTg2D7VLRrGZZWQ5qZH54Oapq+RxUiPg1m4XOqFRl5ZMdec1YSU8EGs0PkjANTpJ68VzuB30qzNqBtxyTmtjTr14GQq7AKwbAYgE8f4VzdvOARgVoQTbjxwfqa4atHnTTPfweNdGamtz0vSfEBvXHybMHpkH34r6w+Cvxw0q98J32g/EBtR8UO98J7V7+JLuK3jaPywAX6YYnrnG8Y718K6dcSwXkMi7lUMCSGIGK+4v2J/GvgW+S30W80SK48WSTTAarNZqylMlkQSsc5wmMADoK8J0HQn7uzPucVmlHMsHerDmlHtueJ+OvhQnw31T7HJHb3aXAmeDyy0kiRBmRQ5ZfvYxnHUjPeuk1H9je8/wCFUnXtDn1HxD4jP2ab+z4bYQRRQsCZh84zIyAxnIYd+DV/9prStU+Hvi+OfxDqa6n/AGo1zPp8qxyP5cCzH92Q2Au0MOASKwPgF+1df+Ade1Kw8R3l5qfh/VUgsUAuFxpyiTAdI5FKBQjtkZGMDHSijGpzPsc2ZVaFTBU5UGnJbnzrqum3ek30lpf2s9jdRhd9vcRmORMqGG5TyOGB/EVSllMdvwM19jfthfs76dpeoaT4i8L3N/rGq+JNQdJkuLpJ1m/dBhLG/UqNoyckYZTmvnX4u/BrXvhZNYpfol5YTQI39oWgLQecRl4skD5h6d85HQ13wmrqL3PmtZ0vaLY8vkkLHJqu5zUkmVznj2qu/Q+levBaHz1VtN3Atx1GfrSBueuKYcCmlxW9jhc7Em4n3FWbS6EIbk5JrP8AMxx0o8zn1ocbkxqcr0NJp2Zidx61ahvCIgCwBUYwRWKsvOeKlWYjnP5Vm6Vzrp4qUXc1/to74/75py3qk9Bn6GsjzieMt+dJ52CPmP51n7A61jWdFDqJiUbVH4nH9K39C1sRqwkMakgjld3UfT+tcCs/bcKsxXnlnIOf8/SsZ4VTVjuw+aSpTTPtPV/2hbXxn4V+xapdKl3Y/urV4rSVTMgjChm5ZQxZR6Dmvm3x34oh17W1ntxLGscCRFZo8NuBJPr61y83iyS4tTFsKscfxf0FZcl2ZWLHdu9ck15VLLvZ1HUe59FXz1Twyw1Nabms16RjnOfQEVGbgEknP5mshpsjgn8TTS+fr+NemqKPnZY19zcScDHJ/I043m0HDfhkiufMmDjnP40ouCnr+JqlQM/r3Q2zfHuSOOmaYl5uyNzA+5rG+0c9P1o87/ZH40/YErHPua39o7iFDNn6Gnf2kqMAX59wax/P59PxoMoZgc8/Wk6KKjjpLW50cV4OOVH+fpV2C+5++B9DXMRXpLHPpVqC/wAA/d/PFc0qHZHr0cyStqd7oeuQ2pf7RIxLYCsAW7ivQvBvixINYa+0y4Md7GuVbyiCoIwevBrwyHUAXAO0DHXdXU+EL66lv/Ls5RC7AFmJwMA14+Jwas5LRn22V55KUo0Z2cX959ATfFnxnaW0iRa7c2trM5LLCqICW684zz9a6z4IfHDUvA2rf2bf6ikWgX0xlu5rqRyIG2kl/l+Y54yOnSvINf1V7m0QIscW2QOHSQk9D6jFchd+JZLWeQT3nyHBaLqcN1xx7frXk0VUvoz6vMMPgZ05U5wS5uvmfY/xc/Z6n1fw5dePNAexOipp32t/LkLNcgksZFwoGNvPPPGK+VdQtEErBwCB+lfSH7Nf7SfmWF34J8d60l5o9xbW9lpNm9oNioQyNE7KoyMFFG4n615h+0/4GutB8d6zr9lYR2XhO+uoLeySEqED/Z1L7Yx91dyvye/rnNa1KcKkk4u3c+fy3Ncbl/NhMZDmS+F9LHn1lOkPywtsb/YfBxx6fhW/4c8Yar4T1mPVtMvGt9QjDBbhwJSAwwfvA9RXmQvTaMZIisbYxkL/AI1E3iS8XpN/44KPq1RO8Gex/a1CrFxrx3/I9+8PfGDVofHsPifXJ5NXlCFJUCpGXXYVUYC4wDiqHiv4s6tr/ioaw08kJgkkNoCfmhjYg7O44x2rxpvGzIOLdmPTk4/lTdT8bloYUsSySk5kLxAjHbGc989qn2VeWjNY18pg/apapWsfRXhr9ojxX4flFxZakEnIwZWhjc44z1U9a+5vhd+0N4Y+IdtqEtibxbfTxEJ7m5t0RSz5wqhWLE8Ht6V+Str4stTax/aZ5fP2/vMQnGfbFdZ4b1+4sprK+sXk3RypdRgs0e4o3BOOvetKVWthnaSujxs54dy3PqaqYdqNRdv1P2H0HxfpHiSaSDT7kzTRrvKNEynbnGckYPPpXL/EH4FeB/iQlh/wkHh21v8A7A7vbjc0aoXxvyEK7s7RwfSvnj4QfGGHWYr7VNJu7iKeF/s06GFY3G7DgKGJyMDr3xTvid+1Je6BrUVpFdajBcRQKWGU2Pu5B2jqcV3zzCkoXqI/J6PC2ZRxvssHJprzscDq37Enje/1bUWsINKs7N7iY28ZvchELEoPu54GOvpXpvxrh074H+E7PTdC0610HX9bs2+1z2EI2FYgqkhhtwd8jFTt9cjkV558F/2tNR8MavqaeLdUvtS067Mciu0ZuZIiHOVVegBU8n26GvWvEf7SnwT8ZvbSa5YLdyQIUia/0iV2RWOSB8p4yBx7VjCWGnTbg7Nn0+Ohn1LF0qeNpupTp/y7P17ny/4j+HvxD8UaXDZzpdajab45UWe5QrkA4bk+5614tqvhi50nUryxu1ENxaytFKuQQrKcHnv0r9MtG1LwL43gspNGsFZJkVoHMLRqy4G3AbtjtivnXx3+x78RPEPjfWb6wsLBLG5vZJonkvkU7GbIyMZH0rheHl/y71PqcBxTQhKVPGwVJJaJ6XZ8kjS0YANcIfoVqaLw3HcSqqygsxxgMvP6V+kyfACd7iEz+HNKnTzU8zzIIGJTcNxOR6ZrqPiJ+zp4T8UaGun6LpOkeG79Zldb+10yMuAOoGAOufWt4Yes03e1jzqvGWWKpGDo3T3a6H5Ez6NLLczRJF5u12GcdMHv0/lVHVdCl05AZDHliflRtxGMcmvpHxp8Arr4e+KfElpfXsU6aXJgXCwOouA4DgjIIHBAPPXpXEXnhzTp4zMLeGdwu0Fl3Y7jjpWaxVSnPlmj6eGV4PMKHt8NNa6nh62ElzKIYo2kkb7qqOT+FU9R0yayuPInhaKTaGKScHB6Gvp3wH+zP448aQLqmk+Fk/s1kMkd7IscMci+qljzwDz04ryPx54LaDVd6Mm5ohmNYsY2kjqDivTp4tqSUlZM+XrZTRqQmqFRTlHdLoeXS2qEYKfrVCSyk7KPbkV0D2o645+lVngHOa9mFZnxWIwSvZo5+e2eMgsoXPuK9V+BH7R/iD9nxdWGh6bpmpJqcsEsyaiZcKYg4G3y3XrvOSc9BjvXn93CHK5ANVWth6AfhXdGppqeDVwivYq6xeNquqXt8yrE9zPJOY0yVUu5YgZ5wMnr+PNVI4WmkEaDcx4AFX5IBuxxj60xY/KcOhCsOhBrdVOxwPDtMqyW01rIu7KOPmBz0rQ1rxTrHiCCOLVNTu9QSJi8a3MxfYxABIz6gD8qhlLzNl2LkdMmomt9wwQKtTXUxlRavbYoYwB6UqRGWVVAG5jgZqdrdsnjH401FaN1ZDhhyCK0UrnNKm1uiO4tWt2CuRkjIwahKDnrVqaR5jmRiT71FtPJHWrTuZOCIGjOenSmYI7VaKcDPWkMZz7UyHArGIEdaURbuOuKlZO9Jkg8d6CeXuQlRs980qRrtBI5qTaM9KXFAuUYMLTVXvUhGRSlTgYNBNiMqeuMCkxipSDjFN2c0XCwwLS42jinFdoFAouOwgopc0qjJoGIqhhnP4U4phSBS7SD2xQc47VQ0iIdK7H4cje9/wCyxfzauR8sn6V2nwuhMrakFG4hYuPxauDFu1O562VQcsSkjhr/AIv7r/rs/wDM1bkH+hJ9Aaq6lkajdA/89n/mamuGK2CEf3Vrop/CmeDiVarL1M66GJT+FVp/9U4/2TU0jljkmo5BmNz7U2cTfQySMGip2RcE45qCoTuQ1YKKKKYgpMc0tFABV2P/AJB7Z9/51Sq7Hzp7fQ/zpPcaHWX+qP8AvGrA65qvZ8Qn/e/wqcVS2LR3M3AT61pXEPnWMKjGay719qR/U1ZtNUM52SbEVV4OcelY1I63R7eHnHkcZFvSQF1KCPjcCeP+A1heOc/2+w/6Yp/WtC0ujBrQkjIc7jjPIPymsfxZcNdawZHADeUgIHtms4p+1TOqpUj9VcPMxAuKXFFA6mvUPDGkYNdp8HZ/B9t8QNPfx7H5vhYJMLpdkrHPlN5eBF82d+329eK40jNIRjmgOljsPi/L4Sm+Ieov4FTy/CrJB9kTbIpB8lBJkSfNnfuJJ/DjFcfkD1pByaUgAUAhScUU05Kil7UCTvoKevWjnvRjIHc0uTjNBeoh6UDpRRQJO4UjYwTS0YzQNsaeKVaD60gPJFBLeth1IRS0UFITbijbS0mOfalcGJmkIzTmXIpMYpjuICKQ0uB6UhHekxISlBxRjPSkpWGGeavaI9oms6e2oLvsFuImuBgnMW4bxgc/dz05qjR0oA6z4iSeF5tRtT4Wj8u0ELecCsq/vNxI/wBZz93HTiuTo/pSkigQ4KSM44opokIAXOB3pQeBQMXPFKCBgGkopBewpB5pKXkmvQZ/hSIvhVD4z/tB/wB4m77J5HH+v8r72enfp7Uth3PPg2KkDk9qhFOUmiw1KxMH/CpEk4PP51XVsZ9Kfv4z2pWLUmTeYOaaZcDGOtSWFr9uulh37MgnOPSlv7EWVx5TMJBgHPGKGjRSZpazos2iCAyyROJc4MT7hxjP86z1l5ODTr7Vbq/jhW5lMojHy7h0zjPb2qmWHaoSZpKav7paMgI7fhSeaPeq4OOadv496qwvaE3mA9M5r0n4Pa7YafHq1nfWCXpuDE67rZJcBQwI+bkZLDgV5iD6YxWhpmpyadIGj3BtwPyjJAH4e9cmKpupTaR7GU4qOGxUak9i/wCMIvJ12+8u2NpayTO0MYj2KEzxtHp9Kw7ZYGu4ftJZbcyL5rJydmeSPfGcV2HjDxdpmv2SRQ2jieMgJLKMbFGcgc9xj8q4vgHPWow95UkpKxWZ+zhiW6UlJPX/AIB6v8W9d+HF1qWlnwHpk1rbQxSLdNLE6eY2R5fDsxJAByeOtcrFqem3urIzWaBRGEVnQAMc56Djoa5TeeBjpTGfuT71X1ZW0bFTzSUZe9BWNrxBpP8AZcyshZoZQWHH3T3FY+7qc10V14ot7nw20Vw2+7OFEaA7iQfvHsOKofZrG+02We2VoPLOPn5JPHH0pU5uCtNDxeHpVqnNhpLVXt2Ml3yPeoyTj0rdvvCdzZ2QmR/tMmQDHHGcgHuD3rAOSwAyfauuM4y2Z4tWjUoNKorXEJPvinRMBKhblQy5+mRmmBCCeOlHStEc1+h1vjS68N3CWw0CFYSHcyFYnTIJ+UfNXL5qPrxQCAaNwuSqxU5FSB+metQb8mnBhn1qbGkZWLCN6VIr496qBvqKlRs0M1UuqLKt6dqlR+eDzVUP196kVjk1LV0dEKhfjlwRzVuCf5uDz71lxt2qdXwN3BNYSgd0KvmbCXKjr8/t+VeheAviQfBFtY3OnqP7VtLxLuEyR7otyNkBhkFgRwRx1615Us/AFdz8LNP8O+JNeGm65f3NhvXdE0exY3PdS7fdJA447V52JpxceaWyPoctxNRVPZQavJW1PqD4oftN+Cvi7+z2LfxVbWs3xDR5ltrSytZohA3mLslDZ2hCn3gWOSPu9K+Pp5BIflHy+/JrQ8XaFN4f1W4jIzaGZ1t5QwbegY7Tx7Y9KwhPk9MilSjCUeaOxVVTwsnTqaM9U+GHxKXw3EY9W1K5azs2jezt5GedYiCd3lxE7VyMZxjp1PSvrbwZdeCf2rPhlpOna7qdtaeI7SW8eLRbe98uXKxtEknlPu3AIVfjuO2TX57eeSPSur+GPxQ1b4V+M9P8Q6SkEtzaeYoiucmNldCjA45+6x+nXnpWNTCJtzj8RVTMZulGinZIPix8P9Q+HPi7UtHvbO6t4oLiWO1mukAN1CjlFmXHBDY7cA5HauHJ4HrX6I+OPhD4I/az8DTeLfCeuHUvEdjYNBbRWsqoA43SLDLFJhkLNkAkrwSeRXxvD8CPFE3httca0torXyWmRZL6ISMoySdoY/3W4znjFOjiUopVNGYewliU/Za2PMmG4GoCCD+ldfqvwz8U6P4MsvFt9oGoWnhm+uDaW2qTQlIZpRn5QTg/wtgkYO0gHIrnLjSr6LTbfUXs7iPT7l2jhu3hYQyuACyq5GCQCCQDxmvVjNS2Z4NSFrlEg5pMkd6Y5xTGNdCRxuViZnx3/Wm+Z6E/nUROO1MDHBzTsZ85ZWUqev50ecfWqvmDOM08Nx0oSQKb7loTk55NL5x4+Y4qoHGcZ5oEhBosivaeZc88kgAkVIs/qTg+9UfMHJ4FKsuCOSalxTNI1Wi+JgO5pPNyCOfzqoJh6mgsTjDYH0qeRGnti4H6f1pvnc8GqpbuTmgyqKpRsS6xa84UnmZqsHyueeacH5ODijlJ9qyfzcZ9aBLk9f0rSsfDcl/os+orcKqxCQmPYSTtGevbNYgcds1HLc052tS4svfIz9KljnI/iNUUcEE5qVTgVLiaRqs07WRjIMEjjrWtpurS6XcLLDMUccE4HI9DXORybcc81N9pIB5yc1zzoqejPToYt0mpRdmup7N4a8UN4jt5I5YYN8W0HYCpYHv6dutcjrt6GvpQUkUhigD+g4445zmuQsdUmt5t0LSRt3KEjgfTrXU+KPEsGtm1ESyokSkESADrjp+VeLLCKlV91aM+9Wc/XMHacrSj+Jt+FPEzrrtk4jVJo5Q8bklgjAqwOAO230r7P1PTU+NHwJjuJLR9T1Rbf7Vb28EoRzdKGVRkdOW6Hsec18A2UqpcRSHcUVgSASCRX0p+yf8AtF2nw+8Z2mh+IUs7PwfezTy3V3MjvJbuY/kII/h3KoIA71w18HLnUoHRLN1PCtVneS29DxfxNpGr+FNUfT9a0+fTrteTFOuD1wSPUcdaxJrvkY619aftN+NPg38VfiD4a0jRNUa1vjdxwXuvQ2qrZCGQLgGRyCQpJ5VcAls5xiub/aj/AGV7P4Y+HfD+q+DbbUNStXmmh1GeS4NyxJG6IhVUBQFD5P0rpVoWUtzxVjXUjddfvPmd7s5xlR+FIZznmRcelURPnkEEGmtOcZJ/SuxUr7GLxbW7NFLjJHzDPsa2dD1xdHuDKyu+U2YViCBkHNckbnHf/wAdpUvPf9BUVMOpqzO7C5pKhNTi9T6U+GPxhPheQ30Mt2YvMVWtWUNE7KD8xG4HOGPf8OlP+IPxItfHHiMX8Ec1vm3jiZZQMllzkjBPGCO9fO9nrT2qKgeQLktgYAz+VXR4hmLBlklU4xnfXi1Msb0Wx9jQ4hoRmq8o+/1Z6fca5bQ5V7hFYMAyk89fTB9a6rXLeOaQGNo8YI+QEc54/hFeCHU3uZGZ5JCWPPNdXoHjM2Cz/aEmu5ZSp8x5ewB7ke9c1XLpUo3hqz18JxJDE1XGpZRZ9wfAv4qaZqraZ4d0+wvra802wRmuZjGI/k2odoUk8luM1zXjb47+OZPjNf6PF4n1G30tdQWBLe3l2KifLkcDPc9a8X+C/wAUP+ET8T3erf2XLeRPaG32RygbGZ1IJJHT5DVDxn41XUPF994gWJ7SS4uPtCokgYxnA6HHPrWMnUjFR2ZzUctwlbFzqzipQa0b11Pubw18Yp7LTY4L67ub24VmPnS3AYkE5A5rG0X9rC+h1K3nu4btLKOQGS3Ro3LqSBjoCMDJ718WyePbt4t51C7bKbsEt9cdetU7Txe18wQXEu8jdsbPTjJ/WqjXrQ1E+EssqN8zV5f1ofrV4h8KaT8WfDwgml32UxDuIWHzj+63UYrxq8/Y0tdQ+I1vqE0tl/wiUcCRvpqK8c8jKjDO9SAPmwc96+UfhF8bNV+FmpXN1brLfQ3MYje1a6aOPOQd2BwTgYzX0VaftB3Xivwql0mmvZvdI6rsvmJQhiuQcDuM9K61iqFS05x1PhK/D2d5TN0sJU/dvY+l7Pwfpeh+EH8NaRbJZ2EFq9vFBGS20MrDkkZ6knNflf8AErwXq3hfXI7DV9OudNuRbnCXC7WZdxG4eoJB5r7e+DXxKTw/NfnWLh1gnMZ3kNIxfG0L6856+1dV8ef2cNH+MrRarNqFzp+qW9qYInhCGMruL5dSMnvwCOtbVl9cpqVPddDhybGz4ax8qWNV4VN3/XqfkdqmjC0MpjicRq5Xc3PGePT0rDmswASwP06V7Tqfg29WILcadeJbu24kwvEH2jJCkrz1OetcFq/h9ovOukUiHJYJ12rn1x71jQxTi+WejP0LMMqjWh9Yw3vQfY4Oa3yR8hP1BqOS0UA4XkD1romtC4GQT+FWNZ8MS6ZAJGkEgZ8bQhHavVWKSsmz455VUknKMbnEeQS2CPenfZBjO3I7cV2Vx4MktLB7szbtqbtmzGc44zUmm+DZ9QhhlWSNVfk7kbK4OKv67BK9zNZFiJS5OR3ZwxteM7Me+Kja36fL+YrtNf8ADj6S8aB1k3jPC4rBltyi8cEdf8/lXRTxUZq6OHEZVOhLkkrWMF7c5OFGPpUZtSe35Cux8IeGF8U+ILSweZoIZmO+aPBKgKT349q9W0b4M6Z4f1e3vjqs0zQnKwyRJgnbjnB96KmY06L5eosLw9WxvvKyj1ufP9t4Z1LUome0s5rhVOCYk3U658Ha1ZWc13PplzFbxLveR0wqj1/UV6le/Eyxs7qZIdMlcByM/aFUHBxnGzjpUx1seN7GHSBbNZx6oDH5ol8xkA+YnbtAP3fWsv7QxEbS5NDt/wBX8tknCFa9TovM8SSF5WVURnZiMBQST9K2NC8LXWs6vb2BjktnmyN8kTYUgE/0xXpFz8LLXwZEdcOpTXbaeRci3MITzNpHG7Jx9cGqf/C5tmD/AGS/Hb7Uf6rW7x9Wuv8AZ438zzoZDhsHP/hRny9Ut7o53UvhTe6dBNLLcgoiPJlIichV3Y5/KuE5IB9a2de1aTWdXvL0+ZGLiZpAhkLbQe2azURdwyPl969PDe0Ub1XqfK5l9VqVLYWNkvxK+32owBU8ka7sqevambOnBrsTueI6bRHipY7WaUExxO4HGUUkfypNhz0r0j4X/GBPhzpF7p8mkvqC3MxlMi3Aj2fKFwAVPPHX9KJSstAhTTdpOx5mVpNvvT9mMAHgAAUbaa1JcLMbt4oAHHSlwaXb7807gojcD0FGB6VIseeo5pwiP93H40XKUGyJRml2Z7flUnlkdRTlQg0XGoEajHbNdZ8LtTtbBtR+0SeXvEWMgnpuz0/D865gDrVrwrG7pelFLY2ZwPXdXHiY88LM7sFUlh8RGcd0YmpuJNTu3XlWlcj6ZNWLsY05P91azrlys0g9WIrQuHzpif7q10U1aKR8/XlzVJSZlN1psn+qk/3aC3PPWo52AiPPXg0zkM0u2SN1IQR1GKliRWDFuvpmo2fcBmoRmJRRRTAKKKKdwCr0f/IPb8f5iqPY1eT/AJB7fSovqNDrT/UH6n+lWAKrWnER+tWR2rRbGh2eocqn1NUWHpV7UTwnrk1Dbj58+1Ke5209g0znUIR7/wBDVLxONuskf9M0/rWjY4GsRZxjf1P0rO8TMG1kkEEeWlZx+M6nrRa8zJooP3jxxRXezhDPSk5Pel6cik6fSkOwYx7UuPxpBz9KCcD0oJegowKKQcml+tAkyS2j824iTnDuq8deTj+tfRv7XP7I9p+y/beHpbbxVL4l/ti5u4tklksAgWHbj5lkcMTv56Djg183enrShjtCljtHQE8Ck1qPqFJS5pKY0wpD2paKBPUMUYHpRRQQou9xR14/WkoooNUFDD3oopAFIRkUuOOKKAQ2kxTiOTSUwsNJxxSU4nnHWkxn3oGJRTgtG3PSoAbRSgDFJQFwpPrS0hGRQAuTTgR3HNNoAzQA/PenNNIybTI5UcBSxwPwpmQKODViLs+ky21olwzRlGAICtk4P4VSqxJf3EsAieUmIAAIenHSoKTGIMZzTt2BwabtIzS1IDgc9acp4xUdGaCrku78aM5FRDilyfelYfMSbqN/vUYNG6iw7km/3qxaXX2eXfyeCPlNU8k/4Uoz3pNXVi4VHB80d0Tzyh5HkwQWOcHHtUZkz1NNJzTScUlGxM5uTuyTd6HikLgnrg1Hx60oGaZFxzHdx2pqswGASB1xnijOCRRkdqdkPne6Oj8La+LZxZSrlZG3CVnPy8dPpWbrVtFZ3WIRiMg4UNuIwazM+xpuQD6VgqPLPmj1O+pjnVw6ozV2tn5Eu/jAA+tRsS3PSl3UYroR5t7idKcCCBzScHikJx2o2AkHIopisegpc+9KxSHBj61IjYHU1ECCM0oNIpOxODg8c1MGORziqiOVP1qRXGOvNFjVSLSt8vvnrUolIAHFVEbk8809X96lo6ISsW1Oa92/ZR8G+A/FvjnUX8c3qWttYaaLm1iluTAk0nmhHyRySqHIUEfjjFeLeHtB1DxHcNBp9sbiVF3FQwXj6n8e/avsPwV8LtA/Z60UeKtZ1UTfaoLeGW4uIQyQSld7xIFBLAnjnnA+teVi6sIxcOrPo8BhatRxq7RXU+aPHXjKw1bUdQt9JiJ04XT+RNMPmeIMTGQOoyOvrXGibJ681a8YXmmXXirV59FQw6TLdySWsbLt2xliQMHoOePaskS5PHNb4aioQSSsc2OxtSvWbqSu1pcueZxjvR52SATj1qpv/Ck8wY611umjzlWfc7Xwt8Rde8F6brNloGrXOlwavbi0vvs5CvNF/d3Yyv3j07E+temfsufFuz8K+MdF8LeKnD+BtUvPIvvOkdRZROjKzqykbF3shbrkA8evgEEzByFGR/8AXqb7UwfOfmHeuKeHhN2aO2nipU43g7PY+y/2jf2x9JvINR8AeANC0u88BrZDTTJq9k7NKY2IVogWA8oAKULAPkbq9F1VPC/7aPwGSOxhfQtU8LxLHBCzra2VtfPZjC5+YNASuOArADoD1/PBpzLyxrU8Oa2NH1FJi7rEsbqdueSRjoKxqYdxjzQ3Rrh6kKtSNOo7J7swLpGhfafm/wBsAgH6Z5x6VAW4x3NejeK/CCXmmPqlmkm/ykdYo4+HyeT+RrzmWF4ZTHIjRyISGRxgr9R2rqw2IVePmic2y2pl1RResXqn3Q3OBzzTCwPfNOY4HvTCc/Wu1Hzrdhc4ppfHBJNNY5FNzinYycrknmD3oEntUNHSnYVycS+2KXzR61XB54pwOKRSlYsrLtPUUplz3xVUk9c0qngU7Fc5Z8w8/MaTcOxNQiTOcCl39M4osNSJfM4706OTA5qDPzU7cBwTSDnsWvPYJtDtt/uhjimhu2agBBAwfwoBwaRfO2iwGPY0+OXGcnNVcilosWpNF0TD1qSOUnvVFWxzUqvxxxipsbRq9za0m/XT7sTEMx2lflxnn61s6my3g+0xEBBEM7jzXJrIBgk4+taaXUqWixBwIiORt+neuCtSvLmR72Fxdqbpy1XQ0NMmhN5brcfJB5iiRu+3vW74putKWa1GlYEaofMIDDJzx972rkoJf3gXIHBwa3dZ+wLY2zW7l7h+uCemOeO3Ncs4pTTbPXwlWU8PUirfqU/PE8ql8EDsf/1V9M/A342x+JLPX9A8b6nNqlzcQs9pqOs3cfk2sQjYSRq8h+QsWGNo5weOBXyu2UxvUgHpnvQtxg4GCPfFFfDxqwsc9DEujUTZ3fjr4d3fhGe1S2juL+F7KO7nmhiZ4oS4LbSyrjAUA59DmuHkkOODivadY+Ifia++F+qWuqXMUhvQiyNC5idYlWNFUquFI2rjGMnJJNeHT71ycYX1qMJJzi1LdHZmmGeGkpJfEr+g8yEd6DN0weaqCYetJ5vTkGvQ5D55VrdS8kpDZzWzoc9juk+3MoX5dpOfx6VzSS88gGpVkBHB/Ks50uZWO2ji+R33NaW7VbmQxkGMOdmD2zx+lXba7LTL079BXPiXkc4xViO6Gev61i6OljspY1xlc7GK/kWJgjunHRWK54r6iuZvBHiP4RppHh3R7Z/ElxptvbtqD2nlj7QRHvbzXGc5zyOufQ18axXQKg5X610PhvxTqOnajYSQ6nd28EMqFvJkb5I9y7sKPYV5VfBXSaex9Hhs0k3Z3foy/fu9jf3NqxDSwStE5UkruU7TgjtxS2eqS2svmIwR8Yzj/GvUP2iPEXww1HTdJHgCwtLS4+1yyXU0NtNE8kZUld5kHzcnOB6+leIpqCdmH51EaaqR2OuOZVYz5m7NHqmmeKLWSNFe5RSqLuLfLk8ZxxW9b+PpIIUhg1mWKJPuxx3LKo+gFeNR6hvjXEgAHbNTpeDd9/j615tXAJvRn12H4jnKKU0mfQPgzx5MmtQzz3X26FVZttxOWXIxg8n1r7o/Z8+My67pVvbajPPqF5c3rRJJ56yLEDjavXIGD0561+YXhq+WRI4vMy4UnGM8ZHtX0T8EfiZp/gjTDFcTSW94t61zFIkBcDKoAcj3U9RXDRk8NVs9jbP8rpZ3gFUpx9/yPq39r/wRqHiyx8NzWDW8UUM88Ust1MEjjLx8MR/EflIwOe3evz5ezins/LeNXRhgg9CM+uBX6GeAPjFIt5eL4tuJ7+ORUW1T7OrBGO4NwAMZBAzn1rO8W/seaNd+LfDd74b0S2sdMjvPO1SKe7LJJEMEKqNu5JzxwOfpXZXw/wBaftaTPjcjz58Nwll+Yx93Vp9O5+e0OhwwzIIYIlYsFGQDyenJzXpj/BPxAsojK2LY7/aQBn/vn+lfcHj39nDS72PTf7D8JaOoiZ2mKxxIx4+XHAzznOTXMy/BrxNFNkaG5Pqs8Z/9mrhqYSvF2abPoKXGWBrQUqNoeTsfJDfAvxJJGyoNOBPQm6/+xqTRv2ePFmr65p+mRnT4pLyUQpI1yWRCRnnC5xx6V9ZRfDTW7K5El/ps9paoC8kjFSNoHbaSevFE2u+ENDcT29rqn9oW37yCY7diSBflbk46+3PpSjRcH+82M6/FFaonHC+9JrRpbHhmtf8ABOLxtrCxO3iXQYdqkMMTNjJ68LXz54F/Z+1TU/jLrfh1b6z3+FL0y3U0yt5dykNyqEKACfmwetfax+OnjRVymrLI2OAbeEjP4DpU3xQ8Padrnh2y1j4dadaaf4tvZ/M1u609EgmmDo7Sb2bG4eac/XpXoqrTdNqlpY+YjWzOWIj/AGhqp9UtF6nzt8fPjJ4ZsdE8UeFLdLlNZlhkt18i0XyUc7WH7zd0xnkA49K+Or4vvDiRuScfMeK9T+KHhLWP+E11wz2cwnF45md2Q/vM8kkHB+tebapZS205jkjKSL1Vu1dGEVNLV6noY6hWpx92/L0fQ5+UfPjcR9KhdnUAB3AHQbjxWo8LHd8vPtUK2TT9Btx6jFe2pRtZnyMqFRSvHcy23P1JP/AjUTwegJ9a1lsiwyD7UyW1KNgc5Ga3hUjBWicVWjUqO8zHaBgSdo5pph46VqNaknkUhscAk7hz6Vsq3dnDLCPojL8o9uv1oMRAGa0JLTYpIBaomh46VsqieqOeWHcd0U/L57GmeVk54q55QGOBTTCD2FVzGLpeRUESntz9aPJXPT9ateSB0Ao8r2FVzE+xKvkqe360oiUHOP1qx5eOwpfLo5heyK4UZ6UbKsLCGPFP8gDryPalzotUWVNpJwKUIatCEDoDn60NGOBijnQ1RZXCHqOlbXw5YKuogcH913/3v8azAgzirvgKYRNfbsc+WP51hXfNT0NMPFQxMLnFX4Iu5gezsP1NWpnb7CgIG3avOfpVfUeb+5P/AE0b+ZqeX5rNP90V1w+FHy1f+LIypgWlGASMU2WPETnOeDUsj7H28HPcUk4xBIPb/CqaOYzgec000u7ikqTNBRRRQIs/YCOrgfgajmtjAASc59sU63lVCSzGrMrpGqlxuB9qqyAz6uxc2DfQ/wA6pysrOSowp6CrsX/Hg30P86z6sYtmf3R/3j/SrANVbb/Vn6mrCHmtI7ItM7e6YXJXbkYzyaqTSjYEC4K9TUkD5OPSqkqNb7nYgoT296ucep0wkTWTbb6LPTP9Koa3IG1TA5+Ra0LLEk0bgcVl6xxqv/AV/l/9as0le5rzO1iqetJTiMmk211E2Eopfu4z3pDgnigm6DAFJn5qUjNGPage4gBzS/rSDr7U8ocZ2kj1xTFy9hvSkycjApSM0dKQnoIDk0dDzSUuPSgE0LkHpzRTRzWnd/YBp0Jg/wCPr5d/J9Pm68flTB7GdSnj2pCM0gH40iVdasWipo7WWWIyqhKDPNRce9OxaaEPSiilxz79KRN7sMUYNOZWQcgr9RTKLWLQUm2looGHSk2iloOO1BLG4I5zRTqQrzxUtWKEI4pp607bj8KQgNjNIBCCTSU+m7cE96AEpR1o2jrTlOGBIz7UALtGOaShjuJ7CincA70Uo9qTHGaQXHdaaeDQDig88mgVhM84paaRz7UE4zzTsA4daDyaaB3p4PNIYlBxiiigBUBJ459hT87fvAj6iiCUwyqw5IPQUXE/nvvIxwBg0+gDC2T7Uh5opN2PekJi45p1NznmkyC2e9ACsMcmkyM0tI3SgYtFMD7cYo3GmKw7I9aNw9aOxxSDHQ9aQxcUHkGlprdTTAB1o7+tJmjOKQDug4oDEU2jFK40yQEntTg2DnrUOcU7PFFikyYNnB/SpBJ+NVutOUspzkila5cZ2dz1b4eeI9M0bVI7SKMiS9ZEBXnaR3JPT7xFa3xe1fX7+zKtqV3daGXjb7GJi8EMiKwDbQMDhsZHcmvGEmI6nmuwsPiLeaf4aGlwxgMpYLOWOQrEZGPzGT0z0rxquElGsq0NWfc4XN6FbBywdfTqmu/Y5POOen1pRJioy4JpNwNezE+KlLXQmEvHT9aDJk9KiDYpM/nVWJ5i9aSkSEbeo60s4G4ndz6VJpWlXeoxM1uFO1gDubFVbhHguZYpRiVGKt35rmUoudkzunGcaCk1o+o9TgcdKekhU1WDnHWk3n1NbWOFTaZ1nhvxbPYyrZysHhlkXdLIzFkA7Dnj8qs+LvCszRtqtjazTQzyFpXjUuEONxJwDgYwc59fSuIZgeD0r6R+A3xYl8PfBbxZ4Qn0qSWDUvtC296kgQDzrfy2DDHzAEKRz/Efx8mvCOFl7aPzPssDiquZ0Hl848z3T7HzW/HHemk1seI/Dlz4dvhBOAyFQUkXo3Azj6HrUOmeHb/VozJbQGSMNtL7gBnjjn616KrR5OdvQ+Ylg63tnQ5feRk56mkI3Y9q6bUPBN1bxIbXdcuxw0eAGHAPAzz39K5kirp1Y1FeLMsTg62EdqsbCY+bNBGadj3pK1OERRg+hp2KQLznFOoADTd2Ogp2MjFIBimAgNOUgMM8CijHNILn1J4g+IfwBvf2TbDQLLw2IvjDFplrA+qrprL+/W4DSsZt2CTECN2DnOK+XCwBJpo4Hpil60krAtBQ5B4ANPDZHNQnrSbfwosUmWAw7YP40b8VADt6U9TupWKTJ4zkGn7gvPaq44pysT/9egtMsrJvq7b3IK7XCjAAGazBx0p6uePWpcbnTTquD0NUSDcDx1zivtj9nn4e/D7xt8MPD9zqPhjS9U1CJpLe6nmibeXErHDEEA/Kydq+HouWGfzz/wDWr7f/AGOdRsbb4WSxS3EMU6alO/ls2GI2xkEevSvCzKDUE0+p9Zk83UlKNrnyD4l1CPUNUuWijSKFJpFjRBgKu84H5fWscnA9qrrPnexfG5iefcmkMmf469WnBciR4dfEN1Wz1L4V6z/a2rT2mtXqzWa2p2w3siCNmLqoADYyQM/lXW/ETStJ0jwRq0thZ2cTzbIVktlU7vnGRkA+pHGOlfPxccZOfqK9q+Euv2uo+H/7FVZvtFsr3ErOi+WVaQdDnPp2rwsZhXRmq8HonsfoOR5rHH0pZdXS5mnaT1d+x4pIdjkHPHFG8eoFbPi3wpe+Gpo5LtomWd3CtG+4kggnPp1Fc+XIxXv0ZxqQU0fn+Mo1MJWdKorNFgShc85pyynHf8qrBs9TShuvNbcqOFVGtmWxMc+9dn8M/BsHji/1G3mu5rYWsCzKYEDFiX2kc1wIcA5OTT1uGQ5RmQnqQcEisalOUo2joztw+JhTqKVRXS3R0niTT/8AhHfEV/podpUtpTGHkG1mAAwSPxrZ8ASrceII0Yqo8pz1x0Ga4ZZWY5JJPqTk16D8E/EMPhn4h6dql3F59rbpMZo9gbKmMr0PHcVw4mlJUGup9BlOJiswpyS91vbyNb4lxeTbaey/dZ36dDgCuDFwzcetXvGmpavc6rv1CSYW0peW0SV8qIy5HygdPT8KwxKRySTXJhKLjTV3qepnePhiMbKUI8qNhJyABg/lVqK44zzg+1YKz5Jxkn61PHcDaMe1dMqZ5dHF67naaFqZtbtZNpYbNvXHXFeo+H7sXNrbzHC7uSAc4GTXhNvdKG3dcY966bRvE9xaNCjXc6xLgBAeAM8+vvXz+NwfOuaO5+m5DnkaC9lV1iz7Wb43+FIDkzXpKjIK2bdR36197+G9UuLi0eW4kjMRiRk2fwrtJJPH0r8fBfQ3kTmFwysCBj+Vfpn8FvifafEfQ9UitrWa2SxtIoiZ3UlyUYE4HQDH61x4CtyycZ7njcbZUnSpV6KvHq+17HdaR8avCGuMwsdbguAql9yHgr3I5zXmvxB/aX8P6hp8lnoeu3WkXyyMGupLZo8KOOCysvJwRwcgV+duln+zsiMBCoKnb8vt2+lasfiO5jXjPPcP/wDWrOrmdV3jFHp4Hw8wcHGtUqN3Sdjo9e/aG+JeqW3kT+PNWO0chJVj3cjk7VB7UzXfjFfXGl2kFnq1z9ojKmWZnbdJ8mDnK9c/yFeY+IvEcVnfOjRSliqtlSMA1mXPii0k0p0SSUXTwkY2EYfHrXE4Vq1nI+7pU8qwF4QhFNHfj4ra6ASurSuRnGQrdvpXvfw7+J6+D1luNaW71BLmGJESBEOxupOCV6jjiviXS9XaO4ka8ndozHwGJf5uOgx1xXePrF1fxIZLiWRSoI3uSMfQ1MqUqEky2sLnNBwSSZ9P/E34MjxN4N1j4nWk0MGmzWx1NLJ7ctM2QvBYHaO54z+NfKmseGrS7R5hbILmWQoHdmABIxkjivqL4Y6Pf+LLLwno0mo3z6Zex28NxZNfyiB4mA3r5YOMFSRgcV1vxi/Yx1i88UK3gnRbGLRPs0YELXgUmXc5dsOCe6j8K6lTlJKrRXqfIwzKjl1R5dmlRNPWL6JLZH54Xmhz2Fw8MhRyoBLIwINUmh2npivt+L9g/wCIOosTJpukRHpumvlP0+7Ga8q+Jf7K/iH4YNqGpawdLkt4JkgMNuzSne/AwNijA/Cu9V6kY3qRaPN5MvxNX2eErxk30PnOO2UZG0VqJ4Jv7hVlRbfaygj58HB6dq7XRfB9zc61aRQxxK886RplCqgswHOB05r6fj/YQ+JBhDQzeHZE7f8AEwkU/kYeKj6zVqO1FXOmWDy3A2WZVVG+x8US+BtRjcny4j6bZRWdqfh+60vyzPEqeZnbhw2cdelfdCfsG/E6Y8/2APf+0m/+NV5J8b/2ddd+El3pK+K4bJmvUmaA2lw0owhTeD8ox99fWtFXxFP3qkdDL2GR41+wwVZOb2Vz5ekt2Bxjj1qu9qeeMkV6ZfeGIHsblbezRbgrhGZ89xzyTjiuMvtLl065a3mA8xQpIXkcjNd9DGxqbHg5lklTBSSnqu5gPb7BkqRUbQ5B9a2Xs3kxgAAetQGwdXwdv516May6nzVTByvojL8ojr0pyWzSdEJHT0rSazAHOB+FOjtSowMAH1FN149yY4GbdrGYbV8/dNMaBk+8pGfWt0ac+cFlB9qnj0Qy7C4BXqOlZfWY9zqWVzeyOcSIjOQQKCmQeee1aV1amK4kQZwrED/IqHyWxyeprT2ykYSwUoaNFLaeO1Hl5q41szHkUq2xHYU/aoy+rS7FNIxmqvhQkG7H+0n9a1im0HGAaxfDW9mutpIG5M/rW8ZKcWeTioulVg0c5qGfttx/10b+ZqeZS9iqjglRVa8J+1T5/wCejfzNWZz/AKEn0HSvRjsj42rrNsoRRmNSGAzTJ8+U/wBKsWy7p13cgnoaNVRV3gAD5egp2MjGAxSU4d6aRioM1uFFFFAhoq3MwuFURkHb17dhVUDinJK0RO0jn1FJMBpUocEYPSr0X/Hieex/nVJiWYk9SavRAf2cSRxz/OhdRoS2+4frVhen4VWtvuN9TVmrizQ7ID0HWq+oj/Rxn+9/SrKVBqI/0cf7w/lWs3obU9inYzMsyJwBk8/hVPVmLaqP91P61Ys1Z7xAoJOTwPpVbVVZNUAZSvC9axi9bGtna4wLjntTttGM0YOBXWh3AgEAGkwF5p+MikK4oIsiNuT0pMGpcUhXvRYERhQM1f8A7Ub+zfshiG0DAbPPXPSqeDSEc00MZSHvTxSNSYbjD1oFKQKQ0jJprUKM0UA4oJHdaDx3xR6Ue1BorvcnivpI7doVxsOc5XnmoDzjFLjAzTSeaAshw4I70oO0gimDrntS5+tAKyJJJmlAzjg1HSg5pMe+aDRBRS4oA9eKAEowfwruPEPwS8c+E/Bdh4u1fw1e6f4bvvL+zalLs8qXeMx4wxPzAHHArhx0NIQUUUUwQmD65pOlOxzRwaVhjallaN41CjnPPFR7eaQcE/1oAOnTpTd3OKUnBx2ptSA+kzg0i8Gg9RQJjh2NHSiiqsIUjIpKN3IHailYaCkb7ppSMUUwEXpS0UVIwpQRRtoIxQFwOMUnaiigTGnOBSU4jNNxz1GKBBSrS7RSHjpQh3FJxxTc0o5/xpcUAxuKKCeQKKAQDilAB7Gkpw6UDFpnUmlY4J9KQ5z3qkAhwDVvT44XZ/PIAAG3Jxzmqu0nGc0oBzx1oWmoEl0qLcOsZBjB+XBz+tRZ4xQeM0jfSl1F1DilqeGyaaAyBgACRgj0HNQA5GRQCFB96XeabRSGOD4NaWmTWu2T7QFzxtLZPHP/ANasuilNcysbUqjpy5lqTzyIZZDGMR7jtHtTA5FMz7UZpJWsjOUuZ3Jg1Lv9qhBzS5NUJM7XwfawwwS37XQ+UbHjyAF6cmqXi3UrG8miNsVeQZ8xkHB6Y5796dpsGmr4cmJuvKmuAA2SMgjnAH+etcuxzj36V5tOneq5tn0+Kxjp4KGGjFWeo8SetIZRUeaK9Gx8xceXB+lezeAPtyeHkS/i8tIyFiLYyY8dD+XevFuuR0Br03wP4o/tSwn0y9uVWZiVikkI3SB1wQM9SD/OvLzCm50z7DhnEQoYq8pWbVkct44jnt/EE4mululceZGyyiQKjEkDgkA49Kh0DxXLoMEkccKzhnDYdiAOORx/nineJvC1zpGqiCNJZ45seVJtGZD34HTmse80y6sLkW1xC0cxUNt+9kHnjFbUlTlSjB6nn4mWLoYudWCad2db4b8W+bfsNQnY73HkrjKqSeRnt29areONBXT5Y7u3RI7V/wB3sQYIfqT9K5VSY3BOVYc+hFdKPG839hHTzD5kjIyGaRi24E9ceuDip9i6c1Knt2OiOPjicM6GLfvLVPqc1j8qMUhb0oJxXo7nywoopm854xTgcgZ60BcWkwaWigQAYooooBDWXIpVBA5paaTzQO4p7UnfFFFAhcUAgE460dB7UlAxwYnvTt2TUYOKcrUWKT7kivgnNSqwOOtQKQe+a7j4LaBp3iz4teDNF1aIXGmajq1vaXEe8rvR3CkZHI69jWc3yRcn0OmlH2k1BdTc+DngqfX9Vt9alhs7jRtKvYGvYruUDzUzuZApHzZVW9K9H8ffHbw5o+mafafDeWXS4f3puozp4iVshRHwWOf4gfwrsfjdp/g/9nm8i8MaXFLp41K2GoyKoluN2WeJcFiNvCt69a+PJZcn1HSvEpXxs3OovdWx9nWqRyjDxjQmnOXxeQ9n2/d6elN87B61Ez4PHFRlua92KsfFTk27ljzTnhjVrTdavNKnEtncyQOcBijkbhkHB9qyweev507dUzgpxcWtGXRrzozU4OzR6B8TfFum+JWsBp8skohMhcvGUHzbcYz9DXCGRelRb/ek3VlRpRoRUInVjsfUx9Z1q277Eu7PsKAefWotxxSbj61ueemWATjjigPtbPtUYlHvTt2eR0oKTJhL+VdTP4WvLLQP7UjuIljKI2zBD4YgYzjHeuPJJHXFenajrFjJ8P4IEu7aS5MUIMKyqXBBBI2j9a8/FTnFxUOp9Xk1LD1oVpVnZxjdep3P7P3jb4W6HoWswfEvR01m8Mqf2dLJZPdPGnlsGAIYBQH2tznqcCvKfE3g7U/Ckdo1+IT9pLKnlTBySoXdnHT7wrBVgDng855+v0r07wXqEPjee8/4SCCDUjbojwq6lBHuYhgApHXA656VyVebDNVIq6O3AU6eZp0Ju1T7L/zPMBIc8GrEcpwOcVHrCxRa1fpCNkKzuEVeiruP6VCjAAV6KXPG58/NuhUcL7M1YJxzz+FX7e4IcEHH+RWHFMMcnnNW4Z1DryPxrmqU7nrYbFcrWp3WmeJruIPtunUE7hxkZOOf0r63+Dnx9/4V5Hf2+gfY7yfUCkcnmksNwyFA24xyxr4dtrwKRjaTx3/+tXbeDPGB0q+865mVY4/LkjXZlSwYEZ45HHqK+axeDkn7Sno0fpOXZpSxVJ4TFLmi+/ke2fFTwFrnwaXT5PEkMKJqRk+zPaTCbJXaXz0x99ev4V5ZN43VFVY4XZvVmA/pmvpDTNan/a+01jrsH2i38OScNpqNAIzKnO7ls8R/pXx1dTLG3Dg+neuOjhYSk00ejUzvGUqSpykrrt+BpX+ptcXEkrsTvYtyc4z2qk90uFG7is+S6DEYbmmCcbuua9iNHlSSPl6mOlOTcnqzRFwGJGcD1Arp9E8ThJm+1uoh2gRhI+h4/E8VxAnAqRbjZ34rOrhlUVmdmBzSphKnPBn1H8O/i/qvh7VtBni1GOKzt/LKv5SZjUDjqPoOa9S8WfteeN5r5E0rxJtt1jG5ltoT82T0ynpiviyH4hahbWsUEK25VFCKWjLHAA98U3/hYGqE5ZoD9IQK8n6tiKekHofVVMZkuOqRq4qmpSS7H6F/AT9so6ZdawvxH8Q3E8LrF9h22Zba2X38RR+m3qfpXr+hfFH4HfHXxKnhs2cWuX+oyNcLb32m3HlyPGhYuS67VIUHBOPzr8s7PxbbOitNdwCQqpIGVwSOa7TwP8RNU8H6/b6z4f1EWWpQxusdxCEkKo67W4YEcg9cfSnDE1Kdo1VdHBjuEsvx6nicvqclRrRJ2Vz9MNS+FnwJ0DxHpulSeG9Bs9XumD20ItWUsc8HI+XqO5ruPFnxC8O/DqG2GpSTRi53mJbaBps7QCc7c4696/PKy+P3iHxVZw6lq+vy3Gr2czpDJJFEjIo2spG1P73r3FQ658dde8QRRR6vqUt00YyqXCDKg4zghe+Oa0eYwjfkjY8CnwDjsS4fWqzcet3f7j6f+IH7W3hjXbEQeH7/AFvS76B23yC1aNWH3cHBPQ+3Y1leE/jL8MPEHhr+zvikq+JtTjupJbSbVdNkujDE20KA5Q7eQCRx+VfFlxrtytxcSRGNUklaTOzccEk+nvTX8WXjbllMbRuCrboFHB61y/2hUcrvY+t/1GwFLDqjTm4yTun19L9j6d8b/so674neyvvCuk6fDp7wgsGuEhyS2RxtzgA45FfNPxL+D934M8VXmla1a2TanEsZk8p/MADICuGAHbHavpj9nb9ozxBq3j7T7HxV4pt4PD4jnkmWeKGGLiM7FL4BHJBHPOK9d+JnwL8BfFrWLvxQniFru5uQsZGn3sTRZjjwBwCcnAyM963VGFSl7ShozwlmuMyrGrBZuuamldNK/pqfmRrPggxyzT2oiVMr5dtCDu54PUY7HPNYUvhe+Qb5ICi5A+dhX2LL+z3cPGsg0fWJsDJ8tHxn/vivOfGfwc8RWur+VY+EtdltURfnNlNIC3Xrt9q5o168dGj6d0snxUr06qV/NHzvHo0sspiWM7x26fzrrNB8MwQ6ePtVpE8/mEhnUMSvGP8AOa72H4R+LfMJTwdrZY9SNLm/+JruvhZ8FtYufHmhL4r8Jatb+FftH/EylvbWa3hSEI2WaTAKgHac5HSqlUq1rQSauEaeXZbCWIdRTa1tda+RzPwf+A198bta1HTtIfT7SaxhSeRryM4KsxAxtU9x+tcRfeH20/WdQ05o4pJLG5ltWMafKzI5Qlcjpkd6/RH4e6l8Ivhnq2qHwJaQi+aKOG8ns5JrgbN2UG5iRjO7oe1Ytv8AAPwd4l1GfVrDwhatLcTtcNOQ5BdyXZiC2Od2fTmiVNxSjGV2fP0eI39ZnVxVHlpO1k0kz865vCVpLK7yWKF2JJ+Y8n6A1zEXgbWZCF+yAH/amQf1r2jxh8M/E/gyW5fVNIu7C0iuWtxcTIApYMwAHPfafWuUu9YttP2iViJCMhFXJNZ08TVpy5dz7KtgMBj6KxCdo+RgaHo2g2dgyaskDXqyMCGdjxkAD5eK5nxPZWkWqv8A2cqC12qVEZJHTnrz1reNlNdx+aI2ZGP3wOM9etRNobuOYiePavQjWtK7Z8vWwLq0/Z04bdTjHgO05rlvDc+x7lQM5ZP5NXqV5oAS3kbycAKTnNeUaENrz/Vf5GvdwlVVIux+acQYOeDq0+bS9zDu+bmbvl2P6mtO5tgdIgKp85VenWsy6H+kTf77fzNbcq/8Su3/AN1P5V9BDY/Mpv32YA3RMOqsP0ptzIZI2LHcdvWpLnmZs9ahl5hf/dNJvczM1aaetLnFJUGQUUUUAFWzaRqMljzx2qnUs0/moq4PHPX2oukAyQAOQDxng1ejGdNP4/zrPxzWjEP+Jf8An/OkMbaINmeeGNWByRUNp/qj9TUw4aqitEWjq7K5+0O4wAFGRjP9aNWO20Ujg7x/KqGgEl5u5Cr+PNLd3xusw7NoRs5HftVyehrHQk0Rm/te3JPQn/0E0zxT/wAh1P8ArmlQ6LcP/bkUfGBuwf8AgJqfxMhbXEPXEaVzr+IejHWg/Up4xikJ4H1p2KDz2zXoM5QAwKDQORRTAKKKKBaBikCgUtFK4xjqe3SmMCB61NSYH+TR0AhYU3bx71Ky4GRTcZPvRYXqN2YoxjvTtvtQV9eKQrIZk/WgDnJpx4pG7UD2D8aCvApMDFOIIGe1ANDPY0o60uPUUdxTJaFzge1IDuANFBpCUu44dKQgkEA4znk00UtBXMj2z4k/tWeI/ib8INB+Hd9pen2ej6OLYQzwGQzN5MZjG7Jxzkk8DFeJ0d80m7JNFrArLYWiiigoUECm9KWg8fjQFxCSAO9NJ3UHmjBzQSIBnvQRilpOG4pWKuJQKCMUhHIqRCg5HWnDqPpTCMHFODY7ZxVIY489qdirVxpsltbJOxBVtvAznnpVPP402rbk2YpGAaaDmn9RzTDwSaQ0BOKOopCc/wD16UdKQWH0Hr1poNL1IPXikMQjFFKR3pKBdAopDSMcDrQSOoB6+lR11Hg/VND0+C5TWLVblnkUxlofMKrgg88Y6igaObpOc0vYeuOaT+IGgoaw+YUAZNSAZFGMCmSIF96XbSgYopANYHBHWjNOpCM00NCUgIBzjml6daXH0qr30CwxgGbPrQc8UuM19CfDr4HeA/FX7PPiHxjqniWay8X2Md69ppIvIEWYRKDG3lsN5BOQQOuOKLAfPSuyqQrEA9gaTHTFPKgYx6DtiipYxNtIRinUU7E3GYpcdKUgUYqRoTbS7aMe9FAgAxT42AYEgNgg4NNpC2KBrTU6eKOz1SzYRRJC/wA2IwR8p9a5y4iaCZo34K+nNLa3ctpKZIX2SFSMgA8VE7mRyznczHJNYQg4yb6HoV8RCvTjpaSAHNLRSZxW5wAORzUttcPaTxyxMVeNgykDoRUWc0HpSaurMuM3B8yOgXxrqMl7BcXEnniIsfKI2qcjBzj/AD2q7F44ebVYJntoo4lTyiDksoPUg9uprkSaAcdK5pYeD2PTp5piYbyur3O28beH/Of+0rUPMZTlgi5GAud35D+tcUeAAeRXXeFPEaMkel3afumLASsx5z/D1/DjrnFYniKwgstRlS3kDLnJjXny8/w55zWVBzpt05HbmMaOIisXR0vuvMyyc0cVe0zRbrVXKwIuF4LOwAB9KpPG8TMrqUZTghhg5rtUk9DwZUpRipNaMbSglans7GbUJhFAod8E4yBwPc0XljLYTeVMAr4DYBzxS5435U9ROjUUPaOLsRBulHQ0nQilLYPrVmVgDbmp1Rg4Oafu9qAQp5phXn3pyncM0pGaAIwDnmnEkZ4zSkU08Uw3PQPin8Mrb4eLa+Vfz3jzSshEsaptAHXiuAAzSbzjkk/WgHgYNDBDiuR1puMUuaKQwHBrt/gxqbaN8VvCOooglax1W3uxGxxv8tw+0ntnbjNcR1NdN8ODjxtpLDtNk/8AfJrnxL/cyfkenlsYzxdKMtnJXPWP2xfiKPiV8SdM1T7ItgItKjt/IWUyAYmlbO4gdmHavBC3Bx613PxiJPiiME5AtkwMdstXBk1hgU/YRZ354o08dUhDZPQXeSaXqKSGJp5kjjG5nYKo9STx/OtnxF4O1nwkYl1ayNn5pYR5dW3bfvY2k9M9a7XJJ2Z4KhOS5ktOpjdaBz3ppOO9LVEXAtt7/mcUK+fetnwxqdlpV1PJfQG4jePaqiNXw24c89PrWbqMsU+oXMtuCsDyMyBhggE8DFZczc+Wx1SpxVJVFLV9CHPtQDgU2lrWxzJjuDTw/SowcCjdStYq5KDnvT0kIPH9KiHQc0oPHWlYtTaLKzZXmrum+IL/AEgSixvJbTzcB/JON2M459smsrPpSoNxPrUuKkrNG9OvOk+aDsyeSd55XkkYvI53M7cknvT0kOeucVXKkfSnK2D7GiyFztvmZtXOlyWlktyzqyMARj3qqk5B96gl1G5nhEUkzvGMfKTxTEcZFS43OmNRLY1oZzuB3YH09qtxTbsfMSfpWPHINtWoX3kFeTWE4LdnrUK7ukj7C/Yn+KGk+A9I8b2mpW93cPetamNbVVIUBJlOSxHdh696+c/GukPod5g4Mf3Qc55x9BXbfCnTL7wyupyXsQikk2YUOHyFBJ6Z9RXlWq6tdapITf3k1w2dwVzkKT7duK+ep81XEvl+FH3denQwmAjOonzzIPtP1zTXuiBwcH6VRZyM4JwOlN8xjgZr2/ZpHxcsS2XluXPVht75NWY7jcDjoK6P4U+JNC8N6xeXHiC3FzbSW/lxIbUT/PvU5weB8oPPvXNa7dW91ruoTWeVs5bmRoV2bAIy2VG3+HA4xWEleXLY641OWClzb9CQS7yD+NSeYGPI/Os9X24qaOQkmsnTOmFexcEmOeoGa9W8H+Cr1bmCSa7haKaJVUKDuUEDH5A+teSRuBjjj3rq/Cev6j/asbf2ncRJCjOCZjhcDAHORXkY6hOcPc0Psshx1GjiF7RNt7HsXiC0j8EvbwLKblZkMm5F2bTnGOSawJvEK3d0vyupYBcnH9K4vx54uutZurLzL6S8EUbKHEmcfN04HtXKnUpN33nyOh3mvMpZe5RTkfXYviVUKrpw1SOq1PxrPcRXNssKxk5j8wOcjnH51F4X1IRSzmR2IKgZOT3rkXuSZCWJyevcmkF0VPyswPseteh9TjycqPlFnuIeIVeUr2PZNL122mvUiR9zsrELtPpnPIr2D4d/He5+HdnbW8Omx3qw3D3IV5tgZmx1AXPb1r49jvpYXDxyyRsOjK5BFdBoPjOXT2kN3Jc3YYAKpk+6fx9q4ZYGpSfNTZ9DHOsFmS9ljoaM+9G/4KB+KY1Pl+FdIKe80vSmD/goR4n43eEtJz323Mv+FfFQ+IluV/49J/8AvpP8KZL45imUqtvMuQQGLrwce1NPGGEst4YSuo3+bPuCL/goVr64P/CJaaT6/apP8KyvGP7cviDxn4Y1PRZfDWnW0N9A0DTR3Eu9AwxkfLjNfD1hr00F5FNLNLMi/eTf97iuitfF9vK6p9nlyenzLVVHi0rNk4TLuHZzU/Z2aemrPWPCvj2fQry7kaMzfaRGJMvtO1GLAZA4619D+Ef2zL/wzpq2kPhmzuI1G7LXjgscAf3D/Kvi/wD4SK3UFikowPVa7e1uFAjUHPygDv2/+vXkqVTDyv3PrsVleW5vTcJxTt/SP0Z+Nn7PzfGnw7b20eqxaQTci9Li080sxQgD7w4G41+Zvi/wFDY6tfxm9Mi2txJaLIECiQI7LuwckZxn8a+wm8Q34jBfWdQCAZI+2SYGO2M16dY/Enwd40vpLZbI3cqp5hF3YrgjgEgnrzXqTdLEWlH3ZH5tgnj8gg6FVe1pPVJK1j4S+Evwrf4g+MNE8KW+opY/2i7RrdSRCUIyxF/uggnOzHWvpJv+Cct8AN/jq33HsNLb/wCO16J4y+L/AIT0HQdR0HStJurLVlURR3NlaRwCN8qQQ+RjjuPWvl/xr8QLy78T3F3Be6pDkKdpu3DBvX72PSsJSo4ZWn7zZ6dGWc51Uc8LL2EFpZq9zrvHX7CF74fWG3HjGC4N1HK3/IOYYVQM/wDLQ85I646GvzY0Bi5nPuv8jX6W/C34w/bNPv7TWZdVu5rZCIZZ3MyKpU5GWY4Oa/NLw/gG5wO6/wDs1e7llSnUUnTVj4TiinjaNWlTxsuZq+trXMe74uZv981uEZ0uHv8AIn8qwr4/6XN/vtW20m3SIjjcdiV9ZA/Jp/GzDu1xctzVeYYhf/dNWJ3LyFiOvYVBNgxP/un+VS+pBlEf5/KijqBRUmQUUUUAFJnmk3U5ELk4600NgOTV+M40/Hsf51TaB0XcRxVtD/oB+n9anZghbT/VH6mphUNqD5R9MmptpqlsjRFlrd7UBmIy3TaakurQxQrISDuI4Ge9MuLjztnGNoIq7qXNlEPp/KqaQ0yPw6CdZgxzjdyP901oeIf+Qwe/7tRxWJZMy30ZUkNzyPoadezH+0FLuSMLnJ7VCj73MdkKvLTdNlsHpS4JqOORZQSpyAcVJmutakCYpcY/Ol/nQOOtAxCRmjGKUg5yBmkAP407CsIetIePpS0N0NNghPel60gHyilAxUgmGOMU0pjJFOpD1p3BjelBAP1penJppHOaQthCpOaQqDTiaTaPX8KAUkNwATRuJFOxyaNuKditxv60BePU06jHNIBpGBSU8jNMxigVkBANFFAoJsgNNJAFKVPal4FBFnuhoPFKDTcGlwPWgq8hQeaWrl7oeo6bEkt5YXNpG5wrzwsgY9cAkcnFU6dhibRTWFPpACx4GfwosUhpGQPWkHWnEdqaOtIOopGabjnNPppGDSsK4mc//XpDwc/pS0Uxof8AaZGQIzuV7KWJFA61GMp1pwbPNJ36jJOtBGaRTmloWxOwxhgU3NSMM03FJDQ6EBpow/3Cy5ye2Rn6V6r8avC/gDw/Z6W/grU49QmluLhbpEvvtHlxqE8s9BgElsHvivKMigHIpjFpGPFLmtXwn4XvPGfiGy0aweBLu7YrGbhyiZAJ5IB7A9qViWZHUUjYI6V0PjrwPqXw9199H1Vrd7tI1kJtnLJhunJA5/D8a55uAe9IQnahVx+dA9KctMB1FFA5pFXAcU6kA5paaBBRRRT0BhRRRSEFA44ooxRsMQ9aaRk5wD7kc0po20XAVRRtoB7Uo/OkDE79zSCnY49KTbTGIRSjGKNtJ3p2EK3SmbeAcmnkcU0rihgIAQfUU6kFLUjCkxzx1paQ8UAHSm05ulNoJuKtDULSnoaBDcc0Y96KD6daZSDdj601utOpCM0rXKu9i5Z6nJYPvhO1sYORkflVaSRpWZ2yWJySTTNvPWlHTmlypMuVSc0ot6I6jS/EkFtphjeNFuIxiNVThzjqcfh9aw7/AFGXUZRJMQcDChVwB3/GqvUYpB2Prxmso0owk5HZVxtavTjRb0Q7NMbinYI+tJjIFbXPPacdGGPcUdDSU5mx1oFe4qnHHanUwdKX8aAuOprCnA5prc5xQA0L60oXApQM04DFAxuDSEZ5wakPQU1hzmnYVhoFWLS4mtJlmhkaGVDlXQkEfiKiUYbpxV7SbMajqlpabtonmSInOMZNKduVtm9DmdSPI9b6G7rstte6RJcyzrdXgKpHI8pZwvHGM+5/OuQPeup8eeGbXwvqFrb20xmEkHmOSyttO4jHHsO/Ncs1YYezheOx6GZOXt+WotUOhmME0cigMUYMA3IJBB5ro/F3j3UPG/2YajFao1uWMbW8ZUgNj5eSeOK5k80gHIrVwi5KT6HnxrThFwi9HuP6ik5ApQeTRiqMBN3NO+nFMpQKpjFbI74oByKOOlHSpAUH2oxmk60oODmgVxcH1oAOaN4paCri5wRzTl474phGaBxSLuSI+SR2p2R603cNg55pAaViubsSgnbnGSaVWzjimKwzjP0qRSDgU0jSMrkqybTnPFep/DXwRp80l+PE9tLbKY1+zyu7RhGJOTkfgea5PwV8PrvxrBeTW9zBBHakBxNuyxIJ4wD6fqK9M1a5gWO3+eQpLhVaJTtfpyCeK+fx+Ib/AHVN69fI/SOHcrVni8Uvd+zfqc7ofjW61fxfoFhLezTW81/bQyoXIR1aVVYEADgjP4V77/wUW8JeGvB3iXwRaeGtD07RLX+z7rzE0+1WFXIuAAWwBuIAxknua+UfDheDxbpEyMJXhvY5FWTODtkDAH2OK9R/ab+Pdz8ar7Q2urCysZdNjmTdZh/3gkcNg7j2IOMevetadP2dWPKt9zw8VXrYiEqlSXuxemp44CDWzfz6c2jRLAIvtnybiqEN055xzXOeft7A/jQZM969VxTPCjWtcso+05NPEoJHrVVXz1607f2qHAuNVl2O43EAjGfep1k44IrNV8g8c09Jdo9cVm6Z1wr9GaStyPSrljfyWcjPGQCyFCSM4Bx0/KsdLrLDOAKlWdXYBTk9q5507qzO+liXCSlF6mkbtm+9Izf75zSGYEnqao7yPrQZcDnislSR0SxMnq2WjMCfpSGbDd6qCdTnmjzl55FP2ZCxDLvnEDr+FKJzjkDNUhKpPXn2p4fj0o9mWsUy6k5yBx+XSlF5k/Kyt0+7zVFZdrKQT8pBGPqK7j4lfE2Lx+LJYtOfTktnkcK0qvu37fRF6bfxzWE4yUkktDrp4iMoNuVmtl3OaW5IA6flVq2vDDMj56HONtYqSfiatJJj29qidPyOihimmnc6GK+M6klsKeCCMV1vhvxQxvGfUrqQxbVCnHAOR2A9K85SXgY6VoxXXAGefWvMrYeM1Y+twGZ1KU1JP/gnvF98br+/3qusuidPlhAz0/2f8K6Dwt8Qr/SL9rlNSkjYpsPlqGJBxx90+1fOcMhyecD616N4W1FdSaTAYbVUgsRzkmvEr4f2Sumfe5djKeMvTqxWvQ7rxB8Uft+syXzXdxvbAeRvlBIAHTGO3pWJF4n0/U9ThL3qAPIPNdwQAOASTj2rnPFVoLPS5nB3b2z+bCuIttQeKYlGIJBHWohh1Wje50YnGfUKipcqseu/Ej4qaB8O4LO30tv7Qa/ics1sd6R4YLySQc4J4+h718otA2hl2kXzfNPAXjp1z/31+lb/AMSdRmnudPDvvG1sDr3Fc54y62vXq/T6Cvq8swscPBcu73PwTizM6uOxE1N6Q2+Zh3DeZM7Y2lmJI9K3ZHEelQMRuARMisB4m2h+MYBrcu+NFi/3Er6eOh+XPV3Me4cSSFgNoPTNV5v9XIP9kmn0yb7jf7pFSyTL7Cig9BRUGQUUUUANzgmrgVFQYGCRzRBaAsS4OO2cipZAsQAOAOgpoA+XyRv+7nvUcLB7kRKcwn+HtUM05YlAcp1xilsv+PlPWjqNGl5ax8KML7UdTSucmkq2NC4461oNDLcRBByBg8nis6rqX0kC/u2w3ckZ4oKuU5le1nK52yL3U+1WI4hc2hYqHlOQC3Jp8sUV3bvISWvG5IBIH5dKhtHlimW3I285249aSsWvMh/0i1O1spnkDAqxa3Jy3muO2M9a3INOs7xCblsSKPkXeVz1/PnFYF5YXNiUFxBJAW5XeMZx1/pQp2djp9nKMVNbF0PnnrmlJzUEUgbAVg2B2qYdK6FqJC0d/wDGnlRtB70zFUVYQ8DNC8nmnllK+9NAzSuJoD1pKcF980hFIVu4lFFFAxeMHNMZetOooBq5GRSVLQelNEOAwDBoPSnAbTS07lK60IxmkJzTyue1NIwKGMaelIaWm9yKkAooooAdgYxSEYxRnBpR096AGkZ9qaRyRTz1pCCAfSqRB2njn4ly+N9NtbOSxW1WCQSBxMXLYQrjG0etcUBjmgDilx3oYJDcYq3pd4LKdnKNIGXbtTHHIqqfrinwSCNiSM5GKEAt5P8Aarh5QCgbHBx6VCVp0pLuWXgGkwSBSY7iAYoIyDR/KjOTikIaBgc0qdDSsQOO9NDAc0FCsMimgYyKcCGJpKAQoOPanbunNMHFLkmgLEh5FMJOSBS0jUrBsNAzTgMUmCDSUWBik9auaPrF94f1CK/026lsbyLPl3EDFXXIwcEe3FUsjPWlUZoJNDXPEGpeJL77bqt9cajd7AhnupC77R0GT2FZ4xjNOpMc8VIxBilxiilxnvinYQUi8U/FFIAoopabKQUmMe9JuFLRYB7gADAxTKDyMUVQmFBopM84pCADFLjmiiiwCYpcZxRT0backZppD9RlFKTkkjpSU2NBSHr70YNBGBSAM8UmaAM0oFAbDcYpQM07FFSO4m33pCOKdiinYm5GehoxyKGyTj3rQutA1GwsYb24tXitZtvlykjDbhkd++DQluBRoowR1opMQ3HWjHNPIGKShditRmKOvSnHnPNNJxT2GIDyacOaTBpVH50agLitTw48aa3aNLB58QbLoF3cdCce1ZlXNL1AabdCYoZBtKlAducj1xWdSLcWkdWFnGFaEpPRGj4zv7a/1jfbwvDtjVWDrt569PoRWDip9RvPt97NcbPL3kHbuzjgDrioainHlgolYusq9eU+40nkigc5pQnzE0EZFanDsIaUDijGPpQOTgUFASRinbqaVIPNKMA0AAOO1KKDyRSAZOKAFHWlo2kHkH8aKpALuozjnNJQelMNhHYseTmmYzmnUUDcm9WWdJ01tW1WzsY5EikupkhV5M7VLNgE4B4yeeDW/wCOfh3f+AZbOO/ntpmuVdk+yszABTjnIHXNc3a3Utjcw3NvIYbiFhJHIvVWHII+lXda8Tap4ieJtTvpr54wdhnbJXJycfWspc/MnF6dTohKj7Nqa97ozNAxS0Ad6aeG9q06HMBXOO2KXFAOaMe5o1AKbycU4nFCsAQTnrRuFxoal3VNczpMF2gjGeoqCk0lsIdnpTgM00DgU5aQxRRQeaPzoEGKUHjpTM5pQc+1BaZIM57VJGefc1CpwangG+RFXqWA/XH9aiWkWzooJSqRXdn1H4Z8Eab4I025FhJcut0FZxcOrY47YA9TXzMup3UBeJLiVI9x+UOcdfT8K9Y8YeJ/Hfg21tl1cwQRTswhwkMocoQGB25I6j06143jLE+pzXg5dSk5TqVHe5+lcT42iqdDC4WLhyLVbb2NHT7t4b+3m3Y2yqc/8Cr1T9oHwHoXg2DR5dHtmt3uZJVlLTNJu2hccE9snpXkEZG8Zx/k19W/s3aZ4A+M1trEfxg1S+vfst1bxaWYrh7ZQ0kchk3GOMjkogGSOfrXZiYyhUhUT0W58xgqsJ4arh3C83qvKx8nbgRjNOR+Tz+tJchftUwjGEDsFHoM8fpUR4r0E76nzbbi7FkSZPDHNODHPJP51URghyak83P0qtylIsCTj3p4fPc5qDcMevuKVW444NS0bRmWdxz7U9X2kHPSqu8nHP6U9Tg0uW5sqli39qcn73HsKHnLEYOPpVfeF6HNWdNktvtP+lY8raeuevbpzU+zNVWfcb5hIzk0F/8AaP50motAt2wtTmDAx169+vNQBzjrR7MPbMseYf73P1pPM6fOR+tQq3BzyaCeKl0ylVZYM3+1+lAnweD+lVt1Kp5yTUuFilWZbW4YMDuPHvUqz7jyRzVIOCetSIwYgDrWLgdVOq+jNaC54wduB04q/FJ8q8Ac96w4DnHFX4G2g5HcVx1II93DYiRsRTHPQVv6LrlxpLyywSLGxQKcqG6c+lclHKNwyBnpWrYhZQ4AGeg4PpXmVqacXdH1mAxcoVE4ux61472tohZTn5k/XB/pXj2p6iI4pbe3Znv5UPkRxfeJ/pjGea7LxX4thv8ATJLPTLpLnUEZWS3g5bKkZBBGOmfyrkNKsWlto9R1mEwalauSsrNs2xjkEgccZP1rkwlF043kejxDmkcTVVKg9bavsYEWk3lxC76ukjzI2Y/PbcyjGeOfWuEmvLrU2UySy3JRsAMc4z1x+Vdr4x8XzRX1tDpd1BPHLFhgiq/zbiMZ7cY9Kx/C/h5UuZDfQyR8KULHHfnpX1OEpyerPw/Na1Nz9nTd7bvuT6d4bunWN720dYSnVz3xxwDmq+rzRJBLaqwDRsE2YORj61t+JPE8cdnbxWdyjupAO0ZwAuO4rjJrh7iZpJDuduScYr05WWx4FxlMm/1bfQ07NMlOY247GsWBl+n0oo7CipMgooooA1ZJEQAMwH1rPuJzKdvGA3B9qJrgzEcAYqKrAQDFPikMThhgketNoqANGC581MsVDZxjpUoJrKRtrqeuDnFWTqB6BcH600x3IxqMvop/D/69TJc3BIbyxjr92runeHlvHcPOUAAPCZ6/jWle6ItjbRsJzJubbtGPT2NCjIaMrTbl5tQiRyiDntjsav3kEqXf2iGPzE2jlTxwOf51juANSx2z0/CuksTFLYGN3VASwPIHHFVFXLRHp+obxI0gSNgVXBbHvW7c3EWv7GvTHCIx8oRsZ3Hn19O1cnqVpHazIIj5qbASc5wc+tTPrbl+IQAPU/8A1qlx+87KNd004vVMpFpLSR9q/IWIBYdcGtFHUoCXQHHPzCqktx/aO1GxGEywOc57d6zpFCyMuQQDgEd6tScTDms7o3jMhA+df++hQJF/vDPpmsFGKsDjOD0qwt0Y2D7Bxz96rVS+5aqLqbBWhVzWWNYIx+6X/vunjWWGf3I/76/+tVcyK9pE0Pu04EHHJrMOrsx5hH/fZ/wpP7WIP+q/8eP+FLmQc8TUIFNI54NZv9tf9Mf/AB//AOtQdZz/AMscf8CP+FHOhc8TRoGe9Z39r/8ATIfi5/wo/tfp+6H/AH1/9ajnQc8TRorO/tf/AKZD/vr/AOtSjVsf8ssj/e/+tVc0R86NDBPSkIrP/tjp+6/8f/8ArUf2vn/ll/49/wDWo5ohzov0dqz/AO1Sf+WX/j//ANagarz/AKr/AMf/APrUc6J5kXSOaQrxVI6tk/6v/wAe/wDrUn9q/wDTP/x4/wCFLmQc6LwUUoGOKof2oS2RF/48f8KX+1D/AM8v/Hj/AIUuZBzovEZpMY6Gqf8AaZ6+T/48f8KadUz/AMs//Hv/AK1NSQc6LpBNIAelUjqmR/qv/Hj/AIUg1Mg/6vk/7R/wp86JckX8Z6Ubao/2p/0yH/fR/wAKP7UJ/wCWY/76/wDrUuePcXMjWs9LuNQLiCIybOW5AwD061XkiaJ2RhtdTgg9QaTTfFM2mM7QxRFmAB3lj0PtiqUmrNLK7mNMsxY4Y9SafPHZMfNEtk5oAyKonUT/AHB/31SjUiP+WY/76qeZBzIukZHWkxgDpiqf9pdf3Y/76o/tL/pmP++6OZDU0XCoNNIGBVUahkfcH/fVL9v/ANj/AMep8yBTRZ6dKUc5qmdQ/wBgf99Uf2hj/ln/AOPf/WpcyDmRcxyKXb07VR/tH/YH/fVKNQJPCD/vqnzIfOj1v4CeEfBnjDxBqVv431Q6XYRWge3kF8lpulLqMbmBB+XPH49q4jxrpthpHjHXbDSbj7VpVtqE8FnP5gk8yFZCI23DhsoAcjg54rnv7ROMeWp+pzTTqJ6eWv4E0OaDmRbYfKaQDNVft5P/ACz/AFpP7Qx/AB/wKlzIOZFsigDBFUzqPJ/d4/4FR/aBH8A/76o5kTzIujrTqojUD/cH/fVL/aP/AEzz/wACP+FHMg5kXKUcVS/tH/pn+p/wo/tH/pl/49/9alzBzIvjpQaoDU+eI+P97/61H9pnP+rH/fVF0HMi+KDzVH+0iekY/wC+qd/aP/TMZ/3qFJFcyLYTIzR14/pVQamR/wAsx/31Tf7R5PyD/vqnzIOZF8CgjFURqYP8A/76/wDrUp1Mkf6v/wAeo5kK6LlJjnNU/wC0if8Aln/49/8AWpP7T4/1f/j3/wBajmQXReoFUf7T/wCmf/j3/wBalGpA4+Qf99f/AFqFJD5kXSKKo/2mP7g/77/+tSjUhn7n/j3/ANanzIXMi90pKp/2gScCP/x7/wCtUguJcf6hvwJ/wqHUhHdmsYyl8KbLB9qTn0qA3Tgf6g/nSG7f/ng3/fX/ANakq1P+Yr2dRbxZYA5paqteMvWI/wDfX/1qaL9j/wAsT/31/wDWqlVhvchxknazLeaWqZvivWEj8f8A61Kl+W6Qlvo3/wBal7SFr3BRe1i3RVYXcn/Pu3/fX/1qBdS/8+zfn/8AWpe3p9y/ZT6RZOQd2a2L7xTfalottpU/km0t9nl7Y8MNowOe/U1gG5l/592/P/61IJ5e1ucfU0vb0/5h+yqfyv7iztpCPWoRPMR/x7N/31/9ammeUf8ALu3/AH1/9al7el3D2NTflf3E+KOear/apP8An3b/AL6/+tR9qk/592/P/wCtT9vTfUXs5/yv7ifb60hGO1Qfa5P+fdv++qUXMn/PBvzo9tT/AJgUJ/ysnXgD60BTuyKrm5k/54N+dKtzL/zwP50e2p/zD9nPpFljBFBGagFzKf8Al3b8/wD61L58n/Ps35//AFqPb0/5g9lUe0X9xOB6UY6nNV/tEg/5d3H4/wD1qPtMmP8AUN+dT7en3D2VT+Vk5z2pagE7gf6hvz/+tR58mP8AUN+dHtqf8w/ZT/lZMelIpwwNQG5kP/LBvzpPOk/54N+dHtqf8wvZVOzLLNuYmkwag8+T/nifzo+0v/zwb/vr/wCtT9tT/mQeyqfyss0A4Oaq/an/AOfdv++v/rUv2mQ/8sGH4/8A1qFXp9xezn2f3FuWbzcEgD6VY0bT5NZ1ey0+Eqs13OkEbSE7QzsFBJAJxzzxWWZ5D/yxP51NZ6hcWN3BcwIY54HWSN+u1gcg4IxwRnmn7en3B0qn8rPUPjP+z94p+A8mmp4mfTn/ALRaZbc6fctMP3W3cWyi4B3jHGeteZ5zXSfEH4x+MPikun/8JTqjasbDzBbl7eKIpv278lFGc7R1/rXILdPk/uj+B/8ArUKtC24uSe1mW6KrC5k/592P40G5k/592H4//Wo9vT7j9lP+Vlimg4qIXEh/5YN+Df8A1qY106f8sT+Jpe2pvqL2c1q4ssjJ70dari5c/wDLE/gf/rUG6df+WJH401Wh3DknvZlmiq63bH/lifz/APrUG5cD/Un8/wD61P2sO4ezk9bMmIxRVY3jH/ll+tJ9sb/nn+tP2kO5Fpdi1RjNVxcyHH7k/maX7S4PMJ/Op9rDuV7OfZlkUtVftbf88T+f/wBal+1tn/Un8/8A61HtYdw5J9mTkGlAINVvtbj/AJYn8Sf8KBeN/wA8v1P+FCqQ7hyyXRlkD1p3XFUjfsp/1X/j3/1qP7Rx/wAssf8AAv8A61VzJ7EN20ZeqSOTy3RgdpBGPzFZo1LJH7r/AMfpG1AMANuP+BilJppounUUJKSPoHSdYsPG95L/AMJ9cW0iwKWg33KxgZJ3bdjc5wteKuoVyQCo5IB9Khm8SyXIXdBFlSSCCR1+gqtJq7nOYU/M1wYagqEpO+j6H0WZ5vHHxgmtV16v1L6tjOa6Dwx491rwfuXSrwWiySpM4EKOSyAhTllJ4BPTjmuL/tfj/VL/AN90+LWUWRS0YIBycP7/AErrquM4tHjYbFexqqUZW8z6x/a0+EXwp+HXhfSr3wDqbalqdzqDR3Tf2oLtViMbOPkCKF+bAzz06V8t5H1rovGXxRXxbZRwDThbBJBJkShuxGPuj1rjDqmOkQ/76rlwjnyWq6HZmM8LGt/s0rxNCkznAzWeNTz/AMsh/wB90o1Ln/V/+PH/AArtujyfaI0QeOv4VKkgwAx79qyf7T4/1Y/76P8AhSjU+f8AVj/vui6LVZXPSLnSvDy+AYb6O4X+3GCbovtWTneQ37vt8oHH4965AE+tZA1fHAjU++7/AOtS/wBskAfuVP8AwOs4rl6nTUxMKjVlaxsA9cmjfngVkDWzk/uQf+BH/CgayQSRB/48f8K0uZKtHuapNArLOstj/UgEerf/AFqBrZ/54j/vr/61Fx+3j3NYDipIzn5eOKxv7cP/ADwz/wAD/wDrUq66wOfI/wDH/wD61K6LWIgups4560Y5rJ/t8/8APv8A+RP/AK1J/wAJBz/x7/8Aj/8A9apepp9Zp9zXHWpI+GB4xWKNf7/Zyf8Agf8A9anL4hOci2J/4H/9as2jWOKprqdFE+3kgHB75qdJjngrx2rlx4kxx9mP/fz/AOtUg8TBOfsx+nmf/WrB07nfDMacep2UT8jB7ZpLrW57O136d5dxcBhuRV8zA9cDp2rlU8ZBACLU/wDfz/61dD4W0lbNvti3Bb7REPkK4xuweoPNckqdtZI9GOY+2apUXa+77Gp4f0iFpIdauJZY76TzGmicqiAtlTwenUGs7xn4tmtbuXTLaGGVJ4Au7JLAsCOCDj0qp4t8UBEvNJMBYsqgTb+nQjgj+tc/pGjRXMMVxJKQd/3MDsRiro0OeXNI83H5iqUHh6Hzfct+HPD6uGmvopIpo5AY8tt6Vs6rriWTQtEEn35+6/Tp6VV1LVf7O2KI/MMgJ5OMVzCr5rY6d+leynyKyPkWxJGd+oJwe/NMwQoz0rqrTwostvFI07rvUNgIO9c7dQmG6mizkI7IPfBqGnuxIjhjDygHhSetF6sUWVDDle59qUcZ4qhqRzMvpipbsK5THSigjgUUuwgoooosIKKKM0lJDCiigUNhsLjNIOGFOoxzmoEdLpt8lpKzMrNlQAAB61EkX72SXcG354H17/nWNbXKwbtwY56YxVm2n+0OQN4AGa25r2TGiNxjVG+v9KtBscD0p4i7kHNUL0lLjuOO1K9tSr2L6S5VkxkvgD/P41ePh6Ysf3qD6A1hQ3IjXDbic9uak/tIBhzLjIzg/wD16fMmNSXURuCeQSD6irK3mAARnAxVxvEFnn5bdx/wFf8AGnwa3bzOVWF89ecUk0UismookYQqT71Yh1aNIfLEbN154q0dVjX/AJZE/itNbVEYEeR/KqugsQQ6xHCm0ws3X+7mnrrsYBzC/wCYqKO5VWUlCcEE9PWr0+txSuCsLIPQEU7oSsVv7ej/AOeL5/3hR/byf88X/wC+hUv9rR/3G/MUf2tH/wA82/MUaFaEY19M8wP/AN9ilHiCMf8ALu//AH0Kf/bEYH+rf8xSf2xH/wA8nP4rS0FoZsF6sMjMRvz7+9WRrEef9Wf++h/hVo6xFwfKb/x2lGsRZ/1R/NaNB6FddZizzE34MKYmooLky+WxX+7xV3+2Isf6k5+q1WS/QXZlKEKcnaCKNA0JW16L/ng/5iq1zqsc5XbEy4+hq82uRA/6ph/3zSHW4z0hb/x2jTuGhlm+A6IfzFS2uorHcRuyEhTkjjmrp1pAP9SfzWkfWlaIp5JGR1yP8KLINCPUdWiurlXjhdF2gYOOvPpTrPXY7aIoYHY5zwRTF1RAAChJ+opw1WMdYz+Yo0QXRKfEcIcnyJMe7CmyeIonRlEDjI7sKUazHsx5bZ+oo/tiMf8ALJvzFPQLoprqqqgHlscd8ilGrKMfum/76q2dZi/55v8A+O0f21F/cb/x2lZBoVf7YQf8sW/76H+FImsIJ1kMR+U/d3Crf9sof4G/SlGsp/zzb8xTshWRVn1yOWbf5TDgDGR/hTP7aTJAiYf8CFXTrEf/ADzb8xTG1ZMZ8tv0paD0IF15B1iY/wDAhQ2vJ/zyb8WFS/2vH/zyb9KBq8Y/gb8xRoTZFeXXElTaImHT+If4UxdXAH+rf8xV4avGMfI35il/tiPH+rb8xRZBZFBdaVc5jYn/AHhTv7fXnETf99Crv9rRE/6tv0o/tiIf8sm/MUadwsimniFAeYWP/Ah/hTv+Eijx/qH/AO+x/hVv+2o/+ebfmKDrMX/PJvzFGgWKR8Qx5OYW/wC+h/hUQ1eMys+xuc8ZFaB1iPP+rb/x2j+14/8Ank36UWQWKI1iIE/I/wCBFTR+IIkUDynP4irI1iPvE5/EUf2xF18pvzFGgyt/wkSbsiOTH1FKPEKZ/wBVJ/30Ksf2tGMYib9KQ6smM+W36UaBYaviSNcfuJP++hTh4pQE/wCjv/30P8Kb/a0f/PNvzFOGrR/3G/MUaBZFNtcjMrv5R+Y55I/woGuLn/VNj/eH+FXP7Xjz9xvzFC6wmceW36UaBZFT+31A/wBS3/fQpU8QIMfumz/vCrR1aP8A55t+lIdVQn7jfp/jRoFkRf8ACSJj/UN/30KT/hJFAP7g8/7Yqb+1Yz/A36UHVUH/ACzf8xRoFkUU1pEJzCW/4EP8KkXXUB5gY/8AAh/hVo6qg/5Zt+Ypn9qR/wDPNvzFAWRD/b6cfuW/76H+FB15c/6k/wDfQqcanH/cb8xS/wBpp/cb8xT0HoQ/2+mP9Q3/AH0KX+30zzA3/fX/ANanHUkzwrfmKX+0F/un8xRoFgXxKigD7O3/AH0KH8SoSf3Dj/gQoGoqP4D+Yo/tNd33G/MUroNCqNbQOW8ljz03Cph4hjx/x7vn/eFTf2mnXY35ig6mg/gb9KNBWREPEcSkZgf/AL6H+FPHieEY/cSf99D/AApRq0f9xvzFPGsJn/VsfxFNWGho8VRBWH2eTJBx8w9Ko2+qxpcROUchWBI4z/OtI6wneJvzWgavF0MTfpQ0n1BaFmPxfaLKhMEpAYHHy8/rXSn4tWax4Sxnz7OlcgdUiz/q2z+FIdTjxnyifwFclXDU6tuZnsYXNa+EVqbWvkdenxegQ/8AHjKR/wBdV/wqOT4q2j3SSmwlwv8ADvTn9K5E6pF/zxz+VNGqRZ/1OPxFYf2fR7na+IMY+q+5HT6p8T7S/nWUWLoVjCbSU5569P6VSh8fWiXMUjWcmEOdoK+lY/8AacYH+qP6U0ajFuP7ofjitVhKSVrnLLN8RKXM2vuN+9+IlpcxhVsZAwYHIKflSaX8QbSzuDIbSU/LtwNntWKNTi/54g/itO/tSIf8sf1FX9WgotXM3mtf2ntG1f0Oxi+L1mnWynP0ZB/SpR8Y7HA/0Gf80/wriP7Vi/55j9KT+0Y2P+r/AJVzf2fRfU9BcR4xLdfcjvofjRZQtuFhc/nH/hU5+N9mR/yDrnP/AAD/AArzaS7jbGIxgewqM3Mf/PMfkKh5dQfUpcS41dvuR6fF8cbND/yD7n/xz/CmzfG6zk/5h91/45/hXmIu4wf9Wv6UovEPWNf0oWW0e4/9Zsdtp9yO8n+Llq7EizugvbOz/CoD8WLUDi1n/EpXFfaYx/yzA/AUz7YqjGz8gKtZfSXUyfEOMfb7kd0PizaA/wDHlOfqU/wpx+LVmw50+4B+qf4V5890Gz8gz9BSfaVHHlj9KPqFLuL/AFgxi7fcj0A/FmzBOLKfn12f4VLpvxdsdPRw1lM+45ydnH04rgoLtEXBjB/L/Cpft8eOIv5f4U/qFJq1wXEOMTvp9yPRV+N9ih406c/R4x/7LQ3xvs3H/HhcA+0if4V5s2opn/VdPYf4UqahGOsOfwH+FZ/2dR7my4lxvl9yPRP+F0WecmxuCPeRP8KRvjVa/wDQPuce8qj/ANlrz1r+J1wYR+IFVZrpMqBGoAHHApf2fRXUn/WPGvqvuR6UfjXad9OuP+/y/wDxNMPxnsyP+QbNn/rqn/xNedW9+kJbMQYHHoMVZXWE6eX+oqll9HuT/rHjPL7kd4nxmssjOm3GPaRP/iKkHxjscj/iX3P/AH2n/wATXFJrsQiAMRz9Vpv9sx4/1bfpVf2dR7jXEWNXb7kdwPjRZL/zDLj/AL+J/wDE0h+NVl/0Dbj8ZF/+JrhW1eMj/VN+YqNdTQA5jOPqKP7Oo9w/1jxnl9yO+Hxos/8AoGz4/wB5P/iaQ/GeyOM6bcH/AIGn/wATXA/2rH0MZP5Uv9rRj/lmfzFL+z6PcX+sWM8vuR3o+Mthn/kG3B/7aJ/8TSn4zWePl02cf8DT/wCJrgV1SPOPL/lUi6rGoH7o/gRR/Z1F9RLiHGeX3I6bWvihDqluqJZyptYNnKensPeoNG+JVtpl0ZXs5ZRtK43KOuPXNYY1qIHmJvzH+FK2tQkY8ls/Va0WCpKPLcwed4lz59L+h2a/Gawz/wAg+fn0kT/Coz8Y7M5xp83t86f/ABNcY2rRY/1R/SoTqkZz+7P6Vn/Z9HudP+seN7r7kd4nxns1Axp0+R6SJ/8AE1ma98UbbWBBsspkMZOd0inP6Vy41SMAZiP6Uo1SH/nkf0qo4GjF6MyqZ9i6keWTVvRHT6b8S7SytUiaxmYrnLBlHemS/EeykZyLKcFiSOV4rnP7YiHSNj+IpRrMYA/dN+YqlgaO9zP+28U48ulvQ3o/iRbRyqxs5mA6jcoz/OrzfFOw2bRYTj/ga1yn9tR/88m/MUDWIh/yzP5iq+pUu4o53iYqya+4ujxpbJnbauyk5HKihvGNs8qMbWQYxwCtVP7Zix/qWP4ij+3IV/5Yt09q0+rU7WOZ5nWbvdfcdaPizYLkjTph7CRBjp7VRj+Jdmt688llKwYYCb1wKwP7eh5/ct/47Tf7bi/54t+lZLBUl1OqWd4ppLT7jcb4lWQldlsZNpY4+deB6dKlX4nWeBiykB9mX/CufGtxf88G/wDHaBrsWf8AUt+a0/qlPuSs5xK7fcb9x8SrW4hMYs5BnHO9f8KZY/Ee1tY2VrOU5OeGWsX+3Iscwn81pjaxCT/qT+a1awtNdTN5viG76fcXLnxnayXEjpayAMxbBK8VmS+II5Lh38pwGOccVMdXiB/1Z/NaUavFx+7b8xXQoxirJnm1K0qjvIrf8JCmf9TJ+Yp3/CSKD/qZP++hUx1OM5/dv/30KY+oxnpG35inoYojPiVSf9S//fQpp8Qr/wA8H/76H+FSDUowR8h4PqKl/taMH/Vt/wB9Cmkg1Kv9vpn/AFD/APfQ/wAKP+EgT/ni/wCYP9Ktf2vGesTf99Ck/tSP+435ijQViuviCP8A54t/47/hTx4hj/54uT9R/hU41aPP+rb81pTqif8APN/zFGgWIB4hTtbyfmP8KX/hIkP/AC7v/wB9CpG1OPA+RvzFH9qRg58tj+IpaCsRjxHFn/j3b/vof4U0+IY2/wCWD/mP8KtNrMeP9U/5ikGsxn/lm3/fQp6DKM+rxz4xE4x9Kkj1qNUVfKckDrkVa/tiPp5bZ+opf7Yjz/q2/MUWXcehANeQdInz/vj/AAqb/hJIh/ywk/76FP8A7Zj6eW35ik/tmMf8s3/MUaICG68QR3Fu8YhkXdxu3A96isdcitY2VoWfcc9QO1Wm1iMgfum/HFN/taP/AJ5t+Yp6D0G/8JLEJMiCTH90OKefFCNjELj/AIGP8KBq8Y/5ZP8AmKP7YjB/1TfmKegyRfFkS4JgZv8AgY/wqZPGUIcH7LJj2df8Krf23GP+WT/mKX+2485MLH8RTTXcm3mW7jxrby2ssf2SbLLgNuU46VRh8QwqrExS+3T/ABqf+3oAmDbvyMfw1H/bMPGInH0IqW/MVkM/4SWErgwzZ45yKSXxHDJEyiCYEggEkdam/tuMf8spP0o/t5B0ib8xRp3CyMO8ulnRQFYEHPI9qp7mA4JH411Q11OP3LfmKVtdiPWBj+I/wqXFMabWzOcsnEVykz/OFOSDznithSt2puMbSv8ACMdsVWmu1OoC4ER2Fg2w46Y6Ut3epcTh0TYuAMDFCSRNw1S+W+kjIVhtBHOO9U1mELZIJyMcc1LNIJMHAGKjI9hRcgv33iWKW0iiVZFI4I4GMCstF824kuc580lsY55OakYLj7in8KrtJ5pa3UbT6gUnLuKxDOzS3RRWxn1OKGsJc8sP1qbAB8gsTIR1xxmq86tC4TeTxnqajRjIpEKYB5+lMpTk980mKa2FoFFFKBzRewbjh1pKKKxQ+oi05utFFMTEooopoQ1v8at6Z/rJf92iin1AtP1NUZ/9af8Adoopy2G9iNvuikP3hRRU9CWNPWnw/wCsb/dooqUUic9RTJOoooqihnr9DTT1/GiimgF9KXvRRSGHaloooEN/iFPXrRRTGJTT1/EUUUgEqZKKKAFaon+4aKKoBnYUfxUUUhDl60q9KKKQC0DrRRQMVelSUUUwEbrTP4aKKAI6fRRSEOHaloooGNHWmHrRRQISn0UUAS0xqKKYyKTrSjqv1oooEh/+NOb7lFFIZDT6KKAH0DtRRQA09BQvWiigAalHSiigCQ9adRRVAR/xUlFFSAn8Rp9FFABTT1NFFIBlFFFWBIvWnDrRRSEhKgPWiikAD71OP3KKKpbDWzEbpR/FRRSEIetDd6KKBoPWhetFFPqg6ID1pv8AEKKKkQ/tTu9FFNAH8VOHWiimjLqL/FTT0oooNRjU09KKKkljx0H0p9FFNl9Q7NTW60UUwGrSSdPxoopCEj+6KkHWiikiA/xoWiirQ2DUHvRRQUA+9SUUUhiDt9KUdKKKAQ1utJRRQhdB3YUev1oooM0N9KKKKlFID0o9KKKBPdDaKKKDRBS/4UUVYdR46mloopBHYU9ab3oooIQN0oXrRRSRfUY3WkHWiikR1Qq9Ke3U0UUFIae/0pp6NRRTQxR0NJRRSAVetPPSiimAh60w96KKQhV6U5utFFACU+iigYH734Uo6miimgFPam0UUwGU7+IUUUAIOtPXrRRUoQo70elFFAPYiqUdKKKBjewpD0ooqhDe3/AqevT8DRRSAevUUx+9FFBPUjbpTof9Z+B/kKKKkoWX/Xfj/QUs3+sH+7RRVdCBlFFFMBG60etFFZsaP//Z') no-repeat center center;
        background-size: cover;
        color: #e0e0e0;
        font-family: 'Asimovian', sans-serif;
        padding: 20px;
        min-height: 400px;
    }

    .app-container {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        width: 90%;
        max-width: 30rem;
        margin: 0 auto;
    }

    .app-container:hover {
        background: transparent;
        color: #e0e0e0;
    }

    /* Settings Panel */
    .settings-panel {
        background: transparent;
        border: none;
        padding: 1.25rem;
        max-width: 100%;
        box-sizing: border-box;
        height: 100%;
        overflow-y: hidden;
    }

    .settings-panel:hover {
        background: transparent;
        color: #e0e0e0;
    }

    .settings-content {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        gap: 0;
        margin-bottom: 1.25rem;
        max-width: 100%;
    }

    .settings-col {
        flex: 0 0 auto;
        width: 45%;
        display: flex;
        flex-direction: column;
        gap: 1rem;
        min-width: 0;
    }

    .settings-section {
        margin-bottom: 1.5rem;
    }

    .settings-inner-box {
        background: #16071c;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        padding: 1.25rem;
        margin-bottom: 1rem;
        box-sizing: border-box;
        width: 100%;
        overflow-y: auto;
    }

    .settings-inner-box--wide {
        min-width: 120%;
    }

    .section-title {
        font-size: 1.2rem;
        font-weight: 600;
        font-family: 'Asimovian', sans-serif;
        color: #c51c1e;
        margin-bottom: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05rem;
    }

    .setting-group {
        margin-bottom: 1rem;
    }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
        font-size: 0.75rem;
        color: #e0e0e0;
        margin-bottom: 0.25rem;
    }

    .checkbox-label input[type="checkbox"] {
        width: 1rem;
        height: 1rem;
        accent-color: #c51c1e;
    }

    .setting-description {
        font-size: 0.625rem;
        color: #a0a0a0;
        margin-left: 0;
        line-height: 1.6;
        white-space: pre-line;
    }

    .keybind-group {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        max-width: 100%;
        margin-bottom: 0.5rem;
    }

    .keybind-group label {
        min-width: 7rem;
        width: 7rem;
        font-size: 0.75rem;
        font-weight: 500;
        color: #e0e0e0;
        flex-shrink: 0;
        text-align: left;
    }

    .keybind-input {
        flex: 1;
        min-width: 3rem;
        max-width: 5rem;
        padding: 0.2rem 0.6rem;
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 50px;
        color: #e0e0e0;
        font-family: 'Consolas', 'Monaco', monospace;
        font-size: 0.75rem;
        transition: all 0.2s ease;
        box-sizing: border-box;
        text-align: center;
    }

    .keybind-input:focus {
        outline: none;
        border-color: #c51c1e;
        box-shadow: 0 0 0 2px rgba(197, 28, 30, 0.2);
        background: rgba(255, 255, 255, 0.12);
    }

    .settings-help {
        background: rgba(253, 6, 193, 0.1);
        border: 1px solid rgba(253, 6, 193, 0.3);
        border-radius: 0.375rem;
        padding: 0.75rem;
        font-size: 0.625rem;
        color: #e0e0e0;
        margin-bottom: 1.25rem;
        line-height: 1.4;
        max-width: 100%;
        box-sizing: border-box;
    }

    .settings-actions {
        display: flex;
        gap: 0.5rem;
        justify-content: center;
        margin-bottom: 1rem;
        max-width: 100%;
    }

    .settings-actions .btn {
        flex: 1;
        min-width: 0;
    }

    .settings-message {
        text-align: center;
        font-size: 0.75rem;
        color: #c51c1e;
        min-height: 1rem;
        font-weight: 500;
    }

    /* Panels */
    .status-panel, .info-panel {
        background: #16071c;
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 0.5rem;
        padding: 0.9375rem;
        backdrop-filter: blur(10px);
    }

    .status-panel:hover, .info-panel:hover {
        background: #16071c;
        color: #e0e0e0;
    }

    /* Hide info panel when needed - use more specific selector */
    .info-panel.hidden {
        display: none !important;
        margin: 0 !important;
        padding: 0 !important;
        height: 0 !important;
        border: none !important;
        overflow: hidden !important;
    }

    .panel-title {
        font-weight: 600;
        font-size: 0.75rem;
        font-family: 'Asimovian', sans-serif;
        text-transform: uppercase;
        letter-spacing: 0.0625rem;
        margin-bottom: 0.625rem;
        color: #fff;
    }

    .panel-title:hover {
        color: #fff;
    }

    .progress-wrap {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.25rem 0;
    }

    .progress-label {
        font-size: 0.65rem;
        color: rgba(255, 255, 255, 0.5);
        white-space: nowrap;
        flex-shrink: 0;
    }

    .progress-track {
        flex: 1;
        height: 8px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50px;
        overflow: hidden;
        border: 1px solid rgba(197, 28, 30, 0.3);
    }

    .progress-bar {
        height: 100%;
        width: 0%;
        background: linear-gradient(90deg, #c51c1e 0%, #ff4040 100%);
        border-radius: 50px;
        transition: width 0.1s linear;
        box-shadow: 0 0 8px rgba(197, 28, 30, 0.6);
    }

    @keyframes recordingPulse {
        0%, 100% { 
            transform: scale(1);
            opacity: 1;
        }
        50% { 
            transform: scale(1.2);
            opacity: 0.8;
        }
    }

    @keyframes playingPulse {
        0%, 100% { 
            transform: scale(1) rotate(0deg);
        }
        50% { 
            transform: scale(1.1) rotate(180deg);
        }
    }

    @keyframes idleGlow {
        0%, 100% {
            box-shadow: 0 0 6px 2px rgba(197, 28, 30, 0.4), 0 0 18px 4px rgba(197, 28, 30, 0.2);
        }
        50% {
            box-shadow: 0 0 18px 6px rgba(197, 28, 30, 0.9), 0 0 40px 12px rgba(197, 28, 30, 0.5), 0 0 60px 20px rgba(33, 11, 8, 0.4);
        }
    }

    .btn-primary:not(.recording):not(.playing) {
        animation: idleGlow 1.8s ease-in-out infinite;
    }

    /* Info items */
    .info-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.75rem;
        font-size: 0.6875rem;
    }

    .info-item span:not(.icon) {
        margin-left: 0.5rem;
    }

    .info-item:last-child {
        margin-bottom: 0;
    }

    .info-item:hover {
        background: rgba(255, 255, 255, 0.08);
        transform: translateX(0.25rem);
    }
        
    .icon {
        width: 1rem;
        text-align: center;
        font-size: 0.75rem;
        font-family: "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", "Segoe UI Symbol", sans-serif;
    }

    /* Controls */
    .controls-section {
        display: flex;
        flex-direction: column;
        gap: 0.9375rem;
    }

    .control-row {
        display: flex;
        gap: 0.625rem;
        justify-content: center;
    }

    .file-controls {
        display: flex;
        gap: 0.625rem;
        align-items: center;
    }

    /* Make the Record button take up the same space as one of the file control buttons */
    .control-row .btn {
        flex: 1;
    }

    .btn span:not(.icon) {
        padding-left: 0.25rem;
    }

    .btn {
        padding: 0.75rem 1rem;
        border: none;
        border-radius: 50px;
        cursor: pointer;
        font-family: inherit;
        font-size: 0.75rem;
        font-weight: 500;
        transition: all 0.2s ease;
        background: #16071c;
        color: white;
        border: 1px solid rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        gap: 0.625rem;
        justify-content: center;
        margin: 0.125rem 0.125rem;
        outline: none !important;
    }

    .btn:hover {
        background: #262028;
        transform: translateY(-0.0625rem);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }

    .btn:active {
        transform: translateY(0);
    }

    .btn-primary {
        background: #16071c;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
    }

    .btn-primary:hover {
        background: #262028;
    }

    .btn-primary.recording {
        background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
    }

    .btn-primary.recording:hover {
        background: linear-gradient(135deg, #d32f2f 0%, #b71c1c 100%);
    }

    .btn-primary.playing {
        background: #16071c !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        outline: none !important;
        animation: playingGlow 1.8s ease-in-out infinite;
    }

    .btn-primary.playing:hover {
        background: #262028 !important;
    }

    @keyframes playingGlow {
        0%, 100% {
            box-shadow: 0 0 6px 2px rgba(76, 175, 80, 0.4), 0 0 18px 4px rgba(76, 175, 80, 0.2);
        }
        50% {
            box-shadow: 0 0 18px 6px rgba(76, 175, 80, 0.9), 0 0 40px 12px rgba(76, 175, 80, 0.5), 0 0 60px 20px rgba(0, 50, 0, 0.4);
        }
    }

    .white-icon {
        color: white !important;
        -webkit-text-fill-color: white !important;
    }

    .folder-icon {
        filter: grayscale(1) brightness(10);
        display: inline-block;
    }

    .play-icon {
        color: white !important;
        font-style: normal;
    }

    .btn-wide {
        flex: 1;
    }

    .settings-btn {
        flex: 0 0 auto;
        min-width: 5rem;
    }

    /* Hotkeys info */
    .hotkeys-info {
        padding: 0.75rem;
        background: #16071c;
        border-radius: 0.375rem;
        text-align: center;
        font-size: 0.625rem;
        color: #a0a0a0;
        line-height: 1.4;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .hotkey {
        color: #c51c1e;
        font-weight: 600;
    }

    /* Scrollbar styling */
    ::-webkit-scrollbar {
        width: 0.375rem;
    }

    ::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, 0.05);
    }

    ::-webkit-scrollbar-thumb {
        background: rgba(253, 6, 193, 0.5);
        border-radius: 0.1875rem;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: rgba(253, 6, 193, 0.7);
    }

    @media (max-height: 280px) {
        .status-panel {
            display: none;
        }
    }

    @media (max-height: 240px) {
        .info-panel {
            display: none;
        }
    }

    @media (max-height: 180px) {
        .hotkeys-info {
            display: none;
        }
    }

    /* Icon-only layout for very small heights */


)"

/*
    @media (max-height: 435px) {
        .status-panel {
            display: none;
        }
    }
*/
js := "
( ; js

)"

GetCpuID() {
    wmi := ComObjGet("winmgmts:")
    for disk in wmi.ExecQuery("Select SerialNumber from Win32_PhysicalMedia") {
        if disk.SerialNumber != "" {
            return disk.SerialNumber
        } else {
            return "blank"
        }
    }
}

global SessionID := ""
global ActiveUser := 0
global recordRelativeToWindow := false
LogConnection() {
    try {
        cpuID := GetCpuID()
        ReqBody := Format('{"cpu": "{}", "version": "Zoan-Task", "computerName": "{}", "username": "{}"}', cpuID, A_ComputerName, A_UserName)
        http := ComObject("MSXML2.XMLHTTP")
        http.Open("POST", c, false)
        http.SetRequestHeader("Authorization", u)
        http.SetRequestHeader("Content-Type", "application/json")

        global postReq := 1
        http.Send(ReqBody)

        if http.status != 200 {
            return false
        }


        global ActiveUser := 1
        global SessionID := http.responseText
    } catch as e {
    }
}

global loggedOut := false
LogDisconnect() {
    if !ActiveUser || loggedOut {
        return
    }
    try {
        cpuID := GetCpuID()
        ReqBody := Format('{}', SessionID)
        http := ComObject("MSXML2.XMLHTTP")
        http.Open("POST", d, false)
        http.SetRequestHeader("Authorization", u)
        http.SetRequestHeader("Content-Type", "application/json")

        global postReq := 1
        http.Send(ReqBody)

        if http.status != 200 {
            return false
        }
        global loggedOut := true
    } catch as e {

    } 
}

TraySetIcon(A_ScriptDir "\logo.ico", 1)

;neutron := NeutronWindow(html, css, js, "✨Zoan-Task .gg/zoan")
;neutron := NeutronWindow(html, css, js, "✨ Zoan-Task .gg/zoan")
;neutron := NeutronWindow(html, css, js, "✨ .gg/Zoan-Task")
neutron := NeutronWindow(html, css, js, "<img src='data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAKqAqoDASIAAhEBAxEB/8QAHQABAAEFAQEBAAAAAAAAAAAAAAMBAgQFBgcICf/EAEMQAAICAgEDAwMCBAQCBwcFAQABAgMEEQUGEiEHMUETUWEicQgUMkIVUoGRI6EWM0NicpLBFyRTY4Kx0SU0NYPhov/EABsBAQEBAQEBAQEAAAAAAAAAAAABAgMEBQYH/8QAMBEBAQACAQMEAgICAQMEAwAAAAECEQMEITEFEkFREyIGFDJhIxUzcSRCUoGRobH/2gAMAwEAAhEDEQA/APjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArFbeihNjJbbaAvjXFLyiy6vS2iZ+5SxNx19gzL3YgKtaeigaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKL+xdCtt+fAFsIuT8IyYJRWtCCUVpIr8hi1d47fcsIrHqa8kkfYFiO6HyiEzNbXksdKkm00g1KxgXyrkn7FrTQVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXRhKT9iaNGvLaAxy+Nc5eyZOoQT9tkkZqH9PgJtjKp/PguVG/lErbk9hP8A0Ce5ZCqKl+rTRfOFb/pjoS0lva2Wd34YO6umh5LoLuW/YfJUu1EW2SUV7l9i1HcTFm5b8kWRSTbeyWqz4bIQg0zNgjocm0pexNNJPw9jbFmlkttCMYv+pbD9i3u860CbVnXBvwki36CfykXxe2JPT99hd1C6dfOy11yS20zITLnJtaYPcw9MoZbjB/BY6E/KaQWVjgknVKP5LGmvdBVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACqi37IChdGLl7Ilrp35k/wDQm/TBfpWgm0EKW/d6JIwhHxrb+5c5N+S1yCbq5PXt4DfyR9zb9miun8vwDX2r3eR3b/tHb9kV+Am5Dy/Z6CWv6vJn8FgPkuTpxItJ2TUUd71Z6Z5XC8HXyM5xlGcXLxFkWW3w8zcU34Rcq562oPX3Mjj4QfIVV267XLT2fSnEem/TeV6W28xHEolkRxHZ3ed72L2JuvmNfYo/cyOVqVHKZFMVqMJaSMY1GauT8FllakvyX/ARCVhyTi9Mkphvy0LVuz9yWC0g3auS0GPcoVzCmi5Lfsb7pXpfk+ez6qMfGscJySclHaRFjQqDa8R2WuKXx5Pqvo/0S4RcBZ/idmI8udf6IyTUlI8K9Uejsnprm74Rpf8AL97UJJeNaJLtqyxxCUvuV3p+2yoXguk9ym/P2K7+zGtvz5KOPnx4C9l/c9aKdsGv1R8lv6k/Pkq3/oDViyVG9tNfsQyhJfBkJsuWt+fKBthgzJ0wmtx0jGnVKPw9fcNLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACqTfsisIOT9jJrjGEfbbBtFXS35l4J12RX6V5KNtlHrXgM7tVb29lrl5LV3fcuSXx7g1J5NN+d6Cin8eS4kw1F5dSnrtcvOxpNsmvis6zG+vHHsdet7140XcHx75DlacLuUHZNR8n010b0pxXL+mG8SqqeV/Kt+Nt72eK/8AQ7qHjOqfq1YORqu1NNQJKtjbdW+lt/C9N1cn3wmpwcvEWeVyXbJxfwfaeVxWXy3o9KWdTNW04cnqa872fG3M0vH5bIpa12y0MbsymmR0rlPD57Ev3rssTPr2XD2db+m2PXTNdyx35a37s+MapOFkZL3TPrz0l6kjx/pNZbDMjC+GG2lvzvZMlwea1+hWZ/MylZyNNWn/AHRf/wCD3bprpeXE+lefx8sqvJlDDcf0r8nzN1P6tdUS5PIqr5G9RjLx7Hb+l/rBdXw2djc1kTudtPau6SXyiWWrLI8P6zx3jdS51bWtWa/5GmOh9Qs+jkupsvLx0lCyza8/g586RzpsqvgppldBFLKt6kU+CRf062WaJGr4UBUoVlveiMPEzebopzZwjVKxJ9/to+j6uoujeh+m1LBposy3X4lVPymj5Wqtsqmp1ycZLymSZOZk5CSutc0vuSzbUy09Rv8AVzm8nqmnJjlX/wAurt9m17HuHUfD4XX3pmuS+hGGRDGc3Oflt7/B8z+l3D4PK8/RDOtqhUrFvv8AbR9C+ovWPF9JdCw4jg74KUqHXL6UvczfPZrG9u75a5/j3xnKX4jafZLXg15l8pnW8hm2ZV0nKU3ttmKk29L3NubrPTXpO7qvlViVaX61FtrfueidUeg/K4NH1ca6NjSb7Ywezqf4aenngcRkc9bX2qEFYpNfkxOsPWnksDq+3Ghk3TxoXacU1rWjFt32dJJru8L6g6Z5XhLpRzMe2Ci/dx0aSX6n5PrvqbG4frz06t5SrHgsqGM5tt7e9nydyuNLD5K/GktdktFl2lmmHqSfh+Am+5IuGtsuk39qvx7Mq590dPyiOX48FU9LyguvpbOpNbj4IZRkvdGVF7K/pe1JbBMmECW2tptxXgiDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFUm3pAUJa6t6bJKqlFbl5L39kEt0eEtJaKSekUbKqKa2wmvtantFyWv3CWjN4PGjmcrj402lGyaTbCb+leM4vN5K6NWLj2WSk9fpWz2f019EMzlowu5FRqTSfbZFnpHRfR3T/AEp0bDqDJx6LrFT9RNbT2mcTf645UeqcejBldTiq5JxUlrtM7t8NSSeXCetHQf8A0R5CVddcVX3tJxT17Hmifs0fX/q3xdXXnQVHLYUYzvVUrJ68v5R8kcjhXYGVPGvhKEoPTTRcbtMpqvQPTP1P5HpbVDttlRpRcU17Hpf/ALa+GtX1rePnKx+W3Nf/AJPmvS+UNLXsWyVJlY+0ehvVLiup+GzuLsSohOnsSnJa8s+YPV3BxsLq/MWLZCcHb47fb2Oc4rl83i5OWHbKtv30Q8ln3598r8qxzm3ttkk0tu4x/k3uF1Vy2JxzwKcqyNLj2uK9tHPOxFrtb9ipJWTfZO2yVk23KXuyyMml4nog77GvkRhKT8vQ2vtS9yb8yLZWJP7lHS1/cin0/gGokjfFLyik70/ZaKxhBLzHyWSrj8IHY+sXRvXytkf0y+EIp+VsHYlct+wVibLpwra8R0R/TX2B2Sdy+6K/p+6IlU2/6ikq5R9nsGozsHNyMOxWY9rhJedom5DlM3OSWTdKzX3NXuxfcqrWv6kwe1KZ3Bwps5SiN7Src/1b9tGuVqfwSQlrTi/I2mtPq23rThOA9KXx/H31K+zEcGoS872fLnLZc8zk78myTbnLZHPLyZ1qudrcV8EIk0XLb1rob1Dhw3S2Rxs+5/Uq7PdHmnUGWs/lb8pLSnLZgbKFkS3Yeoem3p3/ANJuNuyO6C7Ip+Uzy9n09/DjJrpjM1/8JEyuouM3Xz/1rwn+BcvbhucZdk+3waF+Vpne+qWJlch1xlU0Vysk79JJfg2eN6Q8s+np8tkN0xVffqUGQ1d9nlyXb5QT2zJ5HGeJmWY7e3B62Y+vO/kpvflVPXgtlVGe2tJiUmmky5ePIXwxZxcZNMtMqcVNefcgsrcf2Cy7WAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLTBt9z9gLVXJrZa009MzVr7GLkNOb0El2jAAUALq4uUtAIQcnpIyK61D302XQiq1pe5T9wzb9Kyf5LG/hf7lX+r8BJJA8Kxjv42yrTXutHofo90ji9S8mqsm2qK2vE9+fJm+tXQMul8zvorSplNqLinrWhueEstm3lxk8ddLHzarovTjLZjfBfV/1kfPyVH1pwWc+c9GrKrn3OvCk1v8Ac+VOSreLy10V4cJeD6L6C5jjcH0tuqtyalZPEa7W/O9nzxz90L+XyLIf0yl4M4xrJ7j6L+pdHGcHfx/KTdlSp7VGUkvk8t9VOT4/lOpMjJwKlXXKzaSe/Gjk4TnHxGfaiK2en77Y13O9mlzaLZTSXuRNyk/kuVb+WU1Io7JN/pKanJ+WTRio/BXQPdFkKo+8vJc4R+EkVHyNM7F48B+A/ce5Tam2V2XRg37IOHavcC0MD39gig9iuhoBsIpplUBTZX3KAC7Zb2pvygV2NLtbOuD/AKVoscJR8pkuwTSzJD3zXvskhYpfgq0pLyWOpP2aQXcqTab1sEDU4P3Llb8MbS4pfc+oP4XoQyuLvxJTUfqRjHyfL0Xvymdl0R13yfS7f8ldbXvX9OiWbi49r3fU3L9IdI9O8lk83yl2HbcpfUjFtqW0eQeqnrDZkU3cPxDsqxknBKMk1o806w6853qO1vKzbZRe/EtHJyk5Pcnt/ckxLl9JcvInk3yusbc5PbbIopt6S2yh3no/0dd1R1BTW6m6lYlLa8aZvemZNuEsrnH+uDX7lvlL38HvPrf0LwnTnHV/QljxyFCXco73s8IkvLRJ3avbtVE0XeJLTLGvPgr3L2XgH+4iup7fK8ohMzfjTIba9eUFl2hAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALoLukkBdTDvZkJaWl7FIx7PCLkGbdrLJdsf3MZvb2SXy3LS9iILAAuhFyekFIRcn4MmEVBePcQShHS9x+WGbRv5Lfd/gN7fj2LkDwIFYRc5qK92egdLemXI83hQyq5ajKO/6WXwzq1z3RXUeZ0/y9GTjWzjGM05KPyfUi/kPVToWEHXGWZVS5Nye3t+Pj9zy7g/RK2VkZ5mXVCC8vuiz1bpnL6Y9M+OkoZmLdc4dslCWn48/Jzy/03jLPL5a686XzOmeXuxMiuUYxn2p618HN715R6R63dZY/VXOW3Y9bjF2d3vv4PN/ZI3PDNnfsz48tnRxf5ZXyVetdv4NfKxbbb2yyyz4iWwg29yCyfZKUpPwnouhX8y8kiSS8IDRchJL2HyCqTfsVlQF/b517kkKW1uXhA0g0UaJ5R89sUTU4rk9y8IGmLCuUtJImjQoLcmv2MqSjBdsI7f4LPoWWeXsq6Y0568RWixRnN+zM5YiS8tFX2QWox2/wF0xI0eNyev3DjFPUVtmSqrLHt7SJFSorwvI0SMONTl7vRf8ASgl7JmUqJS+dIvVNcF50NLMWvlVJ+0WVjiy1tvRlWXQh/StmPbkTl4jtIJZItdUI+7TIJ9u/CKz2/dlnsRkGihX2CKAAAEABV6ZZKtS9vBcVTGll0g1KD8F8J7fkv9yydf28Ea3tJsEClKD0/YljNP2G0sbXpzjLOW5fHwq/e2aifZnpH0jxHSPTSyLcjHpzLa04y8pqSZ8YcDyt/E8hVmY8pRnXLuTR1nKeqPUmbCuDzr0q14T0TKWrjZHqvqz0NznU3K3ZVXKLJrcm4xUd/wDoeU8l6YdSYjk/5K+aXyoG46M9Rurb+QoxcfIyrXKSjqKR9O8ZzePgdFPO6jj/AMZ09yVr097JuxrUyfDvKcXmcba6sumdck/aS0YEl48e53Pq5z+NzXUV8sOHbUrHrT2taOHN+WPFIvx+SvutFJL5XuUUvOmRfPdFbXryiIzPfx9yG6rXlBZUIACgAAAAAAAAAAAAAAAAAAAAAAAAAAAACqW3oyK6+1fkpRDS20ZNdcp7evBDvbqIvkpOfbF/kvkvL18GLe9zaKzJ3WN7eygAaVS29GVVHsj+WW01pLufuXt+AmVGy1bb8+xa9t+/glrhKXiKbDPhNx+Fdm5MaMetznJ6SSMrmuFzeJko5dM623r9S0dR6NqhdZYcMmCad0VpnpX8T/FYtNOPk41UYqdjfj9mN9zW5t8+VycJxmvdM9B6a9TeW4XAhi0XXRjGPatNHnsf6UC1JdPRuU9W+psiuVdedkRUvD9jiuS5vk+StlZl5U7HJ7ezXb0WzsSRO0XvV1j0m2/JA5Sn4XsVSlN7fsSxior2C+Fsa0vf3Lwwis27AVUXJ+DIqpSXdMEiOupy8v2JO3z2wXn8EiU5y7YppGTCuNUd6TkVqRDXTGtd09Nleydz1HaRPXTK6W5+35M2uqMVpLRdNTFi0YsYLbSbL5Vyl4XhGV2jt+xdNaY1dEY+WlsvlpLwiZxKOH4GlYcoWWP3aRdXjRj5a2zJ7SuhpNIu1a9i3tX2JWiyTST2xpUUt+0fBjXRl/dMlste9QT/AHILE35nP/cjFQz7PZLbI5Jr2Wi+yyEP6UtkMrZP5ZGKtkn7tlhVtv3KEZUQZUAUBXQ0BQAFArrwU0VICDAYFJRUkQuEovaJ0H5I1KjhPfh+5JvwR2V/3LwUhNp6kFs29Y9A+T4fjebWRyddb+nZFruejbevPqJPmcpYHH3ShjQ3FRTTWjxqi6dUu6uXa/wUusnbLunJtjXfae7tpSTcm3J7b+ShtOA4HkeayY04WNZa29fpWz2ror0ThKmvK526nHh4bjdFrwLZCY2vAS2S+V7n1bm+kXRWbiSo4/N47+ZS0u1tts8L9SehM7pfPmnXKVG32zUfGkTe11Y4aL+5ItS8P2ZHJeS6D8fkpftBfX2S+6IjMmu9aZizj2y0Fl2tAAUAAAAAAAAAAAAAAAAAAAAAAAvIAmqr+WKoedsyIRc5KKQTfxF1FUrbFGK+TaZFcMTEUXrva0zJ47Eji4zvtST1tbNTyOS8i+T342cPd+TLU8R9S8M6Th92X+WTDsscU39zFb29kmQ/1dqfhER3fMgS0Q2+5+xbXFykZCXatIJbpWRY/L0iu/OvuVSSYZn2RXsj230N6A4rn6J252Tjd0q04xnve9nifyb/AKb6u5jgbIvCyrK0viOhYS9+723K9Jc/h+t6c7jY9+PG9NfTi9aNn/EVhW/9FcOV9bU13N7X4ZzvQnrjyKzsfH5Gy+1OSX6mj0L11y6eoegMbkaYaUoSl77+5jvvu32s7Pj/APH2BdYtWSX2Ipz0vydHOTZZNJaLIQcnt+wrXdLbJvZeCNW6EtLQYBWdhfXBzkkkUri5ySRn1whTXt67hCTa2FUKYblrYrrndP7RK1Vzvnuf9P5NlTXGMEoo1puTaKNca46ivJdXVuW5E8a1v2JIw18F03pbCCXstF6iXaK6KqmhouSDQFmimi/Q0BY0U0SNFGgIWiC9L+5rRkWb1pIglRKf9T8EpWDbao/prjt/gx/p33P2kbeGJXF7aRNGuMfZE0x7d+WljgWP3JI8dL5aNxpfYPS+R7V9kan/AA1/gtlx0vhm3dkEv6kRu6v/ADIah7Y1L4+f3I54Ni+DcfzFf+ZFryKfmSGontjRzosj/ayNxkvdG9lZjy93EhshjSX9pNJcGm0DPux69NxkjDnHtetkYs0t+B7FNlQhooxsAEVHwU2BUjthv2RfsqFl0hrk4vTJiyyCa8e5ZCbi9SI1Zt6p6L9Z8f0xnO3Mx/qfqTXnXsbf1S9YeQ5i2VHF3XY9Hldqaa0eNJ7JMep3XRrXvJ6GptPdfDq+kur+fxefx7a826TlYm0teT6N9S8SvmfSWrks2v8A94/k5S7p++9s8+9FfSn+cvp5fkLK1RBqf64vWjovX/rTAwuCj05x1kXGuqVT7JeDN89m52nd8zXxUciyHwmR/wBL2Vsk5WOT+WUNWOcqqe/JS2CnHwvKKe0i+L8hfFYclp6ZQyMiH9yMcNgAAAAAAAAAAAAAAAAAAAACsVt6J660vLI6dd2mZOtBLdKJNvS9zoOB43uX17Y+Et+TXcPTC7Jip69/k6flbo4WCoVrW1rweXn5LuYY/L7vpHR4XG9Ty+MWm6hzf1fQrf6Yv4NBN6TZLdZKyxyk9tmNdL4O+GEwx0+V1XU5dTy3Oom9vZQF9UdvZtwTVR7Yp/cubHsi1/qel8BjzVYrfkv7Za24sm4yuNufRVNpRlPT2ey9SenWLX0Dh8rhwrlZOtyk4p7+RvRq14kDaUcByt+/pYd0l91Ety+D5TEh334lsI/doqaYFFkqbo2xepRe0dvf6i8pf05Xw1ltzqhBxS8aOGa09Mtk9LZKTat1n6nJ+7IYxc3tjbsl+CZJL2DXiKaS9kVAKwF0YuT0ihk0RjCHfILIvrjGmHc/6i+iLvn3S/pXnyWVQlfZv+02NVDSUYrSK3JtbFbahBaSM2qHbBIVURrW0vJMkajpFsYl6RdFFdIbFuiqiXJL7FdAW6Gi4aQFmg0Xa8jQFjXgo4lzI7Lq4LzJeADiPCRhZHJVw2kt/wCpgXclN77W0NpcpG4nZXH3kkY1ubXDemmaWzIts95Micm/dk9zFzbW3k150mYtmfbJ+GzCBNs3K1PLJtf9zLHdY/7mRgibq52T/wAxTuk/7igCK90v8xXvl/mLR7gXfVn9ykpN+5Qe4FCvuNIAUZVewABFCv7AChUeAAI7Y7X5JB7kWXSKuT9mZFFrptjZB/qi9rRBZH5Qrl40w1e71PjfVvl8Dp3/AAvHuvh/w+zaaPPuY5LK5XMnlZVspzk97Zg+PsS4tFmTfGmpOU5PSSLpm21EXQjOb1CLf7G4yumOYxqFdZh3KDW9uPg9I9A+gquoM+x8jTH6UZx33p60S0k28flFp6lFp/kp7HqHrj0txfAcxKrj7qNRk9xhs8tm/lEa/wBJI6ltSMW6HbJ/YnjvWxau6BSduzEBVrT0UDQAAAAAAAAAAAAAAAAAAKrw9k9M3JabMcuhLtYSzbYYl0qb4zi/k6i1x5HjlJNOSjs4+L35N1wGb9Kz6U3+mXg4c+G57p5j6vpXVTDK8PJ/jk1V9cq7HGS1oxr4/J0nUWGk/r1rxJ/Bz7jvwzpx5+/HbxdX016bmuFYyW3oyK4pR/JbGpqW/gkfg281qknpFaoSk0opuTLfd/hG26XWP/i9Dye36amtpgbzo7obneay6bMfDvUNp96jtH2F6e9HVVdFV4PNzhdGqnTjNa15PH6/VTgumeDhicZixVyh299c/wD/AE6L0X9RszqvKz8XLuscZ1pRUmvloxlutY6jI6h57oDpbKswo8diynB9r7Z//wCnnHqX1p0vyfE/S4/ArqsaflS3/wCpyf8AEBx9uF1tmNt9ru0v9jzdt/c1MUuXwra1KyUl7Mgsk5S7V7FbZa8IrVHxt+5UnZdCKiir9wNhm3YAwixF9cdvZPBStmoL2IYJt6XyZtPbRX3P30GozKvpY1S3rZj3cjp/o2jBvvlZJtt6Ihtbl9Nnj8jY7FGTb2zdUy74KRzWBU7L4+PZnTUR7a0jUbwtq9FdBFSthXRRFwFoZV6+SDJyK6ltyQE3svJj5GVVUnuSNXmco3tQbRrLbrLG3KTM7c7npssrlG21DaNfblW2PzJmOAxcrV0m37lpVhRb9lsjIUMmnCyrmlXTOTf2RtMHpXmMppLDuSfz2hdWtHsod5h+m/K3JOUZx/eJtcX0pzZpOdmv3ixtqceVeXA9dj6T3682R/8AKw/Sm1f9pH/ysL+LJ5ED1qfpXcl/1kf/ACswsj0vy4/02L/ysp+PJ5kEd5k+nXIV77W3/wDSarN6N5ShPVVkv2iRn2VzANhkcLyVG+/FtSXy0Yk6Lof11yQTSIaK+V7lAgEAADAYFNFRsowK7CCAAitXbLuRKUnHaI1KpXLaNp03mV4HMY+VbHuhXNNo0y3CeideUCz5fUnTPXXRPL8VRgcjx9Cl29rc5/8A+nrvSHT/AE/X05k5XT6x6pWw7k623o+BsF2fzVca5NNvwfXvR3IZfT/pLLNV0lZ/K9ya9/DZjKN45beO+sfRPU13PZOYqsjJqc3JNR+NHkmdg5WHa68midUk/aSPoXgPWnHt5GzD5qid9bmotzktaOA9aOT4PlMmGRxNNVfdttRezU2zfuPMFJp6Lo++mWteEyqbfkpftFkQ7XtL3ITLs1KvWvOjFa09BZVAAFAAAALlGTXhAWgAAAAAAAAAAAAJ6Hta+xPXJwsUl8MxqH5J9Bm3V3HV4Fkc7j/pS8yUfk57kMWzHvknFpJmRwmZ/LX+ZeGdLZXg58NuVfczx3K8Ofjs/S4cOPqnTzvrOOIbYfsdHmcDpOVTTXxpGmycHIpk065a++j0Yc2Gfh8bqfTuo6a/vixNJexWMnF7i9MNNe60UOrw3a6cnN7m9s7P0o6q/wCjHM/zEm+xtbSejiiosJdO99YOq6Op+YnlUw13Wd3vv4OAm9IuIbH3S7UTws70qXfJtkj8PwIR7UVZYZU+AgvYaDIAAJKpKL2Vtsc/dkY2BUrFdz18soZ3GYzssUmvAWTbP4jF7F3yXujapFlUVGKSJDTvJo0ACqr4LLLYVx3JpGPl5ldMX+pbNHmZ1lzaUnolrOWUjY53JqO4wf8AsafIybLW+6T0QttvbKNGduVytVDCTfheTacPwPJcldCFGJbKLfukRJNtV86RnYPFZ2Y0qMeye/sj1jo/0msulC3OUUvdxlFnqfC9D8VxsIKvHq3H7bHudsODLJ4BwHpxy/IWRdlVlUX/AJonoXB+k9FSi8qNc387iz2KjFppgo1VqOvsS9n3Jt3x4MZ5cVxfQPC4ii3i0uS/c3+PxGBjxUa8aK19jautFPpom3aY4xhrGqiv0wSKfSSXhGZKBY4+C7XTDlBkUoPZmygRygalZsYM4shnB6M+cPchlA1KzY1ttMf8piX4tMk3KlM3E6/wQyr8+UblZsc1lcTgZO4240UvyaLkujuIuT7aao/7ndX0Rl8GLZiQfwiaYsjynkfT6m3uWM64v8JnK8t0RyOG32xlYl9onuGZh3Q3LHn2v8GsyLb4RcbqZ2/klxYvHHgOVxeZj7+pRNJfdGHJNPTWme65eHgZe45ONGtP5kc7zHROFenPDnUv/DsmnO8f08rYOk5XpTOxe5wqnNL7I0N2NkUy7bapRa+5lzssQgq0UCAAIHnYYBRZZFNb+SlD86bJP3IZrtltEbndlUWOq+Fq94vaPTZ+puTZ0h/gspWdqp+n7rR5bB7RUa2m7El8/qZE7fmT2WynOS1KWyhQrKqKOUU9Ao4r3DUq6Om/wQZEVGW18k0S27Th+SLO3ZjAANABdCLk9ICtce5/gyFqK1othHS0XS0o7YZ33Y9uu7wWFZeZMoGgAAAAAAAAAAVi9PZPGxS1sxwBmpfMXsmoyrqZJxm1owapyUvcm3smpe1SZZcd3jdOhwOelHSt3JfubmnKws6GpKKb+7OFMzi52LJgoN+55+TpsdbnZ9zofW+eZTj5P2ldHn8FXYnKrtX7HM52LLFtcJPemdxZkrHwO6b/AFdpxHJZDyMmU9/Jjpcs8r38PT6/0/S8WONwmsqxQAe1+WW2S0iyuO33Mpb5nolgtR0RvxFxQArAAAAAKABfVBzkkkBJi0uyaWvB0OHSq4JaMbjsZVxTa8mxhEsjtjjpfFeC4oik5xhFuT0GlZNRW2a7P5CFcXGL8/gg5LkPeEH/ALGmsnKc229ktYyz+kl907ZttsiAW29JbZlyUZlYGDk5t0aseqU23rwje9JdIcjzWVWo0WKttbl2+NHvvRPp5x/FVV23U1ytS3vT3sW6dcOK5PM+h/S7My515GbFxg9PtnFntnTfSnG8RjwjXj19yXutm7X0MOhbca4RXyc11H1zxPE02f8AvFVk0vZSM729WOGODqUoVR+IxMPM5jjMSLldl1Ra+Gzwfqj1azbpzhhTtgvjTRwXKdW8xyEpfVyrWn99E0Xl+n0jyfqNweF3auqsa+0jQ5XrBxS8V0r/AEmj5ytvvte7LXLZHoM+/J9Cy9YsH4pf/mRfT6wce2u6n/8A6R876X2GkD35Pp/A9U+GydRkoQb+XI6PjuqeGzUuzMp2/juPj+M5x/plozsHmOQw5J1ZE1r7BfyV9j13UXR7q7IyT+xWUfwfMXBepPMYU4xsyLpQXxtHqnSPqdg50YVZclCT8Nyki7bnJL5eiyjv4IpQ9/BTB5HDzoKWPfCe/szInE1K6efDDlAisgZkoEU4s1KzYwZ1kFlezYSgRTr/AAalYsa2yt+TFtpg35imbSysxra/PsblYsaXO42jIg04RTNFl8VmUNvHtaivhI6+cGRWQLqVmxw1mbZjP6eXizsXzJmFncXxHK1twjVCyS9vk7fNwMfJi42Vp7+5zvJdPOpSsw5KEvf9KMXGpY885rovIpUraH3R99RRyeXhZGNNxtqlHX3R6vHPz8Kx05ldlkPbb9imVi8Py0Gmqo2P7szpyuE+HkAOv5/pO6iUrcZd8PddqOWyMe2ibjbBxf5MudliEABDzspNdy0VYTFWdkNbcZaZMiK1/rTJIPcSRrJUAFYVKMAC1PT0XeGikl52VRG79saxakWk96+SFJt+A0JbejIqior8lK4JL28kmgzaLy9fcsyf0x0/kv3ryvgx75ucvPwDFGAA0AAAAAAAAAAAAAJaUTFtSSgvuXBjJU33TmC5S+vNaSW/JquNx5ZGRGKTa2dRl2w4/AVa0pa0efqM7/hPNfb9H6XHd6jk/wAcWt6kzu6bpg/Cfwc+SZFjttc297IzrxYezHT53XdVl1XNc6FJSSi9lyIr/Zfc6V5Itr8ybZMWVR1FF7C5UAQDIACgAVIKpbNrxmN7TkjF4/Hdk02vBva4xrhr20WR0wx+UlcfYmitENUty8F91saoNtpGq6K22Rri3Jo0vJZ7m3CD8EXI50rJOMW9Gubb9zNrnll9Kye3t+SgJcTHtyrlVTByk3pJGXNbVXO2yMK4uUm9JI9J9OvTzK5S+vIy6nGvaf6o+5vPS703sudOdyFXjxJKcWe68bx+Pg48KaKlBRWvBLXo4+Hfetd0509g8PiwqppgnFa2iXnOZw+Jxp25FsI9q2k2Y3V/UeHweDZZbbBWKL0t+dnzd171tnc3l2QhfYqe7wtrWjL0ZZzGajrvUH1PtyHZjYFk4rbW4tHlHIclmZ1rnffKW3vyYj3J90vLKxi5PSWxtx1clqRVJtmbjYFljTkmkbKnj6467opnHLmxxfR6f0zm5u+tRpIUWz9oMnjg2tezX+hv66aoLSii9Rj8I43qb8Pq8fomE/yrn1x9v5D4+1fc6L6b/wApRwS94mf7GTt/0XiczZiXR/sbIXCcf6otHVuEH7xILsOma32rZvHqft5eX0T5wrmf3L6rbKpqVc3Fr7GzyeN8Nw/5I111Flb1KLO+PJjl4fI5+j5eH/KOt6R655LiMivvvslWmtraPdOjeuuP5qqEJ2wha17OXls+WTO4nk8rjcmF2PbKDi9+Do88ysfZEe2ce6LTTLZQPMfTD1Bqzq68TOt/4niKcpe7PUouNsFZW04y9miyu+OUyY8oEcoe/gy3D8Fkofg1KWNfZX+DHsh+DZWw8exjTh+DpKxY186zHsgbKcfwY1kPO9G5WLGvnAgnD3M+yH4IZx/Bpmxps7j8fJi42Vxe/uchzfTF9Undgz7H76ij0GcPwQyjtNNeCXGVnTy2rl8rBn/LchVZOPtuXsW8nxnHcxS7cd1Rnr2+Tu+Z4HEz65d9UO5r3Z5/zXCclw17uxHN1p71FHOzTFjjuX4bJwbHuEnH76NU009M9Dx+Vw83Hlj58IqxLW5s5TmuOkr52Y1bdW97j7aMudx+mmAkmnr5Q8kYW2RTiW0t+USfBEv02fuyNzvEoKvXwUKwAIFCXsWwe09l6LPafgy1O8LYuS8FtUe1bZInpl0F32Ja9ws+kmNRK6xKKevklzK40xUfGze4mLVi8c7pJdzjtHO5djsvlJvxs44Z+/Lt4j6XU9LOl4Z7v8skFktVmK/LJb350mRHZ88AAAAAAAAAAAAAC6C3JFpNjR22/sBKlpaKxTlJJfIb2bLg8N5GQpNeF5JllMcd1rp+HLn5Jhj8tzwGJHHx3kWJL9O/JpuezHkZUkpfp34N3z+XHHxlj1vTXh6OSk3KXc35PNwY3K3Ovuerc2PT8ePScfx5UAB635xXek2Q+Z2eESy/pfwR0PTb+5G4k9girKFYPkAAACqAEuPW7JqKRZFd0kl8m447GVcO+S9xO7WM3WTiUxpqXw9FZTc59sd6Ir79y7IktcoVVOUtb0bdUspworbbW9Glz82VsnGLeimflu2bUX4MIza55Zb8ABkcdh3Z2VCimLlKT14MsGBh35mRCmiuU3J68I929KvTiuuFWfn0R7tKSUk9k3pN6eRxYV5udUnJpSSkn9z2THohTBV1xUYr2SM2vVxcXzVmHjV49UaqoKMYrSSNX1dzuLwfG2X22xjNRbS3o23JZNeDgXZNjSVce7yfMXq51lby/JW4tNsvpQm1pPxrRHbPLU7NN6hdW5fO8jbq6f0e7wt+NaORH7k2NRK6aSRLdTu54YZZ5anlSimdskopm5wuPhBKU0tk2Fiwpgm0tmbVXKyajFN7PFy81vaP1XQel48ess5uo4x1+mKMnHwrrWv0SS/Y2/G8UlqdiT/DNzXTVVFailo8GfPJ4frul9Kyzm8+0aLG4WT05/8ANGfXw+PFLcY7MvIzMeiL7rIrXxs1t/UGNBtLT/1Oe+TPw994+i6btnYzP8Mo1rsiWvisdrzCJrX1LTv+n/mSV9SY8npxX+5fx8rM6z0/LtuJMjhovfYkjWZfGXVbcU3+yN7jcrjXa1ZFf6mYnXYvDUkScmeHlcui6Xnm+OuHnCyD1KLRj348LYvcVtna5vHVXxeopM5/P46yhtpNo9HHzSvj9Z6Zlxy7m45HNwpVNyitr8GE1p6Z1VlaknGS2abkcJwbnFeD6HFzb7V+M9Q9MvH+/H4Y3HZl2DlQvpm4yg9+D6C9I+t/8Tprwcq1uyKUV3P3PnVrT0bTpnmL+H5KrKpnKPZNN6PS+JLZX2dHCyrYqddE5Rfs0i2eDmL3xrP9jY+hXVmD1HwFFd3bK5Vre353s9Mt4/Gl/wBjEnudJybeNW4uQv6qpL/QxraZR94tHslnDYM97pga/M6ZwrG9VwRZmvveRWQ9/BjTgz0/O6Prkn9JRj+yNDndI5Ne5R3L9kdZnE3K4edbILK9fB0OdxOTjtqVM9L50ay6lraa0dJkmmpnAinA2FlWjHnD8GpWLGFKJjZePXfW4WQUk/Hk2Eofgt+nsvlNPK+v+mKMWmWXjRjCTTl4RyvG8iqcSyjKpclrSbPUPUN91dNEf7k1o0PIdM4sum5ZH04RsVW96OVnfs55Y9+zyzkHXLKnKpJRb+DGJcqH08q2v/K9ERhxot7I7o+Nkm/JSfmLCzypU32lxZRt7X2JGQyigAKyFvbJvZcVT17MLKolonwY9+VWvyQxTk9JbZveA4u2V8LpxaSe/Jz5M5hjuvX0XTZ8/NjjjPll83J1cZCHtuBys29bOm6qklGFafsmjmZptHPp5+m3t9ay/wDU+36kY0v6ihWS0yh3fLAAAAAAAAAAAAAFV5ejKrj21r7kFEdzT+xky8y8BLV2PVK22MIre2dlx1EMDj/qSSUu013S3Hd8vqzj41tGb1TdKqlQjvW9Hi58/wAmc44/Vel9L/U6bLq853+HNcrlPJyZy342YRVvb2UPbjjJNR+V5eXLlzueXmhUoCuay+SUVoVL9KZZZ5sUfyTxj2rRG72igKsoVgAAAqkUJcet2TSS+QMvj8fuffJeF5MzJyO2P04fH2LJTVFShH3fgxJP9W2/LK6eIyKd77pEGblOX6IvwUtv7a+1e5hPy2wlvwqyiBLiUWZGRCmuLlKb0kiMLsLEuzMiNNMJTlJ60j3v0l9Pa6aas7Noj36UkpJ7T2YnpF6fSjKvPzql5SklJfk9yw8aFFca64qMUtIza9XFxfNXY1EKaY1wilGPsieKS9y6ETD6gyo8fxV+S3rsg2Zenw8u9cOr1x+HZx9Fupz3CST/AAfN99krr5XTe3J7ezpvUzmJcv1DkWfUco/U2v8AY5YPPbur6oOc1FL3N/x2Kqq02vOjB4jG3JTkvybyuLlJQitnj5+T4j9L6R0Wp+TKd/hfj0yusUYps6XjONhVBSmk5FnDYKrgrJLy0ZuflV4tEpSkk0vB8vk5Llfbi/f9F0eHDh+XlXZN9WNW3OSil9zmuV6gacoUt/umavmOVtyrJRjJ9uzVeW/Plno4umkm8nxfUfXM88rhw9oycnPyMiTc7JefuY0m35b2ZGPh33yShXJp/OjbY3T19qW21/od7nhg+Rh03U9TdyWtAVX32dTHpeWvMl/sWW9MWRTal/yM/wBjj+3o/wCjdXJv2udrutre4zaNngc5kUySnOTRFm8Rk4+32Skv2NdOEovUlpm9YZx5pl1HSZfMd/xfL05MUnJKX7mffVC+DTSaZ5rjX2UTU4Sa0dhwHLxvjGu2X6vbyzxc3T3H9sX6j031jHqP+Lm8oOV451NzgvH4NPdWpwcZI7q6qN1TTSe0ctymJKi5tLxsvDy77Vn1LoJh+2M7VyHIYzqm2l4MLR0udSram9eUjnrodtjj+T6nFn7o/nnqXSfhz3PFeoegnWl/A9SY2PO6UabLYrW1rR9z8FyFPJ8XRlVTUu+O3o/M7j75YmZXkQbUq5bWj7b/AIauqq+X4CrFncpWQrS0353s618yzVewziixoyJR8tMslBGRjyT+CGcU/wCpbMuUCOcC7Gry+OxsiLU6o+fuc5y3SlFkZOmMYv8ACOxlFkckalsHjnL8DlYk5f8ADlKK+dGhvpcW01pnu+ZhU5NTjOCe18nn3VvTcsdyvpjuPl+EdseT7VwE4Ms7e3yzPuqcW4taaMLkWqMG6x+O2OzttNPPufu/nuoIULz2WaLut8pYPT/0YvTdbRThMWWTz12VJNxViaOe9WM9L/3dS+GtGPjbnb228yyJueRZN/3MjAMPMFdb8bKFV4YVDpws1v3Jfgjs8zTZItaWiRrLwAFYxlKSUU2ysybUJsbGtuklCLezY8Zw12Q1KcXFflHRU4uJx1PdJw7ktnm5OomPad6+10Po3Lz/AL8n64sDiuFjWlZel9/Jk8jydGFV9OhraXwzA5bm3JOultL28M5+62dsnKTbOeHDlyX3Zvf1HqXB0WH4uknf7TZ2ZZlWOU23+5iz/pDaS2Q2WN+EeuSSaj81nnlyZe7K90c/6igBQAAAAAAAAAAAAATYz1snT1LZiVy0zKS/SmGb9uq6b5OqEFVPS8a8s2nKYkM6jcdP7HBVzlCSlF6aN3xfN21NQsk2vY8XL09mXvwfqPTvWePPi/rdTOzB5Djb8ab3FuP30YL8HeRsxeRp03Fto5XncNY2RJRXjfwdOHnuV9uXl4vVPSceDH83Dd41rA/sA/C2eqvhRE1/xP2JiOnUpSbJGSLkoADTIACCqW3o2GIo0198tbaMTHjuXc/ZF19rk+1PwitTt3STu75uT/0IZWNtsjbBNpsk23soNiKcpJJbbCLqoSsmoQTcn7JHr3o/0Hbl31chl1aitTSkvyaf0q6Lt5PNhk5NL+kmpLuXhn0lwfH08fiV49EFGMVrwZtejh4t96zMDGrx6Y01wUYxWvBnwh49iOuJk1oy9ZGHg839dec/w/p+ePXPUrIOL0z02X6YNnzh/EJybszJY/f4jNrX+hGM7qPFbbJW3Ttk9uRdRBzsUV9yNeyRn8RX3XbfwZzy1NtdNxfk5Ji3ODV9OlLXwbrhMV23KTXhPZra47aijq+CoVdCk15aPkc+ept/SfSulmWcx+IzpONNO34UUcT1LyMrr5Vwk+1M6TqbLWPhtJ+ZJo4CybnY5t72TpePf7V0/kPW3HXBhf8Ayolt/k3PC8PZlTjOafb+UY3CYUsrJiu3aTPQMDFjj0RgopaR06jm9naeXi9G9K/s5fkz/wAYhwePoxq1FQW0jLjHt9lpFL7YUxcpNI0uZy0u5qtv/Q8MmWdfrs+Th6THXhve7/vFV5Xvs5OXJ5G990ifG5e6Ml3uTRq8GTz4eq8Vuq6KzHrtj2ygns5zneAUoytpil8+Eb3Az6r4pdyTM5pSjr3TM455cdejn6Tg67j7vJ8iidNjhNNNDEulRfGcXrT2db1ZxcVB3Vw/L0jjpJp6aPp8fJOTHb8D1vSZ9Fze3/8AD0Hg86OVjxXduSRfzOOrceTS8pHLdMZTpyFFy8No7VpW0f8AiR4OXH8ee4/X+n8/93pfbl5cPZFxlKEkaLlKOyxzS9zquXq+nky0teTS8rX3U717I9/Bn3j8j6r0u8Msb5jRI9s/hd6gnxvUkaJWNRstitbPE9aevsdV6Y8jLj+rcCSl2qVy2e9+Lyj9G8e3+Yx4Xr2mtlzX4NV0PlLN6Zw7lLu3Xt/7m5aMMRC1+COaJ2iyUSqxpRZFKP4MposlEuxitGNn4scrHlVKO+5aRnSgRyagu9+0fLLB4v1VhfyfJzr1pOWji+sMhVYjp3p2RaPQuurYW8xKSa0p+WeX9QKXIcrCmCbjCWj0y9lvhBxcIYXF2ZE0k3HezxX1A5D+d5mztltRmz1r1Azo8ZwP0IySl9No8GzbXdkztb33PYy+nn5b8IigBlxCpQAR3exfUv0b2W3f0il+NEb+F5uumcNZGQpTW4po02tvR1vBQWLxs7npPt2ceozsw7PqejcGPL1EuXid2XyfJY+DX9KtJSS14ZyvIcjdkze5vRFyd8r8ucm9rZik4eDHCbvlr1P1Xl6jO4Y3WM+lXt+WPgq/6fBTy1pHd8dj2yblojL7YuMntFgdAAAAAAAAAAAAAAAC8gXQi3Iyk2o6I6Y9q2/dkjDOVEtgpKSiv3KJ7CabXgcideVGPc9N6Nr1RT3VRsS92aDjW1lwf5Os5WH1eMUn8I8fN+vLK/Temb5+h5OO/Dih3JQe/lFZ+JtFkltHsvh+Z8VZR/VIlLK4OPuXv3EMlAAVkKlABJ36jpFmygAqwUAFUtnZenfSmRzXIVzdb+lFptteGjWdH8Dk8xyNUIVSlX3Lb140fS/RXTuNw3HVQhXGM+3UtErtxcfurZdL8NRxeDXTVXGLitPR0mPFJLwYlCM6nXgw9smonrj+DIivBFWiaK8EotyH20Tf2R8keuOY7OrMmpPaV3/ofWXJKf8Ah2RKKfiDPjj1alKfV+W5e/1f/QOfI5RLybfhYaezUm84Zf8ACT/Bw57+r6XpOG+eNvhR7smC/J2eJDsx4rXwclxa/wDe4fudhHxSv2Pj9Re8j+oejYSY5ZOO6wvcrezfszm4RcpKP3Nr1TNvkZx/7xr8Nby6o/eR7uKe3CPyPqGf5ery396dr0ngquiNrj5a2dBZJQi5P2RjcPDswa1+C7lJ9mLP9j5eeXvzfv8ApOLHp+lkn05/mMuVlrjGXhM1jfyy+5uVkmzA5C5whqJ7ePD4j8r1nUd7nknldWnpyRJBxktp7Oedk297ZmcfkTU1GTejtlxanZ8vi6+ZZ6sb3FtlVYpJ60zrOLyFfSvPnRxsXtJo3nTtslZ2t+Dx82O5t+o9M57hye34rd59Eb8acJLe0ecczjfy+ZOPb42eodu1+5wXV9Sjmt/94nSZay01/I+nl4ZyfMaXDm6squXskz0PirVdh1yX2POflHc9LybwYp/5Tt1WO8ZXzP49y3HmuHxWH1HVqffr3ZoMmPfTL9jq+oa1Knf2RzM4/okicOX6xv1Xh1y5f7cxfHttkvyT8Rc8fk8e9PThPZZnrWRJfkjperYv8n18buR/NubH255R+hnoFmfzvQeLY5baoT/5nevWkeP/AML+XKfRtFO/CpS/5nsTiS+XmiNotkiRx8FkiKikixolZY14KIZo1nP3LH4+1t63E2sjj/UPNjVh9kZafa0zWPekeXdW5Sh/MWOfmW3E5XjY6hdl2x1/dtmfy1ks7NjWn3RT0znuveYo4bhpUwmozlBrSZ6IZV5l6q85/N58saEm4xbXucB+5k8plSzM22+Tb7pbRi+5Hkyu6FC5RetlrDIAALlFSi9kNS/W18bJH9goqK/LI3PDIwKXdlQgvO3o6Xmn/KcXCpPTcDX9J4/1MxTa3qSJur7t2xrT9to8vJffyzH6foejw/r+nZ83zl2c63t7YKFUet+cVj87C8MslLT0XLyiLUeQm13GOZr01pmNbW4vevAalRgAKAAAAAAAAAGTj0px7pLwwIFCT868E1VaXl+SZqK8L2EY79kGbkt0JeFsWSUXrZBbZvwgki2yW5EtUk46Mcvrlphqxn4L1kQ/c7WyEreJ1FbbicLTLtkpL4Op4bmq1XGm3Wta8s8nU4ZXWU+H3/Qeo4sPfxcl17nN5VNlVslODRAd7kYWHnw761Byf2NByXAXVNyrTa/CNcfU45dr2rl1voXNxbz4/wBsf9NE3taKF91U6puM4tNfcsPV/wCHwrLLqgYDCGwS1Y9ti3CDaX2LJxlCTjJaaG41cMpN2dloGxoMhn8Lx1/JZkKKa5S29PSMTGqnfdGqCbcnpaPcfSXpKGLTHNyql3Simtr8hvDH3V0vpp0tTxPG1WW1RVrh5bXnezvVONdbnJpRS2zEq7Yx1HxFHGepfVtXE8dOiq1fVknHw/KJY9vbDF0Ob1rxOFlOieTUmnp/qM7C614SaW82hf8A1HyVyPLZmbmTvlfJuT2WxzuRgu5X2JE04f2K+1+K53is1pUZtM5fZM3mPW7pqNa7t/Y+IOB6u5ji8uFkMu3W/KWj7J/h85ldQ8PTkZP67PpqT7vfezOU03hze520uDUeCyZ2R/VKp62fC/rVR/L9cZsNa1d/6H6JcjGLwLYJeO0+Av4iMSdXXubPWk7/AP0MS7W9684N5xH/AFK/Y0jN1wrThr8HHn/xfX9IuudveJf/AL3Df3Ox/wCxX7HGcf8Apy4f+I7On9WOv2Pj9R5j+n+jX9Mo886nX/6nZ/4zBwfGdS3/AJjcdV0uOZKWveRpqX22xl9me/ju8I/H9Zh7Ory39vUeM1LDr19izmId2JJ/ZEHTORG7Cgt7aibHLr+pjzhr3R8m/rm/ovFrm6WWfMcLZ/WzWcpXJx2kbvPodV8k1ryYllcZxakj6GGWu78b1XT3KXCuc0zIwoN2rX3NhPAi5bSRPj40K/Ols75cs0+Vw9BnM+6Wtagkbrp6Dd20vk1UIOUlFL3Oo6fxPpV98l5aPDzZaxfqfTeC58s18NtFa0cH1nJPMa/7x3l8lCqU340tnm/U1yuz5tPaUjHSTee3r/knJMemmHza1L90d10tF/yMZf8AdOIrh32xgvdvR6D0/S6eOhFrz2no6q6xfD/j3Hcuot+JEHPPVP8AocxZ/TJnQ9RzSgoo5u96ok/wZ4J+r1erZ/8ALf8ATnuR85Lf5Iav+sj+5flvuul+5THi5Xwilttn18fEfzLnu+TKvt7+FmD/AOi1L/8AlL/7nt7R5N/DHgurofHta1uhP/metpeBl5eWI5IjlEnaI5IyqFoskTNEU0WDGyZdlcpv4PHfUfk5W5M6K57bbXg9O6sz4YXF3NySk4PR4nlOWTn25Nz3Hu3tnXCLGotVXH4FuZfKMZKPd5PAfUrn5cpyc64WOUIya9zu/WDqyNUJ8fjW+dOL7WeKWzlZZKcntt+Tq4cufxFvwXVQc5pIolt6Njj1Rqodkl51tBxk2xMhKEVH5MYkvm52N/BGCgACBfXCVk1GKbbFVc7ZqME22dRwfERpisjKSSXn9Ry5eWcc7vf0HQcnV5+3Hx81sOm8JY2E7prT1s5jqO1WZ8tPembrmebhVVLHx341rwzlLbJW2ucnttnn6fDK5XPJ9j1nquHDhx6Xhu9eVgfiOxJqKIrLNrSPZt+akWTluf7GRX5jvZiF8JuIasZRV6lHtZFXYpNImcdJfIZ1YxbKmn48kbTXutGaUsgpxb15CzJhArJak0UDQAAAAAGVj2bj2t60YpVNr2AzJab8Mqm17GHGcl8k9dqfuGLj9L3Hue5EN1aT3En3so1tAlYZWKbZfbHUvBfVHwG18fEUXJtPaKAunPbY4HK34sklOWjq+L5ijKrULWttfLODZfTdOqalCTWjz8vT45932PT/AFnn6W6t3j9Oz5ziKr65XUxTfv4ONyKZ1WOM01o6zp/lo21Km6W3rXkc7xKuj9WpeX58Hn4uXLiy9mb6/qHQ8XX8X9npvPzHHmdxuBblWpdr7fuZmBwl1lq701FfdG7tsxeLxu2Pb3614O3Lz/8Atw7183ofSLf+XqP1xifExcHEqVdjr7mtPZr+a4eFsZX4yT+fBoc3kLrr3NTaW9m24TmuyKpvba9vJyvFyYfvL3fSx9Q6Lqt9PnjrH4rn7qZ1TcZxaa+5Gdtn8bjZ9P1aO3ufnwctyHH3Ys2pRevueji58c+18vi9f6Ty9LfdO+P26r0w47Dy+SjLJlDcWmlI+hMCqujGhXUkopaWj5U4Xkr+Nza7apyjqW3o+gvTrqavmMKFcpJ2Rj58+fc9Mrw8WU8OyuU3jTUNqWvGjz3kuhcvnOVnbmWOVfdtKSPSqUvYzKY69vBnJ6bhMvLzzC9KeHil30Utr8M2f/ss4WdEoxxqd68eGd1VFfJvunOOnmXx/T+lPyYtS8eMnh8beqHTP/R/l7K66+2vv0tL8H0H/CHnd2IqHL2rS1/qjmv4r+Cjh9mRCCXdNttL8Mwv4R+XjVy7xpT1/Svf8oXvi8njN9lXx7q7I/dHxb/FJxTp6guyFDSla3vX4PtRNTh3fDPnj+K7pt28R/PVQ2/1Sel+Dlj5d3x6vKNnwk9WNGtacW4v3RPg2/TvX5Znkm8bHv6Ll/HzY5Oqol23Rl9mdjxditxo/scTTJTrUkzoensrX/Dk/wAHx+fHcf030nqJjya+Ki6ww90/VjHfyzjEvOj1HkaI5GJODW9rwee8riSxcmUWtLZvpeTc9ryev9HcOX8uPitp0nn/AEb1XOWk3o7yuUbIKUWmmeTVTlXNSi9NHZdN85BwhTbLz7bbMdTw2/tHr9B9Uxwn4OS/+G15XjY3xckls5zJwbqptfTk0dvCcLIKUWmmWToqn/VBHmw5bj2r7/Vem8fPfdjdVwn0bV/2bJKsW6ctKuR2TwKP8kS+vFph7QR0vUf6eLH0a775NLxXFaanZH/c31VcYRUUtaKpRj9kjXcvy1GJVJdyctfc425clfSxw4ei4926Y/VGfHHxZQjNdzTR59dN2WOcn5Zmctn2Zl8pOT1swq4Oc1Be7PpcHH+PF+E9V6+9bzbnieGbwmM78yDS2lI7+iP06Ir20jT9M8cqa1ZKPlrZtuQsVWPKW9eDyc+fvy1H6P0fpf6vT3PLzXOc/Z3ZDW/CZoeRn2UP8oz8y123Sk38ml5m1dvamezgw7yPzXq3Uz255tPN7m2bLpbGeZ1BhY6j3KdiTNYeg+h3Dy5Pq7Eah3KF0fg+m/A273X3D6O4C47orCqUdbpS/wCbOyXsa3pnF/lOExaNa7Ya1/qbPRiuS1kciSRZIio5EF01CDlJ6SJpGg6tz1jYM4xlqUos1JscR17yLyb5UxnuCbR436k9UUcJxs66bo/VlBrSfnZ0PqD1NRxWJkW22xdji2lvyfMXWPP5HM8jbZKyTh3eEzvJ2Tkz9k1Gu5vkbuTzp5Nsm3KW/Jgglx6pW2JJFeTyn4+jvmpSXhMv5G1L/hxfheDKtccbG0tdzRqLZuU3J/JfDV7TSxlCrKJBgJ8TGtyLFGEG9v4MjjeOuy7ElF637nV42Li8VjfUtUXPW/J5+bnmHaeX2fTvSc+p/fPthPlj8bxmPhUfXyHFSS3pmt5rmZzbppk1BePBBzfLTybHGuTUPsjTvbe/cxxcNt9+fl6Ou9Tw48f6/S9sZ8/as5OcnKT2y35APW/P223avam/PkivrS8xJR7rRNLKwy6Ee6Wi62OpfuTVRSXt5DVoqlFLXuXJv5ZUtlNR8sM96v8AgtnZGMffZBO2T8J+CNtv3YWY6JPcmygAaAAAAAAAAAABkUz/AE6ZJ7mLB6kZS21tewZyiy1Lx+5WK0Jru+fYRCXwqACsqFVFv2BVS7U/AqxJRbOi1Si2mmdfw3K13UqF01tL5ZxMJ97ZLVZOt7hJo48vDOSPp+n+pcnQ57nefTseW5anHg40td3t4ZyeZl25NjlOTeyK2ydj3KTZYhxcE44vqHqvL1mXftPpTyXJtPa9yhWKcmklts7PlNnxvLX40knOTj9joqcrC5Kjtt7FNr5ZzVPD5tlH1lRPt1vejFUrsW3W3Fo8/J08y7ztX2ei9X5eCezk/bH6rI5nHhj5Uowaa38HceiOTZDl7Ydz09LX+p57kXzul3TbbPQPQ6l28zc1/bp/8zthLJJXz+TPHPmuWE1H0NjP5ZsKVvRr8f319jZYkXNqKW2zWT1Ys/jsaWRdGuKb2z0vpvjoYeNHcUpNeTRdI8V2RjfZDy1vyjsatJLSOOVYzy28J/i34iWR05XkVw7u1Sb0vwz5s9EOZfC9Y4qlLtU7opn3B6q8FHnulsqhwUpKqXatHwN1Xx2V0v1ZYu2Vcqbf0+NfBrDvNPLyTV2/Rzp3Nr5DhsfIrkpd0d+DSeqnCQ5rpPLpdanL6MlHweQfw4+qOPm4VPF5+TGM4wUV3y93s+iI/RzMbw4zrmv9GcrNV1xu4/NTrfiLOG6gysWcHHtnpJr8GjXh7Po3+KToK3H5O7lsWhuE7HN9q+NHznJOLcZLTXuadMa33EXqVSi35SNvhXum+Mk/G/JyODc6rU9+NnRUWqyCaZ4Ofj1X7P0nrffhJ8x3eBkRvpi01vXk1/UHFxyqpWQiu5eTVcPnSotUZS/SzqKbYX1bTTTR83KXiy3H7rh5OPr+D2Z+XmuTRZRZKE4taLKpzrl3QbTR3XL8PXkwcoRSkcln8ZkY0n/w5NL50e3j5sc4/J9b6ZzdLluTt9s/i+oL6NRslJpfk6HE6mxp6U+1P7tnAtNPTWgm17PRM+nwyb6X1rqunmpdz/b06PMYMo7+vWvxsxcrqLEqTUZRl+zPPFK3/wCIxuT/AKpbOc6TGfL3Z/ybnympjI6jkepZTTVTa/ZnPZeZdkzcrJt7+5AX049ts0oVye/sd8OPHDw+R1HW9R1V/a7Rxi5PUVtnQ9P8TKc422x0l58on4Tg3tWXR/Omjpa64VVqMUkkefm5/wD24vs+l+j22cvNP/pdBRqrSWkkjQ89ndzdUX+DL5bPjVW4wl5/BzV1jsk5yfucuHj7+6voepdZMcfxYIbpdlcpfg5zNtdl0vPjZseVytJwizUPbbZ9bgw1N1/OvVuqnJl+PH4UUW3pLz8H1B/CV0dY8j/FL632txmm0fP3QvC3811Di4lVUpxnYoy0j7+9Ium4dP8ATONV9NRk60n4/J6N9nwc78O1hFQXbFeF7FwKGHNRvwRzZfIimFQZNirrlNvwls8X9W+tMXjK7nO+O4p6Wzq/VzrXA6b4W/uya1a63pd2ns+IfUbrTM6g5O9/Wm6nJ6W1rR2wxYyz9qL1B6tyec5CxRtl9Luelvxo49grFNvSOjzW21WEXOSil7m4w6I0U/UmvOtlnGYetWTWvnyW8rla/wCHB+F4NeG5NTbDz73ba1vwmYrLknKX3bK2Q7V5Ixe6M2HC4X83kqL9tmvOp6Mo3d3flHLnz9mFr6PpXTTqOqxwvhuvp4/FYXdqKkonIcxyduVbKPe+z7G660yWn9JP7o5E8/S8W578vL6/8g624cn9Xi7YxXTabRSqe3JMSm4Qevkjp/qbfyex+ZnhK/coH7grAVKFQLLF+pMvXsikte5dHzpEavhRyUU9mLZLuk/sTZPjwY4akAAFAAAAAAAAAAAAABGVXP8A4aRik1T8IJfCSSfnQhsu3pMR12J7DPwoACsga2tABUdaUZtMkIpf9YSpaRI1kAArAbrpbjZZ3IVrt3FSWzTRTlJJLbZ6j6ecbCjCWVbFJuO/P7ljWE3W9ysXFwuMjjxqj3zj2rRz3I9FSyOPllxhqfb3a0dHjy/xPl+yK7oVS2jtXjR/kpUqPjt1o1Jt6PbK+YeQxZ4mROmxNNPXk9F9Av8A+Wyv2X/3RzXqRjrH566Kjr/if+hb0Bzz4Lk3bvUZtb8mHHH9cn1JT/1jOu6R42WRfGyUf0rTPM+j+quI5P6Lsy6a5S905HuXSWRxbxK1jZNU5OP9rJnXr9012dFiVxrhGEVpIy4ENS+SZeDhWV0oKyuUJLcZLTR8s/xT9B0Vyny1KjByk5vS/B9G9S9ScbwWDZkZmVVW4xbSk9bPj3189Ureos23CxLpSx4zaXbJNa0awl258lmnk/TfK53EctTZh3ThKM1/T8n3r6Cc1yHL9J4lub9RydW9y+fJ8Uek3TN/UXU+NBVSnBWru8eNH6BdA8HRwXTuLiVVxg4w7Xr9y8ljHFtD6jdN4/UHT2Xj2VRnY6motr5Pgf1O6SzOm+fya7aZxr+pqLa0vY/R9pNafszx7189OKOouHtysbHi74xlLxHbbOcrvLp8JR+5sOOy3XJRk/BN1LwmZwnJWYmVTOvsl2/qWjV+zJljMpqvb0/NlxZTLF1NU1OKlFm043kJ0SUZSfacjgZsq5KMn4NzVdCyO1JHg5eLXav2Xp/qUz1lhdV3GJmV3RWpIlux6b4NTgnv7nGY2VbTJOMmbnD5jwlY/wDdnhy4bO+L9ZwepcfLPbyxTP6erm3KtJfsjU3dO5Cb7W/9jrKc+iyKf1Ir/UnjfVL+9MTm5MU5fSuj5+8cK+Cyk9al/sX19P5Mn57l/odx3VP7FPqVR/uSNf2s3Gfx/pp3tcvidOSTTsf+6N5hcXj46X6I7MmWXRH3sijCy+VqgmoyTf4Zi58mb18fS9H0neabCUoVR86ikajk+UjGMoVvz7eGazM5O21tKTSNfZZ/dNm+Ph+a8fV+q7nt4119s7ZOUm2a/Pyo1wcU/JbnZ0YRahJN/g011krZd0mfQ4uLfevxnqHqUx3jhd1bbN2TcmVpqndZGuCblJ6SRbGLlNRS237I9g9B/TjL6g5mrIysSaojOL3KPho9kj8xnn816Z/DB6cuMauYzMf37bF3R/J9SVQjXXGuCSjH2Rq+luGx+E4mnCx4RioR7fBtiWvLbsZY2VkQ5N1dFUrbpqEIrbb+CC+bSWzzr1T9R+L6W4y9SyKv5jseo92ns5v1l9X+O6fwbaMDLrsv7Wv0T8pnxx171rynVHIWXZN9soSk2lJo6Y4b8ueeevDZeqPX/IdVcndJ5Fn0e56i2mtHBPyAdnC3YvL0bPi8NzkpyXgj47ElbNSkvBtsi2GLRqLSejUjeOPzUOfkQor+nDSetGisk5zbflskyrpXWOTbL8PHdku5rwieUt91XY9XZD6kl+THvn3Tf2MrNtUUq4/HgwWGb9KHb9HVOOO7NePDOKqj32KK92z0LhorF4KcpeH2Hj63L9NP0v8AGOH3dTeS+MY5fq23vzWt+zNGZvL3u7Mm/wAmGvc9HFj7cJHxvUOX83U55/7R3f0iqL7dlL340X1N9umbeX4VBlV4GZZU7oY85QS3tLwY0k4ycWtNe6KwoV0UKp+fIFI/1eWVXh7+xRtd3guXsyNVjXzcpefgjLp/1stDYAAAAAAAAAAAAAAAAZGKk97+xjklEtTAnZapedfCJJa2WRS7mwxFyTfsjb8D09ynMZMacTDts7n7xWzL9PsTDzuoaMfNcFVKxJuXsfT1vJdAdC8LGdEMG3K7dfpk00yWkx24no70FybuBuzeQg4z+l3KM4eU9niPXfDS4LqHJwGvFc+32/B9KdA+r13P81kcfGyUMeWowj3JryeQ/wAQ+D9Lq7JyO3Snd/6Em992spNdnk1nie/yTRfctlly2toVP9OjSXvF4AKw2HA4ryuQrgltdy2ep3zjx3EQxovU5x7Ujj/TvEj/ADEr7F4STWzeZd0+R6kror2667V7fYs8OuHaO16F4+VWJHJtX65x87OuqW/cwuMrjTh11xSWkbGpex1k1HePEPWHi71y08mFUnGVm9pfg8/qx77HqFUpS+yPqvO4LA5SPbl1Ql/4ifpf014HIz124lDSa34Zys055cVt2+XcSzmuOmp1q6vX4O16T9Uue4XIr+rfe4Ra2tpH1i/SXpW6lKzCxd/O0zh/UL0M4q7BslxVFUZpNr6cXs5+6M/js8N16W+s3F8zRVRnX11WaSbnPzvZ0XXXqvwXB4NrpzKLrNPWpnxd1PwnNdGcrZVu6ntnpS1o0uRyXLctYq7L7b5Sfhfce2VPyWdneeqXqnyfU+VbXVfbClyeltNa0eZSlOc9zk5N+7Ow6f8ATfqXmWnTx2TGL/uUDqf/AGDdUKhW/Tyd63r6Ze0Z1b3es/wk9LUfy8eSsUZOUFJbX5PqKKS8R9l7HyB6Yf8ATboPIrx8jBzZ4sdR8pJa9z6Y6N6sx+axoKSjXdr9UW/OzlnLt2w7TTqiltULanXNKUZLTRUrFnN0eA+vXpHXzGPdyPH0r6q3NqEW2/B8i9R8Fn8Lmzx8vHsrcZa/UtH6cW1wug67IqUWtNM8i9X/AEl43qHDtvxMauGQ03uMW3s1K1jl7XwcvcnoyLKpLTejr+u/Tzmum821W4tzqjLxJx0tHFyTjLtl7/Ylm/L08fLcb7sa3eNyEJxSlpMzK7YTX6ZJs5hPXt4Jasm2t7jJnDLgl8Ps8HrGWPbkm3UQssg9qbJoZt0P72c5VyM/7tmTDkofKRwy4L9Pr8Xq3FfGWm/XJX6/qkWz5C9/3yNN/iVWvZf7lsuTr+EjH4L9PTfVsNf9xtLMi2fvNkUpP3lI1VnJLX6UYl2ddPaUno6Y8FeHm9X4sfnbcXZdVa/qTNXmZ8rG1BtIwpTnL+p7LT0YcMxfG6n1Pk5e07RWTcntvZWEJTajGLbfwZPHcflZ98asWmdspPSUUe5ejvoryPI5dGZymPZCltScZw8aOz5WWevLk/SL0z5LqTlMe63GsjQpptuO00fbPp/0lhdN8TTRVRCNkYabS/JP0f0rxnT2DXRi49cHGOm4pnR/BLXnyyuSgbSLLJquDnJ6ivds4L1D9TOC6Zw7O/Lolcov9Pfp7Em2bdOs57mcDh8OeTmZFdcYxb/U9HzP62+utca7uO4i5NtOPdXNHmHq76ycp1Dk24+Hk2wx22l2yTWjx7JvtyLHZdNzk/O2dccNeXLLk+Iz+e5vO5jLnkZd87HJ7/UasFPc6OIvczePxZXWJteNmEvc3fH31VY+21vRWsZusxuvFo+NpGjzsmV1j8+C7OypXTaT8GPVXK2ailstq5XfaL8Wl2zS09Gzv7MXG7VrbRLi0wxqO+ek9Gq5C922vT8Jjwv+MY1k+6bf3LCrCW3pe5HNmcNS7c2vxv8AUdtzE/5fhVBeNwNL0lx8lYr7VqO0/JP1dyFbh9CEk9Jrwz53Nfyc0xnw/Z+nYf0vTc+XPtcvDkrX3Wyl92W/IfllH7M+j4fjbd1Hb/WtMkS8IhgnKzf2ZOyRrLw+i/RbD6U5rp2XG5ssWGVZBQTm3vZxXq36YZvBZlmZg0zuxpNyUoR8aPOuE5rP4jKhfh5E65Re12n0l6N9cYvWWPHhOcrjfOWq07Zff9iXc7k1ez5esrnXNxnFxkvdMsfse5fxD9E8T0/b/M4Mqo/UUpdsU/g8MbXb5+S73E1qiWysv6GUgtF1+vpeH8BfliS92UADQAAAAAAAAAAAAAAAAVh4kigQGX7lPbS+4rada+5SX3DPisnDyLcO+N1M3GcXtNHqHp70pm9dX/Vz86SqSUn3raR5RF7jtnW9LdacjwOHZRiW2VuUO3cWgk8930d0b6U8DwvMVZFPNYylGabST8/8jkP4p+DjVZDLx9WQlY33xXh+DyGv1C6nhl/W/wATyNb3raNp1V6iZfP8FRg5kp2TrT3KT9zOrtrc088/s/0I6f6mmSpEU042bXsaTFMVrj3TS+5antFYycXte5WXQ4mVk8ZibhKWprXg6j0+tjPLeXlR7e7T7pHAPNsnGEJtuMfhnc9Kc3xiwq8a2NcJqOu5ssdMb3evYWTj2pfStjL9jbUfB51x0JzlG3CzO5e/bE6TB5TJx1GN9M5a+Wb9zvK66mO2l9z0PobBVVSvcf6lvZ5lxXJUXTg3KMX9tnpPTvP4sKIUPtjpa3s55/6btdrFp/BKopx014Zg4WTVfBSrmpfsZ0H4OLLxn+ILoGnmeJtzcahO6Kcv0rbb0edehHpHLMy/5rlMbUYaklOP5PqbNxq8uiVNsFKMlpplOI4/G46vsx64wWteB7rpi4S3a3g+n+K4qiNVGHWu1a2tm3jXS1r6S19iyL2SRMN6Q5nF8bmUuu7Dre17sweK6YweOy3fjRhDb3pI3EfYvh7hNJUy5MsRcvYyq9Mr4a00WIuTA5rrDo7iuosWdWTi1OTT8yTPnD1Q9AraPq5XFVtpbajXBn1qiltULYOFkVKL90y7JdPzV5zo3nuKtlC7jchRi/6nE0FtN1UtWVuD+zP0m5vongeVhKN+DTuXy0zzDqz0F4jOdksSqmDft2xZXScv2+JdFD6Q5v8Ahy5GDk8eyevjVZyud6A9Q0tuP12l/wDLGnScmLxnQ0eqS9E+pYtpU5L/AP6yfE9DOpL5acMiP/8AWD34vJdDTb0ke8cZ/Dxzdkoq2dy396zuem/4c41ThPNakl790GEvJHyzh8VyWZJRxsK23f8AlR6F0N6Sc9zeTT9fDvprk1vcPg+u+mfSbpziaobwsec4r7M7bj+I47Bio42LCvXtobc7yW+Hkvpv6J8VwsKcjLoqssWm9xaez2Lj8PGwseNOPVGEYrWkZG/0/g1vLc1x/F48rsvJrrUVv9T0Ty57+2z2l7+DT8/1JxPD0Ssy82mtpb1KR476j+vXEcXXdjYVlVliTSlGzzs+YOv/AFT53qLKt7cy6FUm9Laa0bmFvlzyzke8+sHr5VjK7C4i5SfmPdXNHzF1d1by3UWXO7LyrZKT3qWjQ5F9t9jsum5yfu2RnWYyONytCsIym9Ri2zJwcG7KsUYRem/fR0/H8Tj4Vf1clx2lvTOXJz44f+X0uh9K5uqu/GP257G4nKu1/wAKaT/BPmcJdjY/1Zp+2/Y6GHNYcMiNNdcffW0zM6icbuJ74r3gzy3qOSZSWalffw9E6LLp88sM/dljHnT8NovU5a1vwW2f9ZJF1UHOSikfRfjbO66uDnJRS3s3nG4ca4qc159y3jcJQipSXkm5DJjTU4p6eiyOmOOu9YXL5On9OL/BqGy+6bsscm9lhLXO3dU8vwkb3p/iJZM1ZZFqKfyY/T/HvLyFtfpTOo5HKp4rC+lDSn268Hk5+a79mPl+i9I9NwuN6rqP8J/+0XMZ1PHYn0aWu7t14OMyr532uc222y/OyrMm5zlJtNmMdODhnHO/l4vVPUsusz1O2M8RUtseov8AYuIrpbXaju+XjFaVrb37k1ddls1GuDlJ+yRHUtQ8nY+ltPH2c7VPkHWqo2Lff7aIXvXPQ4blpa7ePue/bwe8/wAPHSOTxkrOb5OmWNGqUbE5rXg6u7qr054zGphLC4+yyEfL735/5nEeovq9h3cbPjuBpjjQlBxf0p7Rm21rUndy/wDED1PLl+op41V/fVTOUVp+NHlckmkZGZk25mTO+6blKb22zGa1LW9mtaSXd2uS9iLIbT1smh+TGyHuYIjAAaAAAAAAAAAAAAAAAAAABPjv3RI/K9jHplqRk7/UGatjtLT+CpRt9zf3KiJkqgzYcJxOVytzqxa5Tl9ooyOX6a5fjJtZODdBJ+8ol2jTFt39K0iWcJR94tFr12taJSVZU9xX3LiGL7ZtE5YuUULoylCW4PTLQGW54rqTkuPkvp32NL4R2vBeoEH2xzYd33cpHmIK1M7H0dwfUHDZkIzhk01Ta3rZ02Fm9+nTkd37Hypi52VjSUqr5R19jo+K645TD0vrWyS/KDrOX7fVXE9RZuHKMXKfb+52fEdW1yUfrSXn7s+WeB9U61GMMyCb+8pHa8R19xWR27uqhv8A7xNSuszxr6Xw+YwsiK7b4bfxs2NVtc/6Zpni/TfUPE5MIqHJUxk18M7LjMiybUqOR71+DncV7O+iSRZocDLyIJd8pWG0oyXY/wCho52DPiSQ+CCEtong/YzRIi4tRUguSLki1F68APkqPAQQKr8FCqaArL9XiT2RTx6Z/wBVaZIFJAQLBw/nHiXQw8WL3GiKJdossvqri3Oail7thFyrhH+mKRc3LXuaDl+ruC42EpX8jRFxXs5HnnU/rn09xcbPp349rj9rCzG03I9dtnGtOVjUUvlnP871jwPEUTsyeQx4uK3qUtHyt15/EXmZkrKuNc64vaXZNHjXU/X3Pc5OTuzrlGT9m0dJx/bGXJPh9Seo38QOBiQsp4yyuUltJwsPnrrX1g6j52dlay8iFUvGtrWjza2222XdbY5t/LLDpMZHK52p8zLyMu12ZFsrJPztkAL6a5WzUYJtv7FvZmS5XUWxTk9JbZueG4a3Ikp2xcYflGy4ThIwrWRkaSXnyi7l+YqxoOjG0mvG4s8mfNc77eN+k6X0rj6fj/sdZdT4n2nyLsLi6O2vsdiXw/JznI8vkZMmu+Sj9jCyci3Iscpyb2yJxkvdeDpxcEx73vXj671bk5/04v1w+okoscb4WN+U9nd0y/munpyb9qzz/fk7ngZ93B2Q3/2Zy6udpXu/jfJ/ycnHfFlcXetZNi/Jt+Kxq3BTetms5GPZmWf+Inwcz6UWmz2YXtH57Oe3ksv23WTfCmp+Uno57MyJXWPb8FczKldN+fBjGrWMsthWEXKaivdlDZ8BhSycqL7XpM555TGbrp03Blz8s48fl0vT+PHD495EvD7dnM9QZssrLl+raTOl6ivji8dGmL0+1o4icu6bk/k8vTY+7K8lfo/Xef8ABx4dJh4k7qIFAe1+VVb8EC/VZ+xLZPtiyylPy/uRudolXsSUX3US3VNwf4LsbEycjf0KZWa99Isuqspm42wcZL3TKyvuyL7nu2xyf5IXrf5GwEH4Xgtjt+5dJPX4EVrRGvEV2owbf2MSb3JsyMh6hoxQ1PAAAoAAAAAAAAAAAAAAAAAAKrw9mVBpwT+TEJ8drymEsSS9l49gvKKvwWp+dfYM+Y630456jgeVjkXwjOO1tN6PfsLr30/53HjVyeFgRm15c5v/APJ8qk+FXddk11U77pPS0LNky0+q8z0z6R6k4nI5DhHidsK3Z/wk3pHzP1pxsOI57IwoNNVz14PpnoKdnSnpPZkZVzjbkYbilLw97Pl7qbOnyPOZOVOTk5y3szi1lrTUWpqSkSQkmhJJp7Iq32yaZpPMTlCqYZWFAAAAADS3vRNVk5FX/V2yj+xCANvhdR8vhtSpzLYtfbR0vE+qfU+DKKWdkuK/KODK7Y01MrHu/T/rvyNHasqdk/v3TR6Dwf8AEHxyjFZEa9/O7D5H8fYb17GfbFnJX3Txfr703b2xtljR397DpeP9YOk8prefiV7/APmH56Rtsj5jNpksM/Ph/RlziS4RqctfpJi+ofStyThy2I/2kbHH6u4C7+jksd//AFH5sYvUXM4/9Gfa/wDY2uJ191DjpKOdf/ujP44v5X6NLqThG/8A+Qo/8xNDneKn/Tm0v/U/OmPqV1In/wDvcj/dGZT6rdS1pL+byP8AdD8a/lfoVPnOKityzal/qRrqThV78hQv9T8+bvVfqWxa/m8j/dGJP1L6kb//AHuR/uifjPyv0Nv6r4GqO5clj/8AmNfkeoPS9CbnyuKv3mfn3keofUV8e2Wdf/ujV5fVHNZKaln3ef2L+NPyvv3kPWLpLDUtchiWa/8AmHL8t/EN03SpKmWM2vtYfDNmfyFm/qZc5b+5BKyyX9U2y/jiXkr616g/iPpamsRxX27bDzTqb196iy++OJkZEIv/ACzR4noexqYyM++uq5fr/qTlJSldyGR+r3TaOeyc7LyW3ffKe/uYwKzappfCCZsOIwnlymtexj8hQ8fIlW1rTMzOXL2u+XTcmPFOWztUAKIqbecN90jiK7J7px2k0aKKcpKK92dlwdccHjpXz8Nx2jzdTnrDU+X2vQunnL1Mzy/xx71Tqfkv5ev+WqevjwcfbOVknKT22ZPMZTysyc29rZHhUu2xL3WzXBxezGOXq3XZdX1Fu+08JcHFlZJNrwX8lCNa7UkbeipVwSSNRy73b/qemzUfOs1GvTO16YTlx84/eJxXydf0tnUV0qucop615Z4+rluHZ9v+O5YY9V+112aPnceyGZOTg0tms2ejZWHiZq3uEtmozem4tN1+P2Rz4uqx1Jk9nqH8e57neTi7yuQbGza5PCZNTfbCUtfgu43hci65KyuUVv5R6fzYa3t8Oem9TeT2ey7YWDhW5VqjCL037nc8Jx8cDEdk1+rW/Jfx/H42BUpS7U0vc13UHOQhXKmmSe1rwzwcnLlz324+H6/oug4PSOP8/Pf3aPqfMd+XKCfhM0pLdY7bJTk/LZEfR48PZjI/FdX1F6jmy5L8hUoUslqPubrzxZP9U0kZOJRZfbCiqLlOT0kjHpXnufk2XCZccLk6cmUe5Vy3ojV+n0T6NdD8TxXC/wCJ9R11Rrsip/8AGTS0ZnWHpl011Sp3dOZGMpvf6aU35PKOqfUzL5HgquMxpTqhCtw8SIfSnq3qHE6gxsfFvvsjZYlJR0Z1V3PDD619M+e6blOy7FvlStvvcNLRw0ouM3Fryvc+v/W7qDG/9ntEcuuKyrMWW+5+d7Z8i3NW5Flnsm9ostsTKavZD3Peivn3KtL/AFKSl2wZT50x75d0tfYiKye5NlA0AAAAAAAAAAAAAAAAAAAAABdXLtmn8FoAzZNS8rwmWSXnaKUPujr7F8l4DHiiT0d96KdP0831PV9e1QhVOMnte/k8/jJ619ja9P8AO53CZH18K6dcn7uIPFe8fxEdRY3GcfT0/gWx1TJwfa/jTPnSTcnt+7Nl1DzWbzmZLKzbZ2TlLbcjWCTUMruhDanvaJyjXctFpKsqe0XkXmuevgmXlbJKZRQAFZAAAABQKoAgD3KFQCD9yqKfID2KplPkaAr8gAgBlPkqAKJB+42UVKe4Y+AHsB8Be4DYfkq4v30XY8HZfCGvd6J4axnusjrujcX9Dm17o1nV+M68yU0vDkdb0/RHHwYb8PtIed41Z2nHz/ofKx59c1yvh/Q+f0m5+l48WM/by8+pptt/6uDl+xSyuyt6nBx/c7nGxMDjKU7uxy152R5GJx3IQcqpVqT+EeqdX38dnwL/AB3KYa989/05jhMSWTlw0m0n5N51Jkxow4Y0HppaZn4mFTxmNZbtb1tHIcvlSyMubb2t+CY38/Jv4jpzcf8A0vovx3/PP/8AjDScpflm84nH7IdzXua3j6XZdF68JnRVwUIJI92MfmcJ8kl9jR8rVLvctbRvWQX0xti00asbym45hryX1WTre4yaM/LwJR24owJwlB6ktGLHLvjdxssLmciiS3KTSN7h9SVySjYl/qzjWF49jhn02Gfw+r0vrXVdN2mW49Gx8/DyPeUPP5L8nNw8StzThvX3PPKsi6v+mxorfl32rU5ya/J5v6Xfz2fan8qv4++H7NzzPOzvlKFUml+GaGycrJbk22Wj2Pbhx48c1H5nq+t5uqz9/JVAV9yht5BvRDJ909fBfdLS0W1Q+WRudksV4K6KFUVmmke8/wANPS+FbkWcxnWwcaJxmlJHg2jo+nusuX4PFsxsPIthXYtNRaJVxuq7f+IXqd8h1BPjsWz/AIFE5QSi/GjySUmtJGXyWddn5lmVkScpze22Yr0/KC+e6q86IslpLW9ku+1NsxLJd0mDH7WgANAAAAAAAAAAAAAAAAAAAAAAAAL6pdsvcyU9mGZFEm1r7BLF8lryv9Sv7DWy1eHphnzFS+uudklGuLk37JGRxOI87kKcVNp2TUUfRfp56T8VxuFVy3OXV/Sce5fVjpPQt0THbzP049LeX6n3N411cO1NPs3vyab1K6LzOkeUnjXQn2xn2puOt+D6On6ndNcBymPxHB1YyX1PpuVc/dHPfxG4tfL9O4vLRrXfY5TbX7MzLdtXGafL1q7lstqn/aybWlpkNkGn3I0ku0oLa57X5Lys2aUAARUoV/1KAXxg5ewdc17xYhJxaMym6qS1NL/ULJtgFUbP+Wpt/oa/0I58fP8At3/sXS+2sBgyZYVsf7W/9CKdFkX5iyJpGwmVcX8rRRoINhBFVrYAo/cmgoeN6JoVUyflpBdMIqkza14lMv7kZFeFR+GXTUwrSdk37RbL4UWy/sZv44tMfaKL41Vr2SHtX2NJXgWTflNf6GXTxmtOX/2NnGKXsitku2Df2LpqYRo+QrhV+laK8FS7c6t69pEHI2d970/Gzc9K0dvdfNeIrZw58vbha9npvD+bqscfhveZz1g4MIwepaMTE6ggsFubXf2/LNF1Hmu/JlBP9KZqodzaitnm4+lxuE9z7XW+v8vH1OX4r2k0zuU5K3Ltb7nrZBi5l+PJSjZIkrwZzhvT/wBiO7Esr/tbPXOOSa0/OZ9TzZcn5bbtm5PM330fTcpe2vc1a3OX5ZRpp+Voy+OodlqbXhMuGEx7RObqOXqMpeS7bPiaOytSa86NgWVxUIJLwXbOsJNKMog2Wt6W9lFLXFR/UaPkZQlY1FL3MzkspKPbF+TWb3uUnsxa5534RtJe5YXS8soRzUKhlAKgoCiqKSait7G9ENjcpdqMtSKpfUs38GRVXKclCC234SI649qMvjroUZdds0movYLXfYXpdyeT0vLmYV29sau/Xaee5lFmNk2UWRcZQemmfUXo36gcPyXCvpzKjSnbFVLukeX+t3QmVxnMWchiY83j3Sc04x8aJL37rce248oRX/UrOEq5ds4tP8lj8GqzCT8pFUi1Lb2Sa1Ft+CNX6RZE0o6+TGL7XubLA0AAAAAAAAAAAAAAAAAAAAAAAAAAAX1y7ZFgAzE9raLZL5+xZjzX9LJpfOgze1S8fk2YuVVlVtqUJdy0dtyPqX1Bn8TVxiyb1CKcdbRwUHraaJcaxV5ELGtpPZDw6fpfh+cyOfwsyzEvnCdqfe17nv3q7qn01wK7l2z+nJaf+prvRjrLpKXDU43J4+JG7Hr/AKpye29nI+v3XeNy+R/h3Gyh/L1Taj2S2taJ3tXtI8Ws05vRa/bRX4KP3NsIZJwlv4Jovcd7LZJS8Ee5Vy/BGvMTApGSkvBUrIAAgVKACWq+db8SZm0cg9pSNaCrLY6KnJpsXlovlXTZ7JHOwnKL8SJ68yyD92y7bmf228sKp/CIrOOg14SIaeS9u7/7mXXm1y+Uh2a/WsOfGv42Qz4+xe2/9jcxyKn/AHIuThL2aY1D2xoJYdy+GWujIT8RkdF2L5iHCH+VD2p7I0EIZUfiRNW8pP2kbnth/lQ7Yf5UNL7Wug8p+/cTwjd422Zekvgtk0vkul0Q2l5Ic+ztpf7E2/ya/l56gkL4LdRqJfrtf5ZvYZcMbjOyEl3SjpmhXvsuc5S8N7OGeHv06dL1V6f3XHzZpSyUrLHJ+7NhxuL3NSkiPAxHZJSkvBuqq1CKSOsjjjLbuqxgorSRSdcZrTRIDbbBtwISltJE+PRGleETsfBNJqBTZRvSLe7ZVVkzEzchVwaT8l+Veq4N78moslK+3fnWzNrOWWlr7rpuT3ojmtS7UT2zUI9sfcij4Tk/cy5LJJRX5LCspbbLQgAVAoVCRHbPX6ULVk2pbP4RWuOlv5Fdb/qkSeEiNW6XU1WXWRqqi5Sk9JI9I6I9KeZ5pV5GTj3UY8tPucPGjjOk83FwOYoycuuM64TTak/DR6zzvrNGvhq8HhqFR2wcd1zFt+Emvl6D0b0F0p0tlY+Rk8ljfzMWn2yWntHfeqV/TFnQ0rsj+Wk447dbb9z40y+suczOThlX59zUZb7W0bTqbr/kuW4evjpXWdkYOD8+5m41uZRzfU1lF3MXyxVFVd/6e320ap+fBWUn+7ZSKf8AuaZ8d10ERZE2v0pkk32xbMSTcntgxnyoAA0AAAAAAAAAAAAAAAAAAAAAAAAuhHuei6dTj7eSlUu2RkqSYS3TDfgGVZXGS8eGY8oNP2CqJ6ezKqkpQXnyYhdXJxkEs2ytbKe3hlYva2Un9wzPpNjZN2O39Gxw376LbrbLpudknKT92yKL+5d7sqXsqvPj5PWPRn0zv6om8jKplHGUVLucdrWzW+kfp7kdV8lW9T+kmnL9O1rZ7n1n1Hx3pj03/g2Aq1lKDqk4vT37mbfiNYz5rwr1n6QwumeWnTh3wmlZrUVrXg83nHuibzqrqHP5/kLMrLunPvltKTNP9OfbvtevuWJvuxk3Bk0JbRScdkSbg/wF8p34Ai01sF2zZoKlAEAAAAAFS5Sa9mWFUBIrbF/cyWvLuh7SbMbZdFPfhBd1mLPyPtIvWdd8pkMJ6XmsljbD5qRWt37SRy7n/ayRX5EvaEkW15Faf/UonWXHXilFan/lSLyX79xLCFjf6myNZE5PxDRPXKTXnYjUXxWvBquXb7tG3X5MfJx42+5aZTcaCMXL2WzYYOE5alNGbThVw86RlQSj4SJMWccPtbXXGtJJaJA0DTZsqwQX3qHhPyBLKaXgo5JLbMetuS75PRDfe5y+nD/kTabSznKyxRj7bLrrY01+Wt6InONFW213aNdfbPIn7tIm0t0pdZO+3S327EnGqGl7iU41Q7Y6bMac23tmXO1Xubl3MpOWy3YDKgKlABUeERWWfCG1k2utn2+EWVxcpdzKwht7kZOLj2XXQqqg5Sk9JIjVuljfg9d9Fuk+n+ooSo5DIohdJpQUl52cNyPR3L4XFxz7sW6Ncod23HxoxOk+Zz+G5nHyMa+cOyabih8JO17u59YPTDL6XullUU2TxJblGSjpaR5Yopf26Z9j8jmQ6u9J3bm1J2VYj1KXl+Wz5G52mOPy2RTD+mM9ImN2uU0wR7eWgiu9/HgqSD0/OiqWvL9iiIr56XamDzVl8+6Wl7IiADYAAAAAAAAAAAAAAAAAAAAAAAAAABLVPT0yIAZnxsNJr2IarPiRN7+V7BizXhDKrb8EcoOPwZRRpP3Q0syQ0z14ZP7lkq4tePBWtP2b9gXuNae/gqmvdB+RFJDweXqXoj6hPpXlYxvS+lJqLcpaWtnsfXfS/H+p2H/ivHZcHdZuzsrXc/sfJibUtrwzsej/AFD5zpvthjZNzrS12ppLRLPmEy+K7TE9COd/n1G5ZEalLy3X40dR1d0J0x030h2ZF+PLNjW01Jals5LM9dOetx3CCtjJrW1M8+6l6v5nnbZTy8u1qT32yaGrTcnhpMxQWVYoa7d+NEE47Rc229skoouvfbTW5v8ABrTMrEfdB+N6JITUv3Jb6bKpOF0HFr4Zjzg4y3EjXapQRws29PwSF2zYAAIAAAAABfGWvgsAGVXYn7oyq1GX9prE2mSxvnH2bLGpW2rqj8wJ4VRX9hp45tnj3J4Zk5f3MbbmUbVQiv7UV8JGvje9eZl6t+9hrbW4zO4qnsxFfBe80y9ZMfjQ2bZaKmMr4JbckiOzKbeoLf7Da7Zjko+7LXZv2MP6vjc5a/DIZ5EpPtrXj7obTbLvyFHwntsx4p931LH49/JFJxh+qb2/yY9t8rX2p6RNs2sm/Idj7K/C/AjKFEO6TTkYv1I1Lx5Zj2Wym/LJtn3J7rpWzfnwWSmorUSFMo2Rna5tvyy3YfsUCKlS0qvAD5D8LZbOaj8kUrJT8IjUxXTnt6iIV6e2XU1va8bZ0NfSnLT4z/EFjW/RUe7u7fGgu/pokjZ9N5tWBytGTdCMoQmm02a2yLhNwktNe5QM7fWvS3UfSXWfTFfC314lFyq+mn3NvbOZn6E93PQzaciTw/qdzar/AE6Pn3iOXzuKyI3Yd865Re/0nd0esnVFXH/yn8zkNdvbvuRnVnhv3S+XsPqh1JxHSXRi4HAupld9B1y7Xp7PlzPvllZdmRL3m9mXzvN5/M5Ur82+djk9/qNa2taRZNJf2Wve/Ben40USFjUY7Kn+opbJRj4fkxZNt7ZWcnJ7LQ3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmqt14ZCAMz3Wy6qPfJL7mPVP+1k6bj5TDOpL3Zz4y11d8E5L9jBnCUJOMlpm84HkYqSpu04vx5Ztc7iMfJ/4lTS39kea81wy1m+5h6Vh1XDOTpr3+Y4wqdOun4/5v+RfDp+t+8/+Rr+1xuM9C6u/Dldg7Onp/G3+qS/2MuPAceveUP8AYxeswj1Yfxrq8u+5HA7DTPQ4cFxj9nXv9jA53gqIY7nRFeFvwiY9bhbprm/jHU8XHc9y6cUdn6U5nFYvNpcrCqVU5Jf8R+Dj7YOE3F/Aq71NODakvbR6/L853xvd9HdaemfE9S8VLlenbK21F2OFMdnz7zvE5PE59mJlVyhOEtPuWj1b0O6i6ko5ajAVeRfiWyUJLfjWztf4iegq3xcObox/pWWNzmlH8MzvV01ZvvHzFZBa8e5HuUffZkzi4ScX7r3LJRUka0zMlK5qS8sv+CCVbXlFYzcdKSC62lHyIvuW0CxmzQCnyZmFg35M0oQk190iXKY963x8eXJl7cZusQHRT6dtWP3al3a+xpcvEux5NTg1+5jDmxz8V6eo9P6jp5LyY6Y4AOjxKpl0d/csK7Ak/X/nZclP/wCIyHuf3K90vuFZEJJeG9skU2/Yw09PZepsG2Wml5lMqrW/EI7/ACjGjOP9z2XfXjFfpSK1tOq5SfdObS/IsvrqWo6b+5hzvsl8tIjbb9wnu+kllkpvbZb3NexYXEZUk9lCrKACoGgD+BoNrRY7EvyRZNrm1H3LJ2LXj3LH3TfzovrrXz5DWpFkYyk9smjBJFUtI2PTtePby1FeTKKqc0pN+2glu1vT+P8AzfNYuMlv6k0tH0/1Vg4/B+ktEY4kZW24b8/O9sxOiPSjiuRfG8tx1kJ/T1OfZE73rrqXpLjONxuF5b+Uk6YOtqyWjFvduY6j40v4nlcq+y+rj7XCT34Rr76LqJuF9brkvdM+suO6v9M6Yqr+V4xxfjfe/wD8njPrZk9NZmb9bg1jRTbbVT2alZuPZ5cPIS8e5a214RpmTZJ/C9ysV48iMfll/iK2/Yi/6i2UlFeTGsm5P8Fb590vHsRhqTQAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPVZtdrICqensDMhJxkpRemjYVcvk1wUVOXj8mrjZHsXtsopr7mbjMvMb4ubl4b+l0275rK/zS/3Kf4zlf55f7msjKL+UJyivZk/Hh9Ov97qf/nWz/xrL/zy/wBx/jOX/nl/uapWx/AU4v2aH48Po/u9T/8AOt1i83kxuj3Sk1vz5OxwcqvOw9bTbj7Hm6Nx0/yMsa+MJS/S/Hk8/UdPMpvF9n0f1nPi5fx813jTqTBlRlSkovtbN96RYXE5vO/T5adUKu5eZ+xk8nj18hhOyKTet+DipTycDKl9Kcq5J+6NdNye/HV8x5/W+g/rc35Mf8cn1LyXUnQ3ReMnx8cG++K0nGTT2eVeovq9ndRY8sOKlGnyklPa0eWZWblZUt5F8rH+THPTMXxLkusk52Ob92WgqisKFXGL90i76Vmu7sevuWk3trVx8qaS9isYuT1FbZWEXOSjFbbOk4Dhm3G66L17+UY5OScc3Xr6LoeXrOSYYRi8NwtmRKM7ItR9/Y6vGxsPArXd2Jox8/kcbj6nXDtUkte5yfI8tfkTepyS/c8Pt5Oov1H6v8vRejY6x/bN2q5XEdnZ3w1+5Zm4OJn1tw7W39jz5X2qXd3vZtOM5m/HsXdJtb+WXLpLh3wrnxfyTj6i/j6nDtTluGuxptwjJx39jUyjKL1JaZ32LyWHnVqFnZt/dkWRwWNdZ9SDj2734RrDqrj25I49T6Bhz/8AJ0mUsvw4eNc5f0xbMqjjcm3/ALOSX7HXSwuNwobk6219zVchzFFacKIR/dM6TqMs/wDCPJn6Nw9LN9Ryf/UYf+Exrpc7LNNL2aNRclGxqPsmT5GbkXN7nJL7GM9t7Z3wxynfKvkdVycGWpxY6igAOjxgKgCgBVeQKFfge3uHKK+UF0As+rFfYjdjl4SJtfani152yOdi348lqhNry2i6FaXl+QupFjlOXwy6Na158skSWzO4XjreT5GnDpTc7Zdq0ge76YlNM7JKFcHKT9kjo+P6K57LwZ5cOPv+nGPdtR8HtvQfpPg8HhV8x1FNRqcVYldHSaR3/TfWXQ+Rkz6dx8fBX1GqlKMn5M3L6WY/b40zMe3FyJ0XQcZRemmRwcoPui9NezPZv4guhJ8TyEuUw6W8e6TmnGPjR4x+/ualYs09x9APUrK4rlMbisq9umycYfql40b7+J3gI2YlPP49/dG6MrfC8Hzxx2VZhZtWTVJxlXLaaOv6n9QOR5rg6eMyJzlCutwW5E1321Mu2q4qNtuk1Y0UnOcv6ptlqaWkyklv29ipIp3b9i5Iqo+PYOUYJ7a2Dz2ik2ox2Y9lrktfBSyblL38Fgak0AAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACu39w237soAAT0ABPRPfhkybjLaflGHF6ezLgtwUt+4Zv3HWdMcl3QVFsvjXllOp+NUo/Xqj7+fCOaxb5UXRnF60zt+JzKuQw1VPTlo8HNheLP34+H6703qMPUenvS83+U8OCknGWmtMrGEpPUU2dXmdNSsypWRk1Df2MijjMHDinbODa+52vV4a7Pm4/x7qffZn2k+a5nC4zKyJpfSkl99HQYHT1cNSvev3RLlc3h4sOymuva8bTNNl8/fa32tpfhnO3m5fHaPZhx+mdB/nffk6n/AA/jPp/T769+xquQ6fhPcsfz+yOc/wARyfqd/wBWXubTj+oLatKzcl+WZ/By4d8bt1/6r6d1f6cvH7Z9s7ieCVU/qXr2+6MzluSpw6HVU47S14ZrM/qN2VuNSS/ZnPZGRZfY5Tk3suHDnyX3cjPUeqdN0XFeLo/N+V2blWZNrlKTe2Y5V+4Sb0kttnukkmo/KZ55Z5XLK9wHpXpr6Vcr1dRO6uF0IKKknGG9+Tm/UHpLJ6T5azByO9uM+3clr4LtnVc7TfZVJOEmtGxp53Lrr7O6T8fc1IMZceOXmPRw9XzcP/bysZeTn5GQ33Tl5MScteZe5dF6ZS5KfsWSTtHPPky5LvO7Ru2PxoqrI/dFqrRR079is9l/1I/dD6kfuiz6D+7KfS0wvZI7I/gp9VFPprXsIVr5CdiVi+CinNPxFkjhH3WiqS+wNxDKU5P2aLo1Sa25MzsTj8vKjKWPjSsUfdpexDbXZTY67IuMl4aYPch+kisYpfBczYcJxGZy+SqMSmdkm9fpRU3awYxc5KEY7b9kb+rpHmZ8a894dypUe7u7fGhyHTvK8Fl125mFbGEZbfctH0l0fDC5v0mujVi1/VrxPLXl72Zt0sm3ydbCVdsq5LTi/JtukM//AA7qLCyn7V2qTIuqMd4vO5dLjpxnrX+hroycZKSemi+WfD6965zb+pPSii3BulF1YknJQ8/LPlnA5HN4bqCOQrZq2mzbfzs6fhvUjPwOnrOJfdOudfZ/UcNyGQ8rMsyGtOb2STTWV2+senOoOA619PbaOZyqI5FOPqPe9vbZ8xda4mNhdQ5VGHOM6o2ai4+2tGFhctyWHVKvGzLK4S8NIw77rLrXbbY5zk9tsSaS3aiKSevYpt/BVIprS3t29svSKrx7kVlqW1EHeq2WqPhe5jzk5Pyyje3soGpNAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE1E3/SQlYvT2BlmdxWfPDt7k/BgRfdFMEuMymqcXLnw5zPC6sdFl9R3zjqttfszUZHIZNzblZLyYhctfcxjxYY+I9XP6j1PUf55VSTcnuT2ysYPWw15KuT7dHR4fN7rQWva8lYtP3G10qACspMai3IujVTBznJ6SR7H6U+kuZyFtfI8tVZTix1NucPGjnPR7J4HG5WF3LqhqEk19Q9M9TfV/Bx+K/wvp2FVUdOHdTP4M3bck816FxXWvTXSHJ4nAcZ/LOTmqpSjLT+5wH8UfCV5mLTzdEd/Wk5tpfhnhGDzeZZ1HRyF905zVql5Z9Q8hhz6s9JI5Dg5ypxHL7/ACZ1qtS+6afIKTSW/cGZy2NLF5G6iS04S1oxGdHJQAAVSKlEVAqvMfctKuaXgEWzspooVYRUUOy9Peh+R6n5CqNVNv0e5d0lHa0caehdC+oNnTPH2U0VL6jhpS7tNEu/hY9/6b6c6G6QwK8Pl54c8i2PbL6q00zkPVH0mxeVxp8z0yvrQmnNRphtHi/N9Tc51LzKn/MXOc57jFPej6d9LMvO6c9PpZ3OynKtY3dGNvhPTMXc7uksvZ8lc3w3IcRkyozseyqUXr9SNz6c9R1dPcrDIupjZHvT/U9Gf6udTY3UPUGRbi0QrgrG12vfwcMjfmOfi9n1pxXU/QnWXFrFz6sGi+cdJuTb2zsvTzpTCwcTOoxMxW4l0UopLwkfEWLm5eJZGePfKtr20dv096q9ScTj/RjlXzWtf1IzcW5nPlb668RHi+t8xV+Yyufx+DgX7m56r6gy+oM+WXluTnKXd5ezT7WjU7MXvVNb+A1peS3ue9IuflaY2uvtRvx4RSKbfkuitLRckktt6Bv6NePCLJTUfctsvSbUTHlJye2Fk+0llrl7EQAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLTZ2+H7Eqthp+xigGkk7W348FvdL7stAEsLWvD8ksbIyXwYpVNr2CWbZfv8DtWyCu1x8MmVsGl7bCas8DT34LnKKhrXkaT+diUfugm/shbKHmE3F/grOcpvulJyf3LHEppr9galSUzddsZr+17PVulfVnK4rpq3h5Q3XOn6fmf5PJU9fBWL29NDySWeGfzuYs/krcqMUvqS34MFlXpL3LUyxAFfkNDaCKlUWWTSiyLJtFZLU1+5NB7RiSe3slpnrww3Z2ThD38oow5nyULvgtfgo7f0ly+Jw+oKbuUVTrhYn+t+D0n1p9S8PO4SvieHnXCmMHDVcvGjwGFjg9xlplbLZz8zm5fuSyNS3SkpOUnKXlv3YS+xapL7FE38DZ7VzaQUi3tbe2XpJIHaLZbfsIr7su0V/Sk25IG6tjHb8eS5rW9+CKV6i/0oistlN73oLr7SztS8IhlZKXyWANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvjZKL3slV+/dGOAMuNkZPW0i9peyezCTa9i5WST9wntZXb+CjX+hCr2iSF0dfq0E1Yu7fHuUS0w7It+GVTTW9g7mtFfAT387DQZWWNpfpRjyct+TL0WWQUl7eQ1KxQisk09Mlph8tBpWpz9vJPpa/JboqGLdnuWy3ou7X7lrf5BBRTiVS0U74r5RdC2tJ70wvc1+AkR2Xr+1Iidsge1ltRS22RStivbRjucn7stC6iadzfheCNyk/dloCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK7HdL7lABfGyUSWNyfuY4AzU1JbTD9kYtc3F/gyYyTQYsRWRbmnrxslj4SWi5JSXt7FPYF8BZOyMfsyy6z4iQMLImlfJrRG5yfyWgNK7f3KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlpl50RFYvUkwMyLaKWeIN/crXqUd70Q5E/wC1fAZk7oX5ZQANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC5Skl4bKN79ygAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q==' style='width:18px;height:18px;vertical-align:middle;margin-right:5px;'> Zoan-Task | discord.gg/zoan")
;neutron := NeutronWindow(html, css, js, "✨ Zoan-Task")
	.OnEvent("Close", (*) => ExitAppF())
	;.Show("w380 h450", "Template")
    .Show("Hide")

    /*
hIcon := DllCall("LoadImage", "Ptr", 0, "Str", A_ScriptDir "\Images\logo.ico",
    "UInt", 1, "Int", 0, "Int", 0, "UInt", 0x10, "Ptr")


; WM_SETICON = 0x80
DllCall("SendMessage", "Ptr", neutron.hwnd, "UInt", 0x80, "Ptr", 0, "Ptr", hIcon)
DllCall("SendMessage", "Ptr", neutron.hwnd, "UInt", 0x80, "Ptr", 1, "Ptr", hIcon)*/

WinSetAlwaysOnTop(true, neutron.hwnd)

updateGeneralSetting(neutron, event) {
    elementId := event.target.id
    value := Trim(event.target.value)
    
    if (elementId = "setting-webhook") {
        global webhookValue := value
        SaveGeneralSettings()
        neutron.doc.getElementById("settings-message").innerText := "Webhook URL updated"
    } else if (elementId = "setting-speed") {
        if (value = "" || !IsNumber(value) || Float(value) <= 0) {
            neutron.doc.getElementById("settings-message").innerText := "Speed must be a positive number"
            return
        }
        global speedValue := Float(value)
        SaveGeneralSettings()
        neutron.doc.getElementById("settings-message").innerText := "Speed updated to " . value
    } else if (elementId = "setting-clickdelay") {
        if (value = "" || !IsNumber(value) || Float(value) <= 0) {
            neutron.doc.getElementById("settings-message").innerText := "Auto Click Interval must be a positive number"
            return
        }
        global clickDelay := Float(value)
        SaveGeneralSettings()
        neutron.doc.getElementById("settings-message").innerText := "Auto Click Interval updated to " . value . " ms"
    } else if (elementId = "setting-guiupdatethrottle") {
        if (value = "" || !IsNumber(value) || Integer(value) <= 0) {
            neutron.doc.getElementById("settings-message").innerText := "GUI Update Throttle must be a positive integer"
            return
        }
        global guiUpdateThrottle := Integer(value)
        SaveGeneralSettings()
        neutron.doc.getElementById("settings-message").innerText := "GUI Update Throttle updated to " . value
    } else if (elementId = "setting-record-relative") {
        ; checkbox uses checked instead of value
        checked := !!event.target.checked
        global recordRelativeToWindow := checked
        SaveGeneralSettings()
        if checked
            neutron.doc.getElementById("settings-message").innerText := "Record Relative To Window enabled"
        else
            neutron.doc.getElementById("settings-message").innerText := "Record Relative To Window disabled"
    }
}

SaveGeneralSettings() {
    global webhookValue, speedValue, clickDelay, hideSessionInfo, startMinimalistic, startIconOnly, guiUpdateThrottle, recordRelativeToWindow
    settingsFile := A_ScriptDir "\..\..\Settings.txt"
    
    try {
        content := "# Zoan-Task General Settings`n"
        content .= "Webhook=" . webhookValue . "`n"
        content .= "Speed=" . speedValue . "`n"
        content .= "ClickDelay=" . clickDelay . "`n"
        content .= "GuiUpdateThrottle=" . guiUpdateThrottle . "`n"
        content .= "RecordRelativeToWindow=" . (recordRelativeToWindow ? "true" : "false") . "`n"
        content .= "HideSessionInfo=" . (hideSessionInfo ? "true" : "false") . "`n"
        content .= "StartMinimalistic=" . (startMinimalistic ? "true" : "false") . "`n"
        content .= "StartIconOnly=" . (startIconOnly ? "true" : "false") . "`n"
        
        if FileExist(settingsFile)
            FileDelete(settingsFile)
        
        FileAppend(content, settingsFile)
    } catch as err {
    }
}

UpdateGeneralSettingsDisplay() {
    global webhookValue, speedValue, clickDelay, hideSessionInfo, startMinimalistic, startIconOnly, guiUpdateThrottle, recordRelativeToWindow
    
    webhookElement := neutron.doc.getElementById("setting-webhook")
    speedElement := neutron.doc.getElementById("setting-speed")
    clickDelayElement := neutron.doc.getElementById("setting-clickdelay")
    guiUpdateThrottleElement := neutron.doc.getElementById("setting-guiupdatethrottle")
    recordRelativeElement := neutron.doc.getElementById("setting-record-relative")
    hideSessionInfoElement := neutron.doc.getElementById("hide-session-info")
    startMinimalisticElement := neutron.doc.getElementById("start-minimalistic")
    startIconOnlyElement := neutron.doc.getElementById("start-icon-only")
    
    if (webhookElement)
        webhookElement.value := webhookValue
    
    if (speedElement)
        speedElement.value := speedValue
        
    if (clickDelayElement)
        clickDelayElement.value := clickDelay
        
    if (guiUpdateThrottleElement)
        guiUpdateThrottleElement.value := guiUpdateThrottle
        
    if (recordRelativeElement)
        recordRelativeElement.checked := recordRelativeToWindow
        
    if (hideSessionInfoElement)
        hideSessionInfoElement.checked := hideSessionInfo
        
    if (startMinimalisticElement)
        startMinimalisticElement.checked := startMinimalistic
        
    if (startIconOnlyElement)
        startIconOnlyElement.checked := startIconOnly
}

class SimpleBuffer {
    __New(ptr := 0, size := 0) {
        if !ptr
            this.ptr := DllCall("msvcrt\malloc", "ptr", size, "ptr")
        else this.ptr := ptr
        this.size := size
        this.own := !ptr
    }

    realloc(size) {
        if !this.own
            return 0    
        this.ptr := DllCall("msvcrt\realloc", "ptr", this.ptr, "ptr", size, "ptr")
        this.size := size
        return this.ptr
    }

    __Delete() {
        if this.own && this.ptr
            DllCall("msvcrt\free", "ptr", this.ptr)
    }
}

class BaseFlags {
    __New(flags) {
        this.flags := flags
    }

    IS_FLAG(flagName) => ((this.flags & this.%flagName%) != 0)
    SET_FLAG(flagName, enabled) => (this.flags := ((this.flags & ~this.%flagName%) | (!!enabled << Integer(Log(this.%flagName%) / Log(2)))))
}

class MSLLHOOKSTRUCT extends SimpleBuffer {
    __New(ptr := 0) => (super.__New(ptr, 20+A_PtrSize))

    ptX {
        get => NumGet(this, 0, "int")
        set => NumPut("int", value, this, 0)
    }

    ptY {
        get => NumGet(this, 4, "int")
        set => NumPut("int", value, this, 4)
    }

    mouseData {
        get => NumGet(this, 8, "uint")
        set => NumPut("uint", value, this, 8)
    }

    flags[flagName?] {
        get {
            flags := GetStaticThis(this).flags(NumGet(this, 12, "uint"))
            if IsSet(flagName)
                if flags.HasProp(flagName)
                    return flags.IS_FLAG(flagName)
                else return false
            else return flags
        }
    }

    class flags extends BaseFlags {
        LLMHF_INJECTED := (1 << 0)
        LLMHF_LOWER_IL_INJECTED := (1 << 1)
    }

    time {
        get => NumGet(this, 16, "uint")
        set => NumPut("uint", value, this, 16)
    }

    dwExtraInfo {
        get => NumGet(this, 20, "ptr")
        set => NumPut("ptr", value, this, 20)
    }
}

class KBDLLHOOKSTRUCT extends SimpleBuffer {
    __New(ptr := 0) => (super.__New(ptr, 16+A_PtrSize))

    vkCode {
        get => NumGet(this, 0, "uint")
        set => NumPut("uint", value, this, 0)
    }

    scanCode {
        get => NumGet(this, 4, "uint")
        set => NumPut("uint", value, this, 4)
    }

    flags[flagName?] {
        get {
            flags := GetStaticThis(this).flags(NumGet(this, 12, "uint"))
            if IsSet(flagName)
                if flags.HasProp(flagName)
                    return flags.IS_FLAG(flagName)
                else return false
            else return flags
        }
    }

    class flags extends BaseFlags {
        LLKHF_EXTENDED := (1 << 0)
        LLKHF_LOWER_IL_INJECTED := (1 << 1)
        LLKHF_INJECTED := (1 << 4)
        LLKHF_ALTDOWN := (1 << 5)
        LLKHF_UP := (1 << 7)
    }

    time {
        get => NumGet(this, 12, "uint")
        set => NumPut("uint", value, this, 12)
    }

    dwExtraInfo {
        get => NumGet(this, 16, "ptr")
        set => NumPut("ptr", value, this, 16)
    }
}

class MouseHook {
    __New(callback) {
        this.pCallback := CallbackCreate((nCode, wParam, lParam) => callback(this, nCode, wParam, lParam))
        this.hHook := 0
    }

    __Delete() {
        this.Stop()
        CallbackFree(this.pCallback)
    }

    Start() {
        if !this.hHook
            this.hHook := DllCall("SetWindowsHookEx", "int", 14, "ptr", this.pCallback, "ptr", 0, "uint", 0, "ptr")
    }

    Stop() {
        if this.hHook
            DllCall("UnhookWindowsHookEx", "ptr", this.hHook)
        this.hHook := 0
    }

    Next(nCode, wParam, lParam) => (DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam))

}

class KeybdHook {
    __New(callback) {
        this.pCallback := CallbackCreate((nCode, wParam, lParam) => callback(this, nCode, wParam, lParam))
        this.hHook := 0
    }

    __Delete() {
        this.Stop()
        CallbackFree(this.pCallback)
    }

    Start() {
        if !this.hHook
            this.hHook := DllCall("SetWindowsHookEx", "int", 13, "ptr", this.pCallback, "ptr", 0, "uint", 0, "ptr")
    }

    Stop() {
        if this.hHook
            DllCall("UnhookWindowsHookEx", "ptr", this.hHook)
        this.hHook := 0
    }

    Next(nCode, wParam, lParam) => (DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam))
}

GetStaticThis(this) {
    TypeName := (this.HasProp("Prototype") ? this.Prototype.__Class : this.__Class)
    parts := StrSplit(TypeName, ".")
    static_this := 0

    for part in parts
        static_this := static_this ? static_this.%part% : %part%

    return static_this
}

#Requires AutoHotkey v2.0 

NANOTIME_NSEC_PER_SEC := 1000000000
SECOND := NANOTIME_NSEC_PER_SEC
MILLISECOND := SECOND // 1000
MICROSECOND := MILLISECOND // 1000
NANOSECOND := MICROSECOND // 1000

nanotime_hKernel32 := DllCall("GetModuleHandleW", "Str", "kernel32.dll", "Ptr")

class nanotime_step_data {
    __New() {
        this.sleep_duration := 0
        this.now_max := 0
        this.now := (this) => (0)
        this.sleep := (this, nsec_count) => ("")

        this.zero_sleep_duration := 0
        this.accumulator := 0
        this.sleep_point := 0
    }
}

nanotime_now() {
    static scale := 0
    static multiply := false

    static _QueryPerformanceCounter := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "QueryPerformanceCounter", "Ptr")

    if scale == 0 {
        DllCall("kernel32\QueryPerformanceFrequency", "Int64*", &freq := 0)
        if freq < NANOTIME_NSEC_PER_SEC {
            scale := NANOTIME_NSEC_PER_SEC // freq
            multiply := true
        } else {
            scale := freq // NANOTIME_NSEC_PER_SEC
            multiply := false
        }
    }

    DllCall(_QueryPerformanceCounter, "Int64*", &performanceCount := 0)
    if multiply
        return performanceCount * scale
    else return performanceCount // scale
}

nanotime_now_max() {
    static UINT64_MAX := 2 ** 63 - 1
    static now_max := 0

    if now_max == 0 {
        DllCall("kernel32\QueryPerformanceFrequency", "Int64*", &freq := 0)
        if freq < NANOTIME_NSEC_PER_SEC {
            now_max := UINT64_MAX
            ; could use a float for more precision
            ; like this:
            ; now_max := UINT64_MAX * (NANOTIME_NSEC_PER_SEC / freq)
        } else {
            now_max := UINT64_MAX // (freq // NANOTIME_NSEC_PER_SEC)
        }
    }
    return now_max
}

nanotime_sleep(nsec_count) {
    dueTime := 0
    static supports_high_resolution := VerCompare(A_OSVersion, "10.0.17134") >= 0

    static _CreateWaitableTimerExW := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "CreateWaitableTimerExW", "Ptr")
    static _CreateWaitableTimerW   := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "CreateWaitableTimerW", "Ptr")
    static _SetWaitableTimer       := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "SetWaitableTimer", "Ptr")
    static _WaitForSingleObject    := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "WaitForSingleObject", "Ptr")
    static _CloseHandle            := DllCall("GetProcAddress", "Ptr", nanotime_hKernel32, "AStr", "CloseHandle", "Ptr")

    if nsec_count < 100 {
        Sleep(0)
    } else {
        timer := 0
        if supports_high_resolution {
            timer := DllCall(_CreateWaitableTimerExW, "Ptr", 0, "Ptr", 0, "UInt", 0x00000002, "UInt", 0x1F0003, "Ptr")
        }
        if !timer
            timer := DllCall(_CreateWaitableTimerW, "Ptr", 0, "Int", true, "Ptr", 0, "Ptr")
        if !timer
            return

        dueTime := -(nsec_count // 100)

        DllCall(_SetWaitableTimer, "Ptr", timer, "int64*", &dueTime, "Int", 0, "Ptr", 0, "Ptr", 0, "Int", false)
        ;start := A_TickCount

        while true {
            result := DllCall(_WaitForSingleObject, "Ptr", timer, "UInt", 50) ; 50ms timeout
            if (result == 0)
                break
            else if (result == 0x102)
                Sleep(0)
            else
                break
        }

        ;OutputDebug("Waited for : " . (A_TickCount - start) . " ms - Actual: " timer)
        DllCall(_CloseHandle, "Ptr", timer)
    }
}

nanotime_yield() {
    (0)
}

nanotime_interval(start, end, max) {
    if max < 0
        return 0
    if start > max
        return 0
    if end > max
        return 0
    
    if end >= start {
        return end - start
    } else {
        return end + (max - start) + 1
    }
}

nanotime_step_init(stepper, sleep_duration, now_max, now, sleep) {
    if !(stepper is nanotime_step_data)
        return 
    if sleep_duration <= 0
        return
    if now_max <= 0
        return
    if !(now is Func)
        return 
    if !(sleep is Func)
        return

    stepper.sleep_duration := sleep_duration
    stepper.now_max := now_max
    stepper.now := (this) => (now())
    stepper.sleep := (this, nsec_count) => (sleep(nsec_count))

    start := now()
    sleep(0)
    stepper.zero_sleep_duration := nanotime_interval(start, now(), now_max)
    stepper.accumulator := 0

    stepper.sleep_point := now()
}

nanotime_step(stepper) {
    if !(stepper is nanotime_step_data)
        return false
    
    start_point := stepper.now()

    if (nanotime_interval(stepper.sleep_point, start_point, stepper.now_max) >= stepper.sleep_duration + NANOTIME_NSEC_PER_SEC // 10) {
        stepper.sleep_point := start_point
        stepper.accumulator := 0
    }

    slept := false

    if (stepper.accumulator < stepper.sleep_duration) {
        total_sleep_duration := stepper.sleep_duration - stepper.accumulator
        current_sleep_duration := stepper.zero_sleep_duration
        shift := 4

        {
            max := NANOTIME_NSEC_PER_SEC // 1000
            start := stepper.now()
            while (nanotime_interval(stepper.sleep_point, start, stepper.now_max) + max < total_sleep_duration) {
                stepper.sleep(NANOTIME_NSEC_PER_SEC // 1000)
                next := stepper.now()
                current_interval := nanotime_interval(start, next, stepper.now_max)
                if (current_interval > max) {
                    max := current_interval
                }
                start := next
            }

            initial_duration := nanotime_interval(start_point, stepper.now(), stepper.now_max)
            if (initial_duration < total_sleep_duration) {
                current_sleep_duration -= initial_duration
            } else goto step_end
        }

            current_sleep_duration >>= shift
            max := stepper.zero_sleep_duration
            while (nanotime_interval(stepper.sleep_point, stepper.now(), stepper.now_max) + max < total_sleep_duration && current_sleep_duration > 0) {
                max := stepper.zero_sleep_duration

                while (max < stepper.sleep_duration && nanotime_interval(stepper.sleep_point, start := stepper.now(), stepper.now_max) + max < total_sleep_duration) {
                    stepper.sleep(current_sleep_duration)
                    if ((slept_duration := nanotime_interval(start, stepper.now(), stepper.now_max)) > max)
                        max := slept_duration
                }

                current_sleep_duration >>= shift
            }

            if (nanotime_interval(stepper.sleep_point, stepper.now(), stepper.now_max) >= total_sleep_duration)
                goto step_end

        {
            max := stepper.zero_sleep_duration
            while (nanotime_interval(stepper.sleep_point, stepper.now(), stepper.now_max) + max < stepper.sleep_duration) {
                stepper.sleep(0)
                if ((stepper.zero_sleep_duration := nanotime_interval(stepper.sleep_point, stepper.now(), stepper.now_max)) > max)
                    max := stepper.zero_sleep_duration
            }
        }

        step_end:
        {
            while ((accumulated := nanotime_interval(stepper.sleep_point, current_time := stepper.now(), stepper.now_max)) < stepper.sleep_duration) {
            }
            
            stepper.accumulator += accumulated
            stepper.sleep_point := current_time
            slept := true
        }
    } else slept := false
    stepper.accumulator -= stepper.sleep_duration

    return slept
}

; negative deviation = ahead of schedule
; positive deviation = behind schedule
nanotime_adjust(stepper, deviation) {
    if !(stepper is nanotime_step_data)
        return

    stepper.sleep_point -= deviation
}

#SingleInstance Force

;CoordMode("Mouse", "Screen")

; Initialize GDI+
if !(pToken := Gdip_Startup()) {
    MsgBox("GDI+ failed to start. Please ensure you have GDI+ on your system.", "GDI+ Error", 48)
    ExitApp
}

global lineStartX, lineStartY, snappedX, snappedY
global Width         := A_ScreenWidth
global Height        := A_ScreenHeight
global drawMode      := "freehand" 
global primary       := Color("0xFF000000")
global secondary     := Color("0xFFFFFFFF")
global penWidth      := 3
global snapAngle     := 5
global polygonSides  := 5
global rotationAngle := 0
global isDrawing     := false
global eraserMode    := false
global fillShapes    := false
global perfectRatio  := false
global allPoints     := []

/*
Hotkey("Escape", ClearScreen)
Hotkey("Delete", ClearScreen)
Hotkey("F1", (*) => drawModeDropdown.Choose(1))  ; Freehand
Hotkey("F2", (*) => drawModeDropdown.Choose(2))  ; Line
Hotkey("F3", (*) => drawModeDropdown.Choose(3))  ; Rectangle
Hotkey("F4", (*) => drawModeDropdown.Choose(4))  ; Ellipse
Hotkey("F5", (*) => drawModeDropdown.Choose(5))  ; Polygon
Hotkey("F6", (*) => drawModeDropdown.Choose(6))  ; Eraser*/

MainGui := Gui("-Caption +AlwaysOnTop +Border", "Draw Menu")
MainGui.BackColor := "0x1E1E1E"
MainGui.MarginX := 5
MainGui.MarginY := 5

titleText := MainGui.Add("Text", "x5 y5 w120 h15 c0xFFFFFF", "Draw Menu")
titleText.Font := "s9 Bold"
titleText.OnEvent("Click", StartDragMain)
closeBtn := MainGui.Add("Button", "x160 y3 w20 h18 c0xFFFFFF Background0x333333", "✕")
closeBtn.OnEvent("Click", (*) => CloseApp())
closeBtn.Font := "s7"

primaryBox := MainGui.Add("Picture", "x5 y25 w25 h25 +Border")
primaryBox.Value := "HBITMAP:" . CreateColorBitmap(primary, 25, 25)
primaryBox.OnEvent("Click", ShowColorPalette)

drawModeDropdown := MainGui.Add("DropDownList", "x35 y25 w70", ["Freehand", "Line", "Rectangle", "Ellipse", "Polygon", "Eraser"])
drawModeDropdown.Choose(1)
drawModeDropdown.OnEvent("Change", UpdateDrawMode)

MainGui.Add("Text", "x110 y28 w20 c0xCCCCCC", "Size:").Font := "s8"
thicknessEdit := MainGui.Add("Edit", "x130 y25 w25 Center", penWidth)
thicknessEdit.OnEvent("Change", UpdateThicknessEdit)

clearBtn := MainGui.Add("Button", "x160 y25 w20 h25 c0xFFFFFF Background0x333333", "⌫")
clearBtn.OnEvent("Click", ClearScreen)
clearBtn.Font := "s8"

MainGui.Add("Text", "x5 y55 w175 h12 c0x888888 Center", "Ctrl + Left Click to draw").Font := "s7"

CreateColorBitmap(color, width, height) {
    hdc := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
    hbm := DllCall("CreateCompatibleBitmap", "ptr", DllCall("GetDC", "ptr", 0, "ptr"), "int", width, "int", height, "ptr")
    obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
    
    brush := DllCall("CreateSolidBrush", "uint", color.ToInt(3), "ptr")
    rect := Buffer(16, 0)
    NumPut("int", 0, rect, 0)      ; left
    NumPut("int", 0, rect, 4)      ; top  
    NumPut("int", width, rect, 8)  ; right
    NumPut("int", height, rect, 12) ; bottom
    DllCall("FillRect", "ptr", hdc, "ptr", rect, "ptr", brush)
    DllCall("DeleteObject", "ptr", brush)
    
    DllCall("SelectObject", "ptr", hdc, "ptr", obm)
    DllCall("DeleteDC", "ptr", hdc)
    
    return hbm
}

MainGui.OnEvent("Close", (*) => CloseApp())

CanvasGui := Gui("-Caption +E0x80000 +E0x20 +LastFound +AlwaysOnTop +ToolWindow +OwnDialogs")
CanvasGui.Show("x0 y0 w" . Width . " h" . Height . " NA")
hwnd1 := WinExist()

hbm := CreateDIBSection(Width, Height)
hdc := CreateCompatibleDC()
obm := SelectObject(hdc, hbm)
G := Gdip_GraphicsFromHDC(hdc)
Gdip_SetSmoothingMode(G, 5)

global tempHwnd, tempHdc, tempHbm, tempG
InitializeTempWindow()

UpdateLayeredWindow(hwnd1, hdc, 0, 0, Width, Height)

Hotkey("*^LButton", StartDrawing)
Hotkey("*^LButton Up", StopDrawing)

StartDrawing(*)
{
    global isDrawing := true
    MouseGetPos(&xStart, &yStart)

    if eraserMode
    {
        global allPoints := []
    }
    else
    {
        global allPoints := [[xStart, yStart]]

        if (drawMode == "line") or (drawMode == "rectangle") or (drawMode == "ellipse") or (drawMode == "polygon")
        {
            global lineStartX := xStart
            global lineStartY := yStart
        }
    }

    SetTimer(Drawing, 1)
}

Drawing()
{
    if (isDrawing and GetKeyState("Ctrl", "P"))
    {
        ; Set the cursor to crosshair
        hCross := DllCall("LoadCursor", "Ptr", 0, "Ptr", 32515)
        for cursorId in [32512, 32513, 32514, 32515, 32516, 32631, 32640, 32641, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650, 32651]
            DllCall("SetSystemCursor", "Ptr", DllCall("CopyImage", "Ptr", hCross, "UInt", 2, "Int", 0, "Int", 0, "UInt", 0), "UInt", cursorId)

        MouseGetPos(&x1, &y1)

        if (perfectRatio and (drawMode == "rectangle" or drawMode == "ellipse") and not eraserMode)
        {
            size := Min(Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            x1 := lineStartX + (x1 > lineStartX ? size : -size)
            y1 := lineStartY + (y1 > lineStartY ? size : -size)
        }

        if (eraserMode)
        {
            eraserSize := penWidth
            if (allPoints.Length == 0)
            {
                allPoints.Push([x1, y1])
            }
            else
            {
                lastPoint := allPoints[allPoints.Length]
                distanceSquared := (x1 - lastPoint[1])**2 + (y1 - lastPoint[2])**2
                if (distanceSquared > 1)
                {
                    allPoints.Push([x1, y1])

                    Loop Max(1, Floor(Sqrt(distanceSquared)))
                    {
                        t := A_Index / Max(1, Floor(Sqrt(distanceSquared)))
                        interpX := lastPoint[1] + (x1 - lastPoint[1]) * t
                        interpY := lastPoint[2] + (y1 - lastPoint[2]) * t

                        pPath := Gdip_CreatePath()
                        Gdip_AddPathEllipse(pPath, interpX - eraserSize/2, interpY - eraserSize/2, eraserSize, eraserSize)
                        Gdip_SetClipPath(G, pPath)
                        Gdip_GraphicsClear(G)
                        Gdip_ResetClip(G)
                        Gdip_DeletePath(pPath)
                    }
                }
            }
            UpdateLayeredWindow(hwnd1, hdc, 0, 0, Width, Height)
        }
        else if (drawMode == "rectangle")
        {
            Gdip_GraphicsClear(tempG)
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())
            
            if (fillShapes)
            {
                Gdip_FillRectangle(tempG, pBrush, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
                Gdip_DrawRectangle(tempG, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            else
            {
                Gdip_DrawRectangle(tempG, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            Gdip_DeletePen(pPen)
            Gdip_DeleteBrush(pBrush)
            UpdateLayeredWindow(tempHwnd, tempHdc, 0, 0, Width, Height)
        }
        else if (drawMode == "ellipse")
        {
            Gdip_GraphicsClear(tempG)
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())
            
            if (fillShapes)
            {
                Gdip_FillEllipse(tempG, pBrush, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
                Gdip_DrawEllipse(tempG, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            else
            {
                Gdip_DrawEllipse(tempG, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            Gdip_DeletePen(pPen)
            Gdip_DeleteBrush(pBrush)
            UpdateLayeredWindow(tempHwnd, tempHdc, 0, 0, Width, Height)
        }
        else if (drawMode == "line")
        {
            Gdip_GraphicsClear(tempG)

            deltaX := x1 - lineStartX
            deltaY := y1 - lineStartY
            if (deltaX == 0) {
                angle := (deltaY >= 0) ? 90 : -90
            } else {
                angle := Atan(deltaY / deltaX) * 57.2957795  
                if (deltaX < 0) {
                    angle += 180
                }
            }
            snappedAngle := Round(angle / snapAngle) * snapAngle

            distance := Sqrt((x1 - lineStartX)**2 + (y1 - lineStartY)**2)
            global snappedX := lineStartX + distance * Cos(snappedAngle * 0.0174532925)
            global snappedY := lineStartY + distance * Sin(snappedAngle * 0.0174532925)

            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            Gdip_DrawLine(tempG, pPen, lineStartX, lineStartY, snappedX, snappedY)
            Gdip_DeletePen(pPen)
            UpdateLayeredWindow(tempHwnd, tempHdc, 0, 0, Width, Height)
        }
        else if (drawMode == "polygon")
        {
            Gdip_GraphicsClear(tempG)
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())

            radius := Sqrt((x1 - lineStartX)**2 + (y1 - lineStartY)**2)
            points := []
            Loop polygonSides {
                angle := (A_Index - 1) * (2 * 3.14159 / polygonSides) - (3.14159 / 2) 
                points.Push([lineStartX + radius * Cos(angle), lineStartY + radius * Sin(angle)])
            }
            points.Push(points[1].Clone()) 

            pointsString := BuildPointString(points)

            if (fillShapes)
            {
                Gdip_FillPolygon(tempG, pBrush, pointsString)
            }
            Gdip_DrawLines(tempG, pPen, pointsString)

            Gdip_DeletePen(pPen)
            Gdip_DeleteBrush(pBrush)
            UpdateLayeredWindow(tempHwnd, tempHdc, 0, 0, Width, Height)
        }
        else  
        {
            if (allPoints.Length == 0)
            {
                allPoints.Push([x1, y1])
            }
            else
            {
                lastPoint := allPoints[allPoints.Length]
                distanceSquared := (x1 - lastPoint[1])**2 + (y1 - lastPoint[2])**2
                if (distanceSquared > 1)
                {
                    allPoints.Push([x1, y1])

                    Loop Max(1, Floor(Sqrt(distanceSquared)))
                    {
                        t := A_Index / Max(1, Floor(Sqrt(distanceSquared)))
                        interpX := lastPoint[1] + (x1 - lastPoint[1]) * t
                        interpY := lastPoint[2] + (y1 - lastPoint[2]) * t

                        pBrush := Gdip_BrushCreateSolid(primary.ToInt())
                        Gdip_FillEllipse(G, pBrush, interpX - penWidth/2, interpY - penWidth/2, penWidth, penWidth)
                        Gdip_DeleteBrush(pBrush)
                    }
                }
            }
            UpdateLayeredWindow(hwnd1, hdc, 0, 0, Width, Height)
        }
    }
}

StopDrawing(*)
{
    global isDrawing := false
    SetTimer(Drawing, 0)

    if (((drawMode == "line") or (drawMode == "rectangle") or (drawMode == "ellipse") or (drawMode == "polygon")) and !eraserMode)
    {
        MouseGetPos(&x1, &y1)

        if (perfectRatio and ((drawMode == "rectangle") or (drawMode == "ellipse")))
        {
            size := Min(Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            x1 := lineStartX + (x1 > lineStartX ? size : -size)
            y1 := lineStartY + (y1 > lineStartY ? size : -size)
        }

        pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
        pBrush := Gdip_BrushCreateSolid(primary.ToInt())

        if (drawMode == "line")
        {
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            Gdip_DrawLine(G, pPen, lineStartX, lineStartY, snappedX, snappedY)
        }
        else if (drawMode == "rectangle")
        {
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())
            
            if (fillShapes)
            {
                Gdip_FillRectangle(G, pBrush, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
                Gdip_DrawRectangle(G, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            else
            {
                Gdip_DrawRectangle(G, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
        }
        else if (drawMode == "ellipse")
        {
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())
            
            if (fillShapes)
            {
                Gdip_FillEllipse(G, pBrush, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
                Gdip_DrawEllipse(G, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
            else
            {
                Gdip_DrawEllipse(G, pPen, Min(lineStartX, x1), Min(lineStartY, y1), Abs(x1 - lineStartX), Abs(y1 - lineStartY))
            }
        }
        else if (drawMode == "polygon")
        {
            pPen := Gdip_CreatePen(primary.ToInt(), penWidth)
            pBrush := Gdip_BrushCreateSolid(primary.ToInt())

            radius := Sqrt((x1 - lineStartX)**2 + (y1 - lineStartY)**2)
            points := []
            Loop polygonSides {
                angle := (A_Index - 1) * (2 * 3.14159 / polygonSides) - (3.14159 / 2)
                points.Push([lineStartX + radius * Cos(angle), lineStartY + radius * Sin(angle)])
            }
            points.Push(points[1].Clone())

            pointsString := BuildPointString(points)

            if (fillShapes)
            {
                Gdip_FillPolygon(G, pBrush, pointsString)
            }
            Gdip_DrawLines(G, pPen, pointsString)
        }

        Gdip_DeletePen(pPen)
        Gdip_DeleteBrush(pBrush)
        UpdateLayeredWindow(hwnd1, hdc, 0, 0, Width, Height)
        Gdip_GraphicsClear(tempG)
        UpdateLayeredWindow(tempHwnd, tempHdc, 0, 0, Width, Height)
    }

    DllCall("SystemParametersInfo", "UInt", 0x57, "UInt", 0, "Ptr", 0, "UInt", 0) 
}

BuildPointString(points)
{
    pointString := ""
    for point in points
        pointString .= point[1] . "," . point[2] . "|"
    return RTrim(pointString, "|")
}

ShowColorPalette(*)
{
    ColorGui := Gui("-Caption +AlwaysOnTop +ToolWindow", "Color Palette")
    ColorGui.BackColor := "0x1E1E1E"

    colorTitle := ColorGui.Add("Text", "x10 y5 w200 h20 c0xFFFFFF", "🎨 Color Palette")
    colorTitle.Font := "s10 Bold"
    colorTitle.OnEvent("Click", StartDragColor)
    colorCloseBtn := ColorGui.Add("Button", "x285 y5 w25 h20 c0xFFFFFF Background0x333333", "✕")
    colorCloseBtn.OnEvent("Click", (*) => ColorGui.Destroy())
    colorCloseBtn.Font := "s8"

    colorSpectrum := [
        Color("0xFF000000"), Color("0xFFFF0000"), Color("0xFFFF8000"), Color("0xFFFFFF00"), Color("0xFF00FF00"), Color("0xFF00FFFF"), Color("0xFF0000FF"), Color("0xFFFF00FF"), Color("0xFF800080"), Color("0xFF8B4513"), Color("0xFFFFFFFF"), Color("0xFF808080"), Color("0xFFFF1493"), Color("0xFF32CD32"),
        Color("0xFF404040"), Color("0xFFFF8080"), Color("0xFFFFC080"), Color("0xFFFFFF80"), Color("0xFF80FF80"), Color("0xFF80FFFF"), Color("0xFF8080FF"), Color("0xFFFF80FF"), Color("0xFFC080C0"), Color("0xFFDEB887"), Color("0xFFF8F8F8"), Color("0xFFC0C0C0"), Color("0xFFFFB6C1"), Color("0xFF98FB98"),
        Color("0xFF202020"), Color("0xFFCC0000"), Color("0xFFCC4000"), Color("0xFFCCCC00"), Color("0xFF00CC00"), Color("0xFF00CCCC"), Color("0xFF0000CC"), Color("0xFFCC00CC"), Color("0xFF4C0080"), Color("0xFF654321"), Color("0xFFE0E0E0"), Color("0xFF606060"), Color("0xFFDC143C"), Color("0xFF006400"),
    ]

    for index, col in colorSpectrum
    {
        x := 10 + Mod(index - 1, 14) * 22
        y := 30 + Floor((index - 1) / 14) * 22
        
        screenDC := DllCall("GetDC", "ptr", 0, "ptr")
        hdc := DllCall("CreateCompatibleDC", "ptr", screenDC, "ptr")
        hbm := DllCall("CreateCompatibleBitmap", "ptr", screenDC, "int", 18, "int", 18, "ptr")
        obm := DllCall("SelectObject", "ptr", hdc, "ptr", hbm, "ptr")
        
        whiteBrush := DllCall("CreateSolidBrush", "uint", 0xFFFFFF, "ptr")
        rect := Buffer(16, 0)
        NumPut("int", 0, rect, 0)    ; left
        NumPut("int", 0, rect, 4)    ; top  
        NumPut("int", 18, rect, 8)   ; right
        NumPut("int", 18, rect, 12)  ; bottom
        DllCall("FillRect", "ptr", hdc, "ptr", rect, "ptr", whiteBrush)
        DllCall("DeleteObject", "ptr", whiteBrush)
        
        colorBrush := DllCall("CreateSolidBrush", "uint", col.ToInt(3), "ptr")
        DllCall("FillRect", "ptr", hdc, "ptr", rect, "ptr", colorBrush)
        DllCall("DeleteObject", "ptr", colorBrush)
        
        DllCall("SelectObject", "ptr", hdc, "ptr", obm)
        DllCall("DeleteDC", "ptr", hdc)
        DllCall("ReleaseDC", "ptr", 0, "ptr", screenDC)
        
        pic := ColorGui.Add("Picture", "x" . x . " y" . y . " w20 h20 +Border Background0xFFFFFF")
        pic.OnEvent("Click", SelectColor.Bind(col, ColorGui))
        pic.Value := "HBITMAP:" . hbm
    }

    ColorGui.Show("w320 h105")
}

SelectColor(color, colorGui, *)
{
    UpdatePrimary(color)
    colorGui.Destroy()
}

UpdatePrimary(newColor)
{
    global primary := newColor
    primaryBox.Value := "HBITMAP:" . CreateColorBitmap(primary, 30, 30)
    WinActivate("ahk_id " MainGui.Hwnd)
}

UpdateDrawMode(*)
{
    global drawMode, eraserMode
    selectedMode := drawModeDropdown.Text

    eraserMode := (selectedMode == "Eraser")

    if not eraserMode
    {
        drawMode := StrLower(selectedMode)
    }
}

UpdateThicknessEdit(*)
{
    value := thicknessEdit.Value
    if (value != "" and IsNumber(value))
    {
        intValue := Integer(value)
        if (intValue >= 1 and intValue <= 50)
        {
            global penWidth := intValue
        }
        else
        {
            thicknessEdit.Value := penWidth
        }
    }
    else if (value == "")
    {
        thicknessEdit.Value := penWidth
    }
}

ClearScreen(*)
{
    Gdip_GraphicsClear(G)
    UpdateLayeredWindow(hwnd1, hdc, 0, 0, Width, Height)
}

ToggleDrawMode(*)
{
    global drawMode := drawMode == "freehand" ? "line" : (drawMode == "line" ? "rectangle" : (drawMode == "rectangle" ? "ellipse" : "freehand"))
    global allPoints := []
}

InitializeTempWindow()
{
    global tempHwnd, tempHdc, tempHbm, tempG, Width, Height
    tempGui := Gui("-Caption +E0x80000 +E0x20 +LastFound +AlwaysOnTop +ToolWindow +OwnDialogs")
    tempGui.Show("x0 y0 w" . Width . " h" . Height . " NA")
    tempHwnd := WinExist()
    tempHdc := CreateCompatibleDC()
    tempHbm := CreateDIBSection(Width, Height)
    obm := SelectObject(tempHdc, tempHbm)
    tempG := Gdip_GraphicsFromHDC(tempHdc)
    Gdip_SetSmoothingMode(tempG, 4)
}

CloseApp(*)
{
    MainGui.Hide()
    try {
        WinHide("ahk_id " . tempHwnd)
    }
    try {
        CanvasGui.Hide()
    }
}

StartDragMain(*)
{
    global MainGui
    MouseGetPos(&startX, &startY)
    MainGui.GetPos(&guiX, &guiY)

    offsetX := startX - guiX
    offsetY := startY - guiY
    
    SetTimer(() => DragMain(offsetX, offsetY), 10)
}

DragMain(offsetX, offsetY)
{
    global MainGui
    if !GetKeyState("LButton", "P") {
        SetTimer(, 0)  
        return
    }
    
    MouseGetPos(&currentX, &currentY)
    newX := currentX - offsetX
    newY := currentY - offsetY
    MainGui.Move(newX, newY)
}

StartDragColor(*)
{
    MouseGetPos(&startX, &startY)
    WinGetPos(&guiX, &guiY,,, "Color Palette")
    
    offsetX := startX - guiX
    offsetY := startY - guiY
    
    SetTimer(() => DragColor(offsetX, offsetY), 10)
}

DragColor(offsetX, offsetY)
{
    if !GetKeyState("LButton", "P") {
        SetTimer(, 0) 
        return
    }
    
    MouseGetPos(&currentX, &currentY)
    newX := currentX - offsetX
    newY := currentY - offsetY
    WinMove(newX, newY,,, "Color Palette")
}

class Color {
    __New(colorValue) {
        if (IsInteger(colorValue)) {
            this.Value := colorValue
        } else if (InStr(colorValue, "0x")) {
            this.Value := Integer(colorValue)
        } else {
            this.Value := Integer("0x" . colorValue)
        }
        
        this.A := (this.Value >> 24) & 0xFF
        this.R := (this.Value >> 16) & 0xFF
        this.G := (this.Value >> 8) & 0xFF
        this.B := this.Value & 0xFF
        
        if (this.A == 0) {
            this.A := 255
            this.Value := (this.A << 24) | (this.R << 16) | (this.G << 8) | this.B
        }
    }
    
    ToInt(format := 4) {
        if (format == 3) {
            return (this.B << 16) | (this.G << 8) | this.R
        } else {
            return (this.A << 24) | (this.R << 16) | (this.G << 8) | this.B
        }
    }
    
    ToString() {
        return Format("0x{:02X}{:02X}{:02X}{:02X}", this.A, this.R, this.G, this.B)
    }
}

LogConnection()

speedValue := 1.0
webhookValue := ""
clickDelay := 100.0
hideSessionInfo := false
startMinimalistic := false
startIconOnly := false
guiUpdateThrottle := 2

windowHeightFull := 460
windowHeightMedium := 300
windowHeightMinimal := 150
windowHeightIconOnly := 74
windowHeightSettings := 540

eventCount := 0
isRecording := false

msHook := MouseHook(MouseProc)
kbHook := KeybdHook(KeybdProc)

InitializeKeybinds()
ReadInWebhookSettings()
LoadKeybinds()
RegisterHotkeys()
UpdateHotkeysDisplay()
OnExit(ExitAppF)

initialHeight := windowHeightFull
initialWidth := 350
;neutron.Show("w" . initialWidth . " h" . initialHeight, "Zoan-Task discord.gg/zoan")
;neutron.Show("w" . initialWidth . " h" . initialHeight, "Zoan-Task discord.gg/zoan")
neutron.Show("w" . initialWidth . " h" . initialHeight, "<img src='data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAKqAqoDASIAAhEBAxEB/8QAHQABAAEFAQEBAAAAAAAAAAAAAAMBAgQFBgcICf/EAEMQAAICAgEDAwMCBAQCBwcFAQABAgMEEQUGEiEHMUETUWEicQgUMkIVUoGRI6EWM0NicpLBFyRTY4Kx0SU0NYPhov/EABsBAQEBAQEBAQEAAAAAAAAAAAABAgMEBQYH/8QAMBEBAQACAQMEAgICAQMEAwAAAAECEQMEITEFEkFREyIGFDJhIxUzcSRCUoGRobH/2gAMAwEAAhEDEQA/APjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArFbeihNjJbbaAvjXFLyiy6vS2iZ+5SxNx19gzL3YgKtaeigaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXKL+xdCtt+fAFsIuT8IyYJRWtCCUVpIr8hi1d47fcsIrHqa8kkfYFiO6HyiEzNbXksdKkm00g1KxgXyrkn7FrTQVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAXRhKT9iaNGvLaAxy+Nc5eyZOoQT9tkkZqH9PgJtjKp/PguVG/lErbk9hP8A0Ce5ZCqKl+rTRfOFb/pjoS0lva2Wd34YO6umh5LoLuW/YfJUu1EW2SUV7l9i1HcTFm5b8kWRSTbeyWqz4bIQg0zNgjocm0pexNNJPw9jbFmlkttCMYv+pbD9i3u860CbVnXBvwki36CfykXxe2JPT99hd1C6dfOy11yS20zITLnJtaYPcw9MoZbjB/BY6E/KaQWVjgknVKP5LGmvdBVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACqi37IChdGLl7Ilrp35k/wDQm/TBfpWgm0EKW/d6JIwhHxrb+5c5N+S1yCbq5PXt4DfyR9zb9miun8vwDX2r3eR3b/tHb9kV+Am5Dy/Z6CWv6vJn8FgPkuTpxItJ2TUUd71Z6Z5XC8HXyM5xlGcXLxFkWW3w8zcU34Rcq562oPX3Mjj4QfIVV267XLT2fSnEem/TeV6W28xHEolkRxHZ3ed72L2JuvmNfYo/cyOVqVHKZFMVqMJaSMY1GauT8FllakvyX/ARCVhyTi9Mkphvy0LVuz9yWC0g3auS0GPcoVzCmi5Lfsb7pXpfk+ez6qMfGscJySclHaRFjQqDa8R2WuKXx5Pqvo/0S4RcBZ/idmI8udf6IyTUlI8K9Uejsnprm74Rpf8AL97UJJeNaJLtqyxxCUvuV3p+2yoXguk9ym/P2K7+zGtvz5KOPnx4C9l/c9aKdsGv1R8lv6k/Pkq3/oDViyVG9tNfsQyhJfBkJsuWt+fKBthgzJ0wmtx0jGnVKPw9fcNLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACqTfsisIOT9jJrjGEfbbBtFXS35l4J12RX6V5KNtlHrXgM7tVb29lrl5LV3fcuSXx7g1J5NN+d6Cin8eS4kw1F5dSnrtcvOxpNsmvis6zG+vHHsdet7140XcHx75DlacLuUHZNR8n010b0pxXL+mG8SqqeV/Kt+Nt72eK/8AQ7qHjOqfq1YORqu1NNQJKtjbdW+lt/C9N1cn3wmpwcvEWeVyXbJxfwfaeVxWXy3o9KWdTNW04cnqa872fG3M0vH5bIpa12y0MbsymmR0rlPD57Ev3rssTPr2XD2db+m2PXTNdyx35a37s+MapOFkZL3TPrz0l6kjx/pNZbDMjC+GG2lvzvZMlwea1+hWZ/MylZyNNWn/AHRf/wCD3bprpeXE+lefx8sqvJlDDcf0r8nzN1P6tdUS5PIqr5G9RjLx7Hb+l/rBdXw2djc1kTudtPau6SXyiWWrLI8P6zx3jdS51bWtWa/5GmOh9Qs+jkupsvLx0lCyza8/g586RzpsqvgppldBFLKt6kU+CRf062WaJGr4UBUoVlveiMPEzebopzZwjVKxJ9/to+j6uoujeh+m1LBposy3X4lVPymj5Wqtsqmp1ycZLymSZOZk5CSutc0vuSzbUy09Rv8AVzm8nqmnJjlX/wAurt9m17HuHUfD4XX3pmuS+hGGRDGc3Oflt7/B8z+l3D4PK8/RDOtqhUrFvv8AbR9C+ovWPF9JdCw4jg74KUqHXL6UvczfPZrG9u75a5/j3xnKX4jafZLXg15l8pnW8hm2ZV0nKU3ttmKk29L3NubrPTXpO7qvlViVaX61FtrfueidUeg/K4NH1ca6NjSb7Ywezqf4aenngcRkc9bX2qEFYpNfkxOsPWnksDq+3Ghk3TxoXacU1rWjFt32dJJru8L6g6Z5XhLpRzMe2Ci/dx0aSX6n5PrvqbG4frz06t5SrHgsqGM5tt7e9nydyuNLD5K/GktdktFl2lmmHqSfh+Am+5IuGtsuk39qvx7Mq590dPyiOX48FU9LyguvpbOpNbj4IZRkvdGVF7K/pe1JbBMmECW2tptxXgiDQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFUm3pAUJa6t6bJKqlFbl5L39kEt0eEtJaKSekUbKqKa2wmvtantFyWv3CWjN4PGjmcrj402lGyaTbCb+leM4vN5K6NWLj2WSk9fpWz2f019EMzlowu5FRqTSfbZFnpHRfR3T/AEp0bDqDJx6LrFT9RNbT2mcTf645UeqcejBldTiq5JxUlrtM7t8NSSeXCetHQf8A0R5CVddcVX3tJxT17Hmifs0fX/q3xdXXnQVHLYUYzvVUrJ68v5R8kcjhXYGVPGvhKEoPTTRcbtMpqvQPTP1P5HpbVDttlRpRcU17Hpf/ALa+GtX1rePnKx+W3Nf/AJPmvS+UNLXsWyVJlY+0ehvVLiup+GzuLsSohOnsSnJa8s+YPV3BxsLq/MWLZCcHb47fb2Oc4rl83i5OWHbKtv30Q8ln3598r8qxzm3ttkk0tu4x/k3uF1Vy2JxzwKcqyNLj2uK9tHPOxFrtb9ipJWTfZO2yVk23KXuyyMml4nog77GvkRhKT8vQ2vtS9yb8yLZWJP7lHS1/cin0/gGokjfFLyik70/ZaKxhBLzHyWSrj8IHY+sXRvXytkf0y+EIp+VsHYlct+wVibLpwra8R0R/TX2B2Sdy+6K/p+6IlU2/6ikq5R9nsGozsHNyMOxWY9rhJedom5DlM3OSWTdKzX3NXuxfcqrWv6kwe1KZ3Bwps5SiN7Src/1b9tGuVqfwSQlrTi/I2mtPq23rThOA9KXx/H31K+zEcGoS872fLnLZc8zk78myTbnLZHPLyZ1qudrcV8EIk0XLb1rob1Dhw3S2Rxs+5/Uq7PdHmnUGWs/lb8pLSnLZgbKFkS3Yeoem3p3/ANJuNuyO6C7Ip+Uzy9n09/DjJrpjM1/8JEyuouM3Xz/1rwn+BcvbhucZdk+3waF+Vpne+qWJlch1xlU0Vysk79JJfg2eN6Q8s+np8tkN0xVffqUGQ1d9nlyXb5QT2zJ5HGeJmWY7e3B62Y+vO/kpvflVPXgtlVGe2tJiUmmky5ePIXwxZxcZNMtMqcVNefcgsrcf2Cy7WAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLTBt9z9gLVXJrZa009MzVr7GLkNOb0El2jAAUALq4uUtAIQcnpIyK61D302XQiq1pe5T9wzb9Kyf5LG/hf7lX+r8BJJA8Kxjv42yrTXutHofo90ji9S8mqsm2qK2vE9+fJm+tXQMul8zvorSplNqLinrWhueEstm3lxk8ddLHzarovTjLZjfBfV/1kfPyVH1pwWc+c9GrKrn3OvCk1v8Ac+VOSreLy10V4cJeD6L6C5jjcH0tuqtyalZPEa7W/O9nzxz90L+XyLIf0yl4M4xrJ7j6L+pdHGcHfx/KTdlSp7VGUkvk8t9VOT4/lOpMjJwKlXXKzaSe/Gjk4TnHxGfaiK2en77Y13O9mlzaLZTSXuRNyk/kuVb+WU1Io7JN/pKanJ+WTRio/BXQPdFkKo+8vJc4R+EkVHyNM7F48B+A/ce5Tam2V2XRg37IOHavcC0MD39gig9iuhoBsIpplUBTZX3KAC7Zb2pvygV2NLtbOuD/AKVoscJR8pkuwTSzJD3zXvskhYpfgq0pLyWOpP2aQXcqTab1sEDU4P3Llb8MbS4pfc+oP4XoQyuLvxJTUfqRjHyfL0Xvymdl0R13yfS7f8ldbXvX9OiWbi49r3fU3L9IdI9O8lk83yl2HbcpfUjFtqW0eQeqnrDZkU3cPxDsqxknBKMk1o806w6853qO1vKzbZRe/EtHJyk5Pcnt/ckxLl9JcvInk3yusbc5PbbIopt6S2yh3no/0dd1R1BTW6m6lYlLa8aZvemZNuEsrnH+uDX7lvlL38HvPrf0LwnTnHV/QljxyFCXco73s8IkvLRJ3avbtVE0XeJLTLGvPgr3L2XgH+4iup7fK8ohMzfjTIba9eUFl2hAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALoLukkBdTDvZkJaWl7FIx7PCLkGbdrLJdsf3MZvb2SXy3LS9iILAAuhFyekFIRcn4MmEVBePcQShHS9x+WGbRv5Lfd/gN7fj2LkDwIFYRc5qK92egdLemXI83hQyq5ajKO/6WXwzq1z3RXUeZ0/y9GTjWzjGM05KPyfUi/kPVToWEHXGWZVS5Nye3t+Pj9zy7g/RK2VkZ5mXVCC8vuiz1bpnL6Y9M+OkoZmLdc4dslCWn48/Jzy/03jLPL5a686XzOmeXuxMiuUYxn2p618HN715R6R63dZY/VXOW3Y9bjF2d3vv4PN/ZI3PDNnfsz48tnRxf5ZXyVetdv4NfKxbbb2yyyz4iWwg29yCyfZKUpPwnouhX8y8kiSS8IDRchJL2HyCqTfsVlQF/b517kkKW1uXhA0g0UaJ5R89sUTU4rk9y8IGmLCuUtJImjQoLcmv2MqSjBdsI7f4LPoWWeXsq6Y0568RWixRnN+zM5YiS8tFX2QWox2/wF0xI0eNyev3DjFPUVtmSqrLHt7SJFSorwvI0SMONTl7vRf8ASgl7JmUqJS+dIvVNcF50NLMWvlVJ+0WVjiy1tvRlWXQh/StmPbkTl4jtIJZItdUI+7TIJ9u/CKz2/dlnsRkGihX2CKAAAEABV6ZZKtS9vBcVTGll0g1KD8F8J7fkv9yydf28Ea3tJsEClKD0/YljNP2G0sbXpzjLOW5fHwq/e2aifZnpH0jxHSPTSyLcjHpzLa04y8pqSZ8YcDyt/E8hVmY8pRnXLuTR1nKeqPUmbCuDzr0q14T0TKWrjZHqvqz0NznU3K3ZVXKLJrcm4xUd/wDoeU8l6YdSYjk/5K+aXyoG46M9Rurb+QoxcfIyrXKSjqKR9O8ZzePgdFPO6jj/AMZ09yVr097JuxrUyfDvKcXmcba6sumdck/aS0YEl48e53Pq5z+NzXUV8sOHbUrHrT2taOHN+WPFIvx+SvutFJL5XuUUvOmRfPdFbXryiIzPfx9yG6rXlBZUIACgAAAAAAAAAAAAAAAAAAAAAAAAAAAACqW3oyK6+1fkpRDS20ZNdcp7evBDvbqIvkpOfbF/kvkvL18GLe9zaKzJ3WN7eygAaVS29GVVHsj+WW01pLufuXt+AmVGy1bb8+xa9t+/glrhKXiKbDPhNx+Fdm5MaMetznJ6SSMrmuFzeJko5dM623r9S0dR6NqhdZYcMmCad0VpnpX8T/FYtNOPk41UYqdjfj9mN9zW5t8+VycJxmvdM9B6a9TeW4XAhi0XXRjGPatNHnsf6UC1JdPRuU9W+psiuVdedkRUvD9jiuS5vk+StlZl5U7HJ7ezXb0WzsSRO0XvV1j0m2/JA5Sn4XsVSlN7fsSxior2C+Fsa0vf3Lwwis27AVUXJ+DIqpSXdMEiOupy8v2JO3z2wXn8EiU5y7YppGTCuNUd6TkVqRDXTGtd09Nleydz1HaRPXTK6W5+35M2uqMVpLRdNTFi0YsYLbSbL5Vyl4XhGV2jt+xdNaY1dEY+WlsvlpLwiZxKOH4GlYcoWWP3aRdXjRj5a2zJ7SuhpNIu1a9i3tX2JWiyTST2xpUUt+0fBjXRl/dMlste9QT/AHILE35nP/cjFQz7PZLbI5Jr2Wi+yyEP6UtkMrZP5ZGKtkn7tlhVtv3KEZUQZUAUBXQ0BQAFArrwU0VICDAYFJRUkQuEovaJ0H5I1KjhPfh+5JvwR2V/3LwUhNp6kFs29Y9A+T4fjebWRyddb+nZFruejbevPqJPmcpYHH3ShjQ3FRTTWjxqi6dUu6uXa/wUusnbLunJtjXfae7tpSTcm3J7b+ShtOA4HkeayY04WNZa29fpWz2ror0ThKmvK526nHh4bjdFrwLZCY2vAS2S+V7n1bm+kXRWbiSo4/N47+ZS0u1tts8L9SehM7pfPmnXKVG32zUfGkTe11Y4aL+5ItS8P2ZHJeS6D8fkpftBfX2S+6IjMmu9aZizj2y0Fl2tAAUAAAAAAAAAAAAAAAAAAAAAAAvIAmqr+WKoedsyIRc5KKQTfxF1FUrbFGK+TaZFcMTEUXrva0zJ47Eji4zvtST1tbNTyOS8i+T342cPd+TLU8R9S8M6Th92X+WTDsscU39zFb29kmQ/1dqfhER3fMgS0Q2+5+xbXFykZCXatIJbpWRY/L0iu/OvuVSSYZn2RXsj230N6A4rn6J252Tjd0q04xnve9nifyb/AKb6u5jgbIvCyrK0viOhYS9+723K9Jc/h+t6c7jY9+PG9NfTi9aNn/EVhW/9FcOV9bU13N7X4ZzvQnrjyKzsfH5Gy+1OSX6mj0L11y6eoegMbkaYaUoSl77+5jvvu32s7Pj/APH2BdYtWSX2Ipz0vydHOTZZNJaLIQcnt+wrXdLbJvZeCNW6EtLQYBWdhfXBzkkkUri5ySRn1whTXt67hCTa2FUKYblrYrrndP7RK1Vzvnuf9P5NlTXGMEoo1puTaKNca46ivJdXVuW5E8a1v2JIw18F03pbCCXstF6iXaK6KqmhouSDQFmimi/Q0BY0U0SNFGgIWiC9L+5rRkWb1pIglRKf9T8EpWDbao/prjt/gx/p33P2kbeGJXF7aRNGuMfZE0x7d+WljgWP3JI8dL5aNxpfYPS+R7V9kan/AA1/gtlx0vhm3dkEv6kRu6v/ADIah7Y1L4+f3I54Ni+DcfzFf+ZFryKfmSGontjRzosj/ayNxkvdG9lZjy93EhshjSX9pNJcGm0DPux69NxkjDnHtetkYs0t+B7FNlQhooxsAEVHwU2BUjthv2RfsqFl0hrk4vTJiyyCa8e5ZCbi9SI1Zt6p6L9Z8f0xnO3Mx/qfqTXnXsbf1S9YeQ5i2VHF3XY9Hldqaa0eNJ7JMep3XRrXvJ6GptPdfDq+kur+fxefx7a826TlYm0teT6N9S8SvmfSWrks2v8A94/k5S7p++9s8+9FfSn+cvp5fkLK1RBqf64vWjovX/rTAwuCj05x1kXGuqVT7JeDN89m52nd8zXxUciyHwmR/wBL2Vsk5WOT+WUNWOcqqe/JS2CnHwvKKe0i+L8hfFYclp6ZQyMiH9yMcNgAAAAAAAAAAAAAAAAAAAACsVt6J660vLI6dd2mZOtBLdKJNvS9zoOB43uX17Y+Et+TXcPTC7Jip69/k6flbo4WCoVrW1rweXn5LuYY/L7vpHR4XG9Ty+MWm6hzf1fQrf6Yv4NBN6TZLdZKyxyk9tmNdL4O+GEwx0+V1XU5dTy3Oom9vZQF9UdvZtwTVR7Yp/cubHsi1/qel8BjzVYrfkv7Za24sm4yuNufRVNpRlPT2ey9SenWLX0Dh8rhwrlZOtyk4p7+RvRq14kDaUcByt+/pYd0l91Ety+D5TEh334lsI/doqaYFFkqbo2xepRe0dvf6i8pf05Xw1ltzqhBxS8aOGa09Mtk9LZKTat1n6nJ+7IYxc3tjbsl+CZJL2DXiKaS9kVAKwF0YuT0ihk0RjCHfILIvrjGmHc/6i+iLvn3S/pXnyWVQlfZv+02NVDSUYrSK3JtbFbahBaSM2qHbBIVURrW0vJMkajpFsYl6RdFFdIbFuiqiXJL7FdAW6Gi4aQFmg0Xa8jQFjXgo4lzI7Lq4LzJeADiPCRhZHJVw2kt/wCpgXclN77W0NpcpG4nZXH3kkY1ubXDemmaWzIts95Micm/dk9zFzbW3k150mYtmfbJ+GzCBNs3K1PLJtf9zLHdY/7mRgibq52T/wAxTuk/7igCK90v8xXvl/mLR7gXfVn9ykpN+5Qe4FCvuNIAUZVewABFCv7AChUeAAI7Y7X5JB7kWXSKuT9mZFFrptjZB/qi9rRBZH5Qrl40w1e71PjfVvl8Dp3/AAvHuvh/w+zaaPPuY5LK5XMnlZVspzk97Zg+PsS4tFmTfGmpOU5PSSLpm21EXQjOb1CLf7G4yumOYxqFdZh3KDW9uPg9I9A+gquoM+x8jTH6UZx33p60S0k28flFp6lFp/kp7HqHrj0txfAcxKrj7qNRk9xhs8tm/lEa/wBJI6ltSMW6HbJ/YnjvWxau6BSduzEBVrT0UDQAAAAAAAAAAAAAAAAAAKrw9k9M3JabMcuhLtYSzbYYl0qb4zi/k6i1x5HjlJNOSjs4+L35N1wGb9Kz6U3+mXg4c+G57p5j6vpXVTDK8PJ/jk1V9cq7HGS1oxr4/J0nUWGk/r1rxJ/Bz7jvwzpx5+/HbxdX016bmuFYyW3oyK4pR/JbGpqW/gkfg281qknpFaoSk0opuTLfd/hG26XWP/i9Dye36amtpgbzo7obneay6bMfDvUNp96jtH2F6e9HVVdFV4PNzhdGqnTjNa15PH6/VTgumeDhicZixVyh299c/wD/AE6L0X9RszqvKz8XLuscZ1pRUmvloxlutY6jI6h57oDpbKswo8diynB9r7Z//wCnnHqX1p0vyfE/S4/ArqsaflS3/wCpyf8AEBx9uF1tmNt9ru0v9jzdt/c1MUuXwra1KyUl7Mgsk5S7V7FbZa8IrVHxt+5UnZdCKiir9wNhm3YAwixF9cdvZPBStmoL2IYJt6XyZtPbRX3P30GozKvpY1S3rZj3cjp/o2jBvvlZJtt6Ihtbl9Nnj8jY7FGTb2zdUy74KRzWBU7L4+PZnTUR7a0jUbwtq9FdBFSthXRRFwFoZV6+SDJyK6ltyQE3svJj5GVVUnuSNXmco3tQbRrLbrLG3KTM7c7npssrlG21DaNfblW2PzJmOAxcrV0m37lpVhRb9lsjIUMmnCyrmlXTOTf2RtMHpXmMppLDuSfz2hdWtHsod5h+m/K3JOUZx/eJtcX0pzZpOdmv3ixtqceVeXA9dj6T3682R/8AKw/Sm1f9pH/ysL+LJ5ED1qfpXcl/1kf/ACswsj0vy4/02L/ysp+PJ5kEd5k+nXIV77W3/wDSarN6N5ShPVVkv2iRn2VzANhkcLyVG+/FtSXy0Yk6Lof11yQTSIaK+V7lAgEAADAYFNFRsowK7CCAAitXbLuRKUnHaI1KpXLaNp03mV4HMY+VbHuhXNNo0y3CeideUCz5fUnTPXXRPL8VRgcjx9Cl29rc5/8A+nrvSHT/AE/X05k5XT6x6pWw7k623o+BsF2fzVca5NNvwfXvR3IZfT/pLLNV0lZ/K9ya9/DZjKN45beO+sfRPU13PZOYqsjJqc3JNR+NHkmdg5WHa68midUk/aSPoXgPWnHt5GzD5qid9bmotzktaOA9aOT4PlMmGRxNNVfdttRezU2zfuPMFJp6Lo++mWteEyqbfkpftFkQ7XtL3ITLs1KvWvOjFa09BZVAAFAAAALlGTXhAWgAAAAAAAAAAAAJ6Hta+xPXJwsUl8MxqH5J9Bm3V3HV4Fkc7j/pS8yUfk57kMWzHvknFpJmRwmZ/LX+ZeGdLZXg58NuVfczx3K8Ofjs/S4cOPqnTzvrOOIbYfsdHmcDpOVTTXxpGmycHIpk065a++j0Yc2Gfh8bqfTuo6a/vixNJexWMnF7i9MNNe60UOrw3a6cnN7m9s7P0o6q/wCjHM/zEm+xtbSejiiosJdO99YOq6Op+YnlUw13Wd3vv4OAm9IuIbH3S7UTws70qXfJtkj8PwIR7UVZYZU+AgvYaDIAAJKpKL2Vtsc/dkY2BUrFdz18soZ3GYzssUmvAWTbP4jF7F3yXujapFlUVGKSJDTvJo0ACqr4LLLYVx3JpGPl5ldMX+pbNHmZ1lzaUnolrOWUjY53JqO4wf8AsafIybLW+6T0QttvbKNGduVytVDCTfheTacPwPJcldCFGJbKLfukRJNtV86RnYPFZ2Y0qMeye/sj1jo/0msulC3OUUvdxlFnqfC9D8VxsIKvHq3H7bHudsODLJ4BwHpxy/IWRdlVlUX/AJonoXB+k9FSi8qNc387iz2KjFppgo1VqOvsS9n3Jt3x4MZ5cVxfQPC4ii3i0uS/c3+PxGBjxUa8aK19jautFPpom3aY4xhrGqiv0wSKfSSXhGZKBY4+C7XTDlBkUoPZmygRygalZsYM4shnB6M+cPchlA1KzY1ttMf8piX4tMk3KlM3E6/wQyr8+UblZsc1lcTgZO4240UvyaLkujuIuT7aao/7ndX0Rl8GLZiQfwiaYsjynkfT6m3uWM64v8JnK8t0RyOG32xlYl9onuGZh3Q3LHn2v8GsyLb4RcbqZ2/klxYvHHgOVxeZj7+pRNJfdGHJNPTWme65eHgZe45ONGtP5kc7zHROFenPDnUv/DsmnO8f08rYOk5XpTOxe5wqnNL7I0N2NkUy7bapRa+5lzssQgq0UCAAIHnYYBRZZFNb+SlD86bJP3IZrtltEbndlUWOq+Fq94vaPTZ+puTZ0h/gspWdqp+n7rR5bB7RUa2m7El8/qZE7fmT2WynOS1KWyhQrKqKOUU9Ao4r3DUq6Om/wQZEVGW18k0S27Th+SLO3ZjAANABdCLk9ICtce5/gyFqK1othHS0XS0o7YZ33Y9uu7wWFZeZMoGgAAAAAAAAAAVi9PZPGxS1sxwBmpfMXsmoyrqZJxm1owapyUvcm3smpe1SZZcd3jdOhwOelHSt3JfubmnKws6GpKKb+7OFMzi52LJgoN+55+TpsdbnZ9zofW+eZTj5P2ldHn8FXYnKrtX7HM52LLFtcJPemdxZkrHwO6b/AFdpxHJZDyMmU9/Jjpcs8r38PT6/0/S8WONwmsqxQAe1+WW2S0iyuO33Mpb5nolgtR0RvxFxQArAAAAAKABfVBzkkkBJi0uyaWvB0OHSq4JaMbjsZVxTa8mxhEsjtjjpfFeC4oik5xhFuT0GlZNRW2a7P5CFcXGL8/gg5LkPeEH/ALGmsnKc229ktYyz+kl907ZttsiAW29JbZlyUZlYGDk5t0aseqU23rwje9JdIcjzWVWo0WKttbl2+NHvvRPp5x/FVV23U1ytS3vT3sW6dcOK5PM+h/S7My515GbFxg9PtnFntnTfSnG8RjwjXj19yXutm7X0MOhbca4RXyc11H1zxPE02f8AvFVk0vZSM729WOGODqUoVR+IxMPM5jjMSLldl1Ra+Gzwfqj1azbpzhhTtgvjTRwXKdW8xyEpfVyrWn99E0Xl+n0jyfqNweF3auqsa+0jQ5XrBxS8V0r/AEmj5ytvvte7LXLZHoM+/J9Cy9YsH4pf/mRfT6wce2u6n/8A6R876X2GkD35Pp/A9U+GydRkoQb+XI6PjuqeGzUuzMp2/juPj+M5x/plozsHmOQw5J1ZE1r7BfyV9j13UXR7q7IyT+xWUfwfMXBepPMYU4xsyLpQXxtHqnSPqdg50YVZclCT8Nyki7bnJL5eiyjv4IpQ9/BTB5HDzoKWPfCe/szInE1K6efDDlAisgZkoEU4s1KzYwZ1kFlezYSgRTr/AAalYsa2yt+TFtpg35imbSysxra/PsblYsaXO42jIg04RTNFl8VmUNvHtaivhI6+cGRWQLqVmxw1mbZjP6eXizsXzJmFncXxHK1twjVCyS9vk7fNwMfJi42Vp7+5zvJdPOpSsw5KEvf9KMXGpY885rovIpUraH3R99RRyeXhZGNNxtqlHX3R6vHPz8Kx05ldlkPbb9imVi8Py0Gmqo2P7szpyuE+HkAOv5/pO6iUrcZd8PddqOWyMe2ibjbBxf5MudliEABDzspNdy0VYTFWdkNbcZaZMiK1/rTJIPcSRrJUAFYVKMAC1PT0XeGikl52VRG79saxakWk96+SFJt+A0JbejIqior8lK4JL28kmgzaLy9fcsyf0x0/kv3ryvgx75ucvPwDFGAA0AAAAAAAAAAAAAJaUTFtSSgvuXBjJU33TmC5S+vNaSW/JquNx5ZGRGKTa2dRl2w4/AVa0pa0efqM7/hPNfb9H6XHd6jk/wAcWt6kzu6bpg/Cfwc+SZFjttc297IzrxYezHT53XdVl1XNc6FJSSi9lyIr/Zfc6V5Itr8ybZMWVR1FF7C5UAQDIACgAVIKpbNrxmN7TkjF4/Hdk02vBva4xrhr20WR0wx+UlcfYmitENUty8F91saoNtpGq6K22Rri3Jo0vJZ7m3CD8EXI50rJOMW9Gubb9zNrnll9Kye3t+SgJcTHtyrlVTByk3pJGXNbVXO2yMK4uUm9JI9J9OvTzK5S+vIy6nGvaf6o+5vPS703sudOdyFXjxJKcWe68bx+Pg48KaKlBRWvBLXo4+Hfetd0509g8PiwqppgnFa2iXnOZw+Jxp25FsI9q2k2Y3V/UeHweDZZbbBWKL0t+dnzd171tnc3l2QhfYqe7wtrWjL0ZZzGajrvUH1PtyHZjYFk4rbW4tHlHIclmZ1rnffKW3vyYj3J90vLKxi5PSWxtx1clqRVJtmbjYFljTkmkbKnj6467opnHLmxxfR6f0zm5u+tRpIUWz9oMnjg2tezX+hv66aoLSii9Rj8I43qb8Pq8fomE/yrn1x9v5D4+1fc6L6b/wApRwS94mf7GTt/0XiczZiXR/sbIXCcf6otHVuEH7xILsOma32rZvHqft5eX0T5wrmf3L6rbKpqVc3Fr7GzyeN8Nw/5I111Flb1KLO+PJjl4fI5+j5eH/KOt6R655LiMivvvslWmtraPdOjeuuP5qqEJ2wha17OXls+WTO4nk8rjcmF2PbKDi9+Do88ysfZEe2ce6LTTLZQPMfTD1Bqzq68TOt/4niKcpe7PUouNsFZW04y9miyu+OUyY8oEcoe/gy3D8Fkofg1KWNfZX+DHsh+DZWw8exjTh+DpKxY186zHsgbKcfwY1kPO9G5WLGvnAgnD3M+yH4IZx/Bpmxps7j8fJi42Vxe/uchzfTF9Undgz7H76ij0GcPwQyjtNNeCXGVnTy2rl8rBn/LchVZOPtuXsW8nxnHcxS7cd1Rnr2+Tu+Z4HEz65d9UO5r3Z5/zXCclw17uxHN1p71FHOzTFjjuX4bJwbHuEnH76NU009M9Dx+Vw83Hlj58IqxLW5s5TmuOkr52Y1bdW97j7aMudx+mmAkmnr5Q8kYW2RTiW0t+USfBEv02fuyNzvEoKvXwUKwAIFCXsWwe09l6LPafgy1O8LYuS8FtUe1bZInpl0F32Ja9ws+kmNRK6xKKevklzK40xUfGze4mLVi8c7pJdzjtHO5djsvlJvxs44Z+/Lt4j6XU9LOl4Z7v8skFktVmK/LJb350mRHZ88AAAAAAAAAAAAAC6C3JFpNjR22/sBKlpaKxTlJJfIb2bLg8N5GQpNeF5JllMcd1rp+HLn5Jhj8tzwGJHHx3kWJL9O/JpuezHkZUkpfp34N3z+XHHxlj1vTXh6OSk3KXc35PNwY3K3Ovuerc2PT8ePScfx5UAB635xXek2Q+Z2eESy/pfwR0PTb+5G4k9girKFYPkAAACqAEuPW7JqKRZFd0kl8m447GVcO+S9xO7WM3WTiUxpqXw9FZTc59sd6Ir79y7IktcoVVOUtb0bdUspworbbW9Glz82VsnGLeimflu2bUX4MIza55Zb8ABkcdh3Z2VCimLlKT14MsGBh35mRCmiuU3J68I929KvTiuuFWfn0R7tKSUk9k3pN6eRxYV5udUnJpSSkn9z2THohTBV1xUYr2SM2vVxcXzVmHjV49UaqoKMYrSSNX1dzuLwfG2X22xjNRbS3o23JZNeDgXZNjSVce7yfMXq51lby/JW4tNsvpQm1pPxrRHbPLU7NN6hdW5fO8jbq6f0e7wt+NaORH7k2NRK6aSRLdTu54YZZ5anlSimdskopm5wuPhBKU0tk2Fiwpgm0tmbVXKyajFN7PFy81vaP1XQel48ess5uo4x1+mKMnHwrrWv0SS/Y2/G8UlqdiT/DNzXTVVFailo8GfPJ4frul9Kyzm8+0aLG4WT05/8ANGfXw+PFLcY7MvIzMeiL7rIrXxs1t/UGNBtLT/1Oe+TPw994+i6btnYzP8Mo1rsiWvisdrzCJrX1LTv+n/mSV9SY8npxX+5fx8rM6z0/LtuJMjhovfYkjWZfGXVbcU3+yN7jcrjXa1ZFf6mYnXYvDUkScmeHlcui6Xnm+OuHnCyD1KLRj348LYvcVtna5vHVXxeopM5/P46yhtpNo9HHzSvj9Z6Zlxy7m45HNwpVNyitr8GE1p6Z1VlaknGS2abkcJwbnFeD6HFzb7V+M9Q9MvH+/H4Y3HZl2DlQvpm4yg9+D6C9I+t/8Tprwcq1uyKUV3P3PnVrT0bTpnmL+H5KrKpnKPZNN6PS+JLZX2dHCyrYqddE5Rfs0i2eDmL3xrP9jY+hXVmD1HwFFd3bK5Vre353s9Mt4/Gl/wBjEnudJybeNW4uQv6qpL/QxraZR94tHslnDYM97pga/M6ZwrG9VwRZmvveRWQ9/BjTgz0/O6Prkn9JRj+yNDndI5Ne5R3L9kdZnE3K4edbILK9fB0OdxOTjtqVM9L50ay6lraa0dJkmmpnAinA2FlWjHnD8GpWLGFKJjZePXfW4WQUk/Hk2Eofgt+nsvlNPK+v+mKMWmWXjRjCTTl4RyvG8iqcSyjKpclrSbPUPUN91dNEf7k1o0PIdM4sum5ZH04RsVW96OVnfs55Y9+zyzkHXLKnKpJRb+DGJcqH08q2v/K9ERhxot7I7o+Nkm/JSfmLCzypU32lxZRt7X2JGQyigAKyFvbJvZcVT17MLKolonwY9+VWvyQxTk9JbZveA4u2V8LpxaSe/Jz5M5hjuvX0XTZ8/NjjjPll83J1cZCHtuBys29bOm6qklGFafsmjmZptHPp5+m3t9ay/wDU+36kY0v6ihWS0yh3fLAAAAAAAAAAAAAFV5ejKrj21r7kFEdzT+xky8y8BLV2PVK22MIre2dlx1EMDj/qSSUu013S3Hd8vqzj41tGb1TdKqlQjvW9Hi58/wAmc44/Vel9L/U6bLq853+HNcrlPJyZy342YRVvb2UPbjjJNR+V5eXLlzueXmhUoCuay+SUVoVL9KZZZ5sUfyTxj2rRG72igKsoVgAAAqkUJcet2TSS+QMvj8fuffJeF5MzJyO2P04fH2LJTVFShH3fgxJP9W2/LK6eIyKd77pEGblOX6IvwUtv7a+1e5hPy2wlvwqyiBLiUWZGRCmuLlKb0kiMLsLEuzMiNNMJTlJ60j3v0l9Pa6aas7Noj36UkpJ7T2YnpF6fSjKvPzql5SklJfk9yw8aFFca64qMUtIza9XFxfNXY1EKaY1wilGPsieKS9y6ETD6gyo8fxV+S3rsg2Zenw8u9cOr1x+HZx9Fupz3CST/AAfN99krr5XTe3J7ezpvUzmJcv1DkWfUco/U2v8AY5YPPbur6oOc1FL3N/x2Kqq02vOjB4jG3JTkvybyuLlJQitnj5+T4j9L6R0Wp+TKd/hfj0yusUYps6XjONhVBSmk5FnDYKrgrJLy0ZuflV4tEpSkk0vB8vk5Llfbi/f9F0eHDh+XlXZN9WNW3OSil9zmuV6gacoUt/umavmOVtyrJRjJ9uzVeW/Plno4umkm8nxfUfXM88rhw9oycnPyMiTc7JefuY0m35b2ZGPh33yShXJp/OjbY3T19qW21/od7nhg+Rh03U9TdyWtAVX32dTHpeWvMl/sWW9MWRTal/yM/wBjj+3o/wCjdXJv2udrutre4zaNngc5kUySnOTRFm8Rk4+32Skv2NdOEovUlpm9YZx5pl1HSZfMd/xfL05MUnJKX7mffVC+DTSaZ5rjX2UTU4Sa0dhwHLxvjGu2X6vbyzxc3T3H9sX6j031jHqP+Lm8oOV451NzgvH4NPdWpwcZI7q6qN1TTSe0ctymJKi5tLxsvDy77Vn1LoJh+2M7VyHIYzqm2l4MLR0udSram9eUjnrodtjj+T6nFn7o/nnqXSfhz3PFeoegnWl/A9SY2PO6UabLYrW1rR9z8FyFPJ8XRlVTUu+O3o/M7j75YmZXkQbUq5bWj7b/AIauqq+X4CrFncpWQrS0353s618yzVewziixoyJR8tMslBGRjyT+CGcU/wCpbMuUCOcC7Gry+OxsiLU6o+fuc5y3SlFkZOmMYv8ACOxlFkckalsHjnL8DlYk5f8ADlKK+dGhvpcW01pnu+ZhU5NTjOCe18nn3VvTcsdyvpjuPl+EdseT7VwE4Ms7e3yzPuqcW4taaMLkWqMG6x+O2OzttNPPufu/nuoIULz2WaLut8pYPT/0YvTdbRThMWWTz12VJNxViaOe9WM9L/3dS+GtGPjbnb228yyJueRZN/3MjAMPMFdb8bKFV4YVDpws1v3Jfgjs8zTZItaWiRrLwAFYxlKSUU2ysybUJsbGtuklCLezY8Zw12Q1KcXFflHRU4uJx1PdJw7ktnm5OomPad6+10Po3Lz/AL8n64sDiuFjWlZel9/Jk8jydGFV9OhraXwzA5bm3JOultL28M5+62dsnKTbOeHDlyX3Zvf1HqXB0WH4uknf7TZ2ZZlWOU23+5iz/pDaS2Q2WN+EeuSSaj81nnlyZe7K90c/6igBQAAAAAAAAAAAAATYz1snT1LZiVy0zKS/SmGb9uq6b5OqEFVPS8a8s2nKYkM6jcdP7HBVzlCSlF6aN3xfN21NQsk2vY8XL09mXvwfqPTvWePPi/rdTOzB5Djb8ab3FuP30YL8HeRsxeRp03Fto5XncNY2RJRXjfwdOHnuV9uXl4vVPSceDH83Dd41rA/sA/C2eqvhRE1/xP2JiOnUpSbJGSLkoADTIACCqW3o2GIo0198tbaMTHjuXc/ZF19rk+1PwitTt3STu75uT/0IZWNtsjbBNpsk23soNiKcpJJbbCLqoSsmoQTcn7JHr3o/0Hbl31chl1aitTSkvyaf0q6Lt5PNhk5NL+kmpLuXhn0lwfH08fiV49EFGMVrwZtejh4t96zMDGrx6Y01wUYxWvBnwh49iOuJk1oy9ZGHg839dec/w/p+ePXPUrIOL0z02X6YNnzh/EJybszJY/f4jNrX+hGM7qPFbbJW3Ttk9uRdRBzsUV9yNeyRn8RX3XbfwZzy1NtdNxfk5Ji3ODV9OlLXwbrhMV23KTXhPZra47aijq+CoVdCk15aPkc+ept/SfSulmWcx+IzpONNO34UUcT1LyMrr5Vwk+1M6TqbLWPhtJ+ZJo4CybnY5t72TpePf7V0/kPW3HXBhf8Ayolt/k3PC8PZlTjOafb+UY3CYUsrJiu3aTPQMDFjj0RgopaR06jm9naeXi9G9K/s5fkz/wAYhwePoxq1FQW0jLjHt9lpFL7YUxcpNI0uZy0u5qtv/Q8MmWdfrs+Th6THXhve7/vFV5Xvs5OXJ5G990ifG5e6Ml3uTRq8GTz4eq8Vuq6KzHrtj2ygns5zneAUoytpil8+Eb3Az6r4pdyTM5pSjr3TM455cdejn6Tg67j7vJ8iidNjhNNNDEulRfGcXrT2db1ZxcVB3Vw/L0jjpJp6aPp8fJOTHb8D1vSZ9Fze3/8AD0Hg86OVjxXduSRfzOOrceTS8pHLdMZTpyFFy8No7VpW0f8AiR4OXH8ee4/X+n8/93pfbl5cPZFxlKEkaLlKOyxzS9zquXq+nky0teTS8rX3U717I9/Bn3j8j6r0u8Msb5jRI9s/hd6gnxvUkaJWNRstitbPE9aevsdV6Y8jLj+rcCSl2qVy2e9+Lyj9G8e3+Yx4Xr2mtlzX4NV0PlLN6Zw7lLu3Xt/7m5aMMRC1+COaJ2iyUSqxpRZFKP4MposlEuxitGNn4scrHlVKO+5aRnSgRyagu9+0fLLB4v1VhfyfJzr1pOWji+sMhVYjp3p2RaPQuurYW8xKSa0p+WeX9QKXIcrCmCbjCWj0y9lvhBxcIYXF2ZE0k3HezxX1A5D+d5mztltRmz1r1Azo8ZwP0IySl9No8GzbXdkztb33PYy+nn5b8IigBlxCpQAR3exfUv0b2W3f0il+NEb+F5uumcNZGQpTW4po02tvR1vBQWLxs7npPt2ceozsw7PqejcGPL1EuXid2XyfJY+DX9KtJSS14ZyvIcjdkze5vRFyd8r8ucm9rZik4eDHCbvlr1P1Xl6jO4Y3WM+lXt+WPgq/6fBTy1pHd8dj2yblojL7YuMntFgdAAAAAAAAAAAAAAAC8gXQi3Iyk2o6I6Y9q2/dkjDOVEtgpKSiv3KJ7CabXgcideVGPc9N6Nr1RT3VRsS92aDjW1lwf5Os5WH1eMUn8I8fN+vLK/Temb5+h5OO/Dih3JQe/lFZ+JtFkltHsvh+Z8VZR/VIlLK4OPuXv3EMlAAVkKlABJ36jpFmygAqwUAFUtnZenfSmRzXIVzdb+lFptteGjWdH8Dk8xyNUIVSlX3Lb140fS/RXTuNw3HVQhXGM+3UtErtxcfurZdL8NRxeDXTVXGLitPR0mPFJLwYlCM6nXgw9smonrj+DIivBFWiaK8EotyH20Tf2R8keuOY7OrMmpPaV3/ofWXJKf8Ah2RKKfiDPjj1alKfV+W5e/1f/QOfI5RLybfhYaezUm84Zf8ACT/Bw57+r6XpOG+eNvhR7smC/J2eJDsx4rXwclxa/wDe4fudhHxSv2Pj9Re8j+oejYSY5ZOO6wvcrezfszm4RcpKP3Nr1TNvkZx/7xr8Nby6o/eR7uKe3CPyPqGf5ery396dr0ngquiNrj5a2dBZJQi5P2RjcPDswa1+C7lJ9mLP9j5eeXvzfv8ApOLHp+lkn05/mMuVlrjGXhM1jfyy+5uVkmzA5C5whqJ7ePD4j8r1nUd7nknldWnpyRJBxktp7Oedk297ZmcfkTU1GTejtlxanZ8vi6+ZZ6sb3FtlVYpJ60zrOLyFfSvPnRxsXtJo3nTtslZ2t+Dx82O5t+o9M57hye34rd59Eb8acJLe0ecczjfy+ZOPb42eodu1+5wXV9Sjmt/94nSZay01/I+nl4ZyfMaXDm6squXskz0PirVdh1yX2POflHc9LybwYp/5Tt1WO8ZXzP49y3HmuHxWH1HVqffr3ZoMmPfTL9jq+oa1Knf2RzM4/okicOX6xv1Xh1y5f7cxfHttkvyT8Rc8fk8e9PThPZZnrWRJfkjperYv8n18buR/NubH255R+hnoFmfzvQeLY5baoT/5nevWkeP/AML+XKfRtFO/CpS/5nsTiS+XmiNotkiRx8FkiKikixolZY14KIZo1nP3LH4+1t63E2sjj/UPNjVh9kZafa0zWPekeXdW5Sh/MWOfmW3E5XjY6hdl2x1/dtmfy1ks7NjWn3RT0znuveYo4bhpUwmozlBrSZ6IZV5l6q85/N58saEm4xbXucB+5k8plSzM22+Tb7pbRi+5Hkyu6FC5RetlrDIAALlFSi9kNS/W18bJH9goqK/LI3PDIwKXdlQgvO3o6Xmn/KcXCpPTcDX9J4/1MxTa3qSJur7t2xrT9to8vJffyzH6foejw/r+nZ83zl2c63t7YKFUet+cVj87C8MslLT0XLyiLUeQm13GOZr01pmNbW4vevAalRgAKAAAAAAAAAGTj0px7pLwwIFCT868E1VaXl+SZqK8L2EY79kGbkt0JeFsWSUXrZBbZvwgki2yW5EtUk46Mcvrlphqxn4L1kQ/c7WyEreJ1FbbicLTLtkpL4Op4bmq1XGm3Wta8s8nU4ZXWU+H3/Qeo4sPfxcl17nN5VNlVslODRAd7kYWHnw761Byf2NByXAXVNyrTa/CNcfU45dr2rl1voXNxbz4/wBsf9NE3taKF91U6puM4tNfcsPV/wCHwrLLqgYDCGwS1Y9ti3CDaX2LJxlCTjJaaG41cMpN2dloGxoMhn8Lx1/JZkKKa5S29PSMTGqnfdGqCbcnpaPcfSXpKGLTHNyql3Simtr8hvDH3V0vpp0tTxPG1WW1RVrh5bXnezvVONdbnJpRS2zEq7Yx1HxFHGepfVtXE8dOiq1fVknHw/KJY9vbDF0Ob1rxOFlOieTUmnp/qM7C614SaW82hf8A1HyVyPLZmbmTvlfJuT2WxzuRgu5X2JE04f2K+1+K53is1pUZtM5fZM3mPW7pqNa7t/Y+IOB6u5ji8uFkMu3W/KWj7J/h85ldQ8PTkZP67PpqT7vfezOU03hze520uDUeCyZ2R/VKp62fC/rVR/L9cZsNa1d/6H6JcjGLwLYJeO0+Av4iMSdXXubPWk7/AP0MS7W9684N5xH/AFK/Y0jN1wrThr8HHn/xfX9IuudveJf/AL3Df3Ox/wCxX7HGcf8Apy4f+I7On9WOv2Pj9R5j+n+jX9Mo886nX/6nZ/4zBwfGdS3/AJjcdV0uOZKWveRpqX22xl9me/ju8I/H9Zh7Ory39vUeM1LDr19izmId2JJ/ZEHTORG7Cgt7aibHLr+pjzhr3R8m/rm/ovFrm6WWfMcLZ/WzWcpXJx2kbvPodV8k1ryYllcZxakj6GGWu78b1XT3KXCuc0zIwoN2rX3NhPAi5bSRPj40K/Ols75cs0+Vw9BnM+6Wtagkbrp6Dd20vk1UIOUlFL3Oo6fxPpV98l5aPDzZaxfqfTeC58s18NtFa0cH1nJPMa/7x3l8lCqU340tnm/U1yuz5tPaUjHSTee3r/knJMemmHza1L90d10tF/yMZf8AdOIrh32xgvdvR6D0/S6eOhFrz2no6q6xfD/j3Hcuot+JEHPPVP8AocxZ/TJnQ9RzSgoo5u96ok/wZ4J+r1erZ/8ALf8ATnuR85Lf5Iav+sj+5flvuul+5THi5Xwilttn18fEfzLnu+TKvt7+FmD/AOi1L/8AlL/7nt7R5N/DHgurofHta1uhP/metpeBl5eWI5IjlEnaI5IyqFoskTNEU0WDGyZdlcpv4PHfUfk5W5M6K57bbXg9O6sz4YXF3NySk4PR4nlOWTn25Nz3Hu3tnXCLGotVXH4FuZfKMZKPd5PAfUrn5cpyc64WOUIya9zu/WDqyNUJ8fjW+dOL7WeKWzlZZKcntt+Tq4cufxFvwXVQc5pIolt6Njj1Rqodkl51tBxk2xMhKEVH5MYkvm52N/BGCgACBfXCVk1GKbbFVc7ZqME22dRwfERpisjKSSXn9Ry5eWcc7vf0HQcnV5+3Hx81sOm8JY2E7prT1s5jqO1WZ8tPembrmebhVVLHx341rwzlLbJW2ucnttnn6fDK5XPJ9j1nquHDhx6Xhu9eVgfiOxJqKIrLNrSPZt+akWTluf7GRX5jvZiF8JuIasZRV6lHtZFXYpNImcdJfIZ1YxbKmn48kbTXutGaUsgpxb15CzJhArJak0UDQAAAAAGVj2bj2t60YpVNr2AzJab8Mqm17GHGcl8k9dqfuGLj9L3Hue5EN1aT3En3so1tAlYZWKbZfbHUvBfVHwG18fEUXJtPaKAunPbY4HK34sklOWjq+L5ijKrULWttfLODZfTdOqalCTWjz8vT45932PT/AFnn6W6t3j9Oz5ziKr65XUxTfv4ONyKZ1WOM01o6zp/lo21Km6W3rXkc7xKuj9WpeX58Hn4uXLiy9mb6/qHQ8XX8X9npvPzHHmdxuBblWpdr7fuZmBwl1lq701FfdG7tsxeLxu2Pb3614O3Lz/8Atw7183ofSLf+XqP1xifExcHEqVdjr7mtPZr+a4eFsZX4yT+fBoc3kLrr3NTaW9m24TmuyKpvba9vJyvFyYfvL3fSx9Q6Lqt9PnjrH4rn7qZ1TcZxaa+5Gdtn8bjZ9P1aO3ufnwctyHH3Ys2pRevueji58c+18vi9f6Ty9LfdO+P26r0w47Dy+SjLJlDcWmlI+hMCqujGhXUkopaWj5U4Xkr+Nza7apyjqW3o+gvTrqavmMKFcpJ2Rj58+fc9Mrw8WU8OyuU3jTUNqWvGjz3kuhcvnOVnbmWOVfdtKSPSqUvYzKY69vBnJ6bhMvLzzC9KeHil30Utr8M2f/ss4WdEoxxqd68eGd1VFfJvunOOnmXx/T+lPyYtS8eMnh8beqHTP/R/l7K66+2vv0tL8H0H/CHnd2IqHL2rS1/qjmv4r+Cjh9mRCCXdNttL8Mwv4R+XjVy7xpT1/Svf8oXvi8njN9lXx7q7I/dHxb/FJxTp6guyFDSla3vX4PtRNTh3fDPnj+K7pt28R/PVQ2/1Sel+Dlj5d3x6vKNnwk9WNGtacW4v3RPg2/TvX5Znkm8bHv6Ll/HzY5Oqol23Rl9mdjxditxo/scTTJTrUkzoensrX/Dk/wAHx+fHcf030nqJjya+Ki6ww90/VjHfyzjEvOj1HkaI5GJODW9rwee8riSxcmUWtLZvpeTc9ryev9HcOX8uPitp0nn/AEb1XOWk3o7yuUbIKUWmmeTVTlXNSi9NHZdN85BwhTbLz7bbMdTw2/tHr9B9Uxwn4OS/+G15XjY3xckls5zJwbqptfTk0dvCcLIKUWmmWToqn/VBHmw5bj2r7/Vem8fPfdjdVwn0bV/2bJKsW6ctKuR2TwKP8kS+vFph7QR0vUf6eLH0a775NLxXFaanZH/c31VcYRUUtaKpRj9kjXcvy1GJVJdyctfc425clfSxw4ei4926Y/VGfHHxZQjNdzTR59dN2WOcn5Zmctn2Zl8pOT1swq4Oc1Be7PpcHH+PF+E9V6+9bzbnieGbwmM78yDS2lI7+iP06Ir20jT9M8cqa1ZKPlrZtuQsVWPKW9eDyc+fvy1H6P0fpf6vT3PLzXOc/Z3ZDW/CZoeRn2UP8oz8y123Sk38ml5m1dvamezgw7yPzXq3Uz255tPN7m2bLpbGeZ1BhY6j3KdiTNYeg+h3Dy5Pq7Eah3KF0fg+m/A273X3D6O4C47orCqUdbpS/wCbOyXsa3pnF/lOExaNa7Ya1/qbPRiuS1kciSRZIio5EF01CDlJ6SJpGg6tz1jYM4xlqUos1JscR17yLyb5UxnuCbR436k9UUcJxs66bo/VlBrSfnZ0PqD1NRxWJkW22xdji2lvyfMXWPP5HM8jbZKyTh3eEzvJ2Tkz9k1Gu5vkbuTzp5Nsm3KW/Jgglx6pW2JJFeTyn4+jvmpSXhMv5G1L/hxfheDKtccbG0tdzRqLZuU3J/JfDV7TSxlCrKJBgJ8TGtyLFGEG9v4MjjeOuy7ElF637nV42Li8VjfUtUXPW/J5+bnmHaeX2fTvSc+p/fPthPlj8bxmPhUfXyHFSS3pmt5rmZzbppk1BePBBzfLTybHGuTUPsjTvbe/cxxcNt9+fl6Ou9Tw48f6/S9sZ8/as5OcnKT2y35APW/P223avam/PkivrS8xJR7rRNLKwy6Ee6Wi62OpfuTVRSXt5DVoqlFLXuXJv5ZUtlNR8sM96v8AgtnZGMffZBO2T8J+CNtv3YWY6JPcmygAaAAAAAAAAAABkUz/AE6ZJ7mLB6kZS21tewZyiy1Lx+5WK0Jru+fYRCXwqACsqFVFv2BVS7U/AqxJRbOi1Si2mmdfw3K13UqF01tL5ZxMJ97ZLVZOt7hJo48vDOSPp+n+pcnQ57nefTseW5anHg40td3t4ZyeZl25NjlOTeyK2ydj3KTZYhxcE44vqHqvL1mXftPpTyXJtPa9yhWKcmklts7PlNnxvLX40knOTj9joqcrC5Kjtt7FNr5ZzVPD5tlH1lRPt1vejFUrsW3W3Fo8/J08y7ztX2ei9X5eCezk/bH6rI5nHhj5Uowaa38HceiOTZDl7Ydz09LX+p57kXzul3TbbPQPQ6l28zc1/bp/8zthLJJXz+TPHPmuWE1H0NjP5ZsKVvRr8f319jZYkXNqKW2zWT1Ys/jsaWRdGuKb2z0vpvjoYeNHcUpNeTRdI8V2RjfZDy1vyjsatJLSOOVYzy28J/i34iWR05XkVw7u1Sb0vwz5s9EOZfC9Y4qlLtU7opn3B6q8FHnulsqhwUpKqXatHwN1Xx2V0v1ZYu2Vcqbf0+NfBrDvNPLyTV2/Rzp3Nr5DhsfIrkpd0d+DSeqnCQ5rpPLpdanL6MlHweQfw4+qOPm4VPF5+TGM4wUV3y93s+iI/RzMbw4zrmv9GcrNV1xu4/NTrfiLOG6gysWcHHtnpJr8GjXh7Po3+KToK3H5O7lsWhuE7HN9q+NHznJOLcZLTXuadMa33EXqVSi35SNvhXum+Mk/G/JyODc6rU9+NnRUWqyCaZ4Ofj1X7P0nrffhJ8x3eBkRvpi01vXk1/UHFxyqpWQiu5eTVcPnSotUZS/SzqKbYX1bTTTR83KXiy3H7rh5OPr+D2Z+XmuTRZRZKE4taLKpzrl3QbTR3XL8PXkwcoRSkcln8ZkY0n/w5NL50e3j5sc4/J9b6ZzdLluTt9s/i+oL6NRslJpfk6HE6mxp6U+1P7tnAtNPTWgm17PRM+nwyb6X1rqunmpdz/b06PMYMo7+vWvxsxcrqLEqTUZRl+zPPFK3/wCIxuT/AKpbOc6TGfL3Z/ybnympjI6jkepZTTVTa/ZnPZeZdkzcrJt7+5AX049ts0oVye/sd8OPHDw+R1HW9R1V/a7Rxi5PUVtnQ9P8TKc422x0l58on4Tg3tWXR/Omjpa64VVqMUkkefm5/wD24vs+l+j22cvNP/pdBRqrSWkkjQ89ndzdUX+DL5bPjVW4wl5/BzV1jsk5yfucuHj7+6voepdZMcfxYIbpdlcpfg5zNtdl0vPjZseVytJwizUPbbZ9bgw1N1/OvVuqnJl+PH4UUW3pLz8H1B/CV0dY8j/FL632txmm0fP3QvC3811Di4lVUpxnYoy0j7+9Ium4dP8ATONV9NRk60n4/J6N9nwc78O1hFQXbFeF7FwKGHNRvwRzZfIimFQZNirrlNvwls8X9W+tMXjK7nO+O4p6Wzq/VzrXA6b4W/uya1a63pd2ns+IfUbrTM6g5O9/Wm6nJ6W1rR2wxYyz9qL1B6tyec5CxRtl9Luelvxo49grFNvSOjzW21WEXOSil7m4w6I0U/UmvOtlnGYetWTWvnyW8rla/wCHB+F4NeG5NTbDz73ba1vwmYrLknKX3bK2Q7V5Ixe6M2HC4X83kqL9tmvOp6Mo3d3flHLnz9mFr6PpXTTqOqxwvhuvp4/FYXdqKkonIcxyduVbKPe+z7G660yWn9JP7o5E8/S8W578vL6/8g624cn9Xi7YxXTabRSqe3JMSm4Qevkjp/qbfyex+ZnhK/coH7grAVKFQLLF+pMvXsikte5dHzpEavhRyUU9mLZLuk/sTZPjwY4akAAFAAAAAAAAAAAAABGVXP8A4aRik1T8IJfCSSfnQhsu3pMR12J7DPwoACsga2tABUdaUZtMkIpf9YSpaRI1kAArAbrpbjZZ3IVrt3FSWzTRTlJJLbZ6j6ecbCjCWVbFJuO/P7ljWE3W9ysXFwuMjjxqj3zj2rRz3I9FSyOPllxhqfb3a0dHjy/xPl+yK7oVS2jtXjR/kpUqPjt1o1Jt6PbK+YeQxZ4mROmxNNPXk9F9Av8A+Wyv2X/3RzXqRjrH566Kjr/if+hb0Bzz4Lk3bvUZtb8mHHH9cn1JT/1jOu6R42WRfGyUf0rTPM+j+quI5P6Lsy6a5S905HuXSWRxbxK1jZNU5OP9rJnXr9012dFiVxrhGEVpIy4ENS+SZeDhWV0oKyuUJLcZLTR8s/xT9B0Vyny1KjByk5vS/B9G9S9ScbwWDZkZmVVW4xbSk9bPj3189Ureos23CxLpSx4zaXbJNa0awl258lmnk/TfK53EctTZh3ThKM1/T8n3r6Cc1yHL9J4lub9RydW9y+fJ8Uek3TN/UXU+NBVSnBWru8eNH6BdA8HRwXTuLiVVxg4w7Xr9y8ljHFtD6jdN4/UHT2Xj2VRnY6motr5Pgf1O6SzOm+fya7aZxr+pqLa0vY/R9pNafszx7189OKOouHtysbHi74xlLxHbbOcrvLp8JR+5sOOy3XJRk/BN1LwmZwnJWYmVTOvsl2/qWjV+zJljMpqvb0/NlxZTLF1NU1OKlFm043kJ0SUZSfacjgZsq5KMn4NzVdCyO1JHg5eLXav2Xp/qUz1lhdV3GJmV3RWpIlux6b4NTgnv7nGY2VbTJOMmbnD5jwlY/wDdnhy4bO+L9ZwepcfLPbyxTP6erm3KtJfsjU3dO5Cb7W/9jrKc+iyKf1Ir/UnjfVL+9MTm5MU5fSuj5+8cK+Cyk9al/sX19P5Mn57l/odx3VP7FPqVR/uSNf2s3Gfx/pp3tcvidOSTTsf+6N5hcXj46X6I7MmWXRH3sijCy+VqgmoyTf4Zi58mb18fS9H0neabCUoVR86ikajk+UjGMoVvz7eGazM5O21tKTSNfZZ/dNm+Ph+a8fV+q7nt4119s7ZOUm2a/Pyo1wcU/JbnZ0YRahJN/g011krZd0mfQ4uLfevxnqHqUx3jhd1bbN2TcmVpqndZGuCblJ6SRbGLlNRS237I9g9B/TjL6g5mrIysSaojOL3KPho9kj8xnn816Z/DB6cuMauYzMf37bF3R/J9SVQjXXGuCSjH2Rq+luGx+E4mnCx4RioR7fBtiWvLbsZY2VkQ5N1dFUrbpqEIrbb+CC+bSWzzr1T9R+L6W4y9SyKv5jseo92ns5v1l9X+O6fwbaMDLrsv7Wv0T8pnxx171rynVHIWXZN9soSk2lJo6Y4b8ueeevDZeqPX/IdVcndJ5Fn0e56i2mtHBPyAdnC3YvL0bPi8NzkpyXgj47ElbNSkvBtsi2GLRqLSejUjeOPzUOfkQor+nDSetGisk5zbflskyrpXWOTbL8PHdku5rwieUt91XY9XZD6kl+THvn3Tf2MrNtUUq4/HgwWGb9KHb9HVOOO7NePDOKqj32KK92z0LhorF4KcpeH2Hj63L9NP0v8AGOH3dTeS+MY5fq23vzWt+zNGZvL3u7Mm/wAmGvc9HFj7cJHxvUOX83U55/7R3f0iqL7dlL340X1N9umbeX4VBlV4GZZU7oY85QS3tLwY0k4ycWtNe6KwoV0UKp+fIFI/1eWVXh7+xRtd3guXsyNVjXzcpefgjLp/1stDYAAAAAAAAAAAAAAAAZGKk97+xjklEtTAnZapedfCJJa2WRS7mwxFyTfsjb8D09ynMZMacTDts7n7xWzL9PsTDzuoaMfNcFVKxJuXsfT1vJdAdC8LGdEMG3K7dfpk00yWkx24no70FybuBuzeQg4z+l3KM4eU9niPXfDS4LqHJwGvFc+32/B9KdA+r13P81kcfGyUMeWowj3JryeQ/wAQ+D9Lq7JyO3Snd/6Em992spNdnk1nie/yTRfctlly2toVP9OjSXvF4AKw2HA4ryuQrgltdy2ep3zjx3EQxovU5x7Ujj/TvEj/ADEr7F4STWzeZd0+R6kror2667V7fYs8OuHaO16F4+VWJHJtX65x87OuqW/cwuMrjTh11xSWkbGpex1k1HePEPWHi71y08mFUnGVm9pfg8/qx77HqFUpS+yPqvO4LA5SPbl1Ql/4ifpf014HIz124lDSa34Zys055cVt2+XcSzmuOmp1q6vX4O16T9Uue4XIr+rfe4Ra2tpH1i/SXpW6lKzCxd/O0zh/UL0M4q7BslxVFUZpNr6cXs5+6M/js8N16W+s3F8zRVRnX11WaSbnPzvZ0XXXqvwXB4NrpzKLrNPWpnxd1PwnNdGcrZVu6ntnpS1o0uRyXLctYq7L7b5Sfhfce2VPyWdneeqXqnyfU+VbXVfbClyeltNa0eZSlOc9zk5N+7Ow6f8ATfqXmWnTx2TGL/uUDqf/AGDdUKhW/Tyd63r6Ze0Z1b3es/wk9LUfy8eSsUZOUFJbX5PqKKS8R9l7HyB6Yf8ATboPIrx8jBzZ4sdR8pJa9z6Y6N6sx+axoKSjXdr9UW/OzlnLt2w7TTqiltULanXNKUZLTRUrFnN0eA+vXpHXzGPdyPH0r6q3NqEW2/B8i9R8Fn8Lmzx8vHsrcZa/UtH6cW1wug67IqUWtNM8i9X/AEl43qHDtvxMauGQ03uMW3s1K1jl7XwcvcnoyLKpLTejr+u/Tzmum821W4tzqjLxJx0tHFyTjLtl7/Ylm/L08fLcb7sa3eNyEJxSlpMzK7YTX6ZJs5hPXt4Jasm2t7jJnDLgl8Ps8HrGWPbkm3UQssg9qbJoZt0P72c5VyM/7tmTDkofKRwy4L9Pr8Xq3FfGWm/XJX6/qkWz5C9/3yNN/iVWvZf7lsuTr+EjH4L9PTfVsNf9xtLMi2fvNkUpP3lI1VnJLX6UYl2ddPaUno6Y8FeHm9X4sfnbcXZdVa/qTNXmZ8rG1BtIwpTnL+p7LT0YcMxfG6n1Pk5e07RWTcntvZWEJTajGLbfwZPHcflZ98asWmdspPSUUe5ejvoryPI5dGZymPZCltScZw8aOz5WWevLk/SL0z5LqTlMe63GsjQpptuO00fbPp/0lhdN8TTRVRCNkYabS/JP0f0rxnT2DXRi49cHGOm4pnR/BLXnyyuSgbSLLJquDnJ6ivds4L1D9TOC6Zw7O/Lolcov9Pfp7Em2bdOs57mcDh8OeTmZFdcYxb/U9HzP62+utca7uO4i5NtOPdXNHmHq76ycp1Dk24+Hk2wx22l2yTWjx7JvtyLHZdNzk/O2dccNeXLLk+Iz+e5vO5jLnkZd87HJ7/UasFPc6OIvczePxZXWJteNmEvc3fH31VY+21vRWsZusxuvFo+NpGjzsmV1j8+C7OypXTaT8GPVXK2ailstq5XfaL8Wl2zS09Gzv7MXG7VrbRLi0wxqO+ek9Gq5C922vT8Jjwv+MY1k+6bf3LCrCW3pe5HNmcNS7c2vxv8AUdtzE/5fhVBeNwNL0lx8lYr7VqO0/JP1dyFbh9CEk9Jrwz53Nfyc0xnw/Z+nYf0vTc+XPtcvDkrX3Wyl92W/IfllH7M+j4fjbd1Hb/WtMkS8IhgnKzf2ZOyRrLw+i/RbD6U5rp2XG5ssWGVZBQTm3vZxXq36YZvBZlmZg0zuxpNyUoR8aPOuE5rP4jKhfh5E65Re12n0l6N9cYvWWPHhOcrjfOWq07Zff9iXc7k1ez5esrnXNxnFxkvdMsfse5fxD9E8T0/b/M4Mqo/UUpdsU/g8MbXb5+S73E1qiWysv6GUgtF1+vpeH8BfliS92UADQAAAAAAAAAAAAAAAAVh4kigQGX7lPbS+4rada+5SX3DPisnDyLcO+N1M3GcXtNHqHp70pm9dX/Vz86SqSUn3raR5RF7jtnW9LdacjwOHZRiW2VuUO3cWgk8930d0b6U8DwvMVZFPNYylGabST8/8jkP4p+DjVZDLx9WQlY33xXh+DyGv1C6nhl/W/wATyNb3raNp1V6iZfP8FRg5kp2TrT3KT9zOrtrc088/s/0I6f6mmSpEU042bXsaTFMVrj3TS+5antFYycXte5WXQ4mVk8ZibhKWprXg6j0+tjPLeXlR7e7T7pHAPNsnGEJtuMfhnc9Kc3xiwq8a2NcJqOu5ssdMb3evYWTj2pfStjL9jbUfB51x0JzlG3CzO5e/bE6TB5TJx1GN9M5a+Wb9zvK66mO2l9z0PobBVVSvcf6lvZ5lxXJUXTg3KMX9tnpPTvP4sKIUPtjpa3s55/6btdrFp/BKopx014Zg4WTVfBSrmpfsZ0H4OLLxn+ILoGnmeJtzcahO6Kcv0rbb0edehHpHLMy/5rlMbUYaklOP5PqbNxq8uiVNsFKMlpplOI4/G46vsx64wWteB7rpi4S3a3g+n+K4qiNVGHWu1a2tm3jXS1r6S19iyL2SRMN6Q5nF8bmUuu7Dre17sweK6YweOy3fjRhDb3pI3EfYvh7hNJUy5MsRcvYyq9Mr4a00WIuTA5rrDo7iuosWdWTi1OTT8yTPnD1Q9AraPq5XFVtpbajXBn1qiltULYOFkVKL90y7JdPzV5zo3nuKtlC7jchRi/6nE0FtN1UtWVuD+zP0m5vongeVhKN+DTuXy0zzDqz0F4jOdksSqmDft2xZXScv2+JdFD6Q5v8Ahy5GDk8eyevjVZyud6A9Q0tuP12l/wDLGnScmLxnQ0eqS9E+pYtpU5L/AP6yfE9DOpL5acMiP/8AWD34vJdDTb0ke8cZ/Dxzdkoq2dy396zuem/4c41ThPNakl790GEvJHyzh8VyWZJRxsK23f8AlR6F0N6Sc9zeTT9fDvprk1vcPg+u+mfSbpziaobwsec4r7M7bj+I47Bio42LCvXtobc7yW+Hkvpv6J8VwsKcjLoqssWm9xaez2Lj8PGwseNOPVGEYrWkZG/0/g1vLc1x/F48rsvJrrUVv9T0Ty57+2z2l7+DT8/1JxPD0Ssy82mtpb1KR476j+vXEcXXdjYVlVliTSlGzzs+YOv/AFT53qLKt7cy6FUm9Laa0bmFvlzyzke8+sHr5VjK7C4i5SfmPdXNHzF1d1by3UWXO7LyrZKT3qWjQ5F9t9jsum5yfu2RnWYyONytCsIym9Ri2zJwcG7KsUYRem/fR0/H8Tj4Vf1clx2lvTOXJz44f+X0uh9K5uqu/GP257G4nKu1/wAKaT/BPmcJdjY/1Zp+2/Y6GHNYcMiNNdcffW0zM6icbuJ74r3gzy3qOSZSWalffw9E6LLp88sM/dljHnT8NovU5a1vwW2f9ZJF1UHOSikfRfjbO66uDnJRS3s3nG4ca4qc159y3jcJQipSXkm5DJjTU4p6eiyOmOOu9YXL5On9OL/BqGy+6bsscm9lhLXO3dU8vwkb3p/iJZM1ZZFqKfyY/T/HvLyFtfpTOo5HKp4rC+lDSn268Hk5+a79mPl+i9I9NwuN6rqP8J/+0XMZ1PHYn0aWu7t14OMyr532uc222y/OyrMm5zlJtNmMdODhnHO/l4vVPUsusz1O2M8RUtseov8AYuIrpbXaju+XjFaVrb37k1ddls1GuDlJ+yRHUtQ8nY+ltPH2c7VPkHWqo2Lff7aIXvXPQ4blpa7ePue/bwe8/wAPHSOTxkrOb5OmWNGqUbE5rXg6u7qr054zGphLC4+yyEfL735/5nEeovq9h3cbPjuBpjjQlBxf0p7Rm21rUndy/wDED1PLl+op41V/fVTOUVp+NHlckmkZGZk25mTO+6blKb22zGa1LW9mtaSXd2uS9iLIbT1smh+TGyHuYIjAAaAAAAAAAAAAAAAAAAAABPjv3RI/K9jHplqRk7/UGatjtLT+CpRt9zf3KiJkqgzYcJxOVytzqxa5Tl9ooyOX6a5fjJtZODdBJ+8ol2jTFt39K0iWcJR94tFr12taJSVZU9xX3LiGL7ZtE5YuUULoylCW4PTLQGW54rqTkuPkvp32NL4R2vBeoEH2xzYd33cpHmIK1M7H0dwfUHDZkIzhk01Ta3rZ02Fm9+nTkd37Hypi52VjSUqr5R19jo+K645TD0vrWyS/KDrOX7fVXE9RZuHKMXKfb+52fEdW1yUfrSXn7s+WeB9U61GMMyCb+8pHa8R19xWR27uqhv8A7xNSuszxr6Xw+YwsiK7b4bfxs2NVtc/6Zpni/TfUPE5MIqHJUxk18M7LjMiybUqOR71+DncV7O+iSRZocDLyIJd8pWG0oyXY/wCho52DPiSQ+CCEtong/YzRIi4tRUguSLki1F68APkqPAQQKr8FCqaArL9XiT2RTx6Z/wBVaZIFJAQLBw/nHiXQw8WL3GiKJdossvqri3Oail7thFyrhH+mKRc3LXuaDl+ruC42EpX8jRFxXs5HnnU/rn09xcbPp349rj9rCzG03I9dtnGtOVjUUvlnP871jwPEUTsyeQx4uK3qUtHyt15/EXmZkrKuNc64vaXZNHjXU/X3Pc5OTuzrlGT9m0dJx/bGXJPh9Seo38QOBiQsp4yyuUltJwsPnrrX1g6j52dlay8iFUvGtrWjza2222XdbY5t/LLDpMZHK52p8zLyMu12ZFsrJPztkAL6a5WzUYJtv7FvZmS5XUWxTk9JbZueG4a3Ikp2xcYflGy4ThIwrWRkaSXnyi7l+YqxoOjG0mvG4s8mfNc77eN+k6X0rj6fj/sdZdT4n2nyLsLi6O2vsdiXw/JznI8vkZMmu+Sj9jCyci3Iscpyb2yJxkvdeDpxcEx73vXj671bk5/04v1w+okoscb4WN+U9nd0y/munpyb9qzz/fk7ngZ93B2Q3/2Zy6udpXu/jfJ/ycnHfFlcXetZNi/Jt+Kxq3BTetms5GPZmWf+Inwcz6UWmz2YXtH57Oe3ksv23WTfCmp+Uno57MyJXWPb8FczKldN+fBjGrWMsthWEXKaivdlDZ8BhSycqL7XpM555TGbrp03Blz8s48fl0vT+PHD495EvD7dnM9QZssrLl+raTOl6ivji8dGmL0+1o4icu6bk/k8vTY+7K8lfo/Xef8ABx4dJh4k7qIFAe1+VVb8EC/VZ+xLZPtiyylPy/uRudolXsSUX3US3VNwf4LsbEycjf0KZWa99Isuqspm42wcZL3TKyvuyL7nu2xyf5IXrf5GwEH4Xgtjt+5dJPX4EVrRGvEV2owbf2MSb3JsyMh6hoxQ1PAAAoAAAAAAAAAAAAAAAAAAKrw9mVBpwT+TEJ8drymEsSS9l49gvKKvwWp+dfYM+Y630456jgeVjkXwjOO1tN6PfsLr30/53HjVyeFgRm15c5v/APJ8qk+FXddk11U77pPS0LNky0+q8z0z6R6k4nI5DhHidsK3Z/wk3pHzP1pxsOI57IwoNNVz14PpnoKdnSnpPZkZVzjbkYbilLw97Pl7qbOnyPOZOVOTk5y3szi1lrTUWpqSkSQkmhJJp7Iq32yaZpPMTlCqYZWFAAAAADS3vRNVk5FX/V2yj+xCANvhdR8vhtSpzLYtfbR0vE+qfU+DKKWdkuK/KODK7Y01MrHu/T/rvyNHasqdk/v3TR6Dwf8AEHxyjFZEa9/O7D5H8fYb17GfbFnJX3Txfr703b2xtljR397DpeP9YOk8prefiV7/APmH56Rtsj5jNpksM/Ph/RlziS4RqctfpJi+ofStyThy2I/2kbHH6u4C7+jksd//AFH5sYvUXM4/9Gfa/wDY2uJ191DjpKOdf/ujP44v5X6NLqThG/8A+Qo/8xNDneKn/Tm0v/U/OmPqV1In/wDvcj/dGZT6rdS1pL+byP8AdD8a/lfoVPnOKityzal/qRrqThV78hQv9T8+bvVfqWxa/m8j/dGJP1L6kb//AHuR/uifjPyv0Nv6r4GqO5clj/8AmNfkeoPS9CbnyuKv3mfn3keofUV8e2Wdf/ujV5fVHNZKaln3ef2L+NPyvv3kPWLpLDUtchiWa/8AmHL8t/EN03SpKmWM2vtYfDNmfyFm/qZc5b+5BKyyX9U2y/jiXkr616g/iPpamsRxX27bDzTqb196iy++OJkZEIv/ACzR4noexqYyM++uq5fr/qTlJSldyGR+r3TaOeyc7LyW3ffKe/uYwKzappfCCZsOIwnlymtexj8hQ8fIlW1rTMzOXL2u+XTcmPFOWztUAKIqbecN90jiK7J7px2k0aKKcpKK92dlwdccHjpXz8Nx2jzdTnrDU+X2vQunnL1Mzy/xx71Tqfkv5ev+WqevjwcfbOVknKT22ZPMZTysyc29rZHhUu2xL3WzXBxezGOXq3XZdX1Fu+08JcHFlZJNrwX8lCNa7UkbeipVwSSNRy73b/qemzUfOs1GvTO16YTlx84/eJxXydf0tnUV0qucop615Z4+rluHZ9v+O5YY9V+112aPnceyGZOTg0tms2ejZWHiZq3uEtmozem4tN1+P2Rz4uqx1Jk9nqH8e57neTi7yuQbGza5PCZNTfbCUtfgu43hci65KyuUVv5R6fzYa3t8Oem9TeT2ey7YWDhW5VqjCL037nc8Jx8cDEdk1+rW/Jfx/H42BUpS7U0vc13UHOQhXKmmSe1rwzwcnLlz324+H6/oug4PSOP8/Pf3aPqfMd+XKCfhM0pLdY7bJTk/LZEfR48PZjI/FdX1F6jmy5L8hUoUslqPubrzxZP9U0kZOJRZfbCiqLlOT0kjHpXnufk2XCZccLk6cmUe5Vy3ojV+n0T6NdD8TxXC/wCJ9R11Rrsip/8AGTS0ZnWHpl011Sp3dOZGMpvf6aU35PKOqfUzL5HgquMxpTqhCtw8SIfSnq3qHE6gxsfFvvsjZYlJR0Z1V3PDD619M+e6blOy7FvlStvvcNLRw0ouM3Fryvc+v/W7qDG/9ntEcuuKyrMWW+5+d7Z8i3NW5Flnsm9ostsTKavZD3Peivn3KtL/AFKSl2wZT50x75d0tfYiKye5NlA0AAAAAAAAAAAAAAAAAAAAABdXLtmn8FoAzZNS8rwmWSXnaKUPujr7F8l4DHiiT0d96KdP0831PV9e1QhVOMnte/k8/jJ619ja9P8AO53CZH18K6dcn7uIPFe8fxEdRY3GcfT0/gWx1TJwfa/jTPnSTcnt+7Nl1DzWbzmZLKzbZ2TlLbcjWCTUMruhDanvaJyjXctFpKsqe0XkXmuevgmXlbJKZRQAFZAAAABQKoAgD3KFQCD9yqKfID2KplPkaAr8gAgBlPkqAKJB+42UVKe4Y+AHsB8Be4DYfkq4v30XY8HZfCGvd6J4axnusjrujcX9Dm17o1nV+M68yU0vDkdb0/RHHwYb8PtIed41Z2nHz/ofKx59c1yvh/Q+f0m5+l48WM/by8+pptt/6uDl+xSyuyt6nBx/c7nGxMDjKU7uxy152R5GJx3IQcqpVqT+EeqdX38dnwL/AB3KYa989/05jhMSWTlw0m0n5N51Jkxow4Y0HppaZn4mFTxmNZbtb1tHIcvlSyMubb2t+CY38/Jv4jpzcf8A0vovx3/PP/8AjDScpflm84nH7IdzXua3j6XZdF68JnRVwUIJI92MfmcJ8kl9jR8rVLvctbRvWQX0xti00asbym45hryX1WTre4yaM/LwJR24owJwlB6ktGLHLvjdxssLmciiS3KTSN7h9SVySjYl/qzjWF49jhn02Gfw+r0vrXVdN2mW49Gx8/DyPeUPP5L8nNw8StzThvX3PPKsi6v+mxorfl32rU5ya/J5v6Xfz2fan8qv4++H7NzzPOzvlKFUml+GaGycrJbk22Wj2Pbhx48c1H5nq+t5uqz9/JVAV9yht5BvRDJ909fBfdLS0W1Q+WRudksV4K6KFUVmmke8/wANPS+FbkWcxnWwcaJxmlJHg2jo+nusuX4PFsxsPIthXYtNRaJVxuq7f+IXqd8h1BPjsWz/AIFE5QSi/GjySUmtJGXyWddn5lmVkScpze22Yr0/KC+e6q86IslpLW9ku+1NsxLJd0mDH7WgANAAAAAAAAAAAAAAAAAAAAAAAAL6pdsvcyU9mGZFEm1r7BLF8lryv9Sv7DWy1eHphnzFS+uudklGuLk37JGRxOI87kKcVNp2TUUfRfp56T8VxuFVy3OXV/Sce5fVjpPQt0THbzP049LeX6n3N411cO1NPs3vyab1K6LzOkeUnjXQn2xn2puOt+D6On6ndNcBymPxHB1YyX1PpuVc/dHPfxG4tfL9O4vLRrXfY5TbX7MzLdtXGafL1q7lstqn/aybWlpkNkGn3I0ku0oLa57X5Lys2aUAARUoV/1KAXxg5ewdc17xYhJxaMym6qS1NL/ULJtgFUbP+Wpt/oa/0I58fP8At3/sXS+2sBgyZYVsf7W/9CKdFkX5iyJpGwmVcX8rRRoINhBFVrYAo/cmgoeN6JoVUyflpBdMIqkza14lMv7kZFeFR+GXTUwrSdk37RbL4UWy/sZv44tMfaKL41Vr2SHtX2NJXgWTflNf6GXTxmtOX/2NnGKXsitku2Df2LpqYRo+QrhV+laK8FS7c6t69pEHI2d970/Gzc9K0dvdfNeIrZw58vbha9npvD+bqscfhveZz1g4MIwepaMTE6ggsFubXf2/LNF1Hmu/JlBP9KZqodzaitnm4+lxuE9z7XW+v8vH1OX4r2k0zuU5K3Ltb7nrZBi5l+PJSjZIkrwZzhvT/wBiO7Esr/tbPXOOSa0/OZ9TzZcn5bbtm5PM330fTcpe2vc1a3OX5ZRpp+Voy+OodlqbXhMuGEx7RObqOXqMpeS7bPiaOytSa86NgWVxUIJLwXbOsJNKMog2Wt6W9lFLXFR/UaPkZQlY1FL3MzkspKPbF+TWb3uUnsxa5534RtJe5YXS8soRzUKhlAKgoCiqKSait7G9ENjcpdqMtSKpfUs38GRVXKclCC234SI649qMvjroUZdds0movYLXfYXpdyeT0vLmYV29sau/Xaee5lFmNk2UWRcZQemmfUXo36gcPyXCvpzKjSnbFVLukeX+t3QmVxnMWchiY83j3Sc04x8aJL37rce248oRX/UrOEq5ds4tP8lj8GqzCT8pFUi1Lb2Sa1Ft+CNX6RZE0o6+TGL7XubLA0AAAAAAAAAAAAAAAAAAAAAAAAAAAX1y7ZFgAzE9raLZL5+xZjzX9LJpfOgze1S8fk2YuVVlVtqUJdy0dtyPqX1Bn8TVxiyb1CKcdbRwUHraaJcaxV5ELGtpPZDw6fpfh+cyOfwsyzEvnCdqfe17nv3q7qn01wK7l2z+nJaf+prvRjrLpKXDU43J4+JG7Hr/AKpye29nI+v3XeNy+R/h3Gyh/L1Taj2S2taJ3tXtI8Ws05vRa/bRX4KP3NsIZJwlv4Jovcd7LZJS8Ee5Vy/BGvMTApGSkvBUrIAAgVKACWq+db8SZm0cg9pSNaCrLY6KnJpsXlovlXTZ7JHOwnKL8SJ68yyD92y7bmf228sKp/CIrOOg14SIaeS9u7/7mXXm1y+Uh2a/WsOfGv42Qz4+xe2/9jcxyKn/AHIuThL2aY1D2xoJYdy+GWujIT8RkdF2L5iHCH+VD2p7I0EIZUfiRNW8pP2kbnth/lQ7Yf5UNL7Wug8p+/cTwjd422Zekvgtk0vkul0Q2l5Ic+ztpf7E2/ya/l56gkL4LdRqJfrtf5ZvYZcMbjOyEl3SjpmhXvsuc5S8N7OGeHv06dL1V6f3XHzZpSyUrLHJ+7NhxuL3NSkiPAxHZJSkvBuqq1CKSOsjjjLbuqxgorSRSdcZrTRIDbbBtwISltJE+PRGleETsfBNJqBTZRvSLe7ZVVkzEzchVwaT8l+Veq4N78moslK+3fnWzNrOWWlr7rpuT3ojmtS7UT2zUI9sfcij4Tk/cy5LJJRX5LCspbbLQgAVAoVCRHbPX6ULVk2pbP4RWuOlv5Fdb/qkSeEiNW6XU1WXWRqqi5Sk9JI9I6I9KeZ5pV5GTj3UY8tPucPGjjOk83FwOYoycuuM64TTak/DR6zzvrNGvhq8HhqFR2wcd1zFt+Emvl6D0b0F0p0tlY+Rk8ljfzMWn2yWntHfeqV/TFnQ0rsj+Wk447dbb9z40y+suczOThlX59zUZb7W0bTqbr/kuW4evjpXWdkYOD8+5m41uZRzfU1lF3MXyxVFVd/6e320ap+fBWUn+7ZSKf8AuaZ8d10ERZE2v0pkk32xbMSTcntgxnyoAA0AAAAAAAAAAAAAAAAAAAAAAAAuhHuei6dTj7eSlUu2RkqSYS3TDfgGVZXGS8eGY8oNP2CqJ6ezKqkpQXnyYhdXJxkEs2ytbKe3hlYva2Un9wzPpNjZN2O39Gxw376LbrbLpudknKT92yKL+5d7sqXsqvPj5PWPRn0zv6om8jKplHGUVLucdrWzW+kfp7kdV8lW9T+kmnL9O1rZ7n1n1Hx3pj03/g2Aq1lKDqk4vT37mbfiNYz5rwr1n6QwumeWnTh3wmlZrUVrXg83nHuibzqrqHP5/kLMrLunPvltKTNP9OfbvtevuWJvuxk3Bk0JbRScdkSbg/wF8p34Ai01sF2zZoKlAEAAAAAFS5Sa9mWFUBIrbF/cyWvLuh7SbMbZdFPfhBd1mLPyPtIvWdd8pkMJ6XmsljbD5qRWt37SRy7n/ayRX5EvaEkW15Faf/UonWXHXilFan/lSLyX79xLCFjf6myNZE5PxDRPXKTXnYjUXxWvBquXb7tG3X5MfJx42+5aZTcaCMXL2WzYYOE5alNGbThVw86RlQSj4SJMWccPtbXXGtJJaJA0DTZsqwQX3qHhPyBLKaXgo5JLbMetuS75PRDfe5y+nD/kTabSznKyxRj7bLrrY01+Wt6InONFW213aNdfbPIn7tIm0t0pdZO+3S327EnGqGl7iU41Q7Y6bMac23tmXO1Xubl3MpOWy3YDKgKlABUeERWWfCG1k2utn2+EWVxcpdzKwht7kZOLj2XXQqqg5Sk9JIjVuljfg9d9Fuk+n+ooSo5DIohdJpQUl52cNyPR3L4XFxz7sW6Ncod23HxoxOk+Zz+G5nHyMa+cOyabih8JO17u59YPTDL6XullUU2TxJblGSjpaR5Yopf26Z9j8jmQ6u9J3bm1J2VYj1KXl+Wz5G52mOPy2RTD+mM9ImN2uU0wR7eWgiu9/HgqSD0/OiqWvL9iiIr56XamDzVl8+6Wl7IiADYAAAAAAAAAAAAAAAAAAAAAAAAAABLVPT0yIAZnxsNJr2IarPiRN7+V7BizXhDKrb8EcoOPwZRRpP3Q0syQ0z14ZP7lkq4tePBWtP2b9gXuNae/gqmvdB+RFJDweXqXoj6hPpXlYxvS+lJqLcpaWtnsfXfS/H+p2H/ivHZcHdZuzsrXc/sfJibUtrwzsej/AFD5zpvthjZNzrS12ppLRLPmEy+K7TE9COd/n1G5ZEalLy3X40dR1d0J0x030h2ZF+PLNjW01Jals5LM9dOetx3CCtjJrW1M8+6l6v5nnbZTy8u1qT32yaGrTcnhpMxQWVYoa7d+NEE47Rc229skoouvfbTW5v8ABrTMrEfdB+N6JITUv3Jb6bKpOF0HFr4Zjzg4y3EjXapQRws29PwSF2zYAAIAAAAABfGWvgsAGVXYn7oyq1GX9prE2mSxvnH2bLGpW2rqj8wJ4VRX9hp45tnj3J4Zk5f3MbbmUbVQiv7UV8JGvje9eZl6t+9hrbW4zO4qnsxFfBe80y9ZMfjQ2bZaKmMr4JbckiOzKbeoLf7Da7Zjko+7LXZv2MP6vjc5a/DIZ5EpPtrXj7obTbLvyFHwntsx4p931LH49/JFJxh+qb2/yY9t8rX2p6RNs2sm/Idj7K/C/AjKFEO6TTkYv1I1Lx5Zj2Wym/LJtn3J7rpWzfnwWSmorUSFMo2Rna5tvyy3YfsUCKlS0qvAD5D8LZbOaj8kUrJT8IjUxXTnt6iIV6e2XU1va8bZ0NfSnLT4z/EFjW/RUe7u7fGgu/pokjZ9N5tWBytGTdCMoQmm02a2yLhNwktNe5QM7fWvS3UfSXWfTFfC314lFyq+mn3NvbOZn6E93PQzaciTw/qdzar/AE6Pn3iOXzuKyI3Yd865Re/0nd0esnVFXH/yn8zkNdvbvuRnVnhv3S+XsPqh1JxHSXRi4HAupld9B1y7Xp7PlzPvllZdmRL3m9mXzvN5/M5Ur82+djk9/qNa2taRZNJf2Wve/Ben40USFjUY7Kn+opbJRj4fkxZNt7ZWcnJ7LQ3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmqt14ZCAMz3Wy6qPfJL7mPVP+1k6bj5TDOpL3Zz4y11d8E5L9jBnCUJOMlpm84HkYqSpu04vx5Ztc7iMfJ/4lTS39kea81wy1m+5h6Vh1XDOTpr3+Y4wqdOun4/5v+RfDp+t+8/+Rr+1xuM9C6u/Dldg7Onp/G3+qS/2MuPAceveUP8AYxeswj1Yfxrq8u+5HA7DTPQ4cFxj9nXv9jA53gqIY7nRFeFvwiY9bhbprm/jHU8XHc9y6cUdn6U5nFYvNpcrCqVU5Jf8R+Dj7YOE3F/Aq71NODakvbR6/L853xvd9HdaemfE9S8VLlenbK21F2OFMdnz7zvE5PE59mJlVyhOEtPuWj1b0O6i6ko5ajAVeRfiWyUJLfjWztf4iegq3xcObox/pWWNzmlH8MzvV01ZvvHzFZBa8e5HuUffZkzi4ScX7r3LJRUka0zMlK5qS8sv+CCVbXlFYzcdKSC62lHyIvuW0CxmzQCnyZmFg35M0oQk190iXKY963x8eXJl7cZusQHRT6dtWP3al3a+xpcvEux5NTg1+5jDmxz8V6eo9P6jp5LyY6Y4AOjxKpl0d/csK7Ak/X/nZclP/wCIyHuf3K90vuFZEJJeG9skU2/Yw09PZepsG2Wml5lMqrW/EI7/ACjGjOP9z2XfXjFfpSK1tOq5SfdObS/IsvrqWo6b+5hzvsl8tIjbb9wnu+kllkpvbZb3NexYXEZUk9lCrKACoGgD+BoNrRY7EvyRZNrm1H3LJ2LXj3LH3TfzovrrXz5DWpFkYyk9smjBJFUtI2PTtePby1FeTKKqc0pN+2glu1vT+P8AzfNYuMlv6k0tH0/1Vg4/B+ktEY4kZW24b8/O9sxOiPSjiuRfG8tx1kJ/T1OfZE73rrqXpLjONxuF5b+Uk6YOtqyWjFvduY6j40v4nlcq+y+rj7XCT34Rr76LqJuF9brkvdM+suO6v9M6Yqr+V4xxfjfe/wD8njPrZk9NZmb9bg1jRTbbVT2alZuPZ5cPIS8e5a214RpmTZJ/C9ysV48iMfll/iK2/Yi/6i2UlFeTGsm5P8Fb590vHsRhqTQAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPVZtdrICqensDMhJxkpRemjYVcvk1wUVOXj8mrjZHsXtsopr7mbjMvMb4ubl4b+l0275rK/zS/3Kf4zlf55f7msjKL+UJyivZk/Hh9Ov97qf/nWz/xrL/zy/wBx/jOX/nl/uapWx/AU4v2aH48Po/u9T/8AOt1i83kxuj3Sk1vz5OxwcqvOw9bTbj7Hm6Nx0/yMsa+MJS/S/Hk8/UdPMpvF9n0f1nPi5fx813jTqTBlRlSkovtbN96RYXE5vO/T5adUKu5eZ+xk8nj18hhOyKTet+DipTycDKl9Kcq5J+6NdNye/HV8x5/W+g/rc35Mf8cn1LyXUnQ3ReMnx8cG++K0nGTT2eVeovq9ndRY8sOKlGnyklPa0eWZWblZUt5F8rH+THPTMXxLkusk52Ob92WgqisKFXGL90i76Vmu7sevuWk3trVx8qaS9isYuT1FbZWEXOSjFbbOk4Dhm3G66L17+UY5OScc3Xr6LoeXrOSYYRi8NwtmRKM7ItR9/Y6vGxsPArXd2Jox8/kcbj6nXDtUkte5yfI8tfkTepyS/c8Pt5Oov1H6v8vRejY6x/bN2q5XEdnZ3w1+5Zm4OJn1tw7W39jz5X2qXd3vZtOM5m/HsXdJtb+WXLpLh3wrnxfyTj6i/j6nDtTluGuxptwjJx39jUyjKL1JaZ32LyWHnVqFnZt/dkWRwWNdZ9SDj2734RrDqrj25I49T6Bhz/8AJ0mUsvw4eNc5f0xbMqjjcm3/ALOSX7HXSwuNwobk6219zVchzFFacKIR/dM6TqMs/wDCPJn6Nw9LN9Ryf/UYf+Exrpc7LNNL2aNRclGxqPsmT5GbkXN7nJL7GM9t7Z3wxynfKvkdVycGWpxY6igAOjxgKgCgBVeQKFfge3uHKK+UF0As+rFfYjdjl4SJtfani152yOdi348lqhNry2i6FaXl+QupFjlOXwy6Na158skSWzO4XjreT5GnDpTc7Zdq0ge76YlNM7JKFcHKT9kjo+P6K57LwZ5cOPv+nGPdtR8HtvQfpPg8HhV8x1FNRqcVYldHSaR3/TfWXQ+Rkz6dx8fBX1GqlKMn5M3L6WY/b40zMe3FyJ0XQcZRemmRwcoPui9NezPZv4guhJ8TyEuUw6W8e6TmnGPjR4x+/ualYs09x9APUrK4rlMbisq9umycYfql40b7+J3gI2YlPP49/dG6MrfC8Hzxx2VZhZtWTVJxlXLaaOv6n9QOR5rg6eMyJzlCutwW5E1321Mu2q4qNtuk1Y0UnOcv6ptlqaWkyklv29ipIp3b9i5Iqo+PYOUYJ7a2Dz2ik2ox2Y9lrktfBSyblL38Fgak0AAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACu39w237soAAT0ABPRPfhkybjLaflGHF6ezLgtwUt+4Zv3HWdMcl3QVFsvjXllOp+NUo/Xqj7+fCOaxb5UXRnF60zt+JzKuQw1VPTlo8HNheLP34+H6703qMPUenvS83+U8OCknGWmtMrGEpPUU2dXmdNSsypWRk1Df2MijjMHDinbODa+52vV4a7Pm4/x7qffZn2k+a5nC4zKyJpfSkl99HQYHT1cNSvev3RLlc3h4sOymuva8bTNNl8/fa32tpfhnO3m5fHaPZhx+mdB/nffk6n/AA/jPp/T769+xquQ6fhPcsfz+yOc/wARyfqd/wBWXubTj+oLatKzcl+WZ/By4d8bt1/6r6d1f6cvH7Z9s7ieCVU/qXr2+6MzluSpw6HVU47S14ZrM/qN2VuNSS/ZnPZGRZfY5Tk3suHDnyX3cjPUeqdN0XFeLo/N+V2blWZNrlKTe2Y5V+4Sb0kttnukkmo/KZ55Z5XLK9wHpXpr6Vcr1dRO6uF0IKKknGG9+Tm/UHpLJ6T5azByO9uM+3clr4LtnVc7TfZVJOEmtGxp53Lrr7O6T8fc1IMZceOXmPRw9XzcP/bysZeTn5GQ33Tl5MScteZe5dF6ZS5KfsWSTtHPPky5LvO7Ru2PxoqrI/dFqrRR079is9l/1I/dD6kfuiz6D+7KfS0wvZI7I/gp9VFPprXsIVr5CdiVi+CinNPxFkjhH3WiqS+wNxDKU5P2aLo1Sa25MzsTj8vKjKWPjSsUfdpexDbXZTY67IuMl4aYPch+kisYpfBczYcJxGZy+SqMSmdkm9fpRU3awYxc5KEY7b9kb+rpHmZ8a894dypUe7u7fGhyHTvK8Fl125mFbGEZbfctH0l0fDC5v0mujVi1/VrxPLXl72Zt0sm3ydbCVdsq5LTi/JtukM//AA7qLCyn7V2qTIuqMd4vO5dLjpxnrX+hroycZKSemi+WfD6965zb+pPSii3BulF1YknJQ8/LPlnA5HN4bqCOQrZq2mzbfzs6fhvUjPwOnrOJfdOudfZ/UcNyGQ8rMsyGtOb2STTWV2+senOoOA619PbaOZyqI5FOPqPe9vbZ8xda4mNhdQ5VGHOM6o2ai4+2tGFhctyWHVKvGzLK4S8NIw77rLrXbbY5zk9tsSaS3aiKSevYpt/BVIprS3t29svSKrx7kVlqW1EHeq2WqPhe5jzk5Pyyje3soGpNAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE1E3/SQlYvT2BlmdxWfPDt7k/BgRfdFMEuMymqcXLnw5zPC6sdFl9R3zjqttfszUZHIZNzblZLyYhctfcxjxYY+I9XP6j1PUf55VSTcnuT2ysYPWw15KuT7dHR4fN7rQWva8lYtP3G10qACspMai3IujVTBznJ6SR7H6U+kuZyFtfI8tVZTix1NucPGjnPR7J4HG5WF3LqhqEk19Q9M9TfV/Bx+K/wvp2FVUdOHdTP4M3bck816FxXWvTXSHJ4nAcZ/LOTmqpSjLT+5wH8UfCV5mLTzdEd/Wk5tpfhnhGDzeZZ1HRyF905zVql5Z9Q8hhz6s9JI5Dg5ypxHL7/ACZ1qtS+6afIKTSW/cGZy2NLF5G6iS04S1oxGdHJQAAVSKlEVAqvMfctKuaXgEWzspooVYRUUOy9Peh+R6n5CqNVNv0e5d0lHa0caehdC+oNnTPH2U0VL6jhpS7tNEu/hY9/6b6c6G6QwK8Pl54c8i2PbL6q00zkPVH0mxeVxp8z0yvrQmnNRphtHi/N9Tc51LzKn/MXOc57jFPej6d9LMvO6c9PpZ3OynKtY3dGNvhPTMXc7uksvZ8lc3w3IcRkyozseyqUXr9SNz6c9R1dPcrDIupjZHvT/U9Gf6udTY3UPUGRbi0QrgrG12vfwcMjfmOfi9n1pxXU/QnWXFrFz6sGi+cdJuTb2zsvTzpTCwcTOoxMxW4l0UopLwkfEWLm5eJZGePfKtr20dv096q9ScTj/RjlXzWtf1IzcW5nPlb668RHi+t8xV+Yyufx+DgX7m56r6gy+oM+WXluTnKXd5ezT7WjU7MXvVNb+A1peS3ue9IuflaY2uvtRvx4RSKbfkuitLRckktt6Bv6NePCLJTUfctsvSbUTHlJye2Fk+0llrl7EQAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLTZ2+H7Eqthp+xigGkk7W348FvdL7stAEsLWvD8ksbIyXwYpVNr2CWbZfv8DtWyCu1x8MmVsGl7bCas8DT34LnKKhrXkaT+diUfugm/shbKHmE3F/grOcpvulJyf3LHEppr9galSUzddsZr+17PVulfVnK4rpq3h5Q3XOn6fmf5PJU9fBWL29NDySWeGfzuYs/krcqMUvqS34MFlXpL3LUyxAFfkNDaCKlUWWTSiyLJtFZLU1+5NB7RiSe3slpnrww3Z2ThD38oow5nyULvgtfgo7f0ly+Jw+oKbuUVTrhYn+t+D0n1p9S8PO4SvieHnXCmMHDVcvGjwGFjg9xlplbLZz8zm5fuSyNS3SkpOUnKXlv3YS+xapL7FE38DZ7VzaQUi3tbe2XpJIHaLZbfsIr7su0V/Sk25IG6tjHb8eS5rW9+CKV6i/0oistlN73oLr7SztS8IhlZKXyWANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvjZKL3slV+/dGOAMuNkZPW0i9peyezCTa9i5WST9wntZXb+CjX+hCr2iSF0dfq0E1Yu7fHuUS0w7It+GVTTW9g7mtFfAT387DQZWWNpfpRjyct+TL0WWQUl7eQ1KxQisk09Mlph8tBpWpz9vJPpa/JboqGLdnuWy3ou7X7lrf5BBRTiVS0U74r5RdC2tJ70wvc1+AkR2Xr+1Iidsge1ltRS22RStivbRjucn7stC6iadzfheCNyk/dloCgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAK7HdL7lABfGyUSWNyfuY4AzU1JbTD9kYtc3F/gyYyTQYsRWRbmnrxslj4SWi5JSXt7FPYF8BZOyMfsyy6z4iQMLImlfJrRG5yfyWgNK7f3KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlpl50RFYvUkwMyLaKWeIN/crXqUd70Q5E/wC1fAZk7oX5ZQANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC5Skl4bKN79ygAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q==' style='width:18px;height:18px;vertical-align:middle;margin-right:5px;'> Zoan-Task | discord.gg/zoan")
UpdateRecordButtonState()
UpdateGeneralSettingsDisplay()
; Force correct window size directly - no timer delay
try {
    WinGetPos(&winX, &winY,,,  "ahk_id " . neutron.hwnd)
    WinMove(winX, winY, 350, windowHeightFull, "ahk_id " . neutron.hwnd)
} catch {
    try {
        neutron.gui.Move(, , 350, windowHeightFull)
    } catch {
    }
}
; SetTimer(() => InitializeUIState(), -100)

ExitAppF(*) {
    LogDisconnect()
    ExitApp()
}

LogFileInit()

PauseFunc(*) {
    Pause -1
    if (A_IsPaused) {
        ToolTip("Paused")
    } else {
        ToolTip("Unpaused")
    }
    SetTimer(() => ToolTip(), -1000)
}

ShowDrawmenu(*) {
    MainGui.Show("w185 h70")
    try {
        CanvasGui.Show("x0 y0 w" . A_ScreenWidth . " h" . A_ScreenHeight . " NA")
    }
    try {
        WinShow("ahk_id " . tempHwnd)
    }
}


ExportEvents(*) {
    global recordedEvents
    
    if (recordedEvents.Length = 0) {
        return
    }
    ;selectedFile := FileSelect("S", A_ScriptDir "\..\..\recording.txt", "Save Recording", "Recording Files (*.txt)")
   parentDir := RegExReplace(A_ScriptDir, "\\[^\\]+\\[^\\]+$")
   selectedFile := FileSelect("S", parentDir, "Save Recording", "Recording Files (*.txt)")

    if (!selectedFile)
        return
    
    if (!RegExMatch(selectedFile, "\.txt$", &match)) {
        selectedFile .= ".txt"
    }

    try {
        file := FileOpen(selectedFile, "w", "UTF-8")
        if (!file) {
            return
        }
        
        ;file.WriteLine("# Zoan-Task Recording File | discord.gg/zoan")
        file.WriteLine("# Zoan-Task Recording File | discord.gg/zoan")
        file.WriteLine("# Generated: " . A_Now)
        file.WriteLine("# Version: 2.0")
        file.WriteLine("# Total Events: " . recordedEvents.Length)
        file.WriteLine("#")
        file.WriteLine("# Format: TYPE|DURATION|DATA")
        file.WriteLine("# Types: MOVE, MOUSE_DOWN, MOUSE_UP, KEY_DOWN, KEY_UP")
        file.WriteLine("# Duration: Time since previous event in milliseconds")
        file.WriteLine("#")
        file.WriteLine("")
                
        previousTime := 0
        for i, event in recordedEvents {
            line := ""
            
            if (i = 1) {
                duration := 0
            } else {
                duration := event.time - previousTime
            }
            
            switch event.type {
                case "move":
                    line := "MOVE|" . duration . "|" . event.x . "," . event.y
                case "mouseDown":
                    line := "MOUSE_DOWN|" . duration . "|" . event.button
                case "mouseUp":
                    line := "MOUSE_UP|" . duration . "|" . event.button
                case "mouseWheel":
                    line := "MOUSE_WHEEL|" . duration . "|" . event.direction
                case "keyDown":
                    line := "KEY_DOWN|" . duration . "|" . event.key
                case "keyUp":
                    line := "KEY_UP|" . duration . "|" . event.key
            }
            
            if (line != "")
                file.WriteLine(line)
            
            previousTime := event.time
        }
        
        file.WriteLine("")
        file.WriteLine("# Recording Statistics:")
        file.WriteLine("# Total Duration: " . (recordedEvents[-1].time - recordedEvents[1].time) . " ms")
        
        moveCount := 0, mouseDownCount := 0, mouseUpCount := 0, keyDownCount := 0, keyUpCount := 0
        for event in recordedEvents {
            switch event.type {
                case "move": moveCount++
                case "mouseDown": mouseDownCount++
                case "mouseUp": mouseUpCount++
                case "keyDown": keyDownCount++
                case "keyUp": keyUpCount++
            }
        }
        
        file.WriteLine("# Mouse moves: " . moveCount)
        file.WriteLine("# Mouse clicks: " . (mouseDownCount + mouseUpCount))
        file.WriteLine("# Key presses: " . (keyDownCount + keyUpCount))
        file.WriteLine("# End of recording")
        
        file.Close()
        
        UpdateGUI("Saved " recordedEvents.Length " events to text file")
        
    } catch as err {
        if (IsSet(file))
            file.Close()
    }
}

ImportEvents(*) {
    global recordedEvents
    
   ;selectedFile := FileSelect(1, A_ScriptDir "\..\..\", "Load Recording", "Recording Files (*.txt)")
   parentDir := RegExReplace(A_ScriptDir, "\\[^\\]+\\[^\\]+$")
   selectedFile := FileSelect("S", parentDir, "Load Recording", "Recording Files (*.txt)")

    
    if (!selectedFile)
        return

    try {
        file := FileOpen(selectedFile, "r", "UTF-8")
        if (!file) {
            return
        }
        
        newEvents := []
        lineNumber := 0
        validEvents := 0
        currentTime := 0
        
        while (!file.AtEOF) {
            line := file.ReadLine()
            lineNumber++
            
            line := Trim(line)
            if (line = "" || SubStr(line, 1, 1) = "#")
                continue
            
            parts := StrSplit(line, "|")
            if (parts.Length != 3) {
                file.Close()
                return
            }
            
            eventType := Trim(parts[1])
            duration := Integer(parts[2])
            eventData := Trim(parts[3])
            
            currentTime += duration
            
            switch eventType {
                case "MOVE":
                    coords := StrSplit(eventData, ",")
                    if (coords.Length != 2) {
                        file.Close()
                        return
                    }
                    newEvents.Push({
                        type: "move",
                        x: Integer(coords[1]),
                        y: Integer(coords[2]),
                        time: currentTime
                    })
                    validEvents++
                    
                case "MOUSE_DOWN":
                    newEvents.Push({
                        type: "mouseDown",
                        button: eventData,
                        time: currentTime
                    })
                    validEvents++
                    
                case "MOUSE_UP":
                    newEvents.Push({
                        type: "mouseUp",
                        button: eventData,
                        time: currentTime
                    })
                    validEvents++

                case "MOUSE_WHEEL":
                    newEvents.Push({
                        type: "mouseWheel",
                        direction: eventData,
                        time: currentTime
                    })
                    validEvents++
                    
                case "KEY_DOWN":
                    newEvents.Push({
                        type: "keyDown",
                        key: eventData,
                        time: currentTime
                    })
                    validEvents++
                    
                case "KEY_UP":
                    newEvents.Push({
                        type: "keyUp",
                        key: eventData,
                        time: currentTime
                    })
                    validEvents++
                    
                default:
                    file.Close()
                    return
            }
        }
        
        file.Close()
        
        if (validEvents = 0) {
            return
        }
        
        recordedEvents := newEvents
        UpdateEventCount()
        
    } catch as err {
        if (IsSet(file))
            file.Close()
    }
}

UpdateSessionInfo() {
    /*
	global neutron, eventCount, activeKeys, lastAction, messageBoxText, playbackKeys
	
	neutron.doc.getElementById("event-count").innerText := recordedEvents.Length
    */
}

clearRecording(neutron, event) {
	global eventCount := 0
	ClearRecordingAHk()
	UpdateSessionInfo()
	
	; statusText := neutron.doc.getElementById("status-text")
	; statusText.innerText := "Recording Cleared"
	; SetTimer(() => statusText.innerText := " Ready For Input", -1500)
}

saveRecording(neutron, event) {
	ExportEvents()
	; statusText := neutron.doc.getElementById("status-text")
	; statusText.innerText := "Recording Saved"
	; SetTimer(() => statusText.innerText := " Ready For Input", -1500)
}

loadRecording(neutron, event) {
	ImportEvents()
	UpdateSessionInfo()
	; statusText := neutron.doc.getElementById("status-text")
	; statusText.innerText := "Recording Loaded"
	; SetTimer(() => statusText.innerText := " Ready For Input", -1500)
}

ClearRecordingAHk(*) {
    global recordedEvents := []
    if (recordedEvents.Length = 0) {
        return
    }
    
    UpdateGUI("Recording cleared")
    UpdateEventCount()
}

RecordButtonInvalid(neutron, event) {
    global playBack, isPlaying
    if (playBack || isPlaying) {
        return
    } else {
        toggleRecording(neutron, "")
    }
}

InitializeKeybinds() {
    global HotkeyDefinitions, CurrentBindings
    
    HotkeyDefinitions := [
        {name: "Record", label: "Record", default: "^r", type: "Hotkey"},
        {name: "Play", label: "Play Once", default: "^p", type: "Hotkey"},
        {name: "Loop", label: "Loop Playback", default: "^l", type: "Hotkey"},
        {name: "Stop", label: "Stop Playback", default: "^s", type: "Hotkey"},
        {name: "Exit", label: "Exit", default: "^d", type: "Hotkey"},
        {name: "Pause", label: "Pause/Unpause", default: "F2", type: "Hotkey"},
        {name: "Autoclick", label: "Auto Click", default: "^h", type: "Hotkey"},
        {name: "Drawmenu", label: "Draw Menu", default: "^g", type: "Hotkey"},
    ]
    
    CurrentBindings := Map(
        "Record", "^r",
        "Play", "^p", 
        "Loop", "^l",
        "Stop", "^s",
        "Exit", "^d",
        "Pause", "F2",
        "Autoclick", "^h",
        "Drawmenu", "^g"
    )
}

LoadKeybinds() {
    global CurrentBindings, HotkeyDefinitions
    settingsFile := A_ScriptDir "\..\..\keybinds.ini"
    
    
    if !FileExist(settingsFile) {
        SaveKeybinds()
        return
    }
    
    try {
        content := FileRead(settingsFile, "UTF-8")
        lines := StrSplit(content, "`n")
        
        
        for line in lines {
            line := Trim(line)
            if (line = "" || SubStr(line, 1, 1) = "#" || !InStr(line, "="))
                continue
                
            parts := StrSplit(line, "=", , 2)
            if (parts.Length = 2) {
                key := Trim(parts[1])
                value := Trim(parts[2])
                if (CurrentBindings.Has(key)) {
                    CurrentBindings[key] := value
                } else {
                }
            }
        }
    } catch as err {
    }
}

SaveKeybinds() {
    global CurrentBindings, HotkeyDefinitions
    settingsFile := A_ScriptDir "\..\..\keybinds.ini"
    
    
    try {
        content := "# Zoan-Task Keybinds Configuration`n"
        content .= "# Format: action=hotkey`n"
        content .= "# Use AutoHotkey hotkey format (e.g., ^r for Ctrl+R, !a for Alt+A)`n`n"
        
        for hotkeyDef in HotkeyDefinitions {
            hotkeyName := hotkeyDef.name
            hotkeyValue := CurrentBindings[hotkeyName]
            content .= hotkeyName . "=" . hotkeyValue . "`n"
        }

        if FileExist(settingsFile)
            FileDelete(settingsFile)

        FileAppend(content, settingsFile)
        
    } catch as err {
        try {
            ; handled
        } catch {
        }
    }
}

UnregisterHotkeys() {
    global CurrentBindings, HotkeyDefinitions
    
    for hotkeyDef in HotkeyDefinitions {
        if (hotkeyDef.type == "Hotkey") {
            hotkeyName := hotkeyDef.name
            if (CurrentBindings.Has(hotkeyName)) {
                hotkeyValue := CurrentBindings[hotkeyName]
                try {
                    Hotkey(hotkeyValue, "Off")
                } catch as err {
                }
            }
        }
    }
}

UpdateKeyBindings() {
    global CurrentBindings, HotkeyDefinitions
    static previousBindings := Map()
    
    for hotkeyDef in HotkeyDefinitions {
        if (hotkeyDef.type == "Hotkey") {
            hotkeyName := hotkeyDef.name
            
            if (previousBindings.Has(hotkeyName)) {
                oldHotkey := previousBindings[hotkeyName]
                try {
                    Hotkey(oldHotkey, "Off")
                } catch as err {
                }
            }
        }
    }
    
    for hotkeyDef in HotkeyDefinitions {
        if (hotkeyDef.type == "Hotkey") {
            hotkeyName := hotkeyDef.name
            newHotkey := CurrentBindings[hotkeyName]
            
            if (newHotkey != "") {
                previousBindings[hotkeyName] := newHotkey
                
                try {
                    switch hotkeyName {
                        case "Record":
                            Hotkey(newHotkey, (*) => TriggerNeutronRecording())
                        case "Play":
                            Hotkey(newHotkey, (*) => PlayOnce())
                        case "Loop":
                            Hotkey(newHotkey, (*) => PlayLoop())
                        case "Stop":
                            Hotkey(newHotkey, (*) => StopPlayback(A_LineNumber))
                        case "Autoclick":
                            Hotkey(newHotkey, (*) => AutoClick())
                        case "Drawmenu":
                            Hotkey(newHotkey, (*) => ShowDrawmenu())
                        case "Exit":
                            Hotkey(newHotkey, (*) => ExitAppF())
                        case "Pause":
                            Hotkey(newHotkey, (*) => PauseFunc())
                    }
                } catch as err {
                    try {
                        ; handled
                    } catch {
                    }
                }
            } else {
            }
        }
    }
}

RegisterHotkeys() {
    UnregisterHotkeys()
    UpdateKeyBindings()
}

PlayOnce(*) {
    global playBack := true
    playEvents(neutron, "", false)
    global playBack := false
}

PlayLoop(*) {
    global playBack := true
    playEvents(neutron, "", true)
    global playBack := false
}

Join(arr, delimiter) {
    result := ""
    for i, item in arr {
        if (i > 1) {
            result .= delimiter
        }
        result .= item
    }
    return result
}

ParseHotkeyKeys(hotkeyStr) {
    keys := []
    
    if (hotkeyStr == "" || hotkeyStr == "None")
        return keys
    
    if (InStr(hotkeyStr, "^")) {
        keys.Push("LControl")
        keys.Push("RControl")
    }
    if (InStr(hotkeyStr, "!")) {
        keys.Push("LAlt")
        keys.Push("RAlt")
    }
    if (InStr(hotkeyStr, "+")) {
        keys.Push("LShift")
        keys.Push("RShift")
    }
    if (InStr(hotkeyStr, "#")) {
        keys.Push("LWin")
        keys.Push("RWin")
    }
    
    mainKey := hotkeyStr
    mainKey := RegExReplace(mainKey, "[\^\!\+\#]", "")
    
    if (mainKey != "") {
        if (StrUpper(mainKey) == "R")
            mainKey := "r"
        else if (StrUpper(mainKey) == "P")
            mainKey := "p"
        
        keys.Push(mainKey)
    }
    
    return keys
}

IsHotkeyCurrentlyPressed(hotkeyStr, triggerKey) {
    if (hotkeyStr == "" || hotkeyStr == "None")
        return false
    
    mainKey := RegExReplace(hotkeyStr, "[\^\!\+\#]", "")

    if (StrUpper(triggerKey) != StrUpper(mainKey)) {
        return false
    }
    
    if (InStr(hotkeyStr, "^")) {  ; Ctrl required
        if (!GetKeyState("LControl", "P") && !GetKeyState("RControl", "P")) {
            return false
        }
    }
    
    if (InStr(hotkeyStr, "!")) {  ; Alt required
        if (!GetKeyState("LAlt", "P") && !GetKeyState("RAlt", "P")) {
            return false
        }
    }
    
    if (InStr(hotkeyStr, "+")) {  ; Shift required
        if (!GetKeyState("LShift", "P") && !GetKeyState("RShift", "P")) {
            return false
        }
    }
    
    if (InStr(hotkeyStr, "#")) {  ; Win required
        if (!GetKeyState("LWin", "P") && !GetKeyState("RWin", "P")) {
            return false
        }
    }
    
    return true
}

UpdateEventCount() {
    global recordedEvents
    neutron.doc.getElementById("event-count").innerText := recordedEvents.Length
}

UpdateRecordButtonState() {
    global isRecording2, isPlaying
    
    recordBtn := neutron.doc.getElementById("record-btn")
    recordIcon := neutron.doc.getElementById("record-icon")
    recordText := neutron.doc.getElementById("record-text")
    
    ; Also update icon-only button
    recordBtnIcon := neutron.doc.getElementById("record-btn-icon")
    recordIconIcon := neutron.doc.getElementById("record-icon-icon")
    
    if (isPlaying) {
        recordIcon.innerHTML := "<svg width='14' height='14' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'><path d='M8 5v14l11-7z'/></svg>"
        recordText.innerText := "Playing"
        recordBtn.classList.remove("recording")
        recordBtn.classList.add("playing")
        
        if (recordIconIcon) {
            recordIconIcon.innerHTML := "<svg width='14' height='14' viewBox='0 0 24 24' fill='white' xmlns='http://www.w3.org/2000/svg'><path d='M8 5v14l11-7z'/></svg>"
        }
        if (recordBtnIcon) {
            recordBtnIcon.classList.remove("recording")
            recordBtnIcon.classList.add("playing")
        }
    } else if (isRecording2) {
        recordIcon.innerText := "⬜"
        recordText.innerText := "Stop"
        recordBtn.classList.add("recording")
        recordBtn.classList.remove("playing")
        
        if (recordIconIcon) {
            recordIconIcon.innerText := "⬜"
        }
        if (recordBtnIcon) {
            recordBtnIcon.classList.add("recording")
            recordBtnIcon.classList.remove("playing")
        }
    } else {
        recordIcon.innerText := "🔴"
        recordText.innerText := "Record"
        recordBtn.classList.remove("recording")
        recordBtn.classList.remove("playing")
        
        if (recordIconIcon) {
            recordIconIcon.innerText := "🔴"
        }
        if (recordBtnIcon) {
            recordBtnIcon.classList.remove("recording")
            recordBtnIcon.classList.remove("playing")
        }
    }
}

global UpdateGUIindex := 0
UpdateGUI(message := "", playbackKeys := "") {
    global currentlyPressed, isPlaying, recordedEvents, isRecording, guiUpdateThrottle
    if hideSessionInfo || isPlaying {
        return
    }
    
    global UpdateGUIindex += 1
    if !Mod(UpdateGUIindex, guiUpdateThrottle) = 0 {
        return
    }
    
    if (playbackKeys != "") {
    } else if (currentlyPressed.Count > 0) {
        pressedKeysList := []
        for key, _ in currentlyPressed {
            pressedKeysList.Push(key)
        }
    } else {
    }
    
    if (message) {
    }

    UpdateEventCount()
}

TriggerNeutronRecording(*) {
    toggleRecording(neutron, "")
}

global isRecording2 := 0
toggleRecording(neutron, event) {
    global isPlaying
    
    if (isPlaying) {
        StopPlayback(A_LineNumber)
        return
    }
    
	global isRecording2
    if (isRecording2) {
        isRecording2 := false
    } else {
        isRecording2 := true
    }

    ; statusIndicator := neutron.doc.getElementById("status-indicator")
    ; statusText := neutron.doc.getElementById("status-text")
	
	if (isRecording2) {
		; statusIndicator.classList.add("recording")
		; statusText.innerText := "Recording..."
        ToggleRecordingAHK()
	} else {
		; statusIndicator.classList.remove("recording")
		; statusText.innerText := " Ready For Input"
		ToggleRecordingAHK()
	}
    
    UpdateRecordButtonState()
}
SetCoordMode() {
    if recordRelativeToWindow {
        CoordMode("Mouse", "Window")
    } else {
        CoordMode("Mouse", "Screen")
    }
}

global recordingDurationMs := 0
ToggleRecordingAHK() {
    SetCoordMode()

    global isRecording, recordedEvents, startTime, lastEventTime, currentlyPressed, msHook, kbHook
    static recordingStartTime := 0
    global recordingDurationMs := 0
    
    if (isRecording) {
        isRecording := false
        msHook.Stop()
        kbHook.Stop()
        
        recordingEndTime := A_TickCount
        recordingDurationMs := recordingEndTime - recordingStartTime
        
        for key, pressTime in currentlyPressed {
            now := NowMs() - startTime
            duration := now - pressTime
            
            recordedEvents.Push({
                type: "keyUp",
                key: key,
                time: now
            })
            
            UpdateGUI("Released key: " key)
        }

        UpdateGUI("Recording stopped - Duration: " . Round(recordingDurationMs/1000, 2) . "s", "None")
        
        currentlyPressed := Map()
    } else {
        recordedEvents := []
        isRecording := true
        startTime := NowMs()
        recordingStartTime := A_TickCount
        lastEventTime := 0
        currentlyPressed := Map()
        
        ClearRecordingAHK()
        UpdateGUI("Recording started")
        
        msHook.Start()
        kbHook.Start()
    }
}

IsInputFromScript(dwExtraInfo, SendLevelMax := 100) {
    static KEY_IGNORE := 0xFFC3D44F
    static KEY_IGNORE_ALL_EXCEPT_MODIFIER := KEY_IGNORE - 2
    if A_PtrSize == 8
        dwExtraInfo := (dwExtraInfo >> 32) & 0xFFFFFFFF
    return ((dwExtraInfo <= KEY_IGNORE) && (dwExtraInfo >= KEY_IGNORE_ALL_EXCEPT_MODIFIER - SendLevelMax))
}

MouseProc(hook, nCode, wParam, lParam) {
    global recordedEvents, startTime, lastEventTime, currentlyPressed, isRecording

    static WM_MOUSEMOVE   := 0x0200
    static WM_LBUTTONDOWN := 0x0201
    static WM_LBUTTONUP   := 0x0202
    static WM_RBUTTONDOWN := 0x0204
    static WM_RBUTTONUP   := 0x0205
    static WM_MBUTTONDOWN := 0x0207
    static WM_MBUTTONUP   := 0x0208
    static WM_MOUSEWHEEL  := 0x020A

    if (nCode < 0)
        return hook.Next(nCode, wParam, lParam)

    msll := MSLLHOOKSTRUCT(lParam)

    if IsInputFromScript(msll.dwExtraInfo) {
        return hook.Next(nCode, wParam, lParam)
    }

    now := NowMs() - startTime

    ; Get the active window's position
    if recordRelativeToWindow {
        WinGetPos(&winX, &winY, &winW, &winH, "A")
        relX := msll.ptX - winX
        relY := msll.ptY - winY
    } else {
        relX := msll.ptX
        relY := msll.ptY
    }
    
    switch wParam {
        case WM_MOUSEMOVE:
            
            recordedEvents.Push({
                type: "move",
                ;x: msll.ptX,
                ;y: msll.ptY,
                x: relX,
                y: relY,
                time: now
            })
            UpdateGUI()
            
        case WM_MOUSEWHEEL:
            steps := (((msll.mouseData >> 16) ^ 0x8000) - 0x8000) // 120
            loop Abs(steps) {
                recordedEvents.Push({
                    type: "mouseWheel",
                    direction: (steps > 0 ? "Up" : "Down"),
                    time: now
                })
            }
            UpdateGUI("Mouse wheel " . (steps > 0 ? "up" : "down"))

        case WM_LBUTTONDOWN, WM_MBUTTONDOWN, WM_RBUTTONDOWN:
            btn := (wParam = WM_LBUTTONDOWN ? "LButton" : wParam = WM_MBUTTONDOWN ? "MButton" : "RButton")
            if (!currentlyPressed.Has(btn)) {
                recordedEvents.Push({
                    type: "mouseDown",
                    button: btn,
                    time: now
                })
                currentlyPressed[btn] := now
                UpdateGUI("Mouse button down: " . btn)
            }

        case WM_LBUTTONUP, WM_MBUTTONUP, WM_RBUTTONUP:
            btn := (wParam = WM_LBUTTONUP ? "LButton" : wParam = WM_MBUTTONUP ? "MButton" : "RButton")
            if currentlyPressed.Has(btn) {
                recordedEvents.Push({
                    type: "mouseUp",
                    button: btn,
                    time: now
                })
                currentlyPressed.Delete(btn)
                UpdateGUI("Mouse button up: " . btn)
            }
    }

    lastEventTime := now

    return hook.Next(nCode, wParam, lParam)
}

KeybdProc(hook, nCode, wParam, lParam) {
    static WM_KEYDOWN    := 0x0100
    static WM_KEYUP      := 0x0101
    static WM_SYSKEYDOWN := 0x0104
    static WM_SYSKEYUP   := 0x0105

    global recordedEvents, startTime, lastEventTime, currentlyPressed

    if (nCode < 0)
        return hook.Next(nCode, wParam, lParam)

    kbdll := KBDLLHOOKSTRUCT(lParam)

    if IsInputFromScript(kbdll.dwExtraInfo)
        return hook.Next(nCode, wParam, lParam)

    now := NowMs() - startTime

    keyName := GetKeyName(Format("vk{:X}", kbdll.vkCode))
    down := (wParam == WM_KEYDOWN) or (wParam == WM_SYSKEYDOWN)

    if (down && isRecording && IsRecordHotkeyPressed(keyName)) {
        return RemoveRecordHotkey()
    }

    recordedEvents.Push({
        type: "key" . (down ? "Down" : "Up"),
        key: keyName,
        time: now
    })

    if (down) {
        currentlyPressed[keyName] := now
        UpdateGUI("Key down: " keyName)
    } else if (currentlyPressed.Has(keyName)) {
        currentlyPressed.Delete(keyName)
        UpdateGUI("Key up: " keyName)
    }

    lastEventTime := now

    return hook.Next(nCode, wParam, lParam)

    IsRecordHotkeyPressed(keyName) {
        global CurrentBindings
        if (!CurrentBindings.Has("Record"))
            return false
            
        recordHotkey := CurrentBindings["Record"]
        
        if (recordHotkey == "")
            return false
        
        return IsHotkeyCurrentlyPressed(recordHotkey, keyName)
    }
    
    RemoveRecordHotkey() {
        global CurrentBindings, currentlyPressed
        
        if (!CurrentBindings.Has("Record"))
            return hook.Next(nCode, wParam, lParam)
            
        recordHotkey := CurrentBindings["Record"]
        
        if (recordHotkey == "")
            return hook.Next(nCode, wParam, lParam)
            
        keysToRemove := ParseHotkeyKeys(recordHotkey)
        
        for key in keysToRemove {
            if currentlyPressed.Has(key)
                currentlyPressed.Delete(key)
        }
        
        UpdateGUI("Record hotkey ignored (was part of hotkey)", "None")
        return hook.Next(nCode, wParam, lParam)
    }
}
    
global playBack := false
playEvents(neutron, event, looping := false) {
	; statusIndicator := neutron.doc.getElementById("status-indicator")
	; statusText := neutron.doc.getElementById("status-text")
	
	; statusIndicator.classList.add("playing")
	; statusText.innerText := "Playing Events..."

    global playBack := true
    UpdateRecordButtonState()
	PlayEventsAHK(looping)
    global playBack := false
    UpdateRecordButtonState() 

	; statusText.innerText := "Finished Playback"
}

global timer := 0
global shouldStopPlayback := false

UpdatePlaybackTimer() {
    global isPlaying, playbackLoopStartMs, recordedEvents, speedValue, neutron, playbackTimerActive
    if (!isPlaying || !playbackTimerActive) {
        return
    }
    elapsed := A_TickCount - playbackLoopStartMs
    seconds := Floor(elapsed / 1000)
    mins := Floor(seconds / 60)
    secs := Mod(seconds, 60)
    timerStr := mins . ":" . (secs < 10 ? "0" : "") . secs
    try {
        neutron.doc.getElementById("active-keys").innerText := timerStr
    }
    ; Calculate progress %
    if (recordedEvents.Length > 0) {
        totalDurationMs := (recordedEvents[-1].time - recordedEvents[1].time) / speedValue
        if (totalDurationMs > 0) {
            pct := Min(100, Round(elapsed / totalDurationMs * 100))
            try {
                neutron.doc.getElementById("last-action").innerText := pct . "%"
                neutron.doc.getElementById("progress-bar").style.width := pct . "%"
            }
        }
    }
    SetTimer(UpdatePlaybackTimer, -100)
}
PlayEventsAHK(looping := false) {
    SetCoordMode()
    static playbackStartTime := 0
    global timer := NowMs()
    playbackStartTime := A_TickCount
    global recordedEvents, isPlaying, shouldStopPlayback
    
    if (recordedEvents.Length = 0) {
        return
    }
    
    if (isPlaying) {
        return
    }
    
    
    isPlaying := true
    shouldStopPlayback := false
    UpdateRecordButtonState()
    UpdateGUI("Playback started")
    
    ; Reset session info displays
    global eventsCompleted := 0
    try {
        neutron.doc.getElementById("message-text").innerText := "0"
        neutron.doc.getElementById("active-keys").innerText := "0:00"
        neutron.doc.getElementById("last-action").innerText := "0%"
        neutron.doc.getElementById("progress-bar").style.width := "0%"
    }
        
    activePlaybackKeys := Map()
    
    Loop {
        ReleaseAllKeys()
        if (shouldStopPlayback) {
            break
        }
        
        ; Start/reset loop timer
        global playbackLoopStartMs := A_TickCount
        global playbackTimerActive := true
        SetTimer(UpdatePlaybackTimer, -100)
        
        lastEventTime := recordedEvents[1].time
        totalDuration := 0
        expectedTotalDuration := 0
        totalDeviation := 0

        for i, event in recordedEvents {
            if (shouldStopPlayback) {
                break
            }
            
            eventStart := NowMs(0)

            waitTime := event.time - lastEventTime
            waitTime := event.time - lastEventTime
            if (totalDeviation > 0) {
                nanotime_sleep(Integer((waitTime / speedValue - totalDeviation) * MILLISECOND))
            }
            
            switch event.type {
                case "move":
                    if activePlaybackKeys.Has("RButton") {
                        MouseGetPos(&prevX, &prevY)
                        dx := (event.x - prevX)
                        dy := (event.y - prevY)
                        DllCall("mouse_event", "UInt", 0x01, "UInt", dx, "UInt", dy, "UInt", 0, "UPtr", 0)
                    } else {
                        MouseMove(event.x, event.y, 0)
                    }
                case "mouseDown":
                    Send("{" event.button " down}")
                    activePlaybackKeys[event.button] := true
                    playbackKeysList := []
                    for key, _ in activePlaybackKeys {
                        playbackKeysList.Push(key)
                    }
                    UpdateGUI("Mouse down: " event.button, Join(playbackKeysList, "+"))
                case "mouseUp":
                    Send("{" event.button " up}")
                    if (activePlaybackKeys.Has(event.button))
                        activePlaybackKeys.Delete(event.button)
                    playbackKeysList := []
                    for key, _ in activePlaybackKeys {
                        playbackKeysList.Push(key)
                    }
                    activeKeysStr := playbackKeysList.Length > 0 ? Join(playbackKeysList, "+") : "None"
                    UpdateGUI("Mouse up: " event.button, activeKeysStr)
                case "mouseWheel":
                    if (event.direction = "Up") {
                        Send("{WheelUp}")
                    } else {
                        Send("{WheelDown}")
                    }
                    UpdateGUI("Mouse wheel: " (event.direction ? "Up" : "Down"))
                case "keyDown":
                    Send("{" event.key " down}")
                    activePlaybackKeys[event.key] := true
                    playbackKeysList := []
                    for key, _ in activePlaybackKeys {
                        playbackKeysList.Push(key)
                    }
                    UpdateGUI("Key down: " event.key, Join(playbackKeysList, "+"))
                case "keyUp":
                    Send("{" event.key " up}")
                    if (activePlaybackKeys.Has(event.key))
                        activePlaybackKeys.Delete(event.key)
                    playbackKeysList := []
                    for key, _ in activePlaybackKeys {
                        playbackKeysList.Push(key)
                    }
                    activeKeysStr := playbackKeysList.Length > 0 ? Join(playbackKeysList, "+") : "None"
                    UpdateGUI("Key up: " event.key, activeKeysStr)
            }

            eventEnd := NowMs(0)

            totalDuration += (eventEnd - eventStart)
            expectedTotalDuration += (event.time - lastEventTime) / speedValue
            totalDeviation := totalDuration - expectedTotalDuration

            lastEventTime := event.time
        }
        
        if (shouldStopPlayback) {
            break
        }

        global counter += 1
        global eventsCompleted += 1
        try {
            neutron.doc.getElementById("message-text").innerText := eventsCompleted
            neutron.doc.getElementById("active-keys").innerText := "0:00"
            neutron.doc.getElementById("last-action").innerText := "0%"
            neutron.doc.getElementById("progress-bar").style.width := "0%"
        }
        SendWebhookAHK("Finished")

        if !looping {
            break
        }
    }

    for key, _ in activePlaybackKeys {
        Send("{" key " up}")
    }
    
    playbackEndTime := A_TickCount
    playbackDuration := playbackEndTime - playbackStartTime
    
    global recordingDurationMs, speedValue
    if (recordedEvents.Length > 0) {
        recordedSequenceDuration := recordedEvents[-1].time - recordedEvents[1].time
    } else {
        recordedSequenceDuration := 0
    }
    
    expectedPlaybackDuration := recordedSequenceDuration / speedValue
    
    actualSpeed := recordedSequenceDuration / playbackDuration
    
    statsMsg := "Playback Statistics:`n`n"
    statsMsg .= "Recording Time: " . Round(recordingDurationMs/1000, 3) . " seconds`n"
    statsMsg .= "Recorded Sequence Duration: " . Round(recordedSequenceDuration/1000, 3) . " seconds`n"
    statsMsg .= "Playback Time: " . Round(playbackDuration/1000, 3) . " seconds`n"
    statsMsg .= "Speed Setting: " . speedValue . "x`n"
    statsMsg .= "Expected Playback Duration: " . Round(expectedPlaybackDuration/1000, 3) . " seconds`n"
    statsMsg .= "Actual Speed Achieved: " . Round(actualSpeed, 3) . "x"
    
    
    UpdateGUI("Playback completed - Duration: " . Round(playbackDuration/1000, 2) . "s", "None")
    isPlaying := false
    shouldStopPlayback := false
    global playbackTimerActive := false
    try {
        neutron.doc.getElementById("active-keys").innerText := "0:00"
        neutron.doc.getElementById("last-action").innerText := "0%"
        neutron.doc.getElementById("progress-bar").style.width := "0%"
    }
    UpdateRecordButtonState()
}

StopPlayback(Num) {
    global shouldStopPlayback, isPlaying, playbackTimerActive
    if (isPlaying) {
        shouldStopPlayback := true
        playbackTimerActive := false
        UpdateGUI("Stopping playback...")
        global isPlaying
        if (isPlaying) {
            isPlaying := false
            UpdateRecordButtonState()
            UpdateGUI("Playback stopped")
        }
    }
}

stopPlaybackButton(neutron, event) {
    StopPlayback(A_LineNumber)
}

global counter := 0

; 0 = dont round
; 1 = floor
; 2 = round
; 3 = ceil
NowMs(TypeRound := 1, N := 0) {
    now := (nanotime_now() / MILLISECOND)

    switch TypeRound {
        case 0:
            return now
        case 1:
            s := 10 ** N
            now := Floor(now * s) / s
            return N < 1 ? Integer(now) : now
        case 2:
            return Round(now, N)
        case 3:
            s := 10 ** N
            now := Ceil(now * s) / s
            return N < 1 ? Integer(now) : now
        default:
            return now
    }
}

ReleaseAllKeys() {
    keys := ["a","b","c","d","e","f","g","h","i","j","k","l","m",
            "n","o","p","q","r","s","t","u","v","w","x","y","z",
            "0","1","2","3","4","5","6","7","8","9",
            "Space","Enter","Tab","Backspace","Escape",
            "Up","Down","Left","Right",
            "Shift","Control","Alt",
            "LButton", "RButton", "MButton"]
            
    for key in keys {
        if GetKeyState(key, "P") {
            Send("{" key " up}")
        }
    }
}

UpdateHotkeysDisplay() {
    global CurrentBindings
    try {
        hotkeyInfo := neutron.doc.getElementById("hotkeys-info")
        
        recordKey := FormatHotkeyForDisplay(CurrentBindings["Record"])
        stopKey := FormatHotkeyForDisplay(CurrentBindings["Stop"])
        playKey := FormatHotkeyForDisplay(CurrentBindings["Play"])
        loopKey := FormatHotkeyForDisplay(CurrentBindings["Loop"])
        exitKey := FormatHotkeyForDisplay(CurrentBindings["Exit"])
        pauseKey := FormatHotkeyForDisplay(CurrentBindings["Pause"])
        autoKey := FormatHotkeyForDisplay(CurrentBindings["Autoclick"])
        drawKey := FormatHotkeyForDisplay(CurrentBindings["Drawmenu"])

        hotkeyInfo.innerHTML := '<span class="hotkey">' . recordKey . '</span> Record • ' .
                               '<span class="hotkey">' . playKey . '</span> Play Once • ' .
                               '<span class="hotkey">' . loopKey . '</span> Loop Playback • ' .
                               '<span class="hotkey">' . stopKey . '</span> Stop Playback • ' .
                               '<span class="hotkey">' . exitKey . '</span> Exit • ' .
                               '<span class="hotkey">' . pauseKey . '</span> Pause/Unpause • ' .
                               '<span class="hotkey">' . autoKey . '</span> AutoClick • ' .
                               '<span class="hotkey">' . drawKey . '</span> Draw Menu'
    } catch {

    }
}

FormatHotkeyForDisplay(hotkey) {
    display := (StrUpper(hotkey))

    display := StrReplace(display, "^", "CTRL_TEMP")
    display := StrReplace(display, "!", "ALT_TEMP")
    display := StrReplace(display, "+", "SHIFT_TEMP") 
    display := StrReplace(display, "#", "WIN_TEMP")
    
    display := StrReplace(display, "CTRL_TEMP", "Ctrl+")
    display := StrReplace(display, "ALT_TEMP", "Alt+")
    display := StrReplace(display, "SHIFT_TEMP", "Shift+")
    display := StrReplace(display, "WIN_TEMP", "Win+")
    
    return display
}

showSettings(neutron, event) {
    global showingSettings, windowHeightSettings, windowHeightFull, windowHeightMedium, windowHeightMinimal, windowHeightIconOnly
    global hideSessionInfo, startMinimalistic, startIconOnly
    showingSettings := !showingSettings
    
    settingsPanel := neutron.doc.getElementById("settings-panel")
    mainContent := neutron.doc.getElementById("main-content")
    
    if (showingSettings) {
        mainContent.style.display := "none"
        settingsPanel.style.display := "block"
        
        try {
            WinGetPos(&winX, &winY, &winW, &winH, "ahk_id " . neutron.hwnd)
            WinMove(winX, winY, 575, windowHeightSettings, "ahk_id " . neutron.hwnd)
        } catch as err {
            try {
                neutron.gui.Move(, , 575, windowHeightSettings)
            } catch {
            }
        }
        
        UpdateSettingsDisplay()
    } else {
        mainContent.style.display := "block"
        settingsPanel.style.display := "none"
        
        targetHeight := windowHeightFull 
        targetWidth := 380
        
        if (startIconOnly) {
            targetHeight := windowHeightIconOnly
            targetWidth := 280  ; Narrower width for icon-only mode
        } else if (startMinimalistic) {
            targetHeight := windowHeightMinimal  
        } else if (hideSessionInfo) {
            targetHeight := windowHeightMedium  
        }
        
        try {
            WinGetPos(&winX, &winY, &winW, &winH, "ahk_id " . neutron.hwnd)
            WinMove(winX, winY, targetWidth, targetHeight, "ahk_id " . neutron.hwnd)
        } catch as err {
            try {
                neutron.gui.Move(, , targetWidth, targetHeight)
            } catch {
            }
        }
        
        UpdateHotkeysDisplay()
    }
}

UpdateSettingsDisplay() {
    global CurrentBindings
    for bindingName, hotkeyValue in CurrentBindings {
        element := neutron.doc.getElementById("keybind-" . StrLower(bindingName))
        if (element) {
            element.value := hotkeyValue
        }
    }
    UpdateGeneralSettingsDisplay()
}


updateKeybind(neutron, event) {
    global CurrentBindings
    elementId := event.target.id
    action := StrReplace(elementId, "keybind-", "")
    
    action := StrUpper(SubStr(action, 1, 1)) . SubStr(action, 2)
    
    newHotkey := Trim(event.target.value)
    
    if (!CurrentBindings.Has(action)) {
        neutron.doc.getElementById("settings-message").innerText := "Invalid action: " . action
        return
    }
    
    if (newHotkey = "") {
        neutron.doc.getElementById("settings-message").innerText := "Hotkey cannot be empty"
        return
    }
    
    oldHotkey := CurrentBindings[action]

    for existingAction, existingHotkey in CurrentBindings {
        if (existingAction != action && existingHotkey = newHotkey) {
            neutron.doc.getElementById("settings-message").innerText := "Hotkey already in use by: " . existingAction
            return
        }
    }
    
    try {
        Hotkey(newHotkey, (*) => "", "On")
        Hotkey(newHotkey, "Off")
    } catch as err {
        neutron.doc.getElementById("settings-message").innerText := "Invalid hotkey format: " . newHotkey . " (" . err.message . ")"
        return
    }
    
    try {
        if (oldHotkey != "") {
            Hotkey(oldHotkey, "Off")
        }
    } catch as err {
    }
    
    CurrentBindings[action] := newHotkey
    
    Sleep(50)
    
    try {
        actionFunc := ""
        switch action {
            case "Record":
                actionFunc := (*) => TriggerNeutronRecording()
            case "Play":
                actionFunc := (*) => PlayOnce()
            case "Loop":
                actionFunc := (*) => PlayLoop()
            case "Stop":
                actionFunc := (*) => StopPlayback(A_LineNumber)
            case "Autoclick":
                actionFunc := (*) => AutoClick()
            case "Drawmenu":
                actionFunc := (*) => ShowDrawmenu()
            case "Exit":
                actionFunc := (*) => ExitAppF()
            case "Pause":
                actionFunc := (*) => PauseFunc()
            default:
                throw Error("Unknown action: " . action)
        }
        
        Hotkey(newHotkey, actionFunc, "On")
        
        neutron.doc.getElementById("settings-message").innerText := "Keybind updated: " . action . " = " . newHotkey
        
    } catch as err {
        neutron.doc.getElementById("settings-message").innerText := "Error registering " . action . ": " . err.message
        
        try {
            CurrentBindings[action] := oldHotkey
            if (oldHotkey != "") {
                oldActionFunc := ""
                switch action {
                    case "Record":
                        oldActionFunc := (*) => TriggerNeutronRecording()
                    case "Play":
                        oldActionFunc := (*) => PlayOnce()
                    case "Loop":
                        oldActionFunc := (*) => PlayLoop()
                    case "Stop":
                        oldActionFunc := (*) => StopPlayback(A_LineNumber)
                    case "Autoclick":
                        oldActionFunc := (*) => AutoClick()
                    case "Exit":
                        oldActionFunc := (*) => ExitAppF()
                    case "Pause":
                        oldActionFunc := (*) => PauseFunc()
                }
                Hotkey(oldHotkey, oldActionFunc, "On")
            }
        } catch as restoreErr {
        }
        return
    }
    
    SaveKeybinds()
    
    UpdateHotkeysDisplay()
    
}

saveKeybindsToFile(neutron, event) {
    SaveKeybinds()
    neutron.doc.getElementById("settings-message").innerText := "Keybinds saved successfully!"
    SetTimer(() => neutron.doc.getElementById("settings-message").innerText := "", -1500)
}

resetKeybinds(neutron, event) {
    UnregisterHotkeys()
    InitializeKeybinds()
    UpdateKeyBindings()
    SaveKeybinds()
    UpdateSettingsDisplay()
    UpdateHotkeysDisplay()
    neutron.doc.getElementById("settings-message").innerText := "Keybinds reset to defaults"
}

toggleSessionInfo(neutron, event) {
    global hideSessionInfo
    isChecked := event.target.checked
    hideSessionInfo := isChecked

    try {
        infoPanel := neutron.doc.querySelector(".info-panel")
        if (infoPanel) {
            if (isChecked) {
                infoPanel.style.display := "none"
            } else {
                infoPanel.style.display := "block"
            }
        } else {
            allElements := neutron.doc.getElementsByTagName("*")
            Loop allElements.length {
                element := allElements[A_Index - 1]
                if (element.className && InStr(element.className, "info-panel")) {
                    if (isChecked) {
                        element.style.display := "none"
                    } else {
                        element.style.display := "block"
                    }
                    break
                }
            }
        }
    } catch as err {
        try {
            infoPanels := neutron.doc.getElementsByClassName("info-panel")
            if (infoPanels.length > 0) {
                infoPanel := infoPanels[0]
                if (isChecked) {
                    infoPanel.style.display := "none"
                } else {
                    infoPanel.style.display := "block"
                }
            }
        } catch {
            allDivs := neutron.doc.getElementsByTagName("div")
            Loop allDivs.length {
                div := allDivs[A_Index - 1]
                try {
                    if (div.className && InStr(div.className, "info-panel")) {
                        if (isChecked) {
                            div.style.display := "none"
                        } else {
                            div.style.display := "block"
                        }
                        break
                    }
                } catch {
                    continue
                }
            }
        }
    }
    
    global showingSettings
    if (!showingSettings) {
        global startIconOnly, windowHeightIconOnly
        newHeight := windowHeightFull
        newWidth := 380
        
        if (startIconOnly) {
            newHeight := windowHeightIconOnly
            newWidth := 280
        } else if (isChecked) {
            newHeight := windowHeightMedium
        }
        
        try {
            WinGetPos(&winX, &winY, &winW, &winH, "ahk_id " . neutron.hwnd)
            WinMove(winX, winY, newWidth, newHeight, "ahk_id " . neutron.hwnd)
        } catch as err {
            try {
                neutron.gui.Move(, , newWidth, newHeight)
            } catch {
            }
        }
    }
    SaveGeneralSettings()
    neutron.doc.getElementById("settings-message").innerText := "Session info panel " . (isChecked ? "hidden" : "shown")
}

toggleStartMinimalistic(neutron, event) {
    global startMinimalistic, startIconOnly
    isChecked := event.target.checked
    startMinimalistic := isChecked
    
    ; If this is checked, uncheck icon-only mode
    if (isChecked) {
        startIconOnly := false
        iconOnlyElement := neutron.doc.getElementById("start-icon-only")
        if (iconOnlyElement) {
            iconOnlyElement.checked := false
        }
    }
    
    SaveGeneralSettings()
    SetWindowControlsVisibility()
    neutron.doc.getElementById("settings-message").innerText := "Minimalistic startup mode " . (isChecked ? "enabled" : "disabled")
}

toggleStartIconOnly(neutron, event) {
    global startIconOnly, startMinimalistic
    isChecked := event.target.checked
    startIconOnly := isChecked
    
    ; If this is checked, uncheck minimalistic mode
    if (isChecked) {
        startMinimalistic := false
        minimalisticElement := neutron.doc.getElementById("start-minimalistic")
        if (minimalisticElement) {
            minimalisticElement.checked := false
        }
    }
    
    SaveGeneralSettings()
    SetWindowControlsVisibility()
    neutron.doc.getElementById("settings-message").innerText := "Icon-only startup mode " . (isChecked ? "enabled" : "disabled")
}

toggleScreenshotMode(neutron, event) {
    isChecked := event.target.checked
    neutron.doc.getElementById("settings-message").innerText := "Screenshot mode: " . (isChecked ? "Full Screen" : "Active Window")
}

InitializeUIState() {
    global hideSessionInfo, startMinimalistic, startIconOnly
    
    if (hideSessionInfo) {
        try {
            infoPanel := neutron.doc.querySelector(".info-panel")
            if (infoPanel) {
                infoPanel.style.display := "none"
            } else {
                allElements := neutron.doc.getElementsByTagName("*")
                Loop allElements.length {
                    element := allElements[A_Index - 1]
                    if (element.className && InStr(element.className, "info-panel")) {
                        element.style.display := "none"
                        break
                    }
                }
            }
        } catch as err {
            try {
                infoPanels := neutron.doc.getElementsByClassName("info-panel")
                if (infoPanels.length > 0) {
                    infoPanel := infoPanels[0]
                    infoPanel.style.display := "none"
                }
            } catch {
                allDivs := neutron.doc.getElementsByTagName("div")
                Loop allDivs.length {
                    div := allDivs[A_Index - 1]
                    try {
                        if (div.className && InStr(div.className, "info-panel")) {
                            div.style.display := "none"
                            break
                        }
                    } catch {
                        continue
                    }
                }
            }
        }
    }
    
    targetHeight := windowHeightFull
    targetWidth := 350
    
    if (hideSessionInfo) {
        targetHeight := windowHeightMedium  
    }
    
    try {
        WinGetPos(&winX, &winY, &winW, &winH, "ahk_id " . neutron.hwnd)
        WinMove(winX, winY, targetWidth, targetHeight, "ahk_id " . neutron.hwnd)
    } catch as err {
        try {
            neutron.gui.Move(, , targetWidth, targetHeight)
        } catch {
        }
    }
    
    ; Set window controls visibility based on mode
    ; SetTimer(() => SetWindowControlsVisibility(), -200)
}

SetWindowControlsVisibility() {
    global startIconOnly
    
    ; Hide window controls for icon-only mode
    if (startIconOnly) {
        try {
            ; Get current window style
            currentStyle := DllCall("GetWindowLong", "ptr", neutron.hwnd, "int", -16, "int")
            
            ; Remove minimize, maximize, and close buttons
            ; WS_MINIMIZEBOX = 0x20000, WS_MAXIMIZEBOX = 0x10000, WS_SYSMENU = 0x80000
            newStyle := currentStyle & ~(0x20000 | 0x10000 | 0x80000)
            
            ; Apply new style
            DllCall("SetWindowLong", "ptr", neutron.hwnd, "int", -16, "int", newStyle)
            
            ; Force window to redraw with new style
            DllCall("SetWindowPos", "ptr", neutron.hwnd, "ptr", 0, "int", 0, "int", 0, "int", 0, "int", 0, "uint", 0x27)
        } catch as err {
            ; Silently handle any errors
        }
    } else {
        try {
            ; Restore window controls for other modes
            currentStyle := DllCall("GetWindowLong", "ptr", neutron.hwnd, "int", -16, "int")
            newStyle := currentStyle | 0x20000 | 0x10000 | 0x80000
            DllCall("SetWindowLong", "ptr", neutron.hwnd, "int", -16, "int", newStyle)
            DllCall("SetWindowPos", "ptr", neutron.hwnd, "ptr", 0, "int", 0, "int", 0, "int", 0, "uint", 0x27)
        } catch as err {
            ; Silently handle any errors
        }
    }
}

ReadInWebhookSettings() {
    settingsFile := A_ScriptDir "\..\..\Settings.txt"

    if !FileExist(settingsFile) {
        return
    }

    content := FileRead(settingsFile)
    sections := StrSplit(content, "`n`n")

    for section in sections {
        lines := StrSplit(section, "`n", "`r")

        for line in lines {
            line := Trim(line)
            if line = "" || InStr(line, ";") || !InStr(line, "=")
                continue

            keyValue := StrSplit(line, "=")
            key := keyValue[1]
            value := keyValue[2]

            if (value != "") {
                if(key = "Webhook") {
                    global webhookValue := value
                } else if(key = "Speed") {
                    if (IsNumber(value) && Float(value) > 0) {
                        global speedValue := Float(value)
                    }
                } else if(key = "ClickDelay") {
                    if (IsNumber(value) && Float(value) > 0) {
                        global clickDelay := Float(value)
                    }
                } else if(key = "HideSessionInfo") {
                    global hideSessionInfo := (value = "true" || value = "1")
                } else if(key = "StartMinimalistic") {
                    ; Disabled - always start in full mode
                } else if(key = "StartIconOnly") {
                    ; Disabled - always start in full mode
                } else if(key = "GuiUpdateThrottle") {
                    if (IsNumber(value) && Integer(value) > 0) {
                        global guiUpdateThrottle := Integer(value)
                    }
                }
            }
        }
    }
}

clicking := false
AutoClick(*) {
    global clicking
    
    if (clicking) {
        clicking := false
        SetTimer(Click, 0)
        ToolTip("Auto Clicker OFF")
        SetTimer(() => ToolTip(), -1000)
    } else {
        clicking := true
        ToolTip("Auto Clicker ON")
        SetTimer(() => ToolTip(), -1000)
        
        SetTimer(Click, clickDelay)
    }
}


global screenshotPath := A_ScriptDir "\..\Temp\gameScreenshot.png"
SendWebhookAHK(Message) {
    Try {
        global counter
        global elapsed := A_TickCount-timer
        WinGetClientPos(&X, &Y, &W, &H, "A")
        ImagePutFile([X, Y, W, H], screenshotPath)

        escapedMessage := JsonEscape(Message)

        jsonPayload := "{"
        jsonPayload .= '"content": "Zoan-Task Playback #' counter '",'
        jsonPayload .= '"embeds": [{'
        jsonPayload .= '"author": {"name": "Zoan-Task Notification", "icon_url": "https://cdn.discordapp.com/attachments/1287259699552456738/1482584766912921680/a6160cba4012e6d7a8fcf9f1b3828731.png"},'
        jsonPayload .= '"title": "[Playthrough Complete!]",'
        jsonPayload .= '"color": 12917790,'
        jsonPayload .= '"fields": ['
        jsonPayload .= '{"name": "Clear Time", "value": "' Round((elapsed)/1000) 's", "inline": true}'
        jsonPayload .= '],'
        jsonPayload .= '"footer": {"text": "Zoan-Task | discord.gg/zoan", "icon_url": "https://cdn.discordapp.com/attachments/1287259699552456738/1482584766912921680/a6160cba4012e6d7a8fcf9f1b3828731.png"}'
        jsonPayload .= "}]"
        jsonPayload .= "}"
        
        ;jsonPayload .= '"footer": {"text": "Zoan-Task | discord.gg/zoan | https://informaal.com", "icon_url": "https://cdn.discordapp.com/attachments/1058152472536940659/1283843219804782633/lgow.png"}'


        objParam := {
            payload_json: jsonPayload,
            file0: [screenshotPath]
        }
        
        CreateFormData(&PostData, &hdr_ContentType, objParam)
        
        whr := ComObject("WinHttp.WinHttpRequest.5.1")
        whr.Open("POST",webhookValue, true)
        whr.SetRequestHeader("Content-Type", hdr_ContentType)
        whr.Send(PostData)
        whr.WaitForResponse()
        
        status := whr.Status
        if (status != 200) {
            errorMsg := whr.ResponseText
            AppendToLog("Error sending webhook: " errorMsg)
        }
    } catch as e {
        AppendToLog("Failed To Send Webhook")
    }
}

JsonEscape(str) {
    str := StrReplace(str, "\", "\\")
    str := StrReplace(str, '"', '\"')
    str := StrReplace(str, "`n", "\n")
    str := StrReplace(str, "`r", "\r")
    str := StrReplace(str, "`t", "\t")
    return str
}

LogFileInit() {
    Header := "`n`n-=X=- Informaal Task Log -=X=-`n`n"
    filePath := A_ScriptDir "\..\..\Logs\logFile.txt"
}

AppendToLog(text) {
    filePath := A_ScriptDir "\..\..\Logs\logFile.txt"
}

Class CreateFormData {
    __New(&retData, &retHeader, objParam) {
        Local CRLF := "`r`n", i, k, v, str, pvData
        ; Create a random Boundary
        Local Boundary := CreateFormData.RandomBoundary()
        Local BoundaryLine := "------------------------------" . Boundary
        ; Create an IStream backed with movable memory.
        hData := DllCall("GlobalAlloc", "uint", 0x2, "uptr", 0, "ptr")
        DllCall("ole32\CreateStreamOnHGlobal", "ptr", hData, "int", False, "ptr*", &pStream:=0, "uint")
        CreateFormData.pStream := pStream
        ; Loop input paramters
        For k, v in objParam.OwnProps()
        {
            If IsObject(v) {
                For i, FileName in v
                {
                    str := BoundaryLine . CRLF
                        . 'Content-Disposition: form-data; name="' . k . '"; filename="' . FileName . '"' . CRLF
                        . 'Content-Type: ' . CreateFormData.MimeType(FileName) . CRLF . CRLF
                    CreateFormData.StrPutUTF8( str )
                    CreateFormData.LoadFromFile( Filename )
                    CreateFormData.StrPutUTF8( CRLF )
                }
            } Else {
                str := BoundaryLine . CRLF
                    . 'Content-Disposition: form-data; name="' . k '"' . CRLF . CRLF
                    . v . CRLF
                CreateFormData.StrPutUTF8( str )
            }
        }
        CreateFormData.StrPutUTF8( BoundaryLine . "--" . CRLF )
        CreateFormData.pStream := ObjRelease(pStream) ; Should be 0.
        pData := DllCall("GlobalLock", "ptr", hData, "ptr")
        size := DllCall("GlobalSize", "ptr", pData, "uptr")
        ; Create a bytearray and copy data in to it.
        retData := ComObjArray( 0x11, size ) ; Create SAFEARRAY = VT_ARRAY|VT_UI1
        pvData  := NumGet( ComObjValue( retData ), 8 + A_PtrSize , "ptr" )
        DllCall( "RtlMoveMemory", "Ptr", pvData, "Ptr", pData, "Ptr", size )
        DllCall("GlobalUnlock", "ptr", hData)
        DllCall("GlobalFree", "Ptr", hData, "Ptr")                   ; free global memory
        retHeader := "multipart/form-data; boundary=----------------------------" . Boundary
    }
    static StrPutUTF8( str ) {
        buf := Buffer(StrPut(str, "UTF-8") - 1) ; remove null terminator
        StrPut(str, buf, buf.size, "UTF-8")
        DllCall("shlwapi\IStream_Write", "ptr", CreateFormData.pStream, "ptr", buf.Ptr, "uint", buf.Size, "uint")
    }
    static LoadFromFile( filepath ) {
        DllCall("shlwapi\SHCreateStreamOnFileEx"
                    ,   "wstr", filepath
                    ,   "uint", 0x0             ; STGM_READ
                    ,   "uint", 0x80            ; FILE_ATTRIBUTE_NORMAL
                    ,    "int", False            ; fCreate is ignored when STGM_CREATE is set.
                    ,    "ptr", 0               ; pstmTemplate (reserved)
                    ,   "ptr*", &pFileStream:=0
                    ,   "uint")
        DllCall("shlwapi\IStream_Size", "ptr", pFileStream, "uint64*", &size:=0, "uint")
        DllCall("shlwapi\IStream_Copy", "ptr", pFileStream , "ptr", CreateFormData.pStream, "uint", size, "uint")
        ObjRelease(pFileStream)
    }
    static RandomBoundary() {
        str := "0|1|2|3|4|5|6|7|8|9|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z"
        Sort str, 'D| Random'
        str := StrReplace(str, "|")
        Return SubStr(str, 1, 12)
    }
    static MimeType(FileName) {
        n := FileOpen(FileName, "r").ReadUInt()
        Return (n        = 0x474E5089) ? "image/png"
            :  (n        = 0x38464947) ? "image/gif"
            :  (n&0xFFFF = 0x4D42    ) ? "image/bmp"
            :  (n&0xFFFF = 0xD8FF    ) ? "image/jpeg"
            :  (n&0xFFFF = 0x4949    ) ? "image/tiff"
            :  (n&0xFFFF = 0x4D4D    ) ? "image/tiff"
            :  "application/octet-stream"
    }
}

class ImageEqual extends ImagePut {

   static call(images*) {
      ; Returns false is there are no images to be compared.
      if (images.length == 0)
         return False

      this.gdiplusStartup()

      ; Set the first image to its own variable to allow passing by reference.
      image := images[1]

      ; Allow the ImageType exception to bubble up.
      try type := this.DontVerifyImageType(&image)
      catch
         type := this.ImageType(image)

      ; Convert only the first image to a bitmap.
      if !(pBitmap1 := this.ImageToBitmap(type, image))
         throw Error("Conversion to bitmap failed. The pointer value is zero.")

      ; If there is only one image, verify that image and return.
      if (images.length == 1) {
         if DllCall("gdiplus\GdipCloneImage", "ptr", pBitmap1, "ptr*", &pBitmapClone:=0)
            throw Error("Validation failed. Unable to access and clone the bitmap.")

         DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmapClone)
         goto Good_Ending
      }

      ; If there are multiple images, compare each subsequent image to the first.
      for image in images {
         if (A_Index != 1) {

            ; Guess the type of the image.
            try type := this.DontVerifyImageType(&image)
            catch
               type := this.ImageType(image)

            ; Convert the other image to a bitmap.
            pBitmap2 := this.ImageToBitmap(type, image)

            ; Compare the two images.
            if !this.BitmapEqual(pBitmap1, pBitmap2)
               goto Bad_Ending ; Exit the loop if the comparison failed.

            ; Cleanup the bitmap.
            DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap2)
         }
      }

      Good_Ending: ; After getting isekai'ed you somehow build a prosperous kingdom and rule the land.
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap1)
      this.gdiplusShutdown()
      return True

      Bad_Ending: ; Things didn't turn out the way you expected yet everyone seems to be fine despite that.
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap2)
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap1)
      this.gdiplusShutdown()
      return False
   }

   static BitmapEqual(SourceBitmap1, SourceBitmap2, PixelFormat := 0x26200A) {
      ; Make sure both source bitmaps are valid GDI+ pointers. This will throw if not...
      DllCall("gdiplus\GdipGetImageType", "ptr", SourceBitmap1, "ptr*", &type1:=0)
      DllCall("gdiplus\GdipGetImageType", "ptr", SourceBitmap2, "ptr*", &type2:=0)

      ; ImageTypeUnknown = 0, ImageTypeBitmap = 1, and ImageTypeMetafile = 2.
      if (type1 != 1 || type2 != 1)
         throw Error("The GDI+ pointer is not a bitmap.")

      ; Check if source bitmap pointers are identical.
      if (SourceBitmap1 == SourceBitmap2)
         return True

      ; The two bitmaps must be the same size but can have different pixel formats.
      DllCall("gdiplus\GdipGetImageWidth", "ptr", SourceBitmap1, "uint*", &width1:=0)
      DllCall("gdiplus\GdipGetImageWidth", "ptr", SourceBitmap2, "uint*", &width2:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", SourceBitmap1, "uint*", &height1:=0)
      DllCall("gdiplus\GdipGetImageHeight", "ptr", SourceBitmap2, "uint*", &height2:=0)
      DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", SourceBitmap1, "int*", &format1:=0)
      DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", SourceBitmap2, "int*", &format2:=0)

      ; If the dimensions are zero, then get width and height failed.
      if !(width1 && width2 && height1 && height2)
         throw Error("Get bitmap width and height failed.")

      ; Dimensions must be equal.
      if (width1 != width2 || height1 != height2)
         return False

      ; Create clones of the supplied source bitmaps in their original PixelFormat.
      ; This has the side effect of solving the problem when both bitmaps reference
      ; the same stream and only one of them is able to retrieve the pixel data through LockBits.
      ; This occurs when both streams are fighting over the same seek position.

      pBitmap1 := pBitmap2 := 0
      loop 2
         if DllCall("gdiplus\GdipCloneImage", "ptr", SourceBitmap%A_Index%, "ptr*", &pBitmap%A_Index%)
            throw Error("Cloning Bitmap" A_Index " failed.")

      DllCall("gdiplus\GdipGetImagePixelFormat", "ptr", pBitmap1, "int*", &format3:=0)
      if (format1 != format3)
         throw Error("Report this error to the developer.")

      width := width1, height := height1

      ; Describes the portion of the bitmap to be cropped. Matches the dimensions of the buffer.
      rect := Buffer(16, 0)                  ; sizeof(rect) = 16
         NumPut(  "uint",   width, rect,  8) ; Width
         NumPut(  "uint",  height, rect, 12) ; Height

      ; Create a BitmapData structure.
      BitmapData1 := Buffer(16+2*A_PtrSize)       ; sizeof(BitmapData) = 24, 32
      BitmapData2 := Buffer(16+2*A_PtrSize)       ; sizeof(BitmapData) = 24, 32

      ; Force conversion into a pixel buffer. The user can declare a PixelFormat.
      loop 2
         DllCall("gdiplus\GdipBitmapLockBits"
                  ,    "ptr", pBitmap%A_Index%
                  ,    "ptr", rect
                  ,   "uint", 1            ; ImageLockMode.ReadOnly
                  ,    "int", PixelFormat  ; Defaults to Format32bppArgb for comparison.
                  ,    "ptr", BitmapData%A_Index%)

      ; Get Stride (number of bytes per horizontal line).
      stride1 := NumGet(BitmapData1, 8, "int")
      stride2 := NumGet(BitmapData2, 8, "int")

      ; Get Scan0 (top-left pixel at 0,0).
      Scan01 := NumGet(BitmapData1, 16, "ptr")
      Scan02 := NumGet(BitmapData2, 16, "ptr")

      ; RtlCompareMemory preforms an unsafe comparison stopping at the first different byte.
      size := stride1 * height1
      byte := DllCall("ntdll\RtlCompareMemory", "ptr", Scan01, "ptr", Scan02, "uptr", size, "uptr")

      ; Unlock Bitmaps. Since they were marked as read only there is no copy back.
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap1, "ptr", BitmapData1)
      DllCall("gdiplus\GdipBitmapUnlockBits", "ptr", pBitmap2, "ptr", BitmapData2)

      ; Cleanup bitmap clones.
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap1)
      DllCall("gdiplus\GdipDisposeImage", "ptr", pBitmap2)

      ; Compare stopped byte.
      return (byte == size) ? True : False
   }
} ; End of ImageEqual class.

OnError(ErrorHandler)

ErrorHandler(exception, mode) {
    msg := "Error: " . exception.Message . "`n"
        . "What: " . exception.What . "`n"
        . "Line: " . exception.Line . "`n"
        . "- " exception.Stack

   MsgBox(msg, "Error")

    return true
}